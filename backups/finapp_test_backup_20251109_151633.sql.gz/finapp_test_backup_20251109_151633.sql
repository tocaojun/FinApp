--
-- PostgreSQL database dump
--

\restrict 7NJDb3L5mgWV2nRia68Ssj4egjxpcQ5uuvAamrdW2UxnFWBkxE7179vgFQYaTLJ

-- Dumped from database version 13.22
-- Dumped by pg_dump version 13.22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: audit; Type: SCHEMA; Schema: -; Owner: finapp_user
--

CREATE SCHEMA audit;


ALTER SCHEMA audit OWNER TO finapp_user;

--
-- Name: finapp; Type: SCHEMA; Schema: -; Owner: finapp_user
--

CREATE SCHEMA finapp;


ALTER SCHEMA finapp OWNER TO finapp_user;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: caojun
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO caojun;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE finapp._prisma_migrations OWNER TO finapp_user;

--
-- Name: asset_prices; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.asset_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    price_date date NOT NULL,
    open_price numeric(20,8),
    high_price numeric(20,8),
    low_price numeric(20,8),
    close_price numeric(20,8) NOT NULL,
    volume bigint,
    adjusted_close numeric(20,8),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.asset_prices OWNER TO finapp_user;

--
-- Name: asset_types; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.asset_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    location_dimension character varying(20) DEFAULT 'market'::character varying
);


ALTER TABLE finapp.asset_types OWNER TO finapp_user;

--
-- Name: COLUMN asset_types.location_dimension; Type: COMMENT; Schema: finapp; Owner: finapp_user
--

COMMENT ON COLUMN finapp.asset_types.location_dimension IS 'Location dimension for asset type: market (交易市场), country (国家), or global (全球)';


--
-- Name: assets; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.assets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    symbol character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    asset_type_id uuid NOT NULL,
    currency character varying(3) NOT NULL,
    isin character varying(12),
    cusip character varying(9),
    sector character varying(100),
    industry character varying(100),
    description text,
    metadata jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    risk_level character varying(20) DEFAULT 'MEDIUM'::character varying,
    lot_size integer DEFAULT 1,
    tick_size numeric(10,6) DEFAULT 0.01,
    listing_date date,
    delisting_date date,
    tags text[],
    created_by uuid,
    updated_by uuid,
    liquidity_tag uuid,
    country_id uuid
);


ALTER TABLE finapp.assets OWNER TO finapp_user;

--
-- Name: audit_logs; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    table_name character varying(100) NOT NULL,
    record_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.audit_logs OWNER TO finapp_user;

--
-- Name: benchmark_prices; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.benchmark_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    benchmark_id uuid NOT NULL,
    price_date date NOT NULL,
    price numeric(20,8) NOT NULL,
    currency character varying(3) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.benchmark_prices OWNER TO finapp_user;

--
-- Name: benchmarks; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.benchmarks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(20) NOT NULL,
    description text,
    asset_class character varying(50),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.benchmarks OWNER TO finapp_user;

--
-- Name: bond_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.bond_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    bond_type character varying(50) NOT NULL,
    credit_rating character varying(10),
    face_value numeric(20,2) NOT NULL,
    coupon_rate numeric(5,2) NOT NULL,
    coupon_frequency character varying(20),
    issue_date date NOT NULL,
    maturity_date date NOT NULL,
    years_to_maturity numeric(5,2),
    yield_to_maturity numeric(5,2),
    current_yield numeric(5,2),
    issuer character varying(200),
    issue_price numeric(20,2),
    issue_size numeric(20,2),
    callable boolean DEFAULT false,
    call_date date,
    call_price numeric(20,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.bond_details OWNER TO finapp_user;

--
-- Name: cash_flows; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.cash_flows (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid,
    asset_id uuid,
    flow_type character varying(20) NOT NULL,
    amount numeric(20,8) NOT NULL,
    currency character varying(3) NOT NULL,
    flow_date date NOT NULL,
    description text,
    transaction_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    date timestamp(6) with time zone,
    category character varying(50)
);


ALTER TABLE finapp.cash_flows OWNER TO finapp_user;

--
-- Name: countries; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.countries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(3) NOT NULL,
    name character varying(100) NOT NULL,
    currency character varying(3),
    timezone character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.countries OWNER TO finapp_user;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.email_verification_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    verified_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.email_verification_tokens OWNER TO finapp_user;

--
-- Name: exchange_rates; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.exchange_rates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_currency character varying(3) NOT NULL,
    to_currency character varying(3) NOT NULL,
    rate_date date NOT NULL,
    rate numeric(20,8) NOT NULL,
    data_source character varying(50),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.exchange_rates OWNER TO finapp_user;

--
-- Name: fund_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.fund_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    fund_type character varying(50) NOT NULL,
    fund_category character varying(50),
    management_fee numeric(5,2),
    custodian_fee numeric(5,2),
    subscription_fee numeric(5,2),
    redemption_fee numeric(5,2),
    nav numeric(20,4),
    nav_date date,
    accumulated_nav numeric(20,4),
    fund_size numeric(20,2),
    inception_date date,
    fund_manager character varying(200),
    fund_company character varying(200),
    min_investment numeric(20,2),
    min_redemption numeric(20,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.fund_details OWNER TO finapp_user;

--
-- Name: futures_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.futures_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    futures_type character varying(50) NOT NULL,
    underlying_asset character varying(200),
    contract_month character varying(10) NOT NULL,
    contract_size numeric(20,4),
    tick_size numeric(20,8),
    tick_value numeric(20,2),
    trading_hours character varying(100),
    last_trading_date date,
    delivery_date date,
    delivery_method character varying(50),
    initial_margin numeric(20,2),
    maintenance_margin numeric(20,2),
    margin_rate numeric(5,2),
    position_limit integer,
    daily_price_limit numeric(5,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.futures_details OWNER TO finapp_user;

--
-- Name: liquidity_tags; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.liquidity_tags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color character varying(7),
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.liquidity_tags OWNER TO finapp_user;

--
-- Name: markets; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.markets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(3) NOT NULL,
    currency character varying(3) NOT NULL,
    timezone character varying(50) NOT NULL,
    trading_hours jsonb,
    holidays jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.markets OWNER TO finapp_user;

--
-- Name: option_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.option_details (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    underlying_asset_id uuid,
    option_type character varying(10) NOT NULL,
    strike_price numeric(20,8) NOT NULL,
    expiration_date date NOT NULL,
    contract_size integer DEFAULT 100,
    exercise_style character varying(20) DEFAULT 'american'::character varying,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.option_details OWNER TO finapp_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.password_reset_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    used_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.password_reset_tokens OWNER TO finapp_user;

--
-- Name: performance_metrics; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.performance_metrics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    metric_type character varying(50) NOT NULL,
    period_type character varying(20) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    value numeric(20,8) NOT NULL,
    currency character varying(3),
    metadata jsonb,
    calculated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.performance_metrics OWNER TO finapp_user;

--
-- Name: permissions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.permissions OWNER TO finapp_user;

--
-- Name: portfolio_snapshots; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.portfolio_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    total_value numeric(20,8) NOT NULL,
    cash_value numeric(20,8) DEFAULT 0 NOT NULL,
    invested_value numeric(20,8) DEFAULT 0 NOT NULL,
    unrealized_gain_loss numeric(20,8) DEFAULT 0 NOT NULL,
    realized_gain_loss numeric(20,8) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.portfolio_snapshots OWNER TO finapp_user;

--
-- Name: portfolio_tags; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.portfolio_tags (
    id integer NOT NULL,
    portfolio_id uuid NOT NULL,
    tag_id integer NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.portfolio_tags OWNER TO finapp_user;

--
-- Name: portfolio_tags_id_seq; Type: SEQUENCE; Schema: finapp; Owner: finapp_user
--

CREATE SEQUENCE finapp.portfolio_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE finapp.portfolio_tags_id_seq OWNER TO finapp_user;

--
-- Name: portfolio_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: finapp; Owner: finapp_user
--

ALTER SEQUENCE finapp.portfolio_tags_id_seq OWNED BY finapp.portfolio_tags.id;


--
-- Name: portfolios; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.portfolios (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    base_currency character varying(3) DEFAULT 'CNY'::character varying NOT NULL,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    sort_order integer DEFAULT 0
);


ALTER TABLE finapp.portfolios OWNER TO finapp_user;

--
-- Name: position_snapshots; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.position_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    position_id uuid NOT NULL,
    portfolio_snapshot_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    quantity numeric(20,8) NOT NULL,
    market_price numeric(20,8),
    market_value numeric(20,8),
    average_cost numeric(20,8) NOT NULL,
    total_cost numeric(20,8) NOT NULL,
    unrealized_gain_loss numeric(20,8),
    currency character varying(3) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.position_snapshots OWNER TO finapp_user;

--
-- Name: positions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.positions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    quantity numeric(20,8) DEFAULT 0 NOT NULL,
    average_cost numeric(20,8) DEFAULT 0 NOT NULL,
    total_cost numeric(20,8) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    first_purchase_date date,
    last_transaction_date date,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.positions OWNER TO finapp_user;

--
-- Name: price_data_sources; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_data_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    provider character varying(50) NOT NULL,
    api_endpoint character varying(500),
    api_key_encrypted text,
    config jsonb DEFAULT '{}'::jsonb,
    rate_limit integer DEFAULT 60,
    timeout_seconds integer DEFAULT 30,
    is_active boolean DEFAULT true,
    last_sync_at timestamp(6) without time zone,
    last_sync_status character varying(20),
    last_error_message text,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE finapp.price_data_sources OWNER TO finapp_user;

--
-- Name: price_sync_errors; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_errors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    log_id uuid NOT NULL,
    asset_id uuid,
    asset_symbol character varying(50),
    error_type character varying(50),
    error_message text NOT NULL,
    error_details jsonb,
    occurred_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.price_sync_errors OWNER TO finapp_user;

--
-- Name: price_sync_logs; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id uuid,
    data_source_id uuid,
    started_at timestamp(6) without time zone DEFAULT timezone('Asia/Shanghai'::text, CURRENT_TIMESTAMP) NOT NULL,
    completed_at timestamp(6) without time zone,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    total_assets integer DEFAULT 0,
    total_records integer DEFAULT 0,
    success_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    skipped_count integer DEFAULT 0,
    result_summary jsonb,
    error_message text
);


ALTER TABLE finapp.price_sync_logs OWNER TO finapp_user;

--
-- Name: price_sync_logs_backup; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_logs_backup (
    id uuid,
    task_id uuid,
    data_source_id uuid,
    started_at timestamp(6) without time zone,
    completed_at timestamp(6) without time zone,
    status character varying(20),
    total_assets integer,
    total_records integer,
    success_count integer,
    failed_count integer,
    skipped_count integer,
    result_summary jsonb,
    error_message text
);


ALTER TABLE finapp.price_sync_logs_backup OWNER TO finapp_user;

--
-- Name: price_sync_tasks; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    data_source_id uuid NOT NULL,
    asset_type_id uuid,
    asset_ids uuid[],
    schedule_type character varying(20) DEFAULT 'manual'::character varying NOT NULL,
    cron_expression character varying(100),
    interval_minutes integer,
    sync_days_back integer DEFAULT 1,
    overwrite_existing boolean DEFAULT false,
    is_active boolean DEFAULT true,
    last_run_at timestamp(6) without time zone,
    next_run_at timestamp(6) without time zone,
    last_run_status character varying(20),
    last_run_result jsonb,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    country_id uuid
);


ALTER TABLE finapp.price_sync_tasks OWNER TO finapp_user;

--
-- Name: report_executions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.report_executions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    execution_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    started_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp(6) with time zone,
    file_path text,
    file_size bigint,
    error_message text,
    metadata jsonb
);


ALTER TABLE finapp.report_executions OWNER TO finapp_user;

--
-- Name: reports; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    portfolio_id uuid,
    name character varying(200) NOT NULL,
    description text,
    report_type character varying(50) NOT NULL,
    parameters jsonb NOT NULL,
    schedule jsonb,
    is_scheduled boolean DEFAULT false,
    is_active boolean DEFAULT true,
    last_generated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.reports OWNER TO finapp_user;

--
-- Name: role_permissions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.role_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.role_permissions OWNER TO finapp_user;

--
-- Name: roles; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.roles OWNER TO finapp_user;

--
-- Name: stock_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.stock_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    sector character varying(100),
    industry character varying(100),
    market_cap numeric(20,2),
    shares_outstanding bigint,
    pe_ratio numeric(10,2),
    pb_ratio numeric(10,2),
    dividend_yield numeric(5,2),
    company_website character varying(200),
    headquarters character varying(200),
    founded_year integer,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.stock_details OWNER TO finapp_user;

--
-- Name: stock_option_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.stock_option_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    underlying_stock_id uuid,
    underlying_stock_symbol character varying(50),
    underlying_stock_name character varying(200),
    option_type character varying(10) NOT NULL,
    strike_price numeric(20,8) NOT NULL,
    expiration_date date NOT NULL,
    contract_size integer DEFAULT 100,
    exercise_style character varying(20) DEFAULT 'AMERICAN'::character varying,
    settlement_type character varying(20) DEFAULT 'PHYSICAL'::character varying,
    multiplier numeric(10,4) DEFAULT 1.0,
    trading_unit character varying(20) DEFAULT '手'::character varying,
    min_price_change numeric(20,8),
    margin_requirement numeric(20,2),
    commission_rate numeric(5,4),
    delta numeric(10,6),
    gamma numeric(10,6),
    theta numeric(10,6),
    vega numeric(10,6),
    rho numeric(10,6),
    implied_volatility numeric(10,6),
    historical_volatility numeric(10,6),
    premium_currency character varying(10) DEFAULT 'CNY'::character varying,
    intrinsic_value numeric(20,8),
    time_value numeric(20,8),
    cost_divisor numeric(10,2) DEFAULT 3.5,
    notes text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.stock_option_details OWNER TO finapp_user;

--
-- Name: tag_categories; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.tag_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#52c41a'::character varying,
    icon character varying(50),
    user_id uuid NOT NULL,
    parent_id integer,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.tag_categories OWNER TO finapp_user;

--
-- Name: tag_categories_id_seq; Type: SEQUENCE; Schema: finapp; Owner: finapp_user
--

CREATE SEQUENCE finapp.tag_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE finapp.tag_categories_id_seq OWNER TO finapp_user;

--
-- Name: tag_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: finapp; Owner: finapp_user
--

ALTER SEQUENCE finapp.tag_categories_id_seq OWNED BY finapp.tag_categories.id;


--
-- Name: tags; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.tags (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#1890ff'::character varying,
    icon character varying(50),
    user_id uuid NOT NULL,
    category_id integer,
    is_system boolean DEFAULT false,
    is_active boolean DEFAULT true,
    usage_count integer DEFAULT 0,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.tags OWNER TO finapp_user;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: finapp; Owner: finapp_user
--

CREATE SEQUENCE finapp.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE finapp.tags_id_seq OWNER TO finapp_user;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: finapp; Owner: finapp_user
--

ALTER SEQUENCE finapp.tags_id_seq OWNED BY finapp.tags.id;


--
-- Name: trading_accounts; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.trading_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    account_type character varying(50) NOT NULL,
    broker_name character varying(100),
    account_number character varying(100),
    currency character varying(3) NOT NULL,
    initial_balance numeric(20,8) DEFAULT 0,
    current_balance numeric(20,8) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.trading_accounts OWNER TO finapp_user;

--
-- Name: transaction_tag_mappings; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.transaction_tag_mappings (
    transaction_id uuid NOT NULL,
    tag_id integer NOT NULL,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.transaction_tag_mappings OWNER TO finapp_user;

--
-- Name: transactions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    transaction_type character varying(20) NOT NULL,
    quantity numeric(20,8) NOT NULL,
    price numeric(20,8),
    total_amount numeric(20,8) NOT NULL,
    fees numeric(20,8) DEFAULT 0,
    taxes numeric(20,8) DEFAULT 0,
    currency character varying(3) NOT NULL,
    exchange_rate numeric(20,8) DEFAULT 1,
    transaction_date date NOT NULL,
    settlement_date date,
    notes text,
    tags text[],
    liquidity_tag_id uuid,
    external_id character varying(100),
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    user_id uuid,
    side character varying(20),
    executed_at timestamp(6) with time zone,
    settled_at timestamp(6) with time zone,
    status character varying(20) DEFAULT 'EXECUTED'::character varying,
    liquidity_tag character varying(20)
);


ALTER TABLE finapp.transactions OWNER TO finapp_user;

--
-- Name: treasury_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.treasury_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    treasury_type character varying(50) NOT NULL,
    term_type character varying(20),
    face_value numeric(20,2) NOT NULL,
    coupon_rate numeric(5,2) NOT NULL,
    coupon_frequency character varying(20),
    issue_date date NOT NULL,
    maturity_date date NOT NULL,
    term_years integer,
    issue_price numeric(20,2),
    issue_number character varying(50),
    yield_to_maturity numeric(5,2),
    tradable boolean DEFAULT true,
    min_holding_period integer,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.treasury_details OWNER TO finapp_user;

--
-- Name: user_roles; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid,
    assigned_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp(6) with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE finapp.user_roles OWNER TO finapp_user;

--
-- Name: user_sessions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    refresh_token_hash character varying(255),
    device_info jsonb,
    ip_address inet,
    user_agent text,
    is_active boolean DEFAULT true,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    last_used_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.user_sessions OWNER TO finapp_user;

--
-- Name: users; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(50),
    password_hash character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(20),
    avatar_url text,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    language character varying(10) DEFAULT 'zh-CN'::character varying,
    currency_preference character varying(3) DEFAULT 'CNY'::character varying,
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    email_verified_at timestamp(6) with time zone,
    last_login_at timestamp(6) with time zone,
    login_count integer DEFAULT 0,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.users OWNER TO finapp_user;

--
-- Name: v_data_source_market_coverage; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_market_coverage AS
 SELECT ds.id,
    ds.name,
    ds.provider,
    ds.is_active,
    jsonb_array_elements_text((ds.config -> 'supports_markets'::text)) AS market_code,
    m.name AS market_name,
    m.country,
    m.currency
   FROM ((finapp.price_data_sources ds
     LEFT JOIN LATERAL jsonb_array_elements_text((ds.config -> 'supports_markets'::text)) market_code(value) ON (true))
     LEFT JOIN finapp.markets m ON (((m.code)::text = market_code.value)))
  WHERE ((ds.config -> 'supports_markets'::text) IS NOT NULL)
  ORDER BY ds.name, (jsonb_array_elements_text((ds.config -> 'supports_markets'::text)));


ALTER TABLE finapp.v_data_source_market_coverage OWNER TO finapp_user;

--
-- Name: v_data_source_product_coverage; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_product_coverage AS
 SELECT ds.id,
    ds.name,
    ds.provider,
    ds.is_active,
    jsonb_array_elements_text((ds.config -> 'supports_products'::text)) AS product_type
   FROM finapp.price_data_sources ds
  WHERE ((ds.config -> 'supports_products'::text) IS NOT NULL)
  ORDER BY ds.name, (jsonb_array_elements_text((ds.config -> 'supports_products'::text)));


ALTER TABLE finapp.v_data_source_product_coverage OWNER TO finapp_user;

--
-- Name: v_data_source_comparison; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_comparison AS
 SELECT ds.name,
    ds.provider,
        CASE
            WHEN ds.is_active THEN '✅ 激活'::text
            ELSE '❌ 未激活'::text
        END AS status,
        CASE
            WHEN (ds.api_key_encrypted IS NOT NULL) THEN '已配置'::text
            ELSE '未配置'::text
        END AS api_key,
    ds.rate_limit AS rate_limit_per_minute,
    (ds.config ->> 'free_plan'::text) AS free_plan,
    (ds.config ->> 'requires_api_key'::text) AS requires_api_key,
    ( SELECT count(*) AS count
           FROM finapp.v_data_source_product_coverage
          WHERE (v_data_source_product_coverage.id = ds.id)) AS product_count,
    ( SELECT count(*) AS count
           FROM finapp.v_data_source_market_coverage
          WHERE (v_data_source_market_coverage.id = ds.id)) AS market_count,
    ds.last_sync_at,
    ds.last_sync_status
   FROM finapp.price_data_sources ds
  ORDER BY ds.is_active DESC, ds.name;


ALTER TABLE finapp.v_data_source_comparison OWNER TO finapp_user;

--
-- Name: v_data_source_config; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_config AS
 SELECT ds.id,
    ds.name,
    ds.provider,
    ds.is_active,
    ds.api_endpoint,
        CASE
            WHEN (ds.api_key_encrypted IS NOT NULL) THEN '已配置'::text
            ELSE '未配置'::text
        END AS api_key_status,
    ds.rate_limit,
    ds.timeout_seconds,
    (ds.config -> 'description'::text) AS description,
    (ds.config -> 'requires_api_key'::text) AS requires_api_key,
    (ds.config -> 'free_plan'::text) AS free_plan,
    (ds.config -> 'features'::text) AS features,
    ds.last_sync_at,
    ds.last_sync_status,
    COALESCE(ds.last_error_message, '无'::text) AS last_error_message,
    ds.created_at,
    ds.updated_at
   FROM finapp.price_data_sources ds
  ORDER BY ds.created_at DESC;


ALTER TABLE finapp.v_data_source_config OWNER TO finapp_user;

--
-- Name: v_market_source_count; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_market_source_count AS
 SELECT v_data_source_market_coverage.market_code,
    v_data_source_market_coverage.market_name,
    v_data_source_market_coverage.country,
    v_data_source_market_coverage.currency,
    count(DISTINCT v_data_source_market_coverage.id) AS source_count,
    string_agg(DISTINCT (v_data_source_market_coverage.name)::text, ', '::text ORDER BY (v_data_source_market_coverage.name)::text) AS source_names,
    (max(
        CASE
            WHEN v_data_source_market_coverage.is_active THEN 1
            ELSE 0
        END) > 0) AS has_active_source
   FROM finapp.v_data_source_market_coverage
  GROUP BY v_data_source_market_coverage.market_code, v_data_source_market_coverage.market_name, v_data_source_market_coverage.country, v_data_source_market_coverage.currency
  ORDER BY (count(DISTINCT v_data_source_market_coverage.id)) DESC, v_data_source_market_coverage.market_code;


ALTER TABLE finapp.v_market_source_count OWNER TO finapp_user;

--
-- Name: v_product_type_source_count; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_product_type_source_count AS
 SELECT COALESCE(pct.product_type, 'UNKNOWN'::text) AS product_type,
    count(DISTINCT pct.id) AS source_count,
    string_agg(DISTINCT (pct.name)::text, ', '::text ORDER BY (pct.name)::text) AS source_names,
    (max(
        CASE
            WHEN pct.is_active THEN 1
            ELSE 0
        END) > 0) AS has_active_source
   FROM finapp.v_data_source_product_coverage pct
  GROUP BY pct.product_type
  ORDER BY (count(DISTINCT pct.id)) DESC, COALESCE(pct.product_type, 'UNKNOWN'::text);


ALTER TABLE finapp.v_product_type_source_count OWNER TO finapp_user;

--
-- Name: wealth_product_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.wealth_product_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    product_type character varying(50) NOT NULL,
    risk_level character varying(20) NOT NULL,
    expected_return numeric(5,2),
    min_return numeric(5,2),
    max_return numeric(5,2),
    return_type character varying(20),
    issue_date date NOT NULL,
    start_date date NOT NULL,
    maturity_date date NOT NULL,
    lock_period integer,
    min_investment numeric(20,2),
    max_investment numeric(20,2),
    investment_increment numeric(20,2),
    issuer character varying(200),
    product_code character varying(50),
    early_redemption boolean DEFAULT false,
    redemption_fee numeric(5,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.wealth_product_details OWNER TO finapp_user;

--
-- Name: asset_prices; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.asset_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    price_date date NOT NULL,
    open_price numeric(20,8),
    high_price numeric(20,8),
    low_price numeric(20,8),
    close_price numeric(20,8) NOT NULL,
    volume bigint,
    adjusted_close numeric(20,8),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.asset_prices OWNER TO caojun;

--
-- Name: asset_types; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.asset_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.asset_types OWNER TO caojun;

--
-- Name: assets; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.assets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    symbol character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    asset_type_id uuid NOT NULL,
    market_id uuid,
    currency character varying(3) NOT NULL,
    isin character varying(12),
    cusip character varying(9),
    sector character varying(100),
    industry character varying(100),
    description text,
    metadata jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.assets OWNER TO caojun;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    table_name character varying(100) NOT NULL,
    record_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO caojun;

--
-- Name: benchmark_prices; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.benchmark_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    benchmark_id uuid NOT NULL,
    price_date date NOT NULL,
    price numeric(20,8) NOT NULL,
    currency character varying(3) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.benchmark_prices OWNER TO caojun;

--
-- Name: benchmarks; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.benchmarks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(20) NOT NULL,
    description text,
    asset_class character varying(50),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.benchmarks OWNER TO caojun;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.email_verification_tokens OWNER TO caojun;

--
-- Name: TABLE email_verification_tokens; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.email_verification_tokens IS '邮箱验证令牌表';


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.exchange_rates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_currency character varying(3) NOT NULL,
    to_currency character varying(3) NOT NULL,
    rate_date date NOT NULL,
    rate numeric(20,8) NOT NULL,
    data_source character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.exchange_rates OWNER TO caojun;

--
-- Name: liquidity_tags; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.liquidity_tags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color character varying(7),
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.liquidity_tags OWNER TO caojun;

--
-- Name: markets; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.markets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(3) NOT NULL,
    currency character varying(3) NOT NULL,
    timezone character varying(50) NOT NULL,
    trading_hours jsonb,
    holidays jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.markets OWNER TO caojun;

--
-- Name: option_details; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.option_details (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    underlying_asset_id uuid,
    option_type character varying(10) NOT NULL,
    strike_price numeric(20,8) NOT NULL,
    expiration_date date NOT NULL,
    contract_size integer DEFAULT 100,
    exercise_style character varying(20) DEFAULT 'american'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT option_details_option_type_check CHECK (((option_type)::text = ANY ((ARRAY['call'::character varying, 'put'::character varying])::text[])))
);


ALTER TABLE public.option_details OWNER TO caojun;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.password_reset_tokens OWNER TO caojun;

--
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.password_reset_tokens IS '密码重置令牌表';


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO caojun;

--
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.permissions IS '权限表';


--
-- Name: portfolios; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.portfolios (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    base_currency character varying(3) DEFAULT 'CNY'::character varying NOT NULL,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.portfolios OWNER TO caojun;

--
-- Name: positions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.positions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    quantity numeric(20,8) DEFAULT 0 NOT NULL,
    average_cost numeric(20,8) DEFAULT 0 NOT NULL,
    total_cost numeric(20,8) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    first_purchase_date date,
    last_transaction_date date,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.positions OWNER TO caojun;

--
-- Name: report_executions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.report_executions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    execution_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    file_path text,
    file_size bigint,
    error_message text,
    metadata jsonb
);


ALTER TABLE public.report_executions OWNER TO caojun;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    portfolio_id uuid,
    name character varying(200) NOT NULL,
    description text,
    report_type character varying(50) NOT NULL,
    parameters jsonb NOT NULL,
    schedule jsonb,
    is_scheduled boolean DEFAULT false,
    is_active boolean DEFAULT true,
    last_generated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.reports OWNER TO caojun;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.role_permissions OWNER TO caojun;

--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.role_permissions IS '角色权限关联表';


--
-- Name: roles; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO caojun;

--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.roles IS '角色表';


--
-- Name: trading_accounts; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.trading_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    account_type character varying(50) NOT NULL,
    broker_name character varying(100),
    account_number character varying(100),
    currency character varying(3) NOT NULL,
    initial_balance numeric(20,8) DEFAULT 0,
    current_balance numeric(20,8) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.trading_accounts OWNER TO caojun;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    transaction_type character varying(20) NOT NULL,
    quantity numeric(20,8) NOT NULL,
    price numeric(20,8),
    total_amount numeric(20,8) NOT NULL,
    fees numeric(20,8) DEFAULT 0,
    taxes numeric(20,8) DEFAULT 0,
    currency character varying(3) NOT NULL,
    exchange_rate numeric(20,8) DEFAULT 1,
    transaction_date date NOT NULL,
    settlement_date date,
    notes text,
    tags text[],
    liquidity_tag_id uuid,
    external_id character varying(100),
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['buy'::character varying, 'sell'::character varying, 'dividend'::character varying, 'split'::character varying, 'merger'::character varying, 'spin_off'::character varying, 'deposit'::character varying, 'withdrawal'::character varying])::text[])))
);


ALTER TABLE public.transactions OWNER TO caojun;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE public.user_roles OWNER TO caojun;

--
-- Name: TABLE user_roles; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.user_roles IS '用户角色关联表';


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    refresh_token_hash character varying(255),
    device_info jsonb,
    ip_address inet,
    user_agent text,
    is_active boolean DEFAULT true,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_used_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_sessions OWNER TO caojun;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.user_sessions IS '用户会话表，用于JWT令牌管理';


--
-- Name: users; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(50),
    password_hash character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(20),
    avatar_url text,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    language character varying(10) DEFAULT 'zh-CN'::character varying,
    currency_preference character varying(3) DEFAULT 'CNY'::character varying,
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    email_verified_at timestamp with time zone,
    last_login_at timestamp with time zone,
    login_count integer DEFAULT 0,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO caojun;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.users IS '用户基础信息表';


--
-- Name: portfolio_tags id; Type: DEFAULT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags ALTER COLUMN id SET DEFAULT nextval('finapp.portfolio_tags_id_seq'::regclass);


--
-- Name: tag_categories id; Type: DEFAULT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories ALTER COLUMN id SET DEFAULT nextval('finapp.tag_categories_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags ALTER COLUMN id SET DEFAULT nextval('finapp.tags_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: asset_prices; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.asset_prices (id, asset_id, price_date, open_price, high_price, low_price, close_price, volume, adjusted_close, currency, data_source, created_at) FROM stdin;
\.


--
-- Data for Name: asset_types; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.asset_types (id, code, name, category, description, is_active, created_at, location_dimension) FROM stdin;
26baf585-bfba-4af4-bc41-d9efdc05d82a	STOCK_OPTION	股票期权	STOCK_OPTION	股票期权合约，包括认购期权和认沽期权	t	2025-11-07 23:16:55.333125+08	market
ce4ebe16-471f-4d06-b37a-6b5bdf91b018	COMMODITY	商品	commodity	贵金属、原油等商品	t	2025-11-07 21:05:53.355326+08	global
39267764-141d-43f7-bdc3-32a6a4b6e084	TREASURY	国债	BOND	政府债券	t	2025-11-09 11:26:53.055048+08	market
759fd931-caad-408b-9b46-938bc94b62ce	ETF	交易所交易基金	ETF	在交易所交易的指数基金	t	2025-11-07 21:05:53.355326+08	market
1317e563-bc85-418d-bd6b-bc49d6719ce5	BOND	企业债券	BOND	企业债券	t	2025-11-07 21:05:53.355326+08	country
53195789-6c3e-41b3-b30a-4d328126728c	MUTUAL_FUND	共同基金	FUND	开放式基金	t	2025-11-07 21:05:53.355326+08	country
9ed792c8-2fbb-4453-8380-5e957a651df3	CRYPTO	加密货币	CRYPTO	数字货币	t	2025-11-07 21:05:53.355326+08	global
a38b6c3d-61de-482d-8859-16e72f3107fd	HEDGE_FUND	对冲基金	FUND	私募基金与对冲基金	t	2025-11-07 21:06:31.056188+08	country
4016a03f-0738-4c9a-8c77-faa1e4b87966	FOREX	外汇	CURRENCY	\N	t	2025-11-08 15:39:17.304747+08	global
916f709e-d2fe-4bbb-a0b5-f0e680c30c53	REIT	房地产投资信托	FUND	房地产投资信托基金	t	2025-11-07 21:05:53.355326+08	country
716c257e-388f-4cde-a5b6-373effe40d78	OPTION	期权	FUTURE	股票期权合约	t	2025-11-07 21:05:53.355326+08	market
810cc3b6-01c0-4cea-af47-b34563226fc9	FUTURE	期货	FUTURE	期货合约	t	2025-11-07 21:05:53.355326+08	market
c7705c2b-9c24-449e-9015-a1ec8b826f6e	CASH	现金	CURRENCY	现金及现金等价物	t	2025-11-07 21:05:53.355326+08	country
761e5638-cff8-4247-bfd7-00edcd57a51a	STOCK	股票	EQUITY	普通股票	t	2025-11-07 21:05:53.355326+08	market
60c02f02-b096-4f08-971e-653d3b5a7ddf	BANK_WEALTH	银行理财产品	CURRENCY	银行发行的理财产品，包括保本和非保本理财产品	t	2025-11-08 10:18:32.181688+08	country
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.assets (id, symbol, name, asset_type_id, currency, isin, cusip, sector, industry, description, metadata, is_active, created_at, updated_at, risk_level, lot_size, tick_size, listing_date, delisting_date, tags, created_by, updated_by, liquidity_tag, country_id) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.audit_logs (id, user_id, table_name, record_id, action, old_values, new_values, changed_fields, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: benchmark_prices; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.benchmark_prices (id, benchmark_id, price_date, price, currency, created_at) FROM stdin;
\.


--
-- Data for Name: benchmarks; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.benchmarks (id, name, symbol, description, asset_class, currency, data_source, is_active, created_at) FROM stdin;
3295fc27-ccb0-4149-9d63-349231982751	沪深300指数	CSI300	沪深300指数，反映A股市场整体表现	equity	CNY	\N	t	2025-11-07 21:05:53.359287+08
8cdf279f-6a15-4a37-ac94-aecf13e97156	上证指数	SHCOMP	上海证券交易所综合股价指数	equity	CNY	\N	t	2025-11-07 21:05:53.359287+08
37ace466-8b41-4ddb-b0a9-461d96b8eab3	深证成指	SZCOMP	深圳证券交易所成份股价指数	equity	CNY	\N	t	2025-11-07 21:05:53.359287+08
ffd11eda-614b-4cd2-9a2e-41754f2198f3	恒生指数	HSI	香港恒生指数	equity	HKD	\N	t	2025-11-07 21:05:53.359287+08
b37a6a3c-b8a8-46a8-960c-ecb0262fa91a	标普500指数	SPX	标准普尔500指数	equity	USD	\N	t	2025-11-07 21:05:53.359287+08
19548a7a-33cc-4374-a35f-3fd20ef93c8b	纳斯达克指数	IXIC	纳斯达克综合指数	equity	USD	\N	t	2025-11-07 21:05:53.359287+08
fd5ff7d6-8de9-4c98-9f30-41d57a1ba263	日经225指数	N225	日经225指数	equity	JPY	\N	t	2025-11-07 21:05:53.359287+08
8de063ae-fb49-42cf-b18c-9656b1a55a7f	富时100指数	UKX	英国富时100指数	equity	GBP	\N	t	2025-11-07 21:05:53.359287+08
6c8f4959-35d7-43b7-9580-3e0747147ea5	DAX指数	DAX	德国DAX指数	equity	EUR	\N	t	2025-11-07 21:05:53.359287+08
\.


--
-- Data for Name: bond_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.bond_details (id, asset_id, bond_type, credit_rating, face_value, coupon_rate, coupon_frequency, issue_date, maturity_date, years_to_maturity, yield_to_maturity, current_yield, issuer, issue_price, issue_size, callable, call_date, call_price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cash_flows; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.cash_flows (id, portfolio_id, trading_account_id, asset_id, flow_type, amount, currency, flow_date, description, transaction_id, created_at, date, category) FROM stdin;
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.countries (id, code, name, currency, timezone, is_active, created_at, updated_at) FROM stdin;
c447b588-db26-4ef5-bac5-0e623820ecae	US	美国	USD	America/New_York	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
7b1dccae-1542-42fe-b069-e62554e6195a	GB	英国	GBP	Europe/London	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
61ac326e-26e7-454c-a08d-858afc897667	JP	日本	JPY	Asia/Tokyo	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
3d131879-1ea4-46e2-8773-8a2a50bfc460	DE	德国	EUR	Europe/Berlin	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
f0c7ec9b-2a14-41f6-96bf-f45d4d1897e3	FR	法国	EUR	Europe/Paris	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
d7d5c3ba-92c1-4619-891c-de4d455179ed	CN	中国	CNY	Asia/Shanghai	t	2025-11-08 10:22:35.250429+08	2025-11-08 10:22:35.250429+08
a1f8cb91-32af-4479-89e7-0b99e7ee4057	HK	中国香港	HKD	Asia/Hong_Kong	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.email_verification_tokens (id, user_id, token_hash, email, expires_at, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.exchange_rates (id, from_currency, to_currency, rate_date, rate, data_source, created_at) FROM stdin;
f5a3e67c-84c0-43f6-8cd6-829f71d44948	USD	CNY	2015-11-30	6.39840000	historical_import	2025-11-09 10:18:48.376031+08
705b78eb-5be0-4993-8605-950689ed7459	EUR	CNY	2015-11-30	6.76890000	historical_import	2025-11-09 10:18:48.378559+08
66e00dd8-2147-4317-9d21-01ae6ca8a062	GBP	CNY	2015-11-30	9.60400000	historical_import	2025-11-09 10:18:48.379314+08
9b25eec6-d6bd-40fc-9ed4-db013508ef4d	USD	HKD	2025-11-08	7.78000000	api	2025-11-08 20:00:01.099307+08
f5abc080-7d14-4b8e-a26c-a40023d071c5	USD	SGD	2025-11-08	1.30000000	api	2025-11-08 20:00:01.10026+08
55d5639b-2fd7-4fa1-b4f6-0aae15ebbb5b	USD	HKD	2025-11-09	7.78000000	api	2025-11-09 04:00:00.98589+08
b08e1d7c-0620-40bc-a566-96c67c602b0f	USD	SGD	2025-11-09	1.30000000	api	2025-11-09 04:00:00.987092+08
dac7318b-2bf7-465f-8d44-8d716432dba7	JPY	CNY	2015-11-30	0.05198000	historical_import	2025-11-09 10:18:48.379778+08
e2b77e45-ba5c-4a65-bde3-f2937d9a3479	HKD	CNY	2015-11-30	0.82559000	historical_import	2025-11-09 10:18:48.380204+08
93c30e06-fa8a-4a27-a442-0d1839506ef4	SGD	CNY	2015-11-30	4.53070000	historical_import	2025-11-09 10:18:48.380572+08
2f726b9f-e12f-4f43-8e02-ba021e5843c8	AUD	CNY	2015-11-30	4.61380000	historical_import	2025-11-09 10:18:48.38099+08
e41e5546-c346-42aa-b54a-cd439a617914	CAD	CNY	2015-11-30	4.78600000	historical_import	2025-11-09 10:18:48.381367+08
d40ddad6-c365-484d-a84f-58286da0f0d6	CHF	CNY	2015-11-30	6.20830000	historical_import	2025-11-09 10:18:48.381639+08
30081985-81ea-4a83-8d44-0356ad2d0daf	INR	CNY	2015-11-30	0.09597000	historical_import	2025-11-09 10:18:48.381921+08
8d0113ea-4a35-4e2b-9617-ec037baf64df	USD	CNY	2015-12-31	6.48550000	historical_import	2025-11-09 10:18:48.382206+08
5dac055d-a1b5-4a8a-b67a-fe10bec3f9d4	EUR	CNY	2015-12-31	7.06080000	historical_import	2025-11-09 10:18:48.382518+08
834cff17-3dac-4ca4-b0c9-a6c4982c155f	GBP	CNY	2015-12-31	9.62030000	historical_import	2025-11-09 10:18:48.382755+08
0fa1545d-7b00-4013-979e-2406696fda46	JPY	CNY	2015-12-31	0.05387000	historical_import	2025-11-09 10:18:48.383024+08
46270ea5-5be7-412a-9e5b-f1ad0ea4a92c	HKD	CNY	2015-12-31	0.83683000	historical_import	2025-11-09 10:18:48.3834+08
fe4e9b81-de23-41f0-9c19-4d2ebe80ae63	SGD	CNY	2015-12-31	4.57990000	historical_import	2025-11-09 10:18:48.383764+08
7f8633ee-726a-42ac-817c-8386598d2e77	AUD	CNY	2015-12-31	4.73970000	historical_import	2025-11-09 10:18:48.38412+08
a69b5ba1-9ac0-4120-8830-c3264e97126d	CAD	CNY	2015-12-31	4.67110000	historical_import	2025-11-09 10:18:48.384466+08
feb430fd-e97c-489e-9164-3a7a33a1dd3e	CHF	CNY	2015-12-31	6.51670000	historical_import	2025-11-09 10:18:48.384819+08
76039eed-62dd-42f3-b665-8bb0b3626ac2	INR	CNY	2015-12-31	0.09804000	historical_import	2025-11-09 10:18:48.385196+08
6f1dd0c7-8b2a-46f9-82d7-0677d9e8e78f	USD	CNY	2016-01-31	6.57600000	historical_import	2025-11-09 10:18:48.385568+08
710eeea1-3197-4c34-83c8-1476c41015ad	EUR	CNY	2016-01-31	7.18100000	historical_import	2025-11-09 10:18:48.385893+08
79c81d7a-6ba1-4f64-abc3-757376e128db	GBP	CNY	2016-01-31	9.39800000	historical_import	2025-11-09 10:18:48.386447+08
78ae8cd2-769e-41c2-bbf8-a71934dc3e22	JPY	CNY	2016-01-31	0.05430000	historical_import	2025-11-09 10:18:48.386836+08
4b1d55ba-b91a-421a-ac7e-737c9bebd0fa	HKD	CNY	2016-01-31	0.84382000	historical_import	2025-11-09 10:18:48.387179+08
93b3ee74-12f7-4fcf-a357-c2790d2575f0	SGD	CNY	2016-01-31	4.61800000	historical_import	2025-11-09 10:18:48.387465+08
a4366ba6-f992-40d2-8a75-32b855adc8f5	AUD	CNY	2016-01-31	4.66660000	historical_import	2025-11-09 10:18:48.387759+08
91014f40-86bd-48a9-8bef-46990943789e	CAD	CNY	2016-01-31	4.67420000	historical_import	2025-11-09 10:18:48.388047+08
1e5ac69f-534b-436a-8ff0-b13a2a6e2d8e	CHF	CNY	2016-01-31	6.44380000	historical_import	2025-11-09 10:18:48.388327+08
3f0ffee7-305c-4abb-8ad3-0df4d771de27	INR	CNY	2016-01-31	0.09690000	historical_import	2025-11-09 10:18:48.388612+08
59cef3ea-1af5-4d17-8858-b68cdf91cb04	USD	CNY	2016-02-29	6.55320000	historical_import	2025-11-09 10:18:48.388897+08
11a5ce64-6133-4f9a-88ea-3130f1671cbb	EUR	CNY	2016-02-29	7.13510000	historical_import	2025-11-09 10:18:48.389172+08
999222d7-aa3c-4500-a2c4-b897f1109ac3	GBP	CNY	2016-02-29	9.08000000	historical_import	2025-11-09 10:18:48.389465+08
919a75de-a738-4ad8-8c47-dc5d3868a3fe	JPY	CNY	2016-02-29	0.05794000	historical_import	2025-11-09 10:18:48.389672+08
cebaa296-3786-48a5-98ff-02cdf35764ab	HKD	CNY	2016-02-29	0.84288000	historical_import	2025-11-09 10:18:48.389888+08
c61a1942-89a3-4b08-8cee-927862fa3015	SGD	CNY	2016-02-29	4.65590000	historical_import	2025-11-09 10:18:48.390113+08
775045e1-3391-4fbb-a722-f1ca37a15340	AUD	CNY	2016-02-29	4.67570000	historical_import	2025-11-09 10:18:48.390318+08
3c125c53-5755-4d67-93ef-2bfc1eda9dbc	CAD	CNY	2016-02-29	4.83180000	historical_import	2025-11-09 10:18:48.390556+08
fd1de073-f0c6-4647-9731-ad158d05b84d	CHF	CNY	2016-02-29	6.53760000	historical_import	2025-11-09 10:18:48.39085+08
8959a7fa-4743-4fb3-a7b6-59c3c509cf14	INR	CNY	2016-02-29	0.09593000	historical_import	2025-11-09 10:18:48.391114+08
3a7dd6d9-7330-4e35-a438-3d8a0aeffafd	USD	CNY	2016-03-31	6.45710000	historical_import	2025-11-09 10:18:48.391358+08
38958785-3614-424e-969f-8e0edc90877b	EUR	CNY	2016-03-31	7.35140000	historical_import	2025-11-09 10:18:48.391607+08
c5e05c20-5286-48c6-b6fb-75b647d02946	GBP	CNY	2016-03-31	9.28730000	historical_import	2025-11-09 10:18:48.391846+08
d0265e91-a45b-43e0-9f8c-6542365e345d	JPY	CNY	2016-03-31	0.05748000	historical_import	2025-11-09 10:18:48.392096+08
ce30d9fe-b3c3-4b35-9728-ce034799fd8e	HKD	CNY	2016-03-31	0.83272000	historical_import	2025-11-09 10:18:48.392349+08
c39a583f-681e-4cf6-8fcd-adc5822f791e	SGD	CNY	2016-03-31	4.80360000	historical_import	2025-11-09 10:18:48.392612+08
2e4cdf40-d8b3-45d9-b18e-2c86b505c372	AUD	CNY	2016-03-31	4.96480000	historical_import	2025-11-09 10:18:48.392866+08
af6202f9-0f6f-4f05-a26c-36fd51601360	CAD	CNY	2016-03-31	4.98810000	historical_import	2025-11-09 10:18:48.393145+08
0921706a-1703-4573-9edb-92140046950d	CHF	CNY	2016-03-31	6.72530000	historical_import	2025-11-09 10:18:48.393487+08
39d3e1e4-7646-43bb-86a8-a6d2d2b65586	INR	CNY	2016-03-31	0.09746000	historical_import	2025-11-09 10:18:48.393966+08
d178041c-f849-42e9-b5e0-a049b43fc016	USD	CNY	2016-04-30	6.48450000	historical_import	2025-11-09 10:18:48.394219+08
abddb6ae-4934-4795-8b3c-5e6931f72557	EUR	CNY	2016-04-30	7.39430000	historical_import	2025-11-09 10:18:48.394482+08
8e0b9ffa-b24c-4365-9591-181e03b4011e	GBP	CNY	2016-04-30	9.47680000	historical_import	2025-11-09 10:18:48.394738+08
29759de7-fa13-469b-97e8-87159fdcc160	JPY	CNY	2016-04-30	0.06044000	historical_import	2025-11-09 10:18:48.394991+08
e23f5630-ca90-4002-80f7-cd55955278da	HKD	CNY	2016-04-30	0.83584000	historical_import	2025-11-09 10:18:48.395264+08
c889cab6-ae25-4297-bfa2-7becd8ec2dd9	SGD	CNY	2016-04-30	4.82940000	historical_import	2025-11-09 10:18:48.395469+08
3f823d0f-41d3-4ee8-bb0e-933f26ac1f96	AUD	CNY	2016-04-30	4.94670000	historical_import	2025-11-09 10:18:48.395666+08
a6e034d0-0c84-4f16-9254-d50ca9df4d38	CAD	CNY	2016-04-30	5.17590000	historical_import	2025-11-09 10:18:48.395858+08
4949c43d-4436-4835-8d97-c5ca53f5b1a0	CHF	CNY	2016-04-30	6.73190000	historical_import	2025-11-09 10:18:48.396087+08
ce228d34-e1f9-4d02-9982-c09949914f19	INR	CNY	2016-04-30	0.09768000	historical_import	2025-11-09 10:18:48.396319+08
c19e0e9f-4792-4fbd-a1b2-8f131d994dbd	USD	CNY	2016-05-31	6.57730000	historical_import	2025-11-09 10:18:48.396558+08
992a02e6-2bff-4e86-ae4f-35fb43eb13eb	EUR	CNY	2016-05-31	7.33630000	historical_import	2025-11-09 10:18:48.396768+08
74e44e88-5a4b-4eca-9029-56ff42660ba4	GBP	CNY	2016-05-31	9.62960000	historical_import	2025-11-09 10:18:48.396969+08
0907a85f-c66c-42ec-82c6-a5f6b49492c0	JPY	CNY	2016-05-31	0.05924000	historical_import	2025-11-09 10:18:48.397167+08
4b4ed593-f6f2-401c-bd24-bbb435942367	HKD	CNY	2016-05-31	0.84676000	historical_import	2025-11-09 10:18:48.397373+08
9783e483-7724-4ff3-986b-ff1c0ac473c2	SGD	CNY	2016-05-31	4.77410000	historical_import	2025-11-09 10:18:48.397607+08
173d546b-2490-4538-92b5-3b5f24f53aad	AUD	CNY	2016-05-31	4.77440000	historical_import	2025-11-09 10:18:48.397882+08
3a5d1266-34d3-4c91-a827-44f0e0f67af3	CAD	CNY	2016-05-31	5.04910000	historical_import	2025-11-09 10:18:48.398105+08
00edfb9e-4a96-4be7-96ca-cc751d7dc729	CHF	CNY	2016-05-31	6.64280000	historical_import	2025-11-09 10:18:48.398321+08
387db63d-f28a-48bb-89da-12ce073931ff	INR	CNY	2016-05-31	0.09788000	historical_import	2025-11-09 10:18:48.398537+08
3c4cb9f4-d1a9-4501-a260-a8c7b2ad70f9	USD	CNY	2016-06-30	6.64340000	historical_import	2025-11-09 10:18:48.398728+08
8008fe04-1b44-455a-8dbb-a476897fb59e	EUR	CNY	2016-06-30	7.37550000	historical_import	2025-11-09 10:18:48.39894+08
fd46b3f9-feea-4a4e-bc93-d63167815dc1	GBP	CNY	2016-06-30	8.92380000	historical_import	2025-11-09 10:18:48.399145+08
1b33e550-c944-4c6a-9847-837b86c15bca	JPY	CNY	2016-06-30	0.06467000	historical_import	2025-11-09 10:18:48.399434+08
5ad807cd-69c1-4598-a5c7-63c71420d5a2	HKD	CNY	2016-06-30	0.85627000	historical_import	2025-11-09 10:18:48.399863+08
4d061401-9782-481e-8984-fd19beb930f9	SGD	CNY	2016-06-30	4.93110000	historical_import	2025-11-09 10:18:48.400116+08
b04aa83a-13b8-47bd-9a2d-6b7bfdeb0fb4	AUD	CNY	2016-06-30	4.94040000	historical_import	2025-11-09 10:18:48.400365+08
d56a82f5-d5b1-4a4a-9156-67df281e360a	CAD	CNY	2016-06-30	5.12760000	historical_import	2025-11-09 10:18:48.400614+08
e1dca903-de51-420f-aa71-79551607caa8	CHF	CNY	2016-06-30	6.78710000	historical_import	2025-11-09 10:18:48.401096+08
8c8d7dfd-1dbc-472d-883a-8c6b097cdbfc	INR	CNY	2016-06-30	0.09839000	historical_import	2025-11-09 10:18:48.401366+08
7d76cf9a-35b2-4c1f-a04a-792d949981ac	USD	CNY	2016-07-31	6.65060000	historical_import	2025-11-09 10:18:48.401607+08
5710c1c6-77e8-4f4c-b7e7-d57fe8c29e19	EUR	CNY	2016-07-31	7.39080000	historical_import	2025-11-09 10:18:48.401847+08
01040fd7-9792-4f5c-b4a7-7dfbc3f0ca5b	GBP	CNY	2016-07-31	8.75690000	historical_import	2025-11-09 10:18:48.402083+08
01b7326d-a5ae-4beb-b4c2-0bbae5881869	JPY	CNY	2016-07-31	0.06436000	historical_import	2025-11-09 10:18:48.402317+08
4f3b4c2f-d433-41ab-b85a-fc9c66223a91	HKD	CNY	2016-07-31	0.85730000	historical_import	2025-11-09 10:18:48.402559+08
33ee8417-9358-4363-bcd7-5cf25e37a92b	SGD	CNY	2016-07-31	4.92230000	historical_import	2025-11-09 10:18:48.402784+08
c98b12be-2921-4745-a78f-7cce396595e4	AUD	CNY	2016-07-31	4.99990000	historical_import	2025-11-09 10:18:48.403034+08
eeee114e-7462-4ea2-b445-13ff8bd666da	CAD	CNY	2016-07-31	5.04730000	historical_import	2025-11-09 10:18:48.403278+08
aab88e74-f7ef-4d85-9a01-55a14431ddb9	CHF	CNY	2016-07-31	6.82880000	historical_import	2025-11-09 10:18:48.403522+08
8e1c0023-9a2a-4afd-afdd-b40c11320242	INR	CNY	2016-07-31	0.09933000	historical_import	2025-11-09 10:18:48.403755+08
fee3b6d0-5663-4b08-8ea4-c3e11bdb5f9f	USD	CNY	2016-08-31	6.67540000	historical_import	2025-11-09 10:18:48.403988+08
5c56e280-c10d-44ae-b884-4acdff98a2a6	EUR	CNY	2016-08-31	7.43110000	historical_import	2025-11-09 10:18:48.404221+08
cd78ed7c-567a-414d-88cc-6764f78d7c64	GBP	CNY	2016-08-31	8.76250000	historical_import	2025-11-09 10:18:48.404454+08
a23b6a80-f687-4a51-b81c-ce2a252b3e36	JPY	CNY	2025-11-09	0.04651000	api	2025-11-09 10:01:24.782028+08
1df5aa03-fb4c-488a-a0c7-0bf757ca8039	JPY	CNY	2016-08-31	0.06461000	historical_import	2025-11-09 10:18:48.404705+08
05265ebe-e196-4444-b70b-447734de8ce6	HKD	CNY	2016-08-31	0.86051000	historical_import	2025-11-09 10:18:48.404967+08
833f0afe-5234-44b4-b362-95856367557a	SGD	CNY	2016-08-31	4.89500000	historical_import	2025-11-09 10:18:48.405223+08
06cece5c-031d-4552-95fe-5903f646fd79	AUD	CNY	2016-08-31	5.01900000	historical_import	2025-11-09 10:18:48.405486+08
1751a050-9703-46a3-b9c5-13878516e497	CAD	CNY	2016-08-31	5.09570000	historical_import	2025-11-09 10:18:48.405719+08
af677d27-a1c9-4a5d-86a7-577658185333	CHF	CNY	2016-08-31	6.78210000	historical_import	2025-11-09 10:18:48.405981+08
ed11f858-9cae-445c-9ed4-394e242ea296	INR	CNY	2016-08-31	0.09967000	historical_import	2025-11-09 10:18:48.406233+08
92987d5f-dd9c-4038-be13-9cb6817f9788	USD	CNY	2016-09-30	6.67170000	historical_import	2025-11-09 10:18:48.40649+08
86fb7f18-ba5e-43c8-bdea-962c45587a41	EUR	CNY	2016-09-30	7.44630000	historical_import	2025-11-09 10:18:48.406745+08
9ca8c9e7-1991-4319-8af5-79b2cb76a088	GBP	CNY	2016-09-30	8.64810000	historical_import	2025-11-09 10:18:48.406974+08
fee1645a-473b-4c27-b54a-29bebf3d7cc0	JPY	CNY	2016-09-30	0.06584000	historical_import	2025-11-09 10:18:48.407373+08
f8e4603d-e1be-49c4-a456-0b00607b9633	HKD	CNY	2016-09-30	0.86038000	historical_import	2025-11-09 10:18:48.407624+08
52ca84d3-26c7-4a49-ae31-18d25b5bcbbd	SGD	CNY	2016-09-30	4.88760000	historical_import	2025-11-09 10:18:48.407928+08
3e6ba8d7-8c39-4f56-a457-387dcbced6c1	AUD	CNY	2016-09-30	5.08040000	historical_import	2025-11-09 10:18:48.408184+08
42e4132e-d834-4eff-9176-eef0f611314e	CAD	CNY	2016-09-30	5.06900000	historical_import	2025-11-09 10:18:48.408441+08
e4d83335-abf6-41d1-9373-ff1e9f8c9c31	CHF	CNY	2016-09-30	6.84650000	historical_import	2025-11-09 10:18:48.408673+08
ecc77645-203b-4da4-a7ba-452b8787b375	INR	CNY	2016-09-30	0.10013000	historical_import	2025-11-09 10:18:48.408912+08
d56715ce-4028-44d9-af74-26ac5f16d5c7	EUR	CNY	2025-11-09	8.23240000	api	2025-11-09 10:01:24.258241+08
ff71cc69-781d-42e8-b76c-6fc8189021f6	USD	CNY	2016-10-31	6.77470000	historical_import	2025-11-09 10:18:48.409145+08
518e5fe4-face-4b95-9d7d-ffec23d61be0	EUR	CNY	2016-10-31	7.41560000	historical_import	2025-11-09 10:18:48.40939+08
817665a3-5305-4894-af5f-7ecf659ad059	GBP	CNY	2016-10-31	8.23500000	historical_import	2025-11-09 10:18:48.409644+08
5277f1f0-315f-4ff8-a5db-e4ceb235697d	JPY	CNY	2016-10-31	0.06450000	historical_import	2025-11-09 10:18:48.409931+08
e72732fc-b9ac-44dc-b184-cc9613f538e8	HKD	CNY	2016-10-31	0.87358000	historical_import	2025-11-09 10:18:48.410233+08
8924e113-5ff2-4002-a349-2cecfaafd347	INR	CNY	2025-11-09	0.08030000	api	2025-11-09 10:01:28.520667+08
97caa9cb-5990-4f2d-b1d3-2877395b9499	SGD	CNY	2016-10-31	4.86240000	historical_import	2025-11-09 10:18:48.410516+08
01a78508-645d-42dd-a664-6f3790eead9a	AUD	CNY	2016-10-31	5.15080000	historical_import	2025-11-09 10:18:48.410778+08
e158c82e-a37b-42f1-8dcf-82c4c098cda1	AUD	CNY	2025-11-09	4.61510000	api	2025-11-09 10:01:25.627209+08
a8bf0f15-3f6a-4e0a-9681-d9c56f4e3be7	CAD	CNY	2016-10-31	5.05670000	historical_import	2025-11-09 10:18:48.411015+08
8a7edc2c-b26a-43e6-9b42-ca4151ecc6e7	CHF	CNY	2016-10-31	6.85360000	historical_import	2025-11-09 10:18:48.411253+08
5159a6c5-28bc-4fe4-8639-f304975cc7ee	INR	CNY	2016-10-31	0.10145000	historical_import	2025-11-09 10:18:48.411495+08
f339fc6a-e9ea-4b30-afab-d342b0869d70	USD	CNY	2016-11-30	6.88340000	historical_import	2025-11-09 10:18:48.411712+08
e003cc84-c77e-4cfe-bcf6-9a7de2057be9	CAD	CNY	2025-11-09	5.04710000	api	2025-11-09 10:01:26.611882+08
6234ea7a-7fc8-4847-b383-47afd41f44cd	EUR	CNY	2016-11-30	7.32050000	historical_import	2025-11-09 10:18:48.411948+08
522c01b8-5adb-466f-8ad7-8a11811ec1de	GBP	CNY	2016-11-30	8.58710000	historical_import	2025-11-09 10:18:48.412147+08
4fe230cd-3d7d-4be6-b3a7-7e9b4a5a4397	JPY	CNY	2016-11-30	0.06076000	historical_import	2025-11-09 10:18:48.412358+08
0ac51c9e-dfeb-40dd-9b45-9500e4d4e2f1	HKD	CNY	2016-11-30	0.88745000	historical_import	2025-11-09 10:18:48.412573+08
4c5c5962-affe-4eaa-8034-d07300787570	GBP	CNY	2025-11-09	9.34330000	api	2025-11-09 10:01:24.514323+08
aa01da12-43c9-48e9-b6dd-c3d01daadf1b	SGD	CNY	2016-11-30	4.82280000	historical_import	2025-11-09 10:18:48.412806+08
aaaa1c22-12d1-4ed7-94cf-9abca1767615	CHF	CNY	2025-11-09	8.84060000	api	2025-11-09 10:01:27.575053+08
4e2dc1d7-df43-4f35-b754-3638eccdef62	AUD	CNY	2016-11-30	5.12250000	historical_import	2025-11-09 10:18:48.413033+08
142cf0c9-8372-4c2e-9f28-df6f78000cdf	CAD	CNY	2016-11-30	5.14330000	historical_import	2025-11-09 10:18:48.413254+08
ebc68e82-2b82-4730-a7b8-a3fb76fb9eeb	CHF	CNY	2016-11-30	6.77640000	historical_import	2025-11-09 10:18:48.413507+08
495fa3c4-31e3-4b0e-b575-ab3b1e7f9230	INR	CNY	2016-11-30	0.10047000	historical_import	2025-11-09 10:18:48.413747+08
4ae7d54f-ac6e-4735-bb3a-36058c2e9d7c	USD	CNY	2016-12-31	6.94450000	historical_import	2025-11-09 10:18:48.413995+08
b98bd07e-5ece-4369-be9f-bfc1b1074531	EUR	CNY	2016-12-31	7.32020000	historical_import	2025-11-09 10:18:48.414419+08
ff8846ea-45b1-4e2e-b5ee-5637f05b7b64	GBP	CNY	2016-12-31	8.54980000	historical_import	2025-11-09 10:18:48.414644+08
c240a09c-b249-4bd7-9ce5-6fb044b5a35d	JPY	CNY	2016-12-31	0.05932000	historical_import	2025-11-09 10:18:48.41497+08
0d9b7fc8-3552-47df-b194-8fcd3c8153b6	HKD	CNY	2016-12-31	0.89543000	historical_import	2025-11-09 10:18:48.415245+08
3e98c5bb-0824-4b02-bff3-37950c2f674d	SGD	CNY	2016-12-31	4.80520000	historical_import	2025-11-09 10:18:48.415453+08
5be0c0c8-582d-4274-a2b3-f7829e4fd944	AUD	CNY	2016-12-31	5.01520000	historical_import	2025-11-09 10:18:48.415628+08
b6353965-4c73-412f-9a8d-5e920572eb20	CAD	CNY	2016-12-31	5.15940000	historical_import	2025-11-09 10:18:48.415793+08
254c165e-6855-4460-a2b5-ce4cd7fa8130	CHF	CNY	2016-12-31	6.81650000	historical_import	2025-11-09 10:18:48.415945+08
d5257351-d9e2-401f-b194-c2098034c252	INR	CNY	2016-12-31	0.10225000	historical_import	2025-11-09 10:18:48.416099+08
fc2b19e1-32c2-4b06-b6da-017e31a05270	USD	CNY	2017-01-31	6.87770000	historical_import	2025-11-09 10:18:48.416244+08
b38ee1e5-fa5c-4d2a-8fd3-c7d9a47d2ce7	EUR	CNY	2017-01-31	7.39700000	historical_import	2025-11-09 10:18:48.416436+08
5b070de8-e7cf-4f28-aed8-5d94c0ccaa38	GBP	CNY	2017-01-31	8.59070000	historical_import	2025-11-09 10:18:48.416782+08
d7d7fc83-d0f1-4c62-9ea6-f9b93bdad106	JPY	CNY	2017-01-31	0.06066000	historical_import	2025-11-09 10:18:48.416946+08
6117b25d-9182-4355-a8cd-08df15c34ca1	HKD	CNY	2017-01-31	0.88655000	historical_import	2025-11-09 10:18:48.417101+08
13690277-7b5d-4f12-8e98-6fc36ee13d1a	SGD	CNY	2017-01-31	4.86610000	historical_import	2025-11-09 10:18:48.417255+08
8ea3d18e-d60f-4d0e-a90a-7a966bf0db0e	AUD	CNY	2017-01-31	5.20990000	historical_import	2025-11-09 10:18:48.417408+08
8e425d56-448e-4a1e-8e25-9e916f167a6b	CAD	CNY	2017-01-31	5.26250000	historical_import	2025-11-09 10:18:48.417595+08
634abf3a-3155-4869-8cfe-1aeee01e1144	CHF	CNY	2017-01-31	6.93380000	historical_import	2025-11-09 10:18:48.417747+08
d8109b82-ff24-4493-a8d6-9fda43e9976c	INR	CNY	2017-01-31	0.10161000	historical_import	2025-11-09 10:18:48.417901+08
23fd6828-6b27-4768-8b12-369c98ec9061	USD	CNY	2017-02-28	6.86800000	historical_import	2025-11-09 10:18:48.418056+08
909277a5-44fb-4713-a6ed-f823c41c7ddb	EUR	CNY	2017-02-28	7.27800000	historical_import	2025-11-09 10:18:48.418219+08
032fc10d-1d48-4c13-bd99-979b7e0d42d7	GBP	CNY	2017-02-28	8.53170000	historical_import	2025-11-09 10:18:48.418467+08
fe48e924-04d4-44ec-afe0-0e7471a29920	JPY	CNY	2017-02-28	0.06125000	historical_import	2025-11-09 10:18:48.41867+08
2fedd0b0-66e3-46e3-b81e-7f8615bb8231	HKD	CNY	2017-02-28	0.88484000	historical_import	2025-11-09 10:18:48.418855+08
b5a85877-9845-4a1f-aaf7-1985b94b8fa9	SGD	CNY	2017-02-28	4.90730000	historical_import	2025-11-09 10:18:48.41901+08
78b70348-7ade-4016-a8fb-f72add68dec5	AUD	CNY	2017-02-28	5.27120000	historical_import	2025-11-09 10:18:48.419176+08
8a25d11a-62c7-4351-9cf6-d237110b9646	CAD	CNY	2017-02-28	5.20450000	historical_import	2025-11-09 10:18:48.419388+08
82981108-6936-4207-8faf-cd39c73ece41	CHF	CNY	2017-02-28	6.83510000	historical_import	2025-11-09 10:18:48.419728+08
1ddc0a45-9da9-448c-b7d8-f64211125f1c	INR	CNY	2017-02-28	0.10305000	historical_import	2025-11-09 10:18:48.419882+08
06f8d8ab-c71d-409a-a4c0-307ebd3458a2	USD	CNY	2017-03-31	6.88820000	historical_import	2025-11-09 10:18:48.420037+08
626e44b6-0250-4430-b14e-32b14f23d8ad	EUR	CNY	2017-03-31	7.36420000	historical_import	2025-11-09 10:18:48.420187+08
87a9f137-0d33-4334-8b3e-465f5d66981e	GBP	CNY	2017-03-31	8.60780000	historical_import	2025-11-09 10:18:48.420364+08
2b58b137-ea4d-459a-9dbe-42e69e3c05f3	JPY	CNY	2017-03-31	0.06160000	historical_import	2025-11-09 10:18:48.42058+08
6fd30f6f-77fd-423a-9d15-3a9ffa9e24a4	HKD	CNY	2017-03-31	0.88646000	historical_import	2025-11-09 10:18:48.420769+08
95d5f49a-bb21-4851-9fcf-54a178c0b7a4	SGD	CNY	2017-03-31	4.92920000	historical_import	2025-11-09 10:18:48.420936+08
02aca7fd-204e-4198-87c7-7d18cee82ba2	AUD	CNY	2017-03-31	5.26690000	historical_import	2025-11-09 10:18:48.421107+08
de6958c3-6ee5-42af-97cd-986313eea7bc	CAD	CNY	2017-03-31	5.16240000	historical_import	2025-11-09 10:18:48.421301+08
aa8d725b-94ab-4d79-a9dd-0ffd34ab5a81	CHF	CNY	2017-03-31	6.88500000	historical_import	2025-11-09 10:18:48.421489+08
22a94a54-b976-4f47-95cb-2a598f786d5f	INR	CNY	2017-03-31	0.10612000	historical_import	2025-11-09 10:18:48.421679+08
19c825a6-2737-4e68-8dd3-630aee83a172	USD	CNY	2017-04-30	6.89540000	historical_import	2025-11-09 10:18:48.421863+08
b5c32e04-d1a1-4a3f-85f0-fbc4f2054d7c	EUR	CNY	2017-04-30	7.53670000	historical_import	2025-11-09 10:18:48.422018+08
6436d300-2d63-48b2-8ac1-7062e83903cc	GBP	CNY	2017-04-30	8.92200000	historical_import	2025-11-09 10:18:48.422173+08
28ab6fcd-d634-48a9-9f43-83ac0bf4f9f8	JPY	CNY	2017-04-30	0.06190000	historical_import	2025-11-09 10:18:48.422338+08
1032f203-d04a-41f9-b27e-9b2d42f25d7e	HKD	CNY	2017-04-30	0.88663000	historical_import	2025-11-09 10:18:48.422487+08
3912f0a4-fe27-42a0-9039-b53c80dcf57b	SGD	CNY	2017-04-30	4.93950000	historical_import	2025-11-09 10:18:48.42267+08
55b740fa-8eb8-4c13-8cfc-a4f3cda5613c	AUD	CNY	2017-04-30	5.15190000	historical_import	2025-11-09 10:18:48.422884+08
39b3bd4c-1e95-4be1-934b-1448faef8de4	CAD	CNY	2017-04-30	5.05340000	historical_import	2025-11-09 10:18:48.423034+08
faad9390-cb8b-4984-ad5c-ae0d4c004374	CHF	CNY	2017-04-30	6.95850000	historical_import	2025-11-09 10:18:48.423211+08
73fef3d5-2140-4cf6-a085-d35fff8fc4ef	INR	CNY	2017-04-30	0.10727000	historical_import	2025-11-09 10:18:48.423376+08
b4cd0a0c-1636-4df9-9456-e46133964af9	USD	CNY	2017-05-31	6.81300000	historical_import	2025-11-09 10:18:48.423532+08
f70df52d-d792-4a1c-ae87-5764b892721e	EUR	CNY	2017-05-31	7.64490000	historical_import	2025-11-09 10:18:48.423702+08
f72412c5-280a-403a-a7e6-e41c91b70f2a	GBP	CNY	2017-05-31	8.75050000	historical_import	2025-11-09 10:18:48.423859+08
4c50d52d-0611-4e06-979d-a1cf838ad817	JPY	CNY	2017-05-31	0.06145000	historical_import	2025-11-09 10:18:48.424011+08
44d9d808-327f-4995-b9a6-6b6e3ef5b2fc	HKD	CNY	2017-05-31	0.87449000	historical_import	2025-11-09 10:18:48.424177+08
27a0c160-592f-4db3-b40e-c563d9dec1a1	SGD	CNY	2017-05-31	4.92650000	historical_import	2025-11-09 10:18:48.42435+08
6952c279-1471-43e3-b202-6815901cd483	AUD	CNY	2017-05-31	5.07830000	historical_import	2025-11-09 10:18:48.424552+08
764cc7f9-4d7e-453f-b93d-5a540d788c7f	CAD	CNY	2017-05-31	5.06020000	historical_import	2025-11-09 10:18:48.425067+08
6c04e436-98c0-4edf-aa6a-22c6059ed399	CHF	CNY	2017-05-31	7.01620000	historical_import	2025-11-09 10:18:48.425224+08
f559db00-e6e3-4a84-9eee-bd044908680c	INR	CNY	2017-05-31	0.10569000	historical_import	2025-11-09 10:18:48.425375+08
40a97f00-4327-46fa-8ae6-7a355438d682	USD	CNY	2017-06-30	6.78100000	historical_import	2025-11-09 10:18:48.425534+08
45e7c7bd-65bf-4ada-9bc2-bb0fa3ed5475	EUR	CNY	2017-06-30	7.73850000	historical_import	2025-11-09 10:18:48.42569+08
291d2647-ca95-4d5c-b1a6-1fb42ca30cf8	GBP	CNY	2017-06-30	8.80050000	historical_import	2025-11-09 10:18:48.425879+08
7ef56590-5bce-4de2-b0d6-e504067a5ba7	JPY	CNY	2017-06-30	0.06058000	historical_import	2025-11-09 10:18:48.426242+08
1bd7ef06-f055-44df-84c8-7d4d47a557c2	HKD	CNY	2017-06-30	0.86883000	historical_import	2025-11-09 10:18:48.426425+08
93fd6836-8ef4-40c7-8f59-d53bf9248aa5	SGD	CNY	2017-06-30	4.92580000	historical_import	2025-11-09 10:18:48.426586+08
c7a75a54-4cba-4edc-858a-09f70ef6f64a	AUD	CNY	2017-06-30	5.21080000	historical_import	2025-11-09 10:18:48.426733+08
dd7440ed-09db-4478-a383-4361312d9057	CAD	CNY	2017-06-30	5.23400000	historical_import	2025-11-09 10:18:48.426906+08
1fe3c06e-b8f2-461b-8e5c-fe3b85f1f69e	CHF	CNY	2017-06-30	7.08010000	historical_import	2025-11-09 10:18:48.427074+08
d53f74a4-3b1c-4922-b16a-214b7c97e891	INR	CNY	2017-06-30	0.10494000	historical_import	2025-11-09 10:18:48.427543+08
12a1d35d-b382-4575-b96a-8cd0c9bb35e5	USD	CNY	2017-07-31	6.72770000	historical_import	2025-11-09 10:18:48.427708+08
982b9c78-78c0-42a5-aaa3-bdf198a98e6a	EUR	CNY	2017-07-31	7.88960000	historical_import	2025-11-09 10:18:48.427857+08
35aea5e0-ee10-49db-9a2e-8232f549c4a4	GBP	CNY	2017-07-31	8.82310000	historical_import	2025-11-09 10:18:48.428014+08
de27b175-85db-4768-9c8c-d99ce1f75f16	JPY	CNY	2017-07-31	0.06083000	historical_import	2025-11-09 10:18:48.428176+08
d19d60ac-f214-47a7-95b5-e2f3809cbaa7	HKD	CNY	2017-07-31	0.86133000	historical_import	2025-11-09 10:18:48.428339+08
4097f17c-cf04-43d8-a61c-5d5f75bf0692	SGD	CNY	2017-07-31	4.95640000	historical_import	2025-11-09 10:18:48.428489+08
fbeede96-73c8-4609-831c-f3b06e327761	AUD	CNY	2017-07-31	5.36230000	historical_import	2025-11-09 10:18:48.42864+08
4b5484de-510b-4e0f-92b5-e779ea924d14	CAD	CNY	2017-07-31	5.39460000	historical_import	2025-11-09 10:18:48.428783+08
254f1332-6411-40f9-b88e-961badbf547b	CHF	CNY	2017-07-31	6.94570000	historical_import	2025-11-09 10:18:48.428936+08
1552c7ef-4473-4207-85c6-146c346c05dd	INR	CNY	2017-07-31	0.10482000	historical_import	2025-11-09 10:18:48.429259+08
075837fd-d3a0-44ee-a648-e44a371645a2	USD	CNY	2017-08-31	6.60120000	historical_import	2025-11-09 10:18:48.429412+08
10bd1916-b476-44b9-81a1-7b4fa85d5e4d	EUR	CNY	2017-08-31	7.80590000	historical_import	2025-11-09 10:18:48.429554+08
533631c2-b14d-475f-b013-ea7c0bc7324c	GBP	CNY	2017-08-31	8.48720000	historical_import	2025-11-09 10:18:48.429722+08
392394fd-d0c5-497c-a93e-6e393be025c4	JPY	CNY	2017-08-31	0.05967000	historical_import	2025-11-09 10:18:48.429882+08
945c5e68-3327-4caa-bc95-9e321666dd14	HKD	CNY	2017-08-31	0.84364000	historical_import	2025-11-09 10:18:48.430036+08
24b2b457-043a-44a8-8f20-bbc70d88fdfc	SGD	CNY	2017-08-31	4.85020000	historical_import	2025-11-09 10:18:48.430182+08
bbea737c-3d1c-4859-ba01-186b14611170	AUD	CNY	2017-08-31	5.19840000	historical_import	2025-11-09 10:18:48.430333+08
b957d58f-fd4d-45ac-b0dc-eabf7a657772	CAD	CNY	2017-08-31	5.21440000	historical_import	2025-11-09 10:18:48.430492+08
f9ff09b3-207d-4a87-971c-1e2ba76bd17f	CHF	CNY	2017-08-31	6.81980000	historical_import	2025-11-09 10:18:48.4307+08
bbfd6fae-70df-4304-b6f4-ec26b436d865	INR	CNY	2017-08-31	0.10325000	historical_import	2025-11-09 10:18:48.430865+08
5d6171cf-edbc-47a2-9c95-8b892db3aa41	USD	CNY	2017-09-30	6.65200000	historical_import	2025-11-09 10:18:48.431021+08
5a506c84-8560-4be5-a8d8-11e92c4567d4	EUR	CNY	2017-09-30	7.85340000	historical_import	2025-11-09 10:18:48.431181+08
49d04ede-4c19-47f4-a616-9a72205db7c8	GBP	CNY	2017-09-30	8.90630000	historical_import	2025-11-09 10:18:48.431373+08
eebee763-8a54-4d9b-b548-6abe29e7eb7a	JPY	CNY	2017-09-30	0.05913000	historical_import	2025-11-09 10:18:48.431531+08
d40d0ed6-b8e1-4b20-8e51-453b4c9580d7	HKD	CNY	2017-09-30	0.85165000	historical_import	2025-11-09 10:18:48.431691+08
5dbe394c-2269-4ed0-8f05-fd53abb4bc19	SGD	CNY	2017-09-30	4.89890000	historical_import	2025-11-09 10:18:48.431989+08
a2abfb6c-3ed1-4d0a-9325-c5b5c4cdd81b	AUD	CNY	2017-09-30	5.20960000	historical_import	2025-11-09 10:18:48.432176+08
0fef9b1b-3d04-41a6-85ae-01d964adbf64	CAD	CNY	2017-09-30	5.34720000	historical_import	2025-11-09 10:18:48.432354+08
9e36dd92-e33b-495f-af23-8937b74a37c1	CHF	CNY	2017-09-30	6.85470000	historical_import	2025-11-09 10:18:48.432614+08
8d6439e3-6d0e-43ad-ab51-685af70ed38b	INR	CNY	2017-09-30	0.10190000	historical_import	2025-11-09 10:18:48.432928+08
1c278910-f050-4b7c-a1f3-a8012d3e76ee	USD	CNY	2017-10-31	6.63150000	historical_import	2025-11-09 10:18:48.433095+08
d2c5359f-3701-4da3-bd58-5cf6c5c33afe	EUR	CNY	2017-10-31	7.71770000	historical_import	2025-11-09 10:18:48.433252+08
6fb329e1-4989-4a69-ab80-2c8cb88a5fe4	GBP	CNY	2017-10-31	8.78480000	historical_import	2025-11-09 10:18:48.43341+08
88170618-623a-4b02-b191-c36b666bb7b3	JPY	CNY	2017-10-31	0.05847000	historical_import	2025-11-09 10:18:48.433567+08
8dbbfb83-79e3-4874-ba15-fea3fd663519	HKD	CNY	2017-10-31	0.85026000	historical_import	2025-11-09 10:18:48.433781+08
d1542e19-89f5-4c20-9cda-ceb6f4cfbbc7	SGD	CNY	2017-10-31	4.86610000	historical_import	2025-11-09 10:18:48.433964+08
80638608-e73a-4462-9cfb-2ec3990dc0ca	AUD	CNY	2017-10-31	5.07410000	historical_import	2025-11-09 10:18:48.434117+08
d04b9564-29f0-4d79-bc3f-cad90b700856	CAD	CNY	2017-10-31	5.14380000	historical_import	2025-11-09 10:18:48.434271+08
3e84a98c-1819-44a7-8b34-30d2401917e9	CHF	CNY	2017-10-31	6.64060000	historical_import	2025-11-09 10:18:48.434578+08
0f677fa0-f458-433d-8b1f-7acb0ab17bbb	INR	CNY	2017-10-31	0.10242000	historical_import	2025-11-09 10:18:48.434733+08
bf9d3cc1-6f21-49c4-8321-e46a52ff7a34	USD	CNY	2017-11-30	6.61470000	historical_import	2025-11-09 10:18:48.434888+08
b495b171-5541-4400-b517-eb0727c904d1	EUR	CNY	2017-11-30	7.83770000	historical_import	2025-11-09 10:18:48.435041+08
b98d2912-bff9-4750-9008-8d72658d4844	GBP	CNY	2017-11-30	8.90800000	historical_import	2025-11-09 10:18:48.435188+08
72375c55-f3aa-415f-abb8-a3335f5504e2	JPY	CNY	2017-11-30	0.05889000	historical_import	2025-11-09 10:18:48.435333+08
c6a47c69-c666-4a45-9e08-8f7373ffb44e	HKD	CNY	2017-11-30	0.84710000	historical_import	2025-11-09 10:18:48.435485+08
3679ef1a-f047-4564-a2fe-cb1001a19de2	SGD	CNY	2017-11-30	4.90290000	historical_import	2025-11-09 10:18:48.435636+08
88d025e4-834d-47a7-bec0-2f45a9801b01	AUD	CNY	2017-11-30	5.00520000	historical_import	2025-11-09 10:18:48.43578+08
9f53b13e-b511-475c-8751-cf2ec56c2bea	CAD	CNY	2017-11-30	5.13380000	historical_import	2025-11-09 10:18:48.435931+08
dd5e936a-9b33-4a02-bc70-72f41329c9b7	CHF	CNY	2017-11-30	6.69950000	historical_import	2025-11-09 10:18:48.436079+08
d8c27a05-9860-4953-8bf4-0918805f5243	INR	CNY	2017-11-30	0.10260000	historical_import	2025-11-09 10:18:48.436223+08
c618b787-808a-4df3-8734-571f2367feb2	USD	CNY	2017-12-31	6.50750000	historical_import	2025-11-09 10:18:48.436531+08
aa42da29-eb3b-4e1f-a597-40f04f83e9d4	EUR	CNY	2017-12-31	7.80440000	historical_import	2025-11-09 10:18:48.436706+08
21f30083-d653-4882-b365-272babd5ad54	GBP	CNY	2017-12-31	8.79640000	historical_import	2025-11-09 10:18:48.436898+08
ee8cf806-8aa8-4a58-a8c3-76cbbe017672	JPY	CNY	2017-12-31	0.05781000	historical_import	2025-11-09 10:18:48.437156+08
5a16869b-1b70-47c1-89f0-28bdcb87f098	HKD	CNY	2017-12-31	0.83274000	historical_import	2025-11-09 10:18:48.437477+08
08150033-c5b8-4df6-9276-05853917ae40	SGD	CNY	2017-12-31	4.87040000	historical_import	2025-11-09 10:18:48.437766+08
bfee6ee3-7d64-47fd-b8a3-6ea8ac8eb59a	AUD	CNY	2017-12-31	5.08560000	historical_import	2025-11-09 10:18:48.438006+08
d7e04b6c-296e-4a72-8bc5-6b62716889d7	CAD	CNY	2017-12-31	5.18940000	historical_import	2025-11-09 10:18:48.438229+08
8deebc07-485d-4ff5-9b2d-0c1822322b5a	CHF	CNY	2017-12-31	6.66930000	historical_import	2025-11-09 10:18:48.438412+08
f69f0477-b2cb-486d-a8ab-16e4b902c945	INR	CNY	2017-12-31	0.10188000	historical_import	2025-11-09 10:18:48.438659+08
aaf0929f-5197-40ac-af63-aa7506e5220c	USD	CNY	2018-01-31	6.28880000	historical_import	2025-11-09 10:18:48.438948+08
b6472d98-3e33-4b61-9819-e1b4cc94f006	EUR	CNY	2018-01-31	7.83400000	historical_import	2025-11-09 10:18:48.439208+08
f728ac0b-b453-4b1a-a0d2-b3a68929bd78	GBP	CNY	2018-01-31	8.91140000	historical_import	2025-11-09 10:18:48.439406+08
d1d44e31-66f3-4629-94d3-4614bcc2db60	JPY	CNY	2018-01-31	0.05777000	historical_import	2025-11-09 10:18:48.439596+08
a958e097-fe25-43b9-8a23-312e90abcd35	HKD	CNY	2018-01-31	0.80420000	historical_import	2025-11-09 10:18:48.439791+08
c3fbfe42-0783-4863-8d21-6c6bb456bf78	SGD	CNY	2018-01-31	4.80970000	historical_import	2025-11-09 10:18:48.439979+08
e25772e1-7c83-44c3-a284-e672eece942f	AUD	CNY	2018-01-31	5.10130000	historical_import	2025-11-09 10:18:48.440389+08
c0ad0bb7-b08f-48e1-94cd-d252132ab6a5	CAD	CNY	2018-01-31	5.12360000	historical_import	2025-11-09 10:18:48.440904+08
d71dc60c-5443-40e6-a9bc-29e341be6475	CHF	CNY	2018-01-31	6.73540000	historical_import	2025-11-09 10:18:48.441136+08
fe3ffd6b-49b8-4edf-8179-a89f918e985e	INR	CNY	2018-01-31	0.09894000	historical_import	2025-11-09 10:18:48.441348+08
6699f12a-9a76-461a-a0ff-b5cd00f9eb2d	USD	CNY	2018-02-28	6.32760000	historical_import	2025-11-09 10:18:48.441531+08
ab6030ec-d906-4867-878f-d9394d39f722	EUR	CNY	2018-02-28	7.72850000	historical_import	2025-11-09 10:18:48.441695+08
b385fb0c-2805-4f42-afac-a09c07ba4f0d	GBP	CNY	2018-02-28	8.74120000	historical_import	2025-11-09 10:18:48.441914+08
29a71680-0048-479a-a134-c3b773aa90c8	JPY	CNY	2018-02-28	0.05912000	historical_import	2025-11-09 10:18:48.4421+08
c784e828-cd39-4803-beac-97ac187b5708	HKD	CNY	2018-02-28	0.80846000	historical_import	2025-11-09 10:18:48.442271+08
740b284d-7aad-47f5-91ea-e53aaac28f8d	SGD	CNY	2018-02-28	4.78190000	historical_import	2025-11-09 10:18:48.442433+08
e2f35c9c-69a3-4c28-9608-b9e1eab09275	AUD	CNY	2018-02-28	4.94240000	historical_import	2025-11-09 10:18:48.442635+08
f2d38112-1d0c-4ae1-b0ca-d7e770ae892a	CAD	CNY	2018-02-28	4.95160000	historical_import	2025-11-09 10:18:48.442808+08
9fa033d3-b769-465e-90a3-440f25a4ca8a	CHF	CNY	2018-02-28	6.70880000	historical_import	2025-11-09 10:18:48.442987+08
96e6feaa-9880-4880-9e26-95488748e496	INR	CNY	2018-02-28	0.09706000	historical_import	2025-11-09 10:18:48.443163+08
bac652a3-21df-4822-b1fd-db55bf1912d4	USD	CNY	2018-03-31	6.28750000	historical_import	2025-11-09 10:18:48.443318+08
27a471fb-43da-4a04-80ce-401c92594b6f	EUR	CNY	2018-03-31	7.74680000	historical_import	2025-11-09 10:18:48.443463+08
0212035e-adf0-4802-99b1-78ed2e4bf132	GBP	CNY	2018-03-31	8.85450000	historical_import	2025-11-09 10:18:48.443626+08
8ca7c7f8-0ae6-43a8-9ab9-b380aabe62f6	JPY	CNY	2018-03-31	0.05907000	historical_import	2025-11-09 10:18:48.443787+08
9bbac545-11cb-485e-8bd4-f155bdef3007	HKD	CNY	2018-03-31	0.80115000	historical_import	2025-11-09 10:18:48.443942+08
38a515bd-66fe-44ff-91d1-5974af6fedab	SGD	CNY	2018-03-31	4.79440000	historical_import	2025-11-09 10:18:48.444092+08
86fd9a8f-3a9b-4696-afc7-591f6951e485	AUD	CNY	2018-03-31	4.83090000	historical_import	2025-11-09 10:18:48.444248+08
4158cb34-7f3a-4e71-8967-4fc0deb84d1e	CAD	CNY	2018-03-31	4.87370000	historical_import	2025-11-09 10:18:48.444456+08
c4873ad4-f018-4441-b148-66e6e7f12241	INR	CNY	2018-03-31	0.09647000	historical_import	2025-11-09 10:18:48.444632+08
0630ac23-1003-4e9e-8f8f-96537fee9c94	USD	CNY	2018-04-30	6.33940000	historical_import	2025-11-09 10:18:48.444826+08
5c1c80d6-207d-4afe-87d3-a1b19d6c6456	GBP	CNY	2018-04-30	8.70550000	historical_import	2025-11-09 10:18:48.444985+08
21afb216-7096-4d8a-9f31-7786e6446963	JPY	CNY	2018-04-30	0.05796000	historical_import	2025-11-09 10:18:48.445134+08
40761fe2-bddf-422d-a2de-ac79607173c3	HKD	CNY	2018-04-30	0.80773000	historical_import	2025-11-09 10:18:48.445289+08
5cfba312-fa34-4384-8ab0-201ce3d8a307	SGD	CNY	2018-04-30	4.78110000	historical_import	2025-11-09 10:18:48.445436+08
aecded32-77d3-4242-bac5-955478b886bb	AUD	CNY	2018-04-30	4.78200000	historical_import	2025-11-09 10:18:48.445604+08
da173cb6-7e95-46e9-9faa-c25f940453fb	CAD	CNY	2018-04-30	4.92690000	historical_import	2025-11-09 10:18:48.445757+08
8437a9d9-0db6-425b-b2dd-b1c63d416fce	CHF	CNY	2018-04-30	6.39820000	historical_import	2025-11-09 10:18:48.446098+08
9441928b-456c-4745-8270-cdfd046300ca	INR	CNY	2018-04-30	0.09551000	historical_import	2025-11-09 10:18:48.446245+08
bb16abef-3fed-4da7-b76f-e6397fed0eb1	USD	CNY	2018-05-31	6.40660000	historical_import	2025-11-09 10:18:48.446401+08
7903e9c5-e140-4fd9-882f-ab9b9c48a636	EUR	CNY	2018-05-31	7.49510000	historical_import	2025-11-09 10:18:48.446573+08
3c5a25ab-cb6f-4d02-ad43-758d721a12d5	GBP	CNY	2018-05-31	8.54820000	historical_import	2025-11-09 10:18:48.446767+08
8af82d2c-2b09-44ae-8f79-f623beaaba1e	JPY	CNY	2018-05-31	0.05886000	historical_import	2025-11-09 10:18:48.446913+08
196141a8-0f6d-436c-8fec-d21ad915d88a	HKD	CNY	2018-05-31	0.81630000	historical_import	2025-11-09 10:18:48.447067+08
77f3f740-2e10-4b80-a0f3-e2f1634a0789	SGD	CNY	2018-05-31	4.78740000	historical_import	2025-11-09 10:18:48.447207+08
ebaf5976-f6a7-4ced-a8fa-77ef81bdccce	AUD	CNY	2018-05-31	4.86250000	historical_import	2025-11-09 10:18:48.447348+08
d895fcbd-7bc5-472d-b8b4-a20af49b541e	CAD	CNY	2018-05-31	4.98410000	historical_import	2025-11-09 10:18:48.447498+08
6248be92-a947-49a0-8d26-05b5bb1176d4	CHF	CNY	2018-05-31	6.50280000	historical_import	2025-11-09 10:18:48.447647+08
a9163ad6-4d48-47d5-af45-d3c69ca741c8	INR	CNY	2018-05-31	0.09511000	historical_import	2025-11-09 10:18:48.4478+08
66c8e687-b0c1-46bb-a7bf-910270f31446	USD	CNY	2018-06-30	6.61950000	historical_import	2025-11-09 10:18:48.448078+08
0a368c53-b6bd-4e88-8472-9242607943cb	EUR	CNY	2018-06-30	7.71700000	historical_import	2025-11-09 10:18:48.448289+08
90d861fc-af45-4ca0-bf70-90318708d72d	GBP	CNY	2018-06-30	8.70940000	historical_import	2025-11-09 10:18:48.448465+08
4b1ddc78-4f61-402a-8d68-de1c59baf56f	JPY	CNY	2018-06-30	0.05980000	historical_import	2025-11-09 10:18:48.448624+08
5258dedd-53c6-4304-945f-595efaa3b053	HKD	CNY	2018-06-30	0.84368000	historical_import	2025-11-09 10:18:48.448803+08
9b93d1cd-c8b7-4da2-a996-008eda6327b2	SGD	CNY	2018-06-30	4.85470000	historical_import	2025-11-09 10:18:48.448969+08
77355bb5-740e-4cb1-a8f4-276b457aee52	AUD	CNY	2018-06-30	4.88820000	historical_import	2025-11-09 10:18:48.449125+08
a585ba4a-ba6e-415b-88a4-a4160b648c33	CAD	CNY	2018-06-30	4.99740000	historical_import	2025-11-09 10:18:48.449279+08
1fcf1719-1eea-4216-b785-1f49ddc5f89c	CHF	CNY	2018-06-30	6.67040000	historical_import	2025-11-09 10:18:48.449432+08
32b3c497-b7a7-4c75-9410-a52084770c1a	USD	CNY	2018-07-31	6.83180000	historical_import	2025-11-09 10:18:48.449581+08
626b1acf-5f19-4f63-b6f5-4336101fc862	GBP	CNY	2018-07-31	8.98660000	historical_import	2025-11-09 10:18:48.449745+08
fab4acc1-4f5e-4737-bb54-a3d77534f1e5	JPY	CNY	2018-07-31	0.06128000	historical_import	2025-11-09 10:18:48.449894+08
8471fb73-f644-4e60-a50c-94bed3a585fb	HKD	CNY	2018-07-31	0.87042000	historical_import	2025-11-09 10:18:48.450031+08
ac30a5fc-37aa-4e8e-9e9a-cbe7e835bb55	CAD	CNY	2018-07-31	5.24110000	historical_import	2025-11-09 10:18:48.450187+08
7c0b1eb8-8ed8-42ed-8e2d-bd7635148bda	USD	CNY	2018-08-31	6.83750000	historical_import	2025-11-09 10:18:48.450518+08
0303fd80-2d13-41cf-9210-2575d599b5c9	GBP	CNY	2018-08-31	8.87720000	historical_import	2025-11-09 10:18:48.450655+08
6a0f9e32-f816-4742-b556-582ebaca09ca	HKD	CNY	2018-08-31	0.87109000	historical_import	2025-11-09 10:18:48.450802+08
57d8f9da-0caa-4090-8083-77f08ef105fb	SGD	CNY	2018-08-31	4.98990000	historical_import	2025-11-09 10:18:48.450953+08
25941539-dd26-48da-b84b-b54f957b2dc2	USD	CNY	2018-09-30	6.88170000	historical_import	2025-11-09 10:18:48.451105+08
063b8252-fe1b-4bd2-837e-3bfc66a13da7	SGD	CNY	2018-09-30	5.02950000	historical_import	2025-11-09 10:18:48.451251+08
5249bf6d-b663-4ca4-a50f-244d00be8a2b	AUD	CNY	2018-09-30	4.96400000	historical_import	2025-11-09 10:18:48.4514+08
396d8f60-3e02-40e2-9f55-fca319a4cbb7	CAD	CNY	2018-09-30	5.28820000	historical_import	2025-11-09 10:18:48.451562+08
36a7d30b-a131-4bba-b36e-7a9315248b16	USD	CNY	2018-10-31	6.97430000	historical_import	2025-11-09 10:18:48.451716+08
3b594418-31b5-472e-ba63-f7b848c4a7c6	CAD	CNY	2018-10-31	5.31330000	historical_import	2025-11-09 10:18:48.452069+08
d5eb9a93-fa21-4ecb-bd7b-c5bc086bced1	USD	CNY	2018-11-30	6.94580000	historical_import	2025-11-09 10:18:48.452237+08
c9678565-7722-4125-ba97-038231261c45	USD	CNY	2018-12-31	6.87780000	historical_import	2025-11-09 10:18:48.45239+08
6e0b380d-8252-47d5-9bda-1a8bb1c93ba1	USD	CNY	2019-01-31	6.70350000	historical_import	2025-11-09 10:18:48.452532+08
2500081f-ac8b-4bbd-a379-030e2caf19ad	USD	CNY	2019-02-28	6.68440000	historical_import	2025-11-09 10:18:48.452674+08
8b1f4834-294c-4553-9d6a-640d3851c349	USD	CNY	2019-03-31	6.71090000	historical_import	2025-11-09 10:18:48.452823+08
0a7acf3d-2c6d-45cf-bd0f-d8c84aa68776	USD	CNY	2019-04-30	6.73390000	historical_import	2025-11-09 10:18:48.452975+08
c89227a5-e428-4b29-bc9e-cfdc0f625870	USD	CNY	2019-05-31	6.90920000	historical_import	2025-11-09 10:18:48.45313+08
3bfb802b-6942-4442-bd86-1ab9eb1961f7	USD	CNY	2019-06-30	6.87040000	historical_import	2025-11-09 10:18:48.453286+08
52beb4e0-e08f-4dbb-961c-731271ebf828	USD	CNY	2019-07-31	6.88220000	historical_import	2025-11-09 10:18:48.453435+08
a7bce308-72dd-4827-8136-f3f8ee40cb38	USD	CNY	2019-08-31	7.15010000	historical_import	2025-11-09 10:18:48.453599+08
bd564858-b1ac-44f6-a8de-453b306c0808	HKD	CNY	2019-08-31	0.91171000	historical_import	2025-11-09 10:18:48.453748+08
7e99afbb-8fa0-49a6-bea5-88b308fe418d	SGD	CNY	2019-08-31	5.15330000	historical_import	2025-11-09 10:18:48.453908+08
063aa783-4a7b-4e85-b099-15f8be82715a	AUD	CNY	2019-08-31	4.81210000	historical_import	2025-11-09 10:18:48.454063+08
655f6af3-9d13-44b1-8b31-213303e14a66	CHF	CNY	2019-08-31	7.23330000	historical_import	2025-11-09 10:18:48.454233+08
e8685213-0cec-43c1-8772-b88d00928fbd	USD	CNY	2019-09-30	7.14340000	historical_import	2025-11-09 10:18:48.454404+08
7204e787-8335-4bdd-8d8a-6abf387c7bfe	GBP	CNY	2019-09-30	8.78190000	historical_import	2025-11-09 10:18:48.454559+08
44f1c4b9-fecc-43f6-a1e6-5ace45f7b8a3	AUD	CNY	2019-09-30	4.82350000	historical_import	2025-11-09 10:18:48.454712+08
756c6c90-4f60-4dab-a693-98eb1d377fc9	INR	CNY	2019-09-30	0.10081000	historical_import	2025-11-09 10:18:48.454848+08
9822c8cc-2141-4eb6-a06e-699176e336de	USD	CNY	2019-10-31	7.04140000	historical_import	2025-11-09 10:18:48.455+08
608ab141-6134-4309-9d84-b4d1fe79105f	GBP	CNY	2019-10-31	9.11850000	historical_import	2025-11-09 10:18:48.455417+08
0897b481-e1da-4c26-82b6-2ed99f6335b9	JPY	CNY	2019-10-31	0.06505000	historical_import	2025-11-09 10:18:48.455632+08
6abbe92e-9571-4f2f-a14a-6d97f0664384	USD	CNY	2019-11-30	7.02710000	historical_import	2025-11-09 10:18:48.456019+08
095ee77f-af48-4cfc-b22a-c2a8d7f3071d	USD	CNY	2019-12-31	6.96150000	historical_import	2025-11-09 10:18:48.45642+08
a6488787-0878-4763-829a-ccc84ff0d10d	SGD	CNY	2019-12-31	5.17540000	historical_import	2025-11-09 10:18:48.456715+08
503976cc-9770-4b4d-b763-f8480d72f4bb	USD	CNY	2020-02-29	6.98390000	historical_import	2025-11-09 10:18:48.456897+08
060f2f17-1f96-4243-a2b9-4e0bfdafbd4d	USD	CNY	2020-03-31	7.09970000	historical_import	2025-11-09 10:18:48.457081+08
10ca142f-ee74-42f2-aee4-c17d37248a57	USD	CNY	2020-04-30	7.04900000	historical_import	2025-11-09 10:18:48.457245+08
a16b866a-4c74-4380-8fc5-f931a4b4bba1	USD	CNY	2020-05-31	7.13510000	historical_import	2025-11-09 10:18:48.457408+08
2d92f365-52a3-4133-82e2-d794289b1d41	USD	CNY	2020-06-30	7.07440000	historical_import	2025-11-09 10:18:48.45756+08
946d4ccc-ee0d-47d8-a6d0-5b98e7506816	USD	CNY	2020-07-31	6.97480000	historical_import	2025-11-09 10:18:48.457715+08
e5ff4099-6c1a-48bd-98f3-e80af95040c5	USD	CNY	2020-08-31	6.84350000	historical_import	2025-11-09 10:18:48.45786+08
c892db89-94da-4b4f-9c3a-c9b7457cc9f6	USD	CNY	2020-09-30	6.80900000	historical_import	2025-11-09 10:18:48.458004+08
a8eb1e59-78b2-44f7-8bd4-254193d2b860	USD	CNY	2020-10-31	6.68130000	historical_import	2025-11-09 10:18:48.458158+08
2dd24a38-67e2-456c-8047-0f9a9019226f	USD	CNY	2020-11-30	6.57750000	historical_import	2025-11-09 10:18:48.458313+08
8fbd3426-f56f-468f-a9b8-9279d897fc22	USD	CNY	2020-12-31	6.53780000	historical_import	2025-11-09 10:18:48.458461+08
07c99749-6727-42bc-a9d3-cbbbff05553f	USD	CNY	2021-01-31	6.43100000	historical_import	2025-11-09 10:18:48.458607+08
6a8ac654-c671-4b7c-8f44-e0d070a9d64d	USD	CNY	2021-02-28	6.46690000	historical_import	2025-11-09 10:18:48.45876+08
d8602b35-4237-43ba-9455-492638f3efb7	USD	CNY	2021-03-31	6.55110000	historical_import	2025-11-09 10:18:48.458901+08
8f574d4f-54ba-4989-81c3-55fba3db8911	USD	CNY	2021-04-30	6.46700000	historical_import	2025-11-09 10:18:48.459045+08
fec5cd5d-9db7-4fd4-b832-e2ce61effef4	USD	CNY	2021-05-31	6.37010000	historical_import	2025-11-09 10:18:48.459183+08
a6b1b0fd-e677-43ef-827e-54cadfcd10b2	USD	CNY	2021-06-30	6.45760000	historical_import	2025-11-09 10:18:48.459327+08
0c8ea028-0169-4d4b-9fa1-972398496788	USD	CNY	2021-07-31	6.46190000	historical_import	2025-11-09 10:18:48.459507+08
240f42ec-af2a-4b19-b232-5ff90b785296	USD	CNY	2021-08-31	6.46150000	historical_import	2025-11-09 10:18:48.459716+08
6bdd30a7-ec5b-45df-aa85-511360ba79a1	USD	CNY	2021-09-30	6.46400000	historical_import	2025-11-09 10:18:48.459871+08
8d0a8314-e217-46ab-acb3-78c28212247d	USD	CNY	2021-10-31	6.39660000	historical_import	2025-11-09 10:18:48.460047+08
3aea5e17-4bf4-4754-bbc0-156b3193eceb	USD	CNY	2021-11-30	6.37110000	historical_import	2025-11-09 10:18:48.460233+08
caf1c4c7-e352-4d8e-a63a-e82fe2a30b9b	USD	CNY	2021-12-31	6.35240000	historical_import	2025-11-09 10:18:48.460453+08
f46b0d49-4458-4f3f-b45e-25c749029612	USD	CNY	2022-01-31	6.36100000	historical_import	2025-11-09 10:18:48.46062+08
07feb10c-6cbb-42c0-a80b-e4973ae2dab8	USD	CNY	2022-02-28	6.31040000	historical_import	2025-11-09 10:18:48.460951+08
6f5e8b77-6c4b-4232-9698-76fa0543aabf	USD	CNY	2022-03-31	6.34200000	historical_import	2025-11-09 10:18:48.461104+08
6f5a8a00-9c46-4cce-8f15-80e0dc08e934	USD	CNY	2022-04-30	6.58830000	historical_import	2025-11-09 10:18:48.461265+08
5e804733-ee57-47df-92e7-e81ef2703936	USD	CNY	2022-05-31	6.66500000	historical_import	2025-11-09 10:18:48.461409+08
c30a766e-3744-41d5-8515-636b81b90d5b	USD	CNY	2022-06-30	6.70300000	historical_import	2025-11-09 10:18:48.461558+08
0fc6ba4e-2e18-4fa7-8b58-6a9950e239e0	USD	CNY	2022-07-31	6.73710000	historical_import	2025-11-09 10:18:48.461699+08
ff46d973-e179-4b83-9f20-f47f0680e266	USD	CNY	2022-08-31	6.89470000	historical_import	2025-11-09 10:18:48.461849+08
1a1496d1-49f8-44d9-8b04-604522b2f98a	USD	CNY	2022-09-30	7.11610000	historical_import	2025-11-09 10:18:48.462004+08
52b1c95b-e295-45dd-8392-5be99cc1f21d	USD	CNY	2022-10-31	7.30080000	historical_import	2025-11-09 10:18:48.462149+08
51feee79-4d24-45ae-bd86-84d895de4760	USD	CNY	2022-11-30	7.07760000	historical_import	2025-11-09 10:18:48.4623+08
18e71525-e752-4645-ab99-381235e303a9	USD	CNY	2022-12-31	6.89870000	historical_import	2025-11-09 10:18:48.462456+08
d6d437cd-6cc0-4bf1-bc11-41340e90b257	USD	CNY	2023-01-31	6.75690000	historical_import	2025-11-09 10:18:48.462604+08
af50043e-2565-46fe-a20d-3ac8305d9d00	USD	CNY	2023-02-28	6.93690000	historical_import	2025-11-09 10:18:48.462743+08
8c1efb75-4366-4c64-99f8-fbb82ccfa978	USD	CNY	2023-03-31	6.87480000	historical_import	2025-11-09 10:18:48.462902+08
6e4f0abf-e494-4b59-82d2-e016122c4625	USD	CNY	2023-04-30	6.91910000	historical_import	2025-11-09 10:18:48.463053+08
54aef536-34fb-4b78-b3c4-3227f20c8a4b	USD	CNY	2023-05-31	7.10720000	historical_import	2025-11-09 10:18:48.463201+08
f32bfaaa-dd5d-4323-b1af-9743c701a6e8	USD	CNY	2023-06-30	7.26880000	historical_import	2025-11-09 10:18:48.463337+08
ade0c490-63b6-4caf-a2e9-8060eb32420a	USD	CNY	2023-07-31	7.14940000	historical_import	2025-11-09 10:18:48.46348+08
b6505c7b-6517-4c1a-835d-046ba50853db	USD	CNY	2023-08-31	7.28710000	historical_import	2025-11-09 10:18:48.463611+08
e9028997-521a-4e40-9584-8bc2cfe8a703	USD	CNY	2023-09-30	7.30150000	historical_import	2025-11-09 10:18:48.463747+08
980254c0-2ab1-4387-be8d-272b9b98cfb2	USD	CNY	2023-10-31	7.31580000	historical_import	2025-11-09 10:18:48.463903+08
557cf98d-bcab-4086-91b8-b28c15c3335c	USD	CNY	2023-11-30	7.13640000	historical_import	2025-11-09 10:18:48.464079+08
6c7a6326-95ce-4310-a5f6-e0b5265141ce	USD	CNY	2023-12-31	7.10490000	historical_import	2025-11-09 10:18:48.464239+08
11cb26a2-5869-4013-b5f8-0142e6d77efc	USD	CNY	2024-01-31	7.17810000	historical_import	2025-11-09 10:18:48.464391+08
fa0062a0-9b9d-4882-a88c-f385ed7b0609	USD	CNY	2024-02-29	7.19450000	historical_import	2025-11-09 10:18:48.464542+08
9e409e8c-ce3e-4736-8dd4-a19ad556213c	USD	CNY	2024-03-31	7.22820000	historical_import	2025-11-09 10:18:48.464694+08
2d1bb8c8-71ca-4993-9e25-86ded9bd7d52	USD	CNY	2024-04-30	7.24100000	historical_import	2025-11-09 10:18:48.464861+08
33774dbd-d350-49a1-a3a0-175fe861a987	USD	CNY	2024-05-31	7.24080000	historical_import	2025-11-09 10:18:48.465144+08
f7d8bc48-8ea5-4af2-928e-5f0894cc121e	USD	CNY	2024-06-30	7.26280000	historical_import	2025-11-09 10:18:48.465309+08
a916dccd-97a6-47fc-8482-23c47242b2de	USD	CNY	2024-07-31	7.22150000	historical_import	2025-11-09 10:18:48.46571+08
38ad27c4-d352-410f-825d-36d780e482a0	USD	CNY	2024-08-31	7.08800000	historical_import	2025-11-09 10:18:48.465872+08
7c39a4a2-df46-416c-80de-a0ac92e97bba	USD	CNY	2024-09-30	7.01240000	historical_import	2025-11-09 10:18:48.466028+08
c053aad6-fc71-4a25-b334-3fc40c4a4bc2	USD	CNY	2024-10-31	7.11600000	historical_import	2025-11-09 10:18:48.46618+08
b0e8db0e-0fcb-46b9-a5ba-a2e8989a53da	USD	CNY	2024-11-30	7.24140000	historical_import	2025-11-09 10:18:48.466324+08
33e655f5-1598-4d96-a552-b9d05a199af2	USD	CNY	2024-12-31	7.29940000	historical_import	2025-11-09 10:18:48.466477+08
a68cdb33-1d30-48d7-a2d3-5ab749398fb7	USD	CNY	2025-01-31	7.25130000	historical_import	2025-11-09 10:18:48.466628+08
378c446b-adf9-4447-887e-7c92d55ed62f	USD	CNY	2025-02-28	7.27900000	historical_import	2025-11-09 10:18:48.466787+08
abb5fadd-9ec7-451d-9e75-2b8ac7be2907	USD	CNY	2025-03-31	7.25310000	historical_import	2025-11-09 10:18:48.466962+08
f446b0a0-1bc3-4481-94aa-852fa957dfc2	USD	CNY	2025-04-30	7.26590000	historical_import	2025-11-09 10:18:48.467319+08
7b366620-d6fd-489b-bb73-a88a5867ec2d	USD	CNY	2025-05-31	7.19430000	historical_import	2025-11-09 10:18:48.46749+08
500b7f9a-db32-40b0-8602-3e3a0cde3fa9	USD	CNY	2025-06-30	7.16470000	historical_import	2025-11-09 10:18:48.467646+08
a366e8f0-eff2-4490-99a9-f9c2ff8dafa9	USD	CNY	2025-07-31	7.19470000	historical_import	2025-11-09 10:18:48.467789+08
22602695-0fc8-4c4e-a4f0-a76808d0ea8c	USD	CNY	2025-08-31	7.13290000	historical_import	2025-11-09 10:18:48.467934+08
2c3be555-3f35-40e7-bfb3-346002c90686	USD	CNY	2025-09-30	7.11960000	historical_import	2025-11-09 10:18:48.46808+08
dd7f20b2-f501-42c0-af17-6aa34d0898c0	USD	CNY	2025-10-31	7.11620000	historical_import	2025-11-09 10:18:48.46823+08
061915ec-0021-40c8-9c06-18e325e3f282	HKD	CNY	2025-11-09	0.91565000	api	2025-11-09 10:01:25.041952+08
f610750d-2f49-440c-9056-af85efa73f7a	SGD	CNY	2025-11-09	5.46890000	api	2025-11-09 10:01:25.3048+08
\.


--
-- Data for Name: fund_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.fund_details (id, asset_id, fund_type, fund_category, management_fee, custodian_fee, subscription_fee, redemption_fee, nav, nav_date, accumulated_nav, fund_size, inception_date, fund_manager, fund_company, min_investment, min_redemption, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: futures_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.futures_details (id, asset_id, futures_type, underlying_asset, contract_month, contract_size, tick_size, tick_value, trading_hours, last_trading_date, delivery_date, delivery_method, initial_margin, maintenance_margin, margin_rate, position_limit, daily_price_limit, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: liquidity_tags; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.liquidity_tags (id, name, description, color, sort_order, is_active, created_at) FROM stdin;
cc893a70-ae7f-47ed-a81e-97486a3b4524	高流动性	大盘股、主要ETF等高流动性资产	#22c55e	1	t	2025-11-07 21:05:53.358078+08
c6ef56b5-8971-47b6-9f3b-c449ff5913d6	中等流动性	中盘股、部分基金等中等流动性资产	#f59e0b	2	t	2025-11-07 21:05:53.358078+08
7a3c492c-3aa4-494d-9cf2-4a46d17f183a	低流动性	小盘股、私募基金等低流动性资产	#ef4444	3	t	2025-11-07 21:05:53.358078+08
f882c8fd-4edb-4667-8ad0-0aa385d5de71	锁定期	有锁定期限制的资产	#8b5cf6	4	t	2025-11-07 21:05:53.358078+08
7003ccf0-d1c5-4fe0-a32a-7f5b4f35a48f	不可交易	暂停交易或退市的资产	#6b7280	5	t	2025-11-07 21:05:53.358078+08
\.


--
-- Data for Name: markets; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.markets (id, code, name, country, currency, timezone, trading_hours, holidays, is_active, created_at, updated_at) FROM stdin;
d1f012ef-ff87-447e-9061-43b77382c43c	SSE	上海证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
93b2ea2a-17ee-41c5-9603-e82aee44417f	SZSE	深圳证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
b32e2b9c-e3d4-4e41-b7bb-81e9c35db53c	HKEX	香港交易所	HKG	HKD	Asia/Hong_Kong	{"open": "09:30", "close": "16:00", "lunch_break": {"end": "13:00", "start": "12:00"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
bf6232a9-40e3-4788-98e8-f18ee0ec2fb6	NYSE	纽约证券交易所	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
b9e633ae-50b0-467d-bf96-351b9eab0a0c	NASDAQ	纳斯达克	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
93e69f74-5df6-47ef-9ac2-639072dcf1cf	TSE	东京证券交易所	JPN	JPY	Asia/Tokyo	{"open": "09:00", "close": "15:00", "lunch_break": {"end": "12:30", "start": "11:30"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
b4359415-0cbc-4786-97a9-2ffbf5df7188	LSE	伦敦证券交易所	GBR	GBP	Europe/London	{"open": "08:00", "close": "16:30"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
06954cbd-28dd-444c-9137-85bf6a15ecf2	FWB	法兰克福证券交易所	DEU	EUR	Europe/Berlin	{"open": "09:00", "close": "17:30"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
\.


--
-- Data for Name: option_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.option_details (id, asset_id, underlying_asset_id, option_type, strike_price, expiration_date, contract_size, exercise_style, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: performance_metrics; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.performance_metrics (id, portfolio_id, metric_type, period_type, period_start, period_end, value, currency, metadata, calculated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.permissions (id, name, resource, action, description, created_at) FROM stdin;
35705400-574b-4ac4-967f-eea3283e32f8	users.create	users	create	创建用户	2025-11-07 21:05:53.350655+08
eef94c62-8cc3-466b-be67-d6c028dc9320	users.read	users	read	查看用户信息	2025-11-07 21:05:53.350655+08
e5d6ab45-d2b1-463c-a9c3-25acd95a3e20	users.update	users	update	更新用户信息	2025-11-07 21:05:53.350655+08
a8b2da5e-192e-47cf-ac4b-e2221e093c95	users.delete	users	delete	删除用户	2025-11-07 21:05:53.350655+08
85a02685-1689-4abb-9af8-9562db0179ea	portfolios.create	portfolios	create	创建投资组合	2025-11-07 21:05:53.350655+08
213c516c-2e81-4900-b880-390f3221c113	portfolios.read	portfolios	read	查看投资组合	2025-11-07 21:05:53.350655+08
71c5f73f-ec3e-4ffc-9b20-feecaec2f536	portfolios.update	portfolios	update	更新投资组合	2025-11-07 21:05:53.350655+08
c8ea0975-9405-42ce-ab2f-bd1a37de520e	portfolios.delete	portfolios	delete	删除投资组合	2025-11-07 21:05:53.350655+08
1692e1a7-a33d-4dc7-8306-5a25f482d82f	accounts.create	trading_accounts	create	创建交易账户	2025-11-07 21:05:53.350655+08
30d64c5a-fc49-45a3-9652-6747c08a924a	accounts.read	trading_accounts	read	查看交易账户	2025-11-07 21:05:53.350655+08
8485e1e9-2a9e-4704-a863-0e1e5c304950	accounts.update	trading_accounts	update	更新交易账户	2025-11-07 21:05:53.350655+08
b27540e1-0a3b-43ee-9464-e3ecb5b27321	accounts.delete	trading_accounts	delete	删除交易账户	2025-11-07 21:05:53.350655+08
9f757852-e630-498f-a5c5-353436a40ae4	transactions.create	transactions	create	创建交易记录	2025-11-07 21:05:53.350655+08
17a0a364-e115-471d-8392-e88879720791	transactions.read	transactions	read	查看交易记录	2025-11-07 21:05:53.350655+08
cb436f9a-7ef2-46bc-8341-e99372b79f7f	transactions.update	transactions	update	更新交易记录	2025-11-07 21:05:53.350655+08
4d2247d5-2882-4c7c-a300-8e4eaa294b80	transactions.delete	transactions	delete	删除交易记录	2025-11-07 21:05:53.350655+08
d9629cb0-d0eb-4c3b-aa0f-229f93b3e07e	transactions.import	transactions	import	批量导入交易记录	2025-11-07 21:05:53.350655+08
f48b62db-e078-4cfe-b4ac-8dde98283b3c	assets.create	assets	create	创建资产	2025-11-07 21:05:53.350655+08
f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	assets.read	assets	read	查看资产信息	2025-11-07 21:05:53.350655+08
56c23162-5976-4ca4-964e-b1b36ae41e85	assets.update	assets	update	更新资产信息	2025-11-07 21:05:53.350655+08
0790f87a-cd62-4f05-82ff-042902b0a51b	assets.delete	assets	delete	删除资产	2025-11-07 21:05:53.350655+08
09aa0f57-e97a-4dc1-ab00-c3c3af8b1d11	reports.create	reports	create	创建报表	2025-11-07 21:05:53.350655+08
3eed05cc-1d64-4e07-9b97-b8ed103e59b0	reports.read	reports	read	查看报表	2025-11-07 21:05:53.350655+08
6cae6bd0-8d33-4cf5-8a0c-98eab2133ae1	reports.update	reports	update	更新报表	2025-11-07 21:05:53.350655+08
6eca62f8-ff89-4ab0-b45a-f47e056daa5c	reports.delete	reports	delete	删除报表	2025-11-07 21:05:53.350655+08
614e6f26-125d-482e-8480-7ad01bd5228f	reports.export	reports	export	导出报表	2025-11-07 21:05:53.350655+08
e4b3d8bc-3a48-4eb1-bb68-8ca02320f790	system.config	system	config	系统配置管理	2025-11-07 21:05:53.350655+08
f6c544aa-a006-4c5d-8524-813a6b083b8a	system.logs	system	logs	查看系统日志	2025-11-07 21:05:53.350655+08
990cff7f-bdf1-424c-b21a-d4d8f4ee0040	system.backup	system	backup	数据备份管理	2025-11-07 21:05:53.350655+08
16814e43-0a3c-462d-bb1f-79838297ee17	exchange_rate.create	exchange_rate	create	创建汇率记录	2025-11-09 10:31:48.187804+08
4370924f-7b52-464a-a673-4cd437513100	exchange_rate.read	exchange_rate	read	查看汇率信息	2025-11-09 10:31:48.187804+08
09b8012b-b744-444b-8fc0-e93cf6e76917	exchange_rate.update	exchange_rate	update	更新汇率信息	2025-11-09 10:31:48.187804+08
fdacdee2-7d5e-41d2-8899-94210bdbc475	exchange_rate.delete	exchange_rate	delete	删除汇率记录	2025-11-09 10:31:48.187804+08
5cd2d8fd-c94e-406e-87c3-21ea04a19723	exchange_rate.import	exchange_rate	import	批量导入汇率数据	2025-11-09 10:31:48.187804+08
\.


--
-- Data for Name: portfolio_snapshots; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.portfolio_snapshots (id, portfolio_id, snapshot_date, total_value, cash_value, invested_value, unrealized_gain_loss, realized_gain_loss, currency, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: portfolio_tags; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.portfolio_tags (id, portfolio_id, tag_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: portfolios; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.portfolios (id, user_id, name, description, base_currency, is_default, is_active, created_at, updated_at, sort_order) FROM stdin;
\.


--
-- Data for Name: position_snapshots; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.position_snapshots (id, position_id, portfolio_snapshot_id, snapshot_date, quantity, market_price, market_value, average_cost, total_cost, unrealized_gain_loss, currency, created_at) FROM stdin;
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.positions (id, portfolio_id, trading_account_id, asset_id, quantity, average_cost, total_cost, currency, first_purchase_date, last_transaction_date, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: price_data_sources; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_data_sources (id, name, provider, api_endpoint, api_key_encrypted, config, rate_limit, timeout_seconds, is_active, last_sync_at, last_sync_status, last_error_message, created_at, updated_at, created_by, updated_by) FROM stdin;
5a0a447b-27ba-491b-a995-09f80f5162c9	天天基金	ttjj	http://api.1234567.com.cn/fund	\N	{"features": {"fund_nav": true, "fund_holding": true, "fund_ranking": true, "manager_info": true, "fund_performance": true}, "free_plan": false, "data_types": ["fund_nav", "fund_ranking", "fund_holding"], "description": "中国最大的基金数据平台，包含基金净值、排名、持仓", "requires_api_key": true, "supports_markets": ["SSE", "SZSE"], "supports_products": ["FUND", "ETF"], "rate_limit_per_minute": 60}	60	30	f	\N	\N	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
a0bac1dd-9e3d-4988-85f9-f25379e47085	Binance API	binance	https://api.binance.com/api	\N	{"features": {"kline_data": true, "trade_data": true, "order_placement": true, "real_time_prices": true, "account_management": true}, "free_plan": true, "data_types": ["real_time", "historical", "klines", "trades"], "description": "币安加密货币交易所数据，包含实时行情、交易数据", "requires_api_key": false, "supports_markets": ["CRYPTO"], "supports_products": ["CRYPTO"], "rate_limit_per_minute": 1200}	1200	15	f	\N	\N	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
bf901d15-81a7-497d-88b3-d24b8ab60fe9	FRED (Federal Reserve)	fred	https://api.stlouisfed.org/fred	\N	{"features": {"historical": true, "batch_query": true}, "data_types": ["economic_indicators"], "requires_api_key": true, "supports_products": ["ECONOMIC_INDICATOR"], "supports_countries": ["US"], "rate_limit_per_minute": 120}	120	30	t	\N	\N	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
d8654879-c098-491a-bd6c-db7aeb2efbbf	新浪财经	sina	http://hq.sinajs.cn	\N	{"features": {"bid_ask": true, "realtime": true, "batch_query": true}, "data_types": ["realtime", "historical"], "requires_api_key": false, "supports_products": ["STOCK", "FUND", "FUTURES", "FOREX"], "supports_countries": ["CN"], "rate_limit_per_minute": 150}	200	15	t	2025-11-08 15:17:06.335562	success	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
f6fede55-c798-44fa-b5d8-66ec7afd4809	东方财富	eastmoney	http://push2.eastmoney.com/api/qt/stock/kline/get	\N	{"supports_batch": false, "timeout_seconds": 15, "supports_products": ["STOCK", "FUND"], "supports_countries": ["CN"], "rate_limit_per_minute": 100}	60	30	t	\N	\N	\N	2025-11-08 07:13:40.553711	2025-11-08 07:13:40.553711	\N	\N
7755cebe-ded0-4d2e-8ee6-286c48ccf623	Yahoo Finance	yahoo_finance	https://query1.finance.yahoo.com/v8/finance/chart/	\N	{"supports_batch": false, "timeout_seconds": 30, "supports_products": ["STOCK", "ETF", "FUND"], "supports_countries": ["US", "HK", "CN"], "rate_limit_per_minute": 60}	60	30	t	2025-11-09 07:07:12.645739	success	\N	2025-11-08 07:11:32.459892	2025-11-08 07:11:32.459892	\N	\N
\.


--
-- Data for Name: price_sync_errors; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_errors (id, log_id, asset_id, asset_symbol, error_type, error_message, error_details, occurred_at) FROM stdin;
\.


--
-- Data for Name: price_sync_logs; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_logs (id, task_id, data_source_id, started_at, completed_at, status, total_assets, total_records, success_count, failed_count, skipped_count, result_summary, error_message) FROM stdin;
d46d52f7-24e6-4464-9e72-8cb7186072cd	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:23:03.799605	2025-11-07 23:23:03.817978	failed	4	0	0	4	0	{"errors": [{"error": "Unsupported provider: sina", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Unsupported provider: sina", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Unsupported provider: sina", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Unsupported provider: sina", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
221c33f4-5fe3-415c-9978-35945e02387e	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:25:24.389492	2025-11-07 23:25:24.399941	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
14aac112-0432-4d97-a122-6a873091cec8	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:26:34.492899	2025-11-07 23:26:34.496545	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
952c68a8-c3be-4d31-9a86-e01b070b536c	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:30:09.246066	2025-11-07 23:30:11.56784	success	4	261	261	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 261, "total_records": 261, "duration_seconds": 2}	\N
ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	\N	2025-11-07 23:28:27.087069	2025-11-07 23:28:27.113019	failed	4	0	0	4	0	{"errors": [{"error": "Tushare API key not configured", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Tushare API key not configured", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Tushare API key not configured", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Tushare API key not configured", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
b5d226ea-5546-4003-96b9-8217de2fd0d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-08 15:17:03.00095	2025-11-08 15:17:06.3348	success	10	284	284	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 10, "skipped_count": 0, "success_count": 284, "total_records": 284, "duration_seconds": 3}	\N
a7033f67-740f-4eb4-a71b-6c4fbe405420	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:08.30219	2025-11-08 20:00:08.307126	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
138414fc-b7ea-4a66-be8c-f1e3d3b782e2	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:32.049396	2025-11-08 20:00:32.055626	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
54974cb0-d021-46ef-a421-1f2b73e95b0d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:23:36.58379	2025-11-08 20:23:36.597436	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
155bf661-6bb1-4444-9ca5-0223d1d3969d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:55:03.087373	2025-11-08 20:55:06.543362	success	4	264	264	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 264, "total_records": 264, "duration_seconds": 3}	\N
c8838372-8286-4f7f-977b-1a3b9dce1086	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-09 07:07:09.788844	2025-11-09 07:07:12.64543	success	4	968	968	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 968, "total_records": 968, "duration_seconds": 2}	\N
\.


--
-- Data for Name: price_sync_logs_backup; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_logs_backup (id, task_id, data_source_id, started_at, completed_at, status, total_assets, total_records, success_count, failed_count, skipped_count, result_summary, error_message) FROM stdin;
d46d52f7-24e6-4464-9e72-8cb7186072cd	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:23:03.799605	2025-11-07 23:23:03.817978	failed	4	0	0	4	0	{"errors": [{"error": "Unsupported provider: sina", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Unsupported provider: sina", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Unsupported provider: sina", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Unsupported provider: sina", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
221c33f4-5fe3-415c-9978-35945e02387e	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:25:24.389492	2025-11-07 23:25:24.399941	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
14aac112-0432-4d97-a122-6a873091cec8	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:26:34.492899	2025-11-07 23:26:34.496545	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
952c68a8-c3be-4d31-9a86-e01b070b536c	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:30:09.246066	2025-11-07 23:30:11.56784	success	4	261	261	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 261, "total_records": 261, "duration_seconds": 2}	\N
ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	\N	2025-11-07 23:28:27.087069	2025-11-07 23:28:27.113019	failed	4	0	0	4	0	{"errors": [{"error": "Tushare API key not configured", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Tushare API key not configured", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Tushare API key not configured", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Tushare API key not configured", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
b5d226ea-5546-4003-96b9-8217de2fd0d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-08 15:17:03.00095	2025-11-08 15:17:06.3348	success	10	284	284	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 10, "skipped_count": 0, "success_count": 284, "total_records": 284, "duration_seconds": 3}	\N
a7033f67-740f-4eb4-a71b-6c4fbe405420	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:08.30219	2025-11-08 20:00:08.307126	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
138414fc-b7ea-4a66-be8c-f1e3d3b782e2	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:32.049396	2025-11-08 20:00:32.055626	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
54974cb0-d021-46ef-a421-1f2b73e95b0d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:23:36.58379	2025-11-08 20:23:36.597436	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
155bf661-6bb1-4444-9ca5-0223d1d3969d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:55:03.087373	2025-11-08 20:55:06.543362	success	4	264	264	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 264, "total_records": 264, "duration_seconds": 3}	\N
\.


--
-- Data for Name: price_sync_tasks; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_tasks (id, name, description, data_source_id, asset_type_id, asset_ids, schedule_type, cron_expression, interval_minutes, sync_days_back, overwrite_existing, is_active, last_run_at, next_run_at, last_run_status, last_run_result, created_at, updated_at, created_by, updated_by, country_id) FROM stdin;
3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	股票价格同步	\N	7755cebe-ded0-4d2e-8ee6-286c48ccf623	761e5638-cff8-4247-bfd7-00edcd57a51a	\N	manual	\N	\N	365	t	t	2025-11-09 07:07:09.797005	\N	success	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 968, "total_records": 968, "duration_seconds": 2}	2025-11-07 23:21:30.717759	2025-11-07 23:21:30.717759	\N	\N	d7d5c3ba-92c1-4619-891c-de4d455179ed
\.


--
-- Data for Name: report_executions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.report_executions (id, report_id, execution_status, started_at, completed_at, file_path, file_size, error_message, metadata) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.reports (id, user_id, portfolio_id, name, description, report_type, parameters, schedule, is_scheduled, is_active, last_generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.role_permissions (id, role_id, permission_id, created_at) FROM stdin;
a0762afb-a48d-4eb4-8afc-021747207990	eb08af9f-bb10-47f5-94b1-0812282a4917	35705400-574b-4ac4-967f-eea3283e32f8	2025-11-07 21:05:53.352135+08
faaa935f-9a29-4410-8f03-22db179f4c81	eb08af9f-bb10-47f5-94b1-0812282a4917	eef94c62-8cc3-466b-be67-d6c028dc9320	2025-11-07 21:05:53.352135+08
c063991d-29fa-4b8e-b318-054ae2f36313	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	eef94c62-8cc3-466b-be67-d6c028dc9320	2025-11-07 21:05:53.352135+08
23754427-426a-4e88-8c84-ac4f52941aa9	927f1425-7f82-4c3d-8701-289e2ccb820b	eef94c62-8cc3-466b-be67-d6c028dc9320	2025-11-07 21:05:53.352135+08
8cbc685b-a1aa-466e-b618-a9320f638e56	eb08af9f-bb10-47f5-94b1-0812282a4917	e5d6ab45-d2b1-463c-a9c3-25acd95a3e20	2025-11-07 21:05:53.352135+08
76193866-18b5-4c1a-8de1-618b0adf3b4a	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	e5d6ab45-d2b1-463c-a9c3-25acd95a3e20	2025-11-07 21:05:53.352135+08
dc73a69b-72ad-40ab-ad13-e0cbb60c544c	eb08af9f-bb10-47f5-94b1-0812282a4917	a8b2da5e-192e-47cf-ac4b-e2221e093c95	2025-11-07 21:05:53.352135+08
886039eb-3511-4197-b0b7-56bb3f84ab14	eb08af9f-bb10-47f5-94b1-0812282a4917	85a02685-1689-4abb-9af8-9562db0179ea	2025-11-07 21:05:53.352135+08
fdd308e4-9562-4cc6-ac23-2c32aac48c97	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	85a02685-1689-4abb-9af8-9562db0179ea	2025-11-07 21:05:53.352135+08
6c45de77-50c7-4b9f-8daa-17bc30ca39cc	eb08af9f-bb10-47f5-94b1-0812282a4917	213c516c-2e81-4900-b880-390f3221c113	2025-11-07 21:05:53.352135+08
7c006dc1-beda-4d97-8831-fd9f59bc6682	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	213c516c-2e81-4900-b880-390f3221c113	2025-11-07 21:05:53.352135+08
a80c56be-8c70-464b-9235-db3fc6c48768	927f1425-7f82-4c3d-8701-289e2ccb820b	213c516c-2e81-4900-b880-390f3221c113	2025-11-07 21:05:53.352135+08
85998344-ecc2-4d5c-aff8-7e5254318cf3	eb08af9f-bb10-47f5-94b1-0812282a4917	71c5f73f-ec3e-4ffc-9b20-feecaec2f536	2025-11-07 21:05:53.352135+08
19cfc15f-623a-4e76-8321-c7a15a57d3ea	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	71c5f73f-ec3e-4ffc-9b20-feecaec2f536	2025-11-07 21:05:53.352135+08
5fc13459-8909-46cf-aef4-cc6ad01586d9	eb08af9f-bb10-47f5-94b1-0812282a4917	c8ea0975-9405-42ce-ab2f-bd1a37de520e	2025-11-07 21:05:53.352135+08
c15b5272-e623-4417-8bdd-d34ee3f63191	eb08af9f-bb10-47f5-94b1-0812282a4917	1692e1a7-a33d-4dc7-8306-5a25f482d82f	2025-11-07 21:05:53.352135+08
ca5f4613-fcc9-4f62-9680-2c51c4ae0f9f	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	1692e1a7-a33d-4dc7-8306-5a25f482d82f	2025-11-07 21:05:53.352135+08
0c96e9da-0bd2-4f6e-882a-dbf5e6b044be	eb08af9f-bb10-47f5-94b1-0812282a4917	30d64c5a-fc49-45a3-9652-6747c08a924a	2025-11-07 21:05:53.352135+08
e4902116-cdbe-498e-9fad-8828db27a1a9	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	30d64c5a-fc49-45a3-9652-6747c08a924a	2025-11-07 21:05:53.352135+08
3b77f8b3-ee11-4fd6-a9e6-d36ed530628c	927f1425-7f82-4c3d-8701-289e2ccb820b	30d64c5a-fc49-45a3-9652-6747c08a924a	2025-11-07 21:05:53.352135+08
af95b3dc-a339-43b4-b4bf-6a9714980d4d	eb08af9f-bb10-47f5-94b1-0812282a4917	8485e1e9-2a9e-4704-a863-0e1e5c304950	2025-11-07 21:05:53.352135+08
85ca0786-3ed0-4e36-ad18-81e232276c0a	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	8485e1e9-2a9e-4704-a863-0e1e5c304950	2025-11-07 21:05:53.352135+08
789254f4-ee3a-43da-a5cf-f71a1a0d7148	eb08af9f-bb10-47f5-94b1-0812282a4917	b27540e1-0a3b-43ee-9464-e3ecb5b27321	2025-11-07 21:05:53.352135+08
ef116949-f9eb-4074-b6bf-a18b7b0531ee	eb08af9f-bb10-47f5-94b1-0812282a4917	9f757852-e630-498f-a5c5-353436a40ae4	2025-11-07 21:05:53.352135+08
3fe09bb1-c1c9-4609-ad13-54129869cabe	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	9f757852-e630-498f-a5c5-353436a40ae4	2025-11-07 21:05:53.352135+08
dbaa25de-844b-4127-a792-39e2c7cf8e17	eb08af9f-bb10-47f5-94b1-0812282a4917	17a0a364-e115-471d-8392-e88879720791	2025-11-07 21:05:53.352135+08
3e3023c0-4013-4def-976f-427b98946912	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	17a0a364-e115-471d-8392-e88879720791	2025-11-07 21:05:53.352135+08
c37682b9-bd81-44ee-8dea-119d7c9aa8cd	927f1425-7f82-4c3d-8701-289e2ccb820b	17a0a364-e115-471d-8392-e88879720791	2025-11-07 21:05:53.352135+08
4cbd8c34-6dd1-4a30-b1ba-d1c484c78921	eb08af9f-bb10-47f5-94b1-0812282a4917	cb436f9a-7ef2-46bc-8341-e99372b79f7f	2025-11-07 21:05:53.352135+08
81ed3ed4-859d-4b13-9a3e-45e4506e5240	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	cb436f9a-7ef2-46bc-8341-e99372b79f7f	2025-11-07 21:05:53.352135+08
a1842d2a-6b00-4d3f-9226-35e486a996b6	eb08af9f-bb10-47f5-94b1-0812282a4917	4d2247d5-2882-4c7c-a300-8e4eaa294b80	2025-11-07 21:05:53.352135+08
cf446850-9d50-42f7-93a9-d8ec1b82a3de	eb08af9f-bb10-47f5-94b1-0812282a4917	d9629cb0-d0eb-4c3b-aa0f-229f93b3e07e	2025-11-07 21:05:53.352135+08
1c18ec4c-2144-4453-94e6-b56c4bfcfeb5	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	d9629cb0-d0eb-4c3b-aa0f-229f93b3e07e	2025-11-07 21:05:53.352135+08
d5ad8d9c-591c-4446-87a9-17221bfa199c	eb08af9f-bb10-47f5-94b1-0812282a4917	f48b62db-e078-4cfe-b4ac-8dde98283b3c	2025-11-07 21:05:53.352135+08
62cc5d47-fc77-4432-833d-5d6d88498569	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	f48b62db-e078-4cfe-b4ac-8dde98283b3c	2025-11-07 21:05:53.352135+08
ac9a7d81-418c-490d-b0df-6222a912db53	eb08af9f-bb10-47f5-94b1-0812282a4917	f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	2025-11-07 21:05:53.352135+08
4b289b8c-bd0e-4bb6-b37b-6850713696b2	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	2025-11-07 21:05:53.352135+08
d46d66f1-2675-4cf5-83a9-cbbe9c0f3b57	927f1425-7f82-4c3d-8701-289e2ccb820b	f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	2025-11-07 21:05:53.352135+08
cb224bda-bef6-44ff-b5c1-526edec872a6	eb08af9f-bb10-47f5-94b1-0812282a4917	56c23162-5976-4ca4-964e-b1b36ae41e85	2025-11-07 21:05:53.352135+08
01806253-48f6-4eb5-be29-b9302c39846f	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	56c23162-5976-4ca4-964e-b1b36ae41e85	2025-11-07 21:05:53.352135+08
b9dfccbb-9dec-433f-ba22-d8043ca15186	eb08af9f-bb10-47f5-94b1-0812282a4917	0790f87a-cd62-4f05-82ff-042902b0a51b	2025-11-07 21:05:53.352135+08
6c9a8829-da08-4cda-acfa-5ae60556420e	eb08af9f-bb10-47f5-94b1-0812282a4917	09aa0f57-e97a-4dc1-ab00-c3c3af8b1d11	2025-11-07 21:05:53.352135+08
fd327680-1006-4090-971e-58c7ef4b7a10	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	09aa0f57-e97a-4dc1-ab00-c3c3af8b1d11	2025-11-07 21:05:53.352135+08
7b968e74-5cd0-4db7-a1ec-2c27117de43a	eb08af9f-bb10-47f5-94b1-0812282a4917	3eed05cc-1d64-4e07-9b97-b8ed103e59b0	2025-11-07 21:05:53.352135+08
7fda69a5-bcc1-4176-bc38-9b2553a07bd5	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	3eed05cc-1d64-4e07-9b97-b8ed103e59b0	2025-11-07 21:05:53.352135+08
7251ebed-7ab1-41e7-875a-4add9530210e	927f1425-7f82-4c3d-8701-289e2ccb820b	3eed05cc-1d64-4e07-9b97-b8ed103e59b0	2025-11-07 21:05:53.352135+08
9ae6bc0c-90e9-4d95-afc9-de28abc5c88e	eb08af9f-bb10-47f5-94b1-0812282a4917	6cae6bd0-8d33-4cf5-8a0c-98eab2133ae1	2025-11-07 21:05:53.352135+08
b109215a-15a4-4dc3-a767-13b926db2ac7	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	6cae6bd0-8d33-4cf5-8a0c-98eab2133ae1	2025-11-07 21:05:53.352135+08
21ec505c-7127-47c5-b70a-e76e8170b58b	eb08af9f-bb10-47f5-94b1-0812282a4917	6eca62f8-ff89-4ab0-b45a-f47e056daa5c	2025-11-07 21:05:53.352135+08
6a781f73-4d32-401c-9f95-22b59643ab0f	eb08af9f-bb10-47f5-94b1-0812282a4917	614e6f26-125d-482e-8480-7ad01bd5228f	2025-11-07 21:05:53.352135+08
304ce2d4-fd1e-4826-a92c-b13734918ce5	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	614e6f26-125d-482e-8480-7ad01bd5228f	2025-11-07 21:05:53.352135+08
798a6ee0-db04-48b6-9049-63d098a3e85d	eb08af9f-bb10-47f5-94b1-0812282a4917	e4b3d8bc-3a48-4eb1-bb68-8ca02320f790	2025-11-07 21:05:53.352135+08
b4afcc1c-c526-4e88-acd9-9d02961289f3	eb08af9f-bb10-47f5-94b1-0812282a4917	f6c544aa-a006-4c5d-8524-813a6b083b8a	2025-11-07 21:05:53.352135+08
7a0efb20-094e-45ab-9364-2a35dc052f77	eb08af9f-bb10-47f5-94b1-0812282a4917	990cff7f-bdf1-424c-b21a-d4d8f4ee0040	2025-11-07 21:05:53.352135+08
8518ca7b-36ec-4ef6-961f-ed3c4eda0e48	eb08af9f-bb10-47f5-94b1-0812282a4917	16814e43-0a3c-462d-bb1f-79838297ee17	2025-11-09 10:31:48.193349+08
9bed83b4-b843-4e2d-9a2a-887c8cfe5319	eb08af9f-bb10-47f5-94b1-0812282a4917	4370924f-7b52-464a-a673-4cd437513100	2025-11-09 10:31:48.193349+08
fb14ef44-4e35-4aab-a65e-62472dc41927	eb08af9f-bb10-47f5-94b1-0812282a4917	09b8012b-b744-444b-8fc0-e93cf6e76917	2025-11-09 10:31:48.193349+08
36989e01-eff2-4b52-a027-addeb00d798f	eb08af9f-bb10-47f5-94b1-0812282a4917	fdacdee2-7d5e-41d2-8899-94210bdbc475	2025-11-09 10:31:48.193349+08
b49bb067-d906-407e-b07d-f9f8039baec5	eb08af9f-bb10-47f5-94b1-0812282a4917	5cd2d8fd-c94e-406e-87c3-21ea04a19723	2025-11-09 10:31:48.193349+08
88ea4db1-b6c1-4118-b2a5-657dc29774a2	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	4370924f-7b52-464a-a673-4cd437513100	2025-11-09 10:31:48.196485+08
52227707-5119-4891-b5e6-a387e37be6c1	927f1425-7f82-4c3d-8701-289e2ccb820b	4370924f-7b52-464a-a673-4cd437513100	2025-11-09 10:31:48.197136+08
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.roles (id, name, description, is_active, created_at, updated_at) FROM stdin;
eb08af9f-bb10-47f5-94b1-0812282a4917	admin	系统管理员，拥有所有权限	t	2025-11-07 21:05:53.346865+08	2025-11-07 21:05:53.346865+08
38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	user	普通用户，拥有基本功能权限	t	2025-11-07 21:05:53.346865+08	2025-11-07 21:05:53.346865+08
927f1425-7f82-4c3d-8701-289e2ccb820b	viewer	只读用户，只能查看数据	t	2025-11-07 21:05:53.346865+08	2025-11-07 21:05:53.346865+08
\.


--
-- Data for Name: stock_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.stock_details (id, asset_id, sector, industry, market_cap, shares_outstanding, pe_ratio, pb_ratio, dividend_yield, company_website, headquarters, founded_year, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_option_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.stock_option_details (id, asset_id, underlying_stock_id, underlying_stock_symbol, underlying_stock_name, option_type, strike_price, expiration_date, contract_size, exercise_style, settlement_type, multiplier, trading_unit, min_price_change, margin_requirement, commission_rate, delta, gamma, theta, vega, rho, implied_volatility, historical_volatility, premium_currency, intrinsic_value, time_value, cost_divisor, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tag_categories; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.tag_categories (id, name, description, color, icon, user_id, parent_id, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.tags (id, name, description, color, icon, user_id, category_id, is_system, is_active, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trading_accounts; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.trading_accounts (id, portfolio_id, name, account_type, broker_name, account_number, currency, initial_balance, current_balance, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_tag_mappings; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.transaction_tag_mappings (transaction_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.transactions (id, portfolio_id, trading_account_id, asset_id, transaction_type, quantity, price, total_amount, fees, taxes, currency, exchange_rate, transaction_date, settlement_date, notes, tags, liquidity_tag_id, external_id, metadata, created_at, updated_at, user_id, side, executed_at, settled_at, status, liquidity_tag) FROM stdin;
\.


--
-- Data for Name: treasury_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.treasury_details (id, asset_id, treasury_type, term_type, face_value, coupon_rate, coupon_frequency, issue_date, maturity_date, term_years, issue_price, issue_number, yield_to_maturity, tradable, min_holding_period, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.user_roles (id, user_id, role_id, assigned_by, assigned_at, expires_at, is_active) FROM stdin;
cb56861d-abc8-4745-b041-a325409cfe57	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	e04747dd-bbe9-4d24-adcf-1c088e3c3491	2025-11-07 21:20:18.95748+08	\N	t
039c1f2f-0f06-4331-a3b6-2443eca1ce96	e04747dd-bbe9-4d24-adcf-1c088e3c3491	eb08af9f-bb10-47f5-94b1-0812282a4917	e04747dd-bbe9-4d24-adcf-1c088e3c3491	2025-11-07 21:21:06.096613+08	\N	t
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.user_sessions (id, user_id, token_hash, refresh_token_hash, device_info, ip_address, user_agent, is_active, expires_at, created_at, last_used_at) FROM stdin;
724cd83c-27ed-4c53-a025-5dba04b6cb9c	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$473iScTBipzF9PZzdR5TEO42h5KYO/7jeOvOwJAuIkZAx4/cdNSP.	\N	\N	\N	\N	t	2025-11-08 21:17:24+08	2025-11-07 21:17:24.964+08	2025-11-07 21:17:24.964+08
36014bca-ff1e-42a4-b79a-4bb9fd3f160b	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$HrsLtKPYJo9dDFJfud7vKuIrPFMN1ufMu9obK4IXRiSKY3aIFmJLq	\N	\N	\N	\N	t	2025-11-08 21:17:25+08	2025-11-07 21:17:25.393+08	2025-11-07 21:17:25.393+08
bc531fb9-2f42-4880-b6a0-32978f7d7534	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$d/5EhHhZqIv5iGJLe8GD1.BJEpTLnotGGkkoI4N/Ry3G29/93rI2.	\N	\N	\N	\N	t	2025-11-08 21:17:44+08	2025-11-07 21:17:44.897+08	2025-11-07 21:17:44.897+08
f4f7e96c-bf26-4c96-99e5-a3912855bd06	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$wtNGu6nNupnLbP6OgM4GG.nNPEZyzsKL2GlolHXgtj17wS.FBdyqG	\N	\N	\N	\N	t	2025-11-08 21:17:48+08	2025-11-07 21:17:48.248+08	2025-11-07 21:17:48.248+08
7961c023-4622-4351-aaad-daf64879536a	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$ZfpGXZ.nGMQQ2uYzrpr0beB.EjbzsskF.7ZKXYpJBfe0p8WHCPr3.	\N	\N	\N	\N	t	2025-11-08 21:19:41+08	2025-11-07 21:19:41.123+08	2025-11-07 21:19:41.123+08
1ba50a76-d4d4-43ce-bd91-e542995d6713	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$3nn.hYN6N6BdgDUebVaBeuGCHTmB1FdVea6uoYLUrVZ0NG03QM4FS	\N	\N	\N	\N	t	2025-11-08 21:21:33+08	2025-11-07 21:21:33.192+08	2025-11-07 21:21:33.192+08
092c433e-469e-4584-aa74-b0c271da432d	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$IIV3kCzZDGJ8tW3qVy4dSOdBrHQq4eG7.WaAEBcXxCH7rjPV5219.	\N	\N	\N	\N	t	2025-11-08 21:24:36+08	2025-11-07 21:24:36.284+08	2025-11-07 21:24:36.284+08
87955c7d-5d09-436f-89bc-30caaff64826	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$ssDZS2fJ4nDj.0EDxyCQwOtGEcBdsb0QvgyhoCQLGP.4oSqESGDgy	\N	\N	\N	\N	t	2025-11-08 21:25:53+08	2025-11-07 21:25:53.062+08	2025-11-07 21:25:53.062+08
44e22918-5143-43a1-b6e7-4261e0c0b4da	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$6ssOkAB8r7kReFUNnrg7m.XzA/z8cHYSTE9rXm7sW/w6gcBIxi/MO	\N	\N	\N	\N	t	2025-11-08 21:29:16+08	2025-11-07 21:29:16.086+08	2025-11-07 21:29:16.086+08
8f2c0067-b29d-4087-8db2-7a72d7b2f89a	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$28g5cF5.mTT7FCqsMP7Ife7l6rGo67AKrBAcJZWQCMOisUf0/h93a	\N	\N	\N	\N	t	2025-11-08 21:29:57+08	2025-11-07 21:29:57.443+08	2025-11-07 21:29:57.443+08
31703632-2c9e-4da2-9625-d6e7a0432dec	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$VINg0B/IgvBYesnGD3yGquN3VTe.yDsA8UyJb8BBfN89/7qE.8Gxi	\N	\N	\N	\N	t	2025-11-08 21:29:57+08	2025-11-07 21:29:57.547+08	2025-11-07 21:29:57.547+08
474fec7c-e585-44d3-9c36-ac4371e48c12	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$sAcmhlZpJOAwYSy6be3jWOCR0Dap5auDgv7qtJwVb0akuzF6Nony2	\N	\N	\N	\N	t	2025-11-08 21:51:00+08	2025-11-07 21:51:00.705+08	2025-11-07 21:51:00.705+08
e72ab5c2-76aa-4170-97d6-08eb28d71d75	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$wgqVdQ/aWD3.Ee114P034OMtwFUrGmZSFKmtpY/JXiVKJIX.1Pv0.	\N	\N	\N	\N	t	2025-11-08 21:51:59+08	2025-11-07 21:51:59.875+08	2025-11-07 21:51:59.875+08
9a660c5f-5062-4dde-9237-f9b20e3b2525	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$lPZEw03BbOLWWr1yMA2U8.gEuLVxOfY9ZMtqx1vISHNvZHLzKPrOK	\N	\N	\N	\N	t	2025-11-08 21:52:04+08	2025-11-07 21:52:04.922+08	2025-11-07 21:52:04.922+08
f5f13a29-88b8-4b70-a313-9ba60447b4ea	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$trcqziIYTIcoO7JVqtwcuu3FGL0WPoXTYyezR.nZui24g8yQzdypW	\N	\N	\N	\N	t	2025-11-09 10:44:17+08	2025-11-08 10:44:17.188+08	2025-11-08 10:44:17.188+08
c606ada3-8d3d-49c5-8492-d793307ae54d	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$d8Rivm25Vg9Dh9TykAPH3uTy7JMNG1mtNBxTa8JygtX.lwztbITjK	\N	\N	\N	\N	t	2025-11-09 10:44:22+08	2025-11-08 10:44:22.418+08	2025-11-08 10:44:22.418+08
6b813dc2-a6b1-4213-8835-640cd23ff5ce	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$PtAgktzeC5diScSEcVoqKuXso5g0BKI0DCs0e.mG9J8SAWuvkNyga	\N	\N	\N	\N	t	2025-11-09 11:46:51+08	2025-11-08 11:46:51.327+08	2025-11-08 11:46:51.327+08
9cb3c41d-6e48-4fe2-872a-136ff2de8795	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$VGLxV.yO2/GN8rUgus6sHOgaR4CAgm.sh7qWVzwU6ss2Pmrw7Wz2W	\N	\N	\N	\N	t	2025-11-09 16:05:06+08	2025-11-08 16:05:06.381+08	2025-11-08 16:05:06.381+08
0db59352-e2c6-45bc-9726-e5fc87b0c702	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$4WhkNeZNgszytcn/aHADYu.Vo/XZIHOnkqVwU1g.5XC1Ai75Vb2.q	\N	\N	\N	\N	t	2025-11-09 18:54:22+08	2025-11-08 18:54:22.366+08	2025-11-08 18:54:22.366+08
70048169-e1d7-445c-83b2-a16a14985cf2	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$WkafIl2RbvMB3nCLtixeKem96iT6jNRjtCXnnDvCLf8i62pUoz592	\N	\N	\N	\N	t	2025-11-09 18:54:27+08	2025-11-08 18:54:27.804+08	2025-11-08 18:54:27.804+08
9f2e9d95-e7df-45a8-a018-fbd2e5f4fe96	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$RkNsbIok5m4T/zAgtuyAcOUK2oQ9vuUHcYiaTN4SyoeZsoeuEK2PC	\N	\N	\N	\N	t	2025-11-10 10:30:22+08	2025-11-09 10:30:23.023+08	2025-11-09 10:30:23.023+08
712e486f-4760-485d-9820-bf8486a61936	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$GVTYo.RHfvTg01ggXBDTjuU72QABIkeVGhKa.3CF8zujjqY8FWNp6	\N	\N	\N	\N	t	2025-11-10 10:32:43+08	2025-11-09 10:32:43.693+08	2025-11-09 10:32:43.693+08
6f74010f-9c93-434d-8ab4-46fc477ef949	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$GPb4oSM82kgm2du6QsMfhOglNzBew1Qb68unvs0ZhesIPuFgs78o.	\N	\N	\N	\N	t	2025-11-10 10:32:49+08	2025-11-09 10:32:49.272+08	2025-11-09 10:32:49.272+08
5c8631af-272c-44ff-a1e4-18b3c25f7114	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$u7qhX1/7tMAaJU5i7HyxjOjfq9ckZERpgCxDuBeY6jmAg99AKFgd.	\N	\N	\N	\N	t	2025-11-10 10:32:55+08	2025-11-09 10:32:55.365+08	2025-11-09 10:32:55.365+08
9e4f336a-462b-4c72-8e79-4b53847a8510	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$6F6VYaX/c0NtUPFsrT7EfenksWYkTrqOA0J6HxtORebl5Sxb8mYk6	\N	\N	\N	\N	t	2025-11-10 10:33:23+08	2025-11-09 10:33:23.23+08	2025-11-09 10:33:23.23+08
61c9190a-e798-486c-828e-5dadc684b0f3	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$A8SX80TU2hF2lMd/kkY2F.9hla2685T1ad08epQvRkpKKnOR6tBs6	\N	\N	\N	\N	t	2025-11-10 10:33:42+08	2025-11-09 10:33:42.198+08	2025-11-09 10:33:42.198+08
e82edf9a-628e-469a-befb-612fc488bea9	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$ovmYWNo5iRRqAykqxCePe.kpET09.6KkYCkOLb881rxjAHZtq.36.	\N	\N	\N	\N	t	2025-11-10 10:34:08+08	2025-11-09 10:34:08.927+08	2025-11-09 10:34:08.927+08
9d7bbee9-6eed-4310-b4b1-a849ab2bfd63	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$m5IrpJ20CtZeDL83fBipHud9nZtzimHIqqqxIIrLsVrxxBYYFsMY2	\N	\N	\N	\N	t	2025-11-10 10:34:16+08	2025-11-09 10:34:16.852+08	2025-11-09 10:34:16.852+08
9bc94f18-8d1e-4c75-9e06-2e9322fcb300	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$d7tazGtQn55wtrC6YYXR4u0PlfdLTl61da/NRG65E1Do9J29orqpe	\N	\N	\N	\N	t	2025-11-10 10:34:32+08	2025-11-09 10:34:32.205+08	2025-11-09 10:34:32.205+08
193e9be6-7e2e-4957-9397-d72301f08a24	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$s8FUegNGJrcN9vUvmhBu2OdUqgIxzyU8NM6Cuhc.Ap.SXpIXKYUvm	\N	\N	\N	\N	t	2025-11-10 10:36:20+08	2025-11-09 10:36:20.484+08	2025-11-09 10:36:20.484+08
9b118150-5699-4b50-9226-f9eb6ec216a4	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$0Z3TKxqdtiA9RZI137TXqOl6de6ggUpnb0cY8ok1/cCw10EG1ggIi	\N	\N	\N	\N	t	2025-11-10 10:37:26+08	2025-11-09 10:37:26.195+08	2025-11-09 10:37:26.195+08
5f4e2d76-9774-4146-badd-3b6e56efdbbc	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$KKEJBmvI0B39i.isRqL7DO5XF82mcoCvOKrN472UkaCAUpFBp9H9K	\N	\N	\N	\N	t	2025-11-10 10:37:43+08	2025-11-09 10:37:43.174+08	2025-11-09 10:37:43.174+08
9549a7a0-a50a-4d89-b280-4332bb6a429e	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$EgMSCYLAdM29Xr97aNJjE.UZIyQcSkagnRUFtgGKRPuh0wX3f/.La	\N	\N	\N	\N	t	2025-11-10 10:38:30+08	2025-11-09 10:38:30.763+08	2025-11-09 10:38:30.763+08
dcce7fc1-3fc3-452a-87e8-8f56d2ad82de	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$EnL6N0mp0haP1KQDq0TUHuHGxgw.27E0cvprO79GObDmLmDGPkWVq	\N	\N	\N	\N	t	2025-11-10 10:42:20+08	2025-11-09 10:42:20.075+08	2025-11-09 10:42:20.075+08
dc148f4a-3ace-4b4b-8f33-62a90f16db12	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$nZtVqUKcTHlKhuJPG7knGeFuwD.m9tgL19Avv05hS03ZobarNEhn.	\N	\N	\N	\N	t	2025-11-10 10:42:36+08	2025-11-09 10:42:37.02+08	2025-11-09 10:42:37.02+08
714d6697-5e21-4cf6-a201-325bd2b98e14	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$sC59w6oZVR1aZenff0HwFeoREpFSiZj4EjEthbOIUTZbG4FQdJfjC	\N	\N	\N	\N	t	2025-11-10 10:44:14+08	2025-11-09 10:44:14.291+08	2025-11-09 10:44:14.291+08
214e3a51-9d24-4e1e-8284-2b25c642afe1	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$QrDqHxzbzVSREKTIYwEhA.BHyjbF2JdSkAvwOxLNiILK72jekz4Eq	\N	\N	\N	\N	t	2025-11-10 10:44:31+08	2025-11-09 10:44:31.249+08	2025-11-09 10:44:31.249+08
b48f0972-775e-4083-a277-ba3fefe43737	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$j5hLbZxYZlQ.mKZQgDEbYOzy6Y/L/O3xXc.0oqJ6ECzlUf.orqqzm	\N	\N	\N	\N	t	2025-11-10 12:35:15+08	2025-11-09 12:35:15.79+08	2025-11-09 12:35:15.79+08
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.users (id, email, username, password_hash, first_name, last_name, phone, avatar_url, timezone, language, currency_preference, is_active, is_verified, email_verified_at, last_login_at, login_count, failed_login_attempts, locked_until, created_at, updated_at) FROM stdin;
e04747dd-bbe9-4d24-adcf-1c088e3c3491	admin@finapp.com	\N	$2b$12$KPg1vbozHHnAzbBRBkYdOOx3Q9kYBmg44XS4JZFDK1U9st..iQpcy	Admin	User	+86 10 8765 4321	\N	UTC	zh-CN	CNY	t	t	\N	2025-11-09 10:44:31.249+08	0	0	\N	2025-11-07 21:17:25.336+08	2025-11-09 10:44:31.25+08
a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	testapi@finapp.com	\N	$2b$12$CngaJ48leb94pf7hX/ku1euMpsLvtgcLF3q6WvYOhzTMUq5MeYs.u	Jason		+86 10 1234 5678	\N	Asia/Shanghai	zh-CN	CNY	t	t	\N	2025-11-09 12:35:15.797+08	0	0	\N	2025-11-07 21:17:24.904+08	2025-11-09 12:35:15.798+08
\.


--
-- Data for Name: wealth_product_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.wealth_product_details (id, asset_id, product_type, risk_level, expected_return, min_return, max_return, return_type, issue_date, start_date, maturity_date, lock_period, min_investment, max_investment, investment_increment, issuer, product_code, early_redemption, redemption_fee, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: asset_prices; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.asset_prices (id, asset_id, price_date, open_price, high_price, low_price, close_price, volume, adjusted_close, currency, data_source, created_at) FROM stdin;
\.


--
-- Data for Name: asset_types; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.asset_types (id, code, name, category, description, is_active, created_at) FROM stdin;
69bcd777-7604-4e76-9ce2-fabbadfbc440	STOCK	股票	equity	普通股票	t	2025-11-07 20:37:50.506681+08
0f9ab4f3-972e-43d6-9408-a484c9a1a041	ETF	交易所交易基金	fund	在交易所交易的指数基金	t	2025-11-07 20:37:50.506681+08
8616eafb-743d-458b-811a-fd4f45972fc3	MUTUAL_FUND	共同基金	fund	开放式基金	t	2025-11-07 20:37:50.506681+08
da6a3219-2479-4926-844d-5f60ebfe41aa	BOND	债券	fixed_income	政府或企业债券	t	2025-11-07 20:37:50.506681+08
80634d26-c443-4f06-8008-63aa32d79e2e	OPTION	期权	derivative	股票期权合约	t	2025-11-07 20:37:50.506681+08
872a1de0-a165-47d9-b06f-9fd8fd0a0d2a	FUTURE	期货	derivative	期货合约	t	2025-11-07 20:37:50.506681+08
923e9701-bf7b-49d3-9b61-eb7af43d602c	CRYPTO	加密货币	crypto	数字货币	t	2025-11-07 20:37:50.506681+08
c7a568c1-edbf-45dc-8566-add099f23906	CASH	现金	cash	现金及现金等价物	t	2025-11-07 20:37:50.506681+08
8afad30b-8184-41a5-b34b-b608225f4fbd	COMMODITY	商品	commodity	贵金属、原油等商品	t	2025-11-07 20:37:50.506681+08
3ff57144-fd98-4999-bb9b-03d4878223b5	REIT	房地产投资信托	real_estate	房地产投资信托基金	t	2025-11-07 20:37:50.506681+08
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.assets (id, symbol, name, asset_type_id, market_id, currency, isin, cusip, sector, industry, description, metadata, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.audit_logs (id, user_id, table_name, record_id, action, old_values, new_values, changed_fields, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: benchmark_prices; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.benchmark_prices (id, benchmark_id, price_date, price, currency, created_at) FROM stdin;
\.


--
-- Data for Name: benchmarks; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.benchmarks (id, name, symbol, description, asset_class, currency, data_source, is_active, created_at) FROM stdin;
10d6e355-01c0-4c1f-8bd8-aaa54446d4cd	沪深300指数	CSI300	沪深300指数，反映A股市场整体表现	equity	CNY	\N	t	2025-11-07 20:37:50.510462+08
2cc3c56a-87c5-4355-b572-17c5fa1a83a9	上证指数	SHCOMP	上海证券交易所综合股价指数	equity	CNY	\N	t	2025-11-07 20:37:50.510462+08
ae3cf127-5dd1-43c6-99bc-827ae1799509	深证成指	SZCOMP	深圳证券交易所成份股价指数	equity	CNY	\N	t	2025-11-07 20:37:50.510462+08
6a517bb3-67cd-44b1-b6c2-735703840de5	恒生指数	HSI	香港恒生指数	equity	HKD	\N	t	2025-11-07 20:37:50.510462+08
cc5c1be2-2754-4296-9c37-1a37758522ec	标普500指数	SPX	标准普尔500指数	equity	USD	\N	t	2025-11-07 20:37:50.510462+08
6659ec57-b45c-4d6f-9f85-791ddba0aca2	纳斯达克指数	IXIC	纳斯达克综合指数	equity	USD	\N	t	2025-11-07 20:37:50.510462+08
e0e808fb-f21d-4988-8f22-e41337868f2c	日经225指数	N225	日经225指数	equity	JPY	\N	t	2025-11-07 20:37:50.510462+08
d646987a-83a6-4f2f-873d-ee7906292bb1	富时100指数	UKX	英国富时100指数	equity	GBP	\N	t	2025-11-07 20:37:50.510462+08
0c0b3a4c-8c8f-4320-8421-af90f1b651ad	DAX指数	DAX	德国DAX指数	equity	EUR	\N	t	2025-11-07 20:37:50.510462+08
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.email_verification_tokens (id, user_id, token_hash, email, expires_at, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.exchange_rates (id, from_currency, to_currency, rate_date, rate, data_source, created_at) FROM stdin;
c01cc66e-216b-4100-a24a-e595abbccb10	USD	CNY	2025-11-07	7.20000000	manual	2025-11-07 20:37:50.511495+08
2e5338a4-478d-4bf1-b7f8-ecfb27fdf6c5	HKD	CNY	2025-11-07	0.92000000	manual	2025-11-07 20:37:50.511495+08
ccba404d-5084-4d76-ab7b-4eb4a845ca28	JPY	CNY	2025-11-07	0.04800000	manual	2025-11-07 20:37:50.511495+08
8dd5ab6a-44f9-44ed-87de-585381784ddf	EUR	CNY	2025-11-07	7.80000000	manual	2025-11-07 20:37:50.511495+08
a1a0c810-b051-4da3-9fc4-8b0d675e25f2	GBP	CNY	2025-11-07	9.10000000	manual	2025-11-07 20:37:50.511495+08
3ee7ef26-e69e-45ff-a321-ad4f28d50485	CNY	USD	2025-11-07	0.13890000	manual	2025-11-07 20:37:50.511495+08
7d055819-8893-476c-aeda-18a4e89e4b16	CNY	HKD	2025-11-07	1.08700000	manual	2025-11-07 20:37:50.511495+08
85a56ad3-50ff-4dcb-93d3-1344121cbfd1	CNY	JPY	2025-11-07	20.83330000	manual	2025-11-07 20:37:50.511495+08
f96571bf-8f8c-480c-a4eb-65965fb0db82	CNY	EUR	2025-11-07	0.12820000	manual	2025-11-07 20:37:50.511495+08
899d3d8f-c3eb-4687-9d2e-5138b3dd506e	CNY	GBP	2025-11-07	0.10990000	manual	2025-11-07 20:37:50.511495+08
\.


--
-- Data for Name: liquidity_tags; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.liquidity_tags (id, name, description, color, sort_order, is_active, created_at) FROM stdin;
b6d9da25-d0ce-4bca-9253-d1d7ed63a70c	高流动性	大盘股、主要ETF等高流动性资产	#22c55e	1	t	2025-11-07 20:37:50.508391+08
23fc8fc7-fc39-4a3d-b994-ae8eccfbadca	中等流动性	中盘股、部分基金等中等流动性资产	#f59e0b	2	t	2025-11-07 20:37:50.508391+08
1cc2f5cc-7d93-4ccd-a261-4f259ff1d7d5	低流动性	小盘股、私募基金等低流动性资产	#ef4444	3	t	2025-11-07 20:37:50.508391+08
68a43122-aba5-4c91-a173-a44a08f73ab8	锁定期	有锁定期限制的资产	#8b5cf6	4	t	2025-11-07 20:37:50.508391+08
04cb9d00-1029-4e11-898b-44fd864c84c8	不可交易	暂停交易或退市的资产	#6b7280	5	t	2025-11-07 20:37:50.508391+08
\.


--
-- Data for Name: markets; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.markets (id, code, name, country, currency, timezone, trading_hours, holidays, is_active, created_at, updated_at) FROM stdin;
f999a5fb-414f-445e-9c50-462214781ed0	SSE	上海证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
96179b90-7208-4a4c-ad01-a6c5c4c345c1	SZSE	深圳证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
1bd28043-093d-4794-a4f6-38b961fc1614	HKEX	香港交易所	HKG	HKD	Asia/Hong_Kong	{"open": "09:30", "close": "16:00", "lunch_break": {"end": "13:00", "start": "12:00"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
1cefc02a-e99f-4e09-bad4-773c281d4bd6	NYSE	纽约证券交易所	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
c014db1e-0629-4e9d-b704-b73d8e3d4f0f	NASDAQ	纳斯达克	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
9187f350-df32-4ffd-baeb-7f64afb2cdb7	TSE	东京证券交易所	JPN	JPY	Asia/Tokyo	{"open": "09:00", "close": "15:00", "lunch_break": {"end": "12:30", "start": "11:30"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
e37cc414-b563-4d78-ab52-e4c5bc9c0108	LSE	伦敦证券交易所	GBR	GBP	Europe/London	{"open": "08:00", "close": "16:30"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
0c2ae5d6-bd49-4d80-940b-704008bda5d5	FWB	法兰克福证券交易所	DEU	EUR	Europe/Berlin	{"open": "09:00", "close": "17:30"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
\.


--
-- Data for Name: option_details; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.option_details (id, asset_id, underlying_asset_id, option_type, strike_price, expiration_date, contract_size, exercise_style, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.permissions (id, name, resource, action, description, created_at) FROM stdin;
cfea6186-62c8-4b3e-abfb-c81905aed9fc	users.create	users	create	创建用户	2025-11-07 20:37:50.501561+08
ea335b30-6c85-43e9-b9ff-711571342403	users.read	users	read	查看用户信息	2025-11-07 20:37:50.501561+08
d0459fcf-9155-4ef8-af0a-edd0d94b32ee	users.update	users	update	更新用户信息	2025-11-07 20:37:50.501561+08
f0bbb563-f1d6-4334-94c1-d00aa7962407	users.delete	users	delete	删除用户	2025-11-07 20:37:50.501561+08
d4b15ebc-7ae4-4a5e-ae16-34b249792989	portfolios.create	portfolios	create	创建投资组合	2025-11-07 20:37:50.501561+08
a22f3316-86f1-4d7b-912a-ffec9fff0d6c	portfolios.read	portfolios	read	查看投资组合	2025-11-07 20:37:50.501561+08
096d4047-bac5-4bf2-ae3a-d516c449b48e	portfolios.update	portfolios	update	更新投资组合	2025-11-07 20:37:50.501561+08
7d201d1f-96c1-4b69-a829-87e0e3845b2a	portfolios.delete	portfolios	delete	删除投资组合	2025-11-07 20:37:50.501561+08
0d6ec5f1-789b-45af-806e-47100da555f4	accounts.create	trading_accounts	create	创建交易账户	2025-11-07 20:37:50.501561+08
c624ee32-b553-4244-8a0c-2050465a9623	accounts.read	trading_accounts	read	查看交易账户	2025-11-07 20:37:50.501561+08
7341a05c-da3b-4739-9dfd-eaf819a014b6	accounts.update	trading_accounts	update	更新交易账户	2025-11-07 20:37:50.501561+08
32ae4e88-42e0-4594-98b9-2cee8fcf716e	accounts.delete	trading_accounts	delete	删除交易账户	2025-11-07 20:37:50.501561+08
15434351-d5f9-4cab-9dad-c183a4ef1575	transactions.create	transactions	create	创建交易记录	2025-11-07 20:37:50.501561+08
b9053248-fdfb-4734-8ba2-be991d59d52f	transactions.read	transactions	read	查看交易记录	2025-11-07 20:37:50.501561+08
f3ee0981-5c2a-4b0a-a826-3d70d112c1c1	transactions.update	transactions	update	更新交易记录	2025-11-07 20:37:50.501561+08
5ff1f467-b1bc-4e4c-a590-89c282096518	transactions.delete	transactions	delete	删除交易记录	2025-11-07 20:37:50.501561+08
aaac51da-aec2-4027-a78d-42d2f523f2d4	transactions.import	transactions	import	批量导入交易记录	2025-11-07 20:37:50.501561+08
b9ad6bef-ffb9-4c13-aa81-f16910f9ad3f	assets.create	assets	create	创建资产	2025-11-07 20:37:50.501561+08
72b8d6da-754b-4083-9cdf-2a251f8d6adb	assets.read	assets	read	查看资产信息	2025-11-07 20:37:50.501561+08
028ad711-52f7-4e19-bae1-b3b3977292db	assets.update	assets	update	更新资产信息	2025-11-07 20:37:50.501561+08
733a755a-781c-4f2b-848b-e48e28e9c504	assets.delete	assets	delete	删除资产	2025-11-07 20:37:50.501561+08
902a61ea-a904-4ea0-bff3-1ba041ed5be0	reports.create	reports	create	创建报表	2025-11-07 20:37:50.501561+08
aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	reports.read	reports	read	查看报表	2025-11-07 20:37:50.501561+08
b6a43b66-a24d-4ff1-852f-6dd7130a427f	reports.update	reports	update	更新报表	2025-11-07 20:37:50.501561+08
6cfe96ff-09af-42ef-9fda-cfcf349eb518	reports.delete	reports	delete	删除报表	2025-11-07 20:37:50.501561+08
39584463-d9f5-449c-bba0-44d02580dcdb	reports.export	reports	export	导出报表	2025-11-07 20:37:50.501561+08
6381d308-4c2d-43a2-9662-15ced4e87c3e	system.config	system	config	系统配置管理	2025-11-07 20:37:50.501561+08
142f03b1-a24f-4346-9c9f-4fe5187ba829	system.logs	system	logs	查看系统日志	2025-11-07 20:37:50.501561+08
4902d6c6-845e-4247-a7e8-9eea1c512f8e	system.backup	system	backup	数据备份管理	2025-11-07 20:37:50.501561+08
\.


--
-- Data for Name: portfolios; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.portfolios (id, user_id, name, description, base_currency, is_default, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.positions (id, portfolio_id, trading_account_id, asset_id, quantity, average_cost, total_cost, currency, first_purchase_date, last_transaction_date, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report_executions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.report_executions (id, report_id, execution_status, started_at, completed_at, file_path, file_size, error_message, metadata) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.reports (id, user_id, portfolio_id, name, description, report_type, parameters, schedule, is_scheduled, is_active, last_generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.role_permissions (id, role_id, permission_id, created_at) FROM stdin;
1c6228cf-f559-49bc-b92f-835dfaaf2145	1f1bf9e1-758f-4be9-8aed-93ce84986f44	cfea6186-62c8-4b3e-abfb-c81905aed9fc	2025-11-07 20:37:50.503104+08
2de9830c-2b90-459c-80eb-9ada2f260361	1f1bf9e1-758f-4be9-8aed-93ce84986f44	ea335b30-6c85-43e9-b9ff-711571342403	2025-11-07 20:37:50.503104+08
7fbb2227-f8f8-4a33-9c6e-a994d8fc7ad3	802fd45d-95dd-4548-a7d6-e09808832ae7	ea335b30-6c85-43e9-b9ff-711571342403	2025-11-07 20:37:50.503104+08
b6a967c5-70dd-492a-adb1-2344f00a2d73	660d9712-b07c-4519-8a84-9da637180dfd	ea335b30-6c85-43e9-b9ff-711571342403	2025-11-07 20:37:50.503104+08
28fd9e7c-785a-49d1-a129-894beaaec763	1f1bf9e1-758f-4be9-8aed-93ce84986f44	d0459fcf-9155-4ef8-af0a-edd0d94b32ee	2025-11-07 20:37:50.503104+08
86a48c0a-a06d-4d42-a16a-71020c3f9a39	802fd45d-95dd-4548-a7d6-e09808832ae7	d0459fcf-9155-4ef8-af0a-edd0d94b32ee	2025-11-07 20:37:50.503104+08
5777b665-a90e-45b4-b86d-2acad46f4a05	1f1bf9e1-758f-4be9-8aed-93ce84986f44	f0bbb563-f1d6-4334-94c1-d00aa7962407	2025-11-07 20:37:50.503104+08
bab7a8e5-0933-4b59-ac45-ec3be48867f3	1f1bf9e1-758f-4be9-8aed-93ce84986f44	d4b15ebc-7ae4-4a5e-ae16-34b249792989	2025-11-07 20:37:50.503104+08
7e18ac8b-eec5-45d3-9a76-e9436ba15568	802fd45d-95dd-4548-a7d6-e09808832ae7	d4b15ebc-7ae4-4a5e-ae16-34b249792989	2025-11-07 20:37:50.503104+08
1141dfeb-8ba7-4f47-b1d2-aa169840bb82	1f1bf9e1-758f-4be9-8aed-93ce84986f44	a22f3316-86f1-4d7b-912a-ffec9fff0d6c	2025-11-07 20:37:50.503104+08
08e7c34e-bfd2-4aea-9aee-19e543eeed3c	802fd45d-95dd-4548-a7d6-e09808832ae7	a22f3316-86f1-4d7b-912a-ffec9fff0d6c	2025-11-07 20:37:50.503104+08
3ebd9397-213f-46f4-a354-9b697ab648e4	660d9712-b07c-4519-8a84-9da637180dfd	a22f3316-86f1-4d7b-912a-ffec9fff0d6c	2025-11-07 20:37:50.503104+08
598061dd-dc89-4dc0-a6a3-d3539a3d112d	1f1bf9e1-758f-4be9-8aed-93ce84986f44	096d4047-bac5-4bf2-ae3a-d516c449b48e	2025-11-07 20:37:50.503104+08
9f1172af-5f5b-494a-9456-e8f3d20b9750	802fd45d-95dd-4548-a7d6-e09808832ae7	096d4047-bac5-4bf2-ae3a-d516c449b48e	2025-11-07 20:37:50.503104+08
3f33a2a6-cf29-4fa5-95db-3471883a6967	1f1bf9e1-758f-4be9-8aed-93ce84986f44	7d201d1f-96c1-4b69-a829-87e0e3845b2a	2025-11-07 20:37:50.503104+08
9926dd2f-1a81-46f3-82d5-2fa54c5aadb7	1f1bf9e1-758f-4be9-8aed-93ce84986f44	0d6ec5f1-789b-45af-806e-47100da555f4	2025-11-07 20:37:50.503104+08
050d4379-daf9-4b31-8942-be42c3df3de6	802fd45d-95dd-4548-a7d6-e09808832ae7	0d6ec5f1-789b-45af-806e-47100da555f4	2025-11-07 20:37:50.503104+08
e8a046ec-0bac-4db1-bb79-6c9e7d64f2c4	1f1bf9e1-758f-4be9-8aed-93ce84986f44	c624ee32-b553-4244-8a0c-2050465a9623	2025-11-07 20:37:50.503104+08
8b950b7b-0fcd-4546-984b-f11ec231e5e1	802fd45d-95dd-4548-a7d6-e09808832ae7	c624ee32-b553-4244-8a0c-2050465a9623	2025-11-07 20:37:50.503104+08
d073e28c-8f4c-4550-ab2d-976fb619f34a	660d9712-b07c-4519-8a84-9da637180dfd	c624ee32-b553-4244-8a0c-2050465a9623	2025-11-07 20:37:50.503104+08
5493d02b-ee58-401e-b5ca-6a96bb5caa0f	1f1bf9e1-758f-4be9-8aed-93ce84986f44	7341a05c-da3b-4739-9dfd-eaf819a014b6	2025-11-07 20:37:50.503104+08
06ee4715-aa05-44b8-b0cb-be110ea86411	802fd45d-95dd-4548-a7d6-e09808832ae7	7341a05c-da3b-4739-9dfd-eaf819a014b6	2025-11-07 20:37:50.503104+08
6ffe0421-e098-476b-9b1f-3e4dda86baf8	1f1bf9e1-758f-4be9-8aed-93ce84986f44	32ae4e88-42e0-4594-98b9-2cee8fcf716e	2025-11-07 20:37:50.503104+08
65e4da36-2341-451d-abae-836f157aed60	1f1bf9e1-758f-4be9-8aed-93ce84986f44	15434351-d5f9-4cab-9dad-c183a4ef1575	2025-11-07 20:37:50.503104+08
78fc81e0-c8b3-475a-8533-ddbe15706a25	802fd45d-95dd-4548-a7d6-e09808832ae7	15434351-d5f9-4cab-9dad-c183a4ef1575	2025-11-07 20:37:50.503104+08
dcd2c76b-c534-4a41-b7d3-08d573bf32f1	1f1bf9e1-758f-4be9-8aed-93ce84986f44	b9053248-fdfb-4734-8ba2-be991d59d52f	2025-11-07 20:37:50.503104+08
fb30803a-2eae-457c-8d04-b92892f7b7dc	802fd45d-95dd-4548-a7d6-e09808832ae7	b9053248-fdfb-4734-8ba2-be991d59d52f	2025-11-07 20:37:50.503104+08
cc36c127-38b9-415f-9743-67bcb46d4692	660d9712-b07c-4519-8a84-9da637180dfd	b9053248-fdfb-4734-8ba2-be991d59d52f	2025-11-07 20:37:50.503104+08
a70139b0-efd2-4bcd-a735-1cfa2d46d902	1f1bf9e1-758f-4be9-8aed-93ce84986f44	f3ee0981-5c2a-4b0a-a826-3d70d112c1c1	2025-11-07 20:37:50.503104+08
6f90d00e-f71e-48e5-841e-61585cf2a107	802fd45d-95dd-4548-a7d6-e09808832ae7	f3ee0981-5c2a-4b0a-a826-3d70d112c1c1	2025-11-07 20:37:50.503104+08
1a997484-c395-4459-a160-df01663d7036	1f1bf9e1-758f-4be9-8aed-93ce84986f44	5ff1f467-b1bc-4e4c-a590-89c282096518	2025-11-07 20:37:50.503104+08
a3456c00-14f3-4c27-a73c-76fefeaa3026	1f1bf9e1-758f-4be9-8aed-93ce84986f44	aaac51da-aec2-4027-a78d-42d2f523f2d4	2025-11-07 20:37:50.503104+08
97046e7a-a28f-4815-84b3-abcbc5c360f6	802fd45d-95dd-4548-a7d6-e09808832ae7	aaac51da-aec2-4027-a78d-42d2f523f2d4	2025-11-07 20:37:50.503104+08
baf99772-34cd-422d-94a6-0db3f4a16bcf	1f1bf9e1-758f-4be9-8aed-93ce84986f44	b9ad6bef-ffb9-4c13-aa81-f16910f9ad3f	2025-11-07 20:37:50.503104+08
0b393b69-c40c-4f83-b215-be1a7b62eb6e	802fd45d-95dd-4548-a7d6-e09808832ae7	b9ad6bef-ffb9-4c13-aa81-f16910f9ad3f	2025-11-07 20:37:50.503104+08
31b70301-fa05-4f8c-ac12-11107c951d89	1f1bf9e1-758f-4be9-8aed-93ce84986f44	72b8d6da-754b-4083-9cdf-2a251f8d6adb	2025-11-07 20:37:50.503104+08
d61922c9-b6a2-46a2-ab88-2e020d9902e8	802fd45d-95dd-4548-a7d6-e09808832ae7	72b8d6da-754b-4083-9cdf-2a251f8d6adb	2025-11-07 20:37:50.503104+08
c4ec9870-1ae1-43be-8b37-4908b9bb575f	660d9712-b07c-4519-8a84-9da637180dfd	72b8d6da-754b-4083-9cdf-2a251f8d6adb	2025-11-07 20:37:50.503104+08
cd03f8d9-9e7e-4a03-acc0-41b89b97a5ee	1f1bf9e1-758f-4be9-8aed-93ce84986f44	028ad711-52f7-4e19-bae1-b3b3977292db	2025-11-07 20:37:50.503104+08
3fd1bcfc-091a-46a7-8ffb-bb2cdaabd0d1	802fd45d-95dd-4548-a7d6-e09808832ae7	028ad711-52f7-4e19-bae1-b3b3977292db	2025-11-07 20:37:50.503104+08
acf2604b-e588-4691-9c8d-68b7bef01cb8	1f1bf9e1-758f-4be9-8aed-93ce84986f44	733a755a-781c-4f2b-848b-e48e28e9c504	2025-11-07 20:37:50.503104+08
86e7f89f-8d98-4277-a9c0-ac9431f2aa24	1f1bf9e1-758f-4be9-8aed-93ce84986f44	902a61ea-a904-4ea0-bff3-1ba041ed5be0	2025-11-07 20:37:50.503104+08
71a86e31-b9dd-467a-9215-f1486e936a5f	802fd45d-95dd-4548-a7d6-e09808832ae7	902a61ea-a904-4ea0-bff3-1ba041ed5be0	2025-11-07 20:37:50.503104+08
85881fe7-0fe7-4b1d-9985-169a397d09be	1f1bf9e1-758f-4be9-8aed-93ce84986f44	aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	2025-11-07 20:37:50.503104+08
4f95f0c9-39ee-465c-9f2b-792ad33cd625	802fd45d-95dd-4548-a7d6-e09808832ae7	aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	2025-11-07 20:37:50.503104+08
3cf859a3-ee33-49a7-ac92-86529558a762	660d9712-b07c-4519-8a84-9da637180dfd	aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	2025-11-07 20:37:50.503104+08
226097d0-6b02-4647-bffc-4e5af64a7f88	1f1bf9e1-758f-4be9-8aed-93ce84986f44	b6a43b66-a24d-4ff1-852f-6dd7130a427f	2025-11-07 20:37:50.503104+08
f98cc7e6-30a0-4346-9f15-63b5cb122d23	802fd45d-95dd-4548-a7d6-e09808832ae7	b6a43b66-a24d-4ff1-852f-6dd7130a427f	2025-11-07 20:37:50.503104+08
e746fdaf-d111-472f-90fe-63c923067476	1f1bf9e1-758f-4be9-8aed-93ce84986f44	6cfe96ff-09af-42ef-9fda-cfcf349eb518	2025-11-07 20:37:50.503104+08
f1be91e8-e81e-4da5-b06a-2d8400e1937a	1f1bf9e1-758f-4be9-8aed-93ce84986f44	39584463-d9f5-449c-bba0-44d02580dcdb	2025-11-07 20:37:50.503104+08
48794cc7-7a28-461a-bc3b-d42a8806a6d6	802fd45d-95dd-4548-a7d6-e09808832ae7	39584463-d9f5-449c-bba0-44d02580dcdb	2025-11-07 20:37:50.503104+08
8398cd4b-4485-4e47-8e5f-f215724d9f57	1f1bf9e1-758f-4be9-8aed-93ce84986f44	6381d308-4c2d-43a2-9662-15ced4e87c3e	2025-11-07 20:37:50.503104+08
42cfff39-2bdb-49cf-bec3-5926b4b4e163	1f1bf9e1-758f-4be9-8aed-93ce84986f44	142f03b1-a24f-4346-9c9f-4fe5187ba829	2025-11-07 20:37:50.503104+08
f834d16a-4e94-441b-9438-6ae205b7a231	1f1bf9e1-758f-4be9-8aed-93ce84986f44	4902d6c6-845e-4247-a7e8-9eea1c512f8e	2025-11-07 20:37:50.503104+08
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.roles (id, name, description, is_active, created_at, updated_at) FROM stdin;
1f1bf9e1-758f-4be9-8aed-93ce84986f44	admin	系统管理员，拥有所有权限	t	2025-11-07 20:37:50.495427+08	2025-11-07 20:37:50.495427+08
802fd45d-95dd-4548-a7d6-e09808832ae7	user	普通用户，拥有基本功能权限	t	2025-11-07 20:37:50.495427+08	2025-11-07 20:37:50.495427+08
660d9712-b07c-4519-8a84-9da637180dfd	viewer	只读用户，只能查看数据	t	2025-11-07 20:37:50.495427+08	2025-11-07 20:37:50.495427+08
\.


--
-- Data for Name: trading_accounts; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.trading_accounts (id, portfolio_id, name, account_type, broker_name, account_number, currency, initial_balance, current_balance, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.transactions (id, portfolio_id, trading_account_id, asset_id, transaction_type, quantity, price, total_amount, fees, taxes, currency, exchange_rate, transaction_date, settlement_date, notes, tags, liquidity_tag_id, external_id, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assigned_at, expires_at, is_active) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.user_sessions (id, user_id, token_hash, refresh_token_hash, device_info, ip_address, user_agent, is_active, expires_at, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.users (id, email, username, password_hash, first_name, last_name, phone, avatar_url, timezone, language, currency_preference, is_active, is_verified, email_verified_at, last_login_at, login_count, failed_login_attempts, locked_until, created_at, updated_at) FROM stdin;
\.


--
-- Name: portfolio_tags_id_seq; Type: SEQUENCE SET; Schema: finapp; Owner: finapp_user
--

SELECT pg_catalog.setval('finapp.portfolio_tags_id_seq', 1, false);


--
-- Name: tag_categories_id_seq; Type: SEQUENCE SET; Schema: finapp; Owner: finapp_user
--

SELECT pg_catalog.setval('finapp.tag_categories_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: finapp; Owner: finapp_user
--

SELECT pg_catalog.setval('finapp.tags_id_seq', 1, false);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: asset_prices asset_prices_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.asset_prices
    ADD CONSTRAINT asset_prices_pkey PRIMARY KEY (id);


--
-- Name: asset_types asset_types_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.asset_types
    ADD CONSTRAINT asset_types_pkey PRIMARY KEY (id);


--
-- Name: assets assets_country_id_symbol_unique; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_country_id_symbol_unique UNIQUE (country_id, symbol);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: benchmark_prices benchmark_prices_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.benchmark_prices
    ADD CONSTRAINT benchmark_prices_pkey PRIMARY KEY (id);


--
-- Name: benchmarks benchmarks_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.benchmarks
    ADD CONSTRAINT benchmarks_pkey PRIMARY KEY (id);


--
-- Name: bond_details bond_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.bond_details
    ADD CONSTRAINT bond_details_pkey PRIMARY KEY (id);


--
-- Name: cash_flows cash_flows_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_pkey PRIMARY KEY (id);


--
-- Name: countries countries_code_key; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.countries
    ADD CONSTRAINT countries_code_key UNIQUE (code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: fund_details fund_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.fund_details
    ADD CONSTRAINT fund_details_pkey PRIMARY KEY (id);


--
-- Name: futures_details futures_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.futures_details
    ADD CONSTRAINT futures_details_pkey PRIMARY KEY (id);


--
-- Name: liquidity_tags liquidity_tags_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.liquidity_tags
    ADD CONSTRAINT liquidity_tags_pkey PRIMARY KEY (id);


--
-- Name: markets markets_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.markets
    ADD CONSTRAINT markets_pkey PRIMARY KEY (id);


--
-- Name: option_details option_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.option_details
    ADD CONSTRAINT option_details_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: performance_metrics performance_metrics_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.performance_metrics
    ADD CONSTRAINT performance_metrics_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: portfolio_snapshots portfolio_snapshots_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_snapshots
    ADD CONSTRAINT portfolio_snapshots_pkey PRIMARY KEY (id);


--
-- Name: portfolio_tags portfolio_tags_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_pkey PRIMARY KEY (id);


--
-- Name: portfolios portfolios_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolios
    ADD CONSTRAINT portfolios_pkey PRIMARY KEY (id);


--
-- Name: position_snapshots position_snapshots_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.position_snapshots
    ADD CONSTRAINT position_snapshots_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: price_data_sources price_data_sources_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_data_sources
    ADD CONSTRAINT price_data_sources_pkey PRIMARY KEY (id);


--
-- Name: price_sync_errors price_sync_errors_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_errors
    ADD CONSTRAINT price_sync_errors_pkey PRIMARY KEY (id);


--
-- Name: price_sync_logs price_sync_logs_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_logs
    ADD CONSTRAINT price_sync_logs_pkey PRIMARY KEY (id);


--
-- Name: price_sync_tasks price_sync_tasks_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_pkey PRIMARY KEY (id);


--
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: stock_details stock_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_details
    ADD CONSTRAINT stock_details_pkey PRIMARY KEY (id);


--
-- Name: stock_option_details stock_option_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_option_details
    ADD CONSTRAINT stock_option_details_pkey PRIMARY KEY (id);


--
-- Name: tag_categories tag_categories_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories
    ADD CONSTRAINT tag_categories_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: trading_accounts trading_accounts_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.trading_accounts
    ADD CONSTRAINT trading_accounts_pkey PRIMARY KEY (id);


--
-- Name: transaction_tag_mappings transaction_tag_mappings_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transaction_tag_mappings
    ADD CONSTRAINT transaction_tag_mappings_pkey PRIMARY KEY (transaction_id, tag_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: treasury_details treasury_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.treasury_details
    ADD CONSTRAINT treasury_details_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wealth_product_details wealth_product_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.wealth_product_details
    ADD CONSTRAINT wealth_product_details_pkey PRIMARY KEY (id);


--
-- Name: asset_prices asset_prices_asset_id_price_date_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_asset_id_price_date_key UNIQUE (asset_id, price_date);


--
-- Name: asset_prices asset_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_pkey PRIMARY KEY (id);


--
-- Name: asset_types asset_types_code_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_types
    ADD CONSTRAINT asset_types_code_key UNIQUE (code);


--
-- Name: asset_types asset_types_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_types
    ADD CONSTRAINT asset_types_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: assets assets_symbol_market_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_symbol_market_id_key UNIQUE (symbol, market_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: benchmark_prices benchmark_prices_benchmark_id_price_date_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmark_prices
    ADD CONSTRAINT benchmark_prices_benchmark_id_price_date_key UNIQUE (benchmark_id, price_date);


--
-- Name: benchmark_prices benchmark_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmark_prices
    ADD CONSTRAINT benchmark_prices_pkey PRIMARY KEY (id);


--
-- Name: benchmarks benchmarks_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_name_key UNIQUE (name);


--
-- Name: benchmarks benchmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_pkey PRIMARY KEY (id);


--
-- Name: benchmarks benchmarks_symbol_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_symbol_key UNIQUE (symbol);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_from_currency_to_currency_rate_date_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_from_currency_to_currency_rate_date_key UNIQUE (from_currency, to_currency, rate_date);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: liquidity_tags liquidity_tags_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.liquidity_tags
    ADD CONSTRAINT liquidity_tags_name_key UNIQUE (name);


--
-- Name: liquidity_tags liquidity_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.liquidity_tags
    ADD CONSTRAINT liquidity_tags_pkey PRIMARY KEY (id);


--
-- Name: markets markets_code_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT markets_code_key UNIQUE (code);


--
-- Name: markets markets_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT markets_pkey PRIMARY KEY (id);


--
-- Name: option_details option_details_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.option_details
    ADD CONSTRAINT option_details_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: portfolios portfolios_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_pkey PRIMARY KEY (id);


--
-- Name: portfolios portfolios_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_user_id_name_key UNIQUE (user_id, name);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: positions positions_portfolio_id_trading_account_id_asset_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_portfolio_id_trading_account_id_asset_id_key UNIQUE (portfolio_id, trading_account_id, asset_id);


--
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_id_key UNIQUE (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: trading_accounts trading_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.trading_accounts
    ADD CONSTRAINT trading_accounts_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_key UNIQUE (user_id, role_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: asset_prices_asset_id_price_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX asset_prices_asset_id_price_date_key ON finapp.asset_prices USING btree (asset_id, price_date);


--
-- Name: asset_types_code_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX asset_types_code_key ON finapp.asset_types USING btree (code);


--
-- Name: benchmark_prices_benchmark_id_price_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX benchmark_prices_benchmark_id_price_date_key ON finapp.benchmark_prices USING btree (benchmark_id, price_date);


--
-- Name: benchmarks_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX benchmarks_name_key ON finapp.benchmarks USING btree (name);


--
-- Name: benchmarks_symbol_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX benchmarks_symbol_key ON finapp.benchmarks USING btree (symbol);


--
-- Name: bond_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX bond_details_asset_id_key ON finapp.bond_details USING btree (asset_id);


--
-- Name: exchange_rates_from_currency_to_currency_rate_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX exchange_rates_from_currency_to_currency_rate_date_key ON finapp.exchange_rates USING btree (from_currency, to_currency, rate_date);


--
-- Name: fund_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX fund_details_asset_id_key ON finapp.fund_details USING btree (asset_id);


--
-- Name: futures_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX futures_details_asset_id_key ON finapp.futures_details USING btree (asset_id);


--
-- Name: idx_asset_prices_asset_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_asset_date ON finapp.asset_prices USING btree (asset_id, price_date);


--
-- Name: idx_asset_prices_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_asset_id ON finapp.asset_prices USING btree (asset_id);


--
-- Name: idx_asset_prices_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_created_at ON finapp.asset_prices USING btree (created_at);


--
-- Name: idx_asset_prices_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_date ON finapp.asset_prices USING btree (price_date);


--
-- Name: idx_asset_prices_price_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_price_date ON finapp.asset_prices USING btree (price_date);


--
-- Name: idx_asset_types_category; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_category ON finapp.asset_types USING btree (category);


--
-- Name: idx_asset_types_code; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_code ON finapp.asset_types USING btree (code);


--
-- Name: idx_asset_types_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_is_active ON finapp.asset_types USING btree (is_active);


--
-- Name: idx_asset_types_location_dimension; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_location_dimension ON finapp.asset_types USING btree (location_dimension);


--
-- Name: idx_assets_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_active ON finapp.assets USING btree (is_active);


--
-- Name: idx_assets_asset_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_asset_type ON finapp.assets USING btree (asset_type_id);


--
-- Name: idx_assets_asset_type_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_asset_type_id ON finapp.assets USING btree (asset_type_id);


--
-- Name: idx_assets_country_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_country_id ON finapp.assets USING btree (country_id);


--
-- Name: idx_assets_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_created_at ON finapp.assets USING btree (created_at);


--
-- Name: idx_assets_currency; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_currency ON finapp.assets USING btree (currency);


--
-- Name: idx_assets_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_is_active ON finapp.assets USING btree (is_active);


--
-- Name: idx_assets_sector; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_sector ON finapp.assets USING btree (sector);


--
-- Name: idx_assets_symbol; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_symbol ON finapp.assets USING btree (symbol);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_action ON finapp.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_created_at ON finapp.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_record_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_record_id ON finapp.audit_logs USING btree (record_id);


--
-- Name: idx_audit_logs_table_name; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_table_name ON finapp.audit_logs USING btree (table_name);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_user_id ON finapp.audit_logs USING btree (user_id);


--
-- Name: idx_benchmark_prices_benchmark_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmark_prices_benchmark_date ON finapp.benchmark_prices USING btree (benchmark_id, price_date);


--
-- Name: idx_benchmark_prices_benchmark_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmark_prices_benchmark_id ON finapp.benchmark_prices USING btree (benchmark_id);


--
-- Name: idx_benchmark_prices_price_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmark_prices_price_date ON finapp.benchmark_prices USING btree (price_date);


--
-- Name: idx_benchmarks_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmarks_is_active ON finapp.benchmarks USING btree (is_active);


--
-- Name: idx_benchmarks_symbol; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmarks_symbol ON finapp.benchmarks USING btree (symbol);


--
-- Name: idx_bond_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_bond_details_asset ON finapp.bond_details USING btree (asset_id);


--
-- Name: idx_bond_details_maturity; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_bond_details_maturity ON finapp.bond_details USING btree (maturity_date);


--
-- Name: idx_bond_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_bond_details_type ON finapp.bond_details USING btree (bond_type);


--
-- Name: idx_cash_flows_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_asset_id ON finapp.cash_flows USING btree (asset_id);


--
-- Name: idx_cash_flows_category; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_category ON finapp.cash_flows USING btree (category);


--
-- Name: idx_cash_flows_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_date ON finapp.cash_flows USING btree (date);


--
-- Name: idx_cash_flows_flow_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_flow_date ON finapp.cash_flows USING btree (flow_date);


--
-- Name: idx_cash_flows_flow_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_flow_type ON finapp.cash_flows USING btree (flow_type);


--
-- Name: idx_cash_flows_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_portfolio_id ON finapp.cash_flows USING btree (portfolio_id);


--
-- Name: idx_cash_flows_trading_account_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_trading_account_id ON finapp.cash_flows USING btree (trading_account_id);


--
-- Name: idx_cash_flows_transaction_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_transaction_id ON finapp.cash_flows USING btree (transaction_id);


--
-- Name: idx_email_verification_tokens_expires_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_email_verification_tokens_expires_at ON finapp.email_verification_tokens USING btree (expires_at);


--
-- Name: idx_email_verification_tokens_token_hash; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_email_verification_tokens_token_hash ON finapp.email_verification_tokens USING btree (token_hash);


--
-- Name: idx_email_verification_tokens_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_email_verification_tokens_user_id ON finapp.email_verification_tokens USING btree (user_id);


--
-- Name: idx_exchange_rates_currencies; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_exchange_rates_currencies ON finapp.exchange_rates USING btree (from_currency, to_currency);


--
-- Name: idx_exchange_rates_currencies_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_exchange_rates_currencies_date ON finapp.exchange_rates USING btree (from_currency, to_currency, rate_date);


--
-- Name: idx_exchange_rates_rate_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_exchange_rates_rate_date ON finapp.exchange_rates USING btree (rate_date);


--
-- Name: idx_fund_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_fund_details_asset ON finapp.fund_details USING btree (asset_id);


--
-- Name: idx_fund_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_fund_details_type ON finapp.fund_details USING btree (fund_type);


--
-- Name: idx_futures_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_futures_details_asset ON finapp.futures_details USING btree (asset_id);


--
-- Name: idx_futures_details_month; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_futures_details_month ON finapp.futures_details USING btree (contract_month);


--
-- Name: idx_futures_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_futures_details_type ON finapp.futures_details USING btree (futures_type);


--
-- Name: idx_liquidity_tags_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_liquidity_tags_is_active ON finapp.liquidity_tags USING btree (is_active);


--
-- Name: idx_liquidity_tags_sort_order; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_liquidity_tags_sort_order ON finapp.liquidity_tags USING btree (sort_order);


--
-- Name: idx_markets_code; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_markets_code ON finapp.markets USING btree (code);


--
-- Name: idx_markets_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_markets_is_active ON finapp.markets USING btree (is_active);


--
-- Name: idx_option_details_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_option_details_asset_id ON finapp.option_details USING btree (asset_id);


--
-- Name: idx_option_details_expiration_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_option_details_expiration_date ON finapp.option_details USING btree (expiration_date);


--
-- Name: idx_option_details_underlying_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_option_details_underlying_asset_id ON finapp.option_details USING btree (underlying_asset_id);


--
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_password_reset_tokens_expires_at ON finapp.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token_hash; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_password_reset_tokens_token_hash ON finapp.password_reset_tokens USING btree (token_hash);


--
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_password_reset_tokens_user_id ON finapp.password_reset_tokens USING btree (user_id);


--
-- Name: idx_performance_metrics_metric_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_metric_type ON finapp.performance_metrics USING btree (metric_type);


--
-- Name: idx_performance_metrics_period_dates; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_period_dates ON finapp.performance_metrics USING btree (period_start, period_end);


--
-- Name: idx_performance_metrics_period_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_period_type ON finapp.performance_metrics USING btree (period_type);


--
-- Name: idx_performance_metrics_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_portfolio_id ON finapp.performance_metrics USING btree (portfolio_id);


--
-- Name: idx_portfolio_snapshots_portfolio_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolio_snapshots_portfolio_date ON finapp.portfolio_snapshots USING btree (portfolio_id, snapshot_date);


--
-- Name: idx_portfolio_snapshots_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolio_snapshots_portfolio_id ON finapp.portfolio_snapshots USING btree (portfolio_id);


--
-- Name: idx_portfolio_snapshots_snapshot_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolio_snapshots_snapshot_date ON finapp.portfolio_snapshots USING btree (snapshot_date);


--
-- Name: idx_portfolios_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_is_active ON finapp.portfolios USING btree (is_active);


--
-- Name: idx_portfolios_is_default; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_is_default ON finapp.portfolios USING btree (is_default);


--
-- Name: idx_portfolios_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_user_id ON finapp.portfolios USING btree (user_id);


--
-- Name: idx_portfolios_user_sort; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_user_sort ON finapp.portfolios USING btree (user_id, sort_order);


--
-- Name: idx_position_snapshots_portfolio_snapshot_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_position_snapshots_portfolio_snapshot_id ON finapp.position_snapshots USING btree (portfolio_snapshot_id);


--
-- Name: idx_position_snapshots_position_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_position_snapshots_position_id ON finapp.position_snapshots USING btree (position_id);


--
-- Name: idx_position_snapshots_snapshot_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_position_snapshots_snapshot_date ON finapp.position_snapshots USING btree (snapshot_date);


--
-- Name: idx_positions_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_asset_id ON finapp.positions USING btree (asset_id);


--
-- Name: idx_positions_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_is_active ON finapp.positions USING btree (is_active);


--
-- Name: idx_positions_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_portfolio_id ON finapp.positions USING btree (portfolio_id);


--
-- Name: idx_positions_trading_account_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_trading_account_id ON finapp.positions USING btree (trading_account_id);


--
-- Name: idx_price_data_sources_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_data_sources_active ON finapp.price_data_sources USING btree (is_active);


--
-- Name: idx_price_data_sources_provider; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_data_sources_provider ON finapp.price_data_sources USING btree (provider);


--
-- Name: idx_price_sync_errors_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_errors_asset ON finapp.price_sync_errors USING btree (asset_id);


--
-- Name: idx_price_sync_errors_log; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_errors_log ON finapp.price_sync_errors USING btree (log_id);


--
-- Name: idx_price_sync_logs_started; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_logs_started ON finapp.price_sync_logs USING btree (started_at DESC);


--
-- Name: idx_price_sync_logs_status; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_logs_status ON finapp.price_sync_logs USING btree (status);


--
-- Name: idx_price_sync_logs_task; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_logs_task ON finapp.price_sync_logs USING btree (task_id);


--
-- Name: idx_price_sync_tasks_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_active ON finapp.price_sync_tasks USING btree (is_active);


--
-- Name: idx_price_sync_tasks_country_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_country_id ON finapp.price_sync_tasks USING btree (country_id);


--
-- Name: idx_price_sync_tasks_data_source; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_data_source ON finapp.price_sync_tasks USING btree (data_source_id);


--
-- Name: idx_price_sync_tasks_schedule; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_schedule ON finapp.price_sync_tasks USING btree (schedule_type, is_active);


--
-- Name: idx_report_executions_report_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_report_executions_report_id ON finapp.report_executions USING btree (report_id);


--
-- Name: idx_report_executions_started_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_report_executions_started_at ON finapp.report_executions USING btree (started_at);


--
-- Name: idx_report_executions_status; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_report_executions_status ON finapp.report_executions USING btree (execution_status);


--
-- Name: idx_reports_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_is_active ON finapp.reports USING btree (is_active);


--
-- Name: idx_reports_is_scheduled; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_is_scheduled ON finapp.reports USING btree (is_scheduled);


--
-- Name: idx_reports_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_portfolio_id ON finapp.reports USING btree (portfolio_id);


--
-- Name: idx_reports_report_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_report_type ON finapp.reports USING btree (report_type);


--
-- Name: idx_reports_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_user_id ON finapp.reports USING btree (user_id);


--
-- Name: idx_role_permissions_permission_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_role_permissions_permission_id ON finapp.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_role_permissions_role_id ON finapp.role_permissions USING btree (role_id);


--
-- Name: idx_stock_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_details_asset ON finapp.stock_details USING btree (asset_id);


--
-- Name: idx_stock_details_industry; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_details_industry ON finapp.stock_details USING btree (industry);


--
-- Name: idx_stock_details_sector; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_details_sector ON finapp.stock_details USING btree (sector);


--
-- Name: idx_stock_option_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_asset ON finapp.stock_option_details USING btree (asset_id);


--
-- Name: idx_stock_option_details_expiration; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_expiration ON finapp.stock_option_details USING btree (expiration_date);


--
-- Name: idx_stock_option_details_strike; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_strike ON finapp.stock_option_details USING btree (strike_price);


--
-- Name: idx_stock_option_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_type ON finapp.stock_option_details USING btree (option_type);


--
-- Name: idx_stock_option_details_underlying; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_underlying ON finapp.stock_option_details USING btree (underlying_stock_id);


--
-- Name: idx_trading_accounts_account_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_trading_accounts_account_type ON finapp.trading_accounts USING btree (account_type);


--
-- Name: idx_trading_accounts_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_trading_accounts_is_active ON finapp.trading_accounts USING btree (is_active);


--
-- Name: idx_trading_accounts_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_trading_accounts_portfolio_id ON finapp.trading_accounts USING btree (portfolio_id);


--
-- Name: idx_transaction_tag_mappings_tag_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transaction_tag_mappings_tag_id ON finapp.transaction_tag_mappings USING btree (tag_id);


--
-- Name: idx_transaction_tag_mappings_transaction_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transaction_tag_mappings_transaction_id ON finapp.transaction_tag_mappings USING btree (transaction_id);


--
-- Name: idx_transactions_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_asset_id ON finapp.transactions USING btree (asset_id);


--
-- Name: idx_transactions_executed_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_executed_at ON finapp.transactions USING btree (executed_at);


--
-- Name: idx_transactions_external_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_external_id ON finapp.transactions USING btree (external_id);


--
-- Name: idx_transactions_liquidity_tag; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_liquidity_tag ON finapp.transactions USING btree (liquidity_tag);


--
-- Name: idx_transactions_liquidity_tag_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_liquidity_tag_id ON finapp.transactions USING btree (liquidity_tag_id);


--
-- Name: idx_transactions_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_portfolio_id ON finapp.transactions USING btree (portfolio_id);


--
-- Name: idx_transactions_side; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_side ON finapp.transactions USING btree (side);


--
-- Name: idx_transactions_status; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_status ON finapp.transactions USING btree (status);


--
-- Name: idx_transactions_tags; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_tags ON finapp.transactions USING gin (tags);


--
-- Name: idx_transactions_total_amount; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_total_amount ON finapp.transactions USING btree (total_amount);


--
-- Name: idx_transactions_trading_account_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_trading_account_id ON finapp.transactions USING btree (trading_account_id);


--
-- Name: idx_transactions_transaction_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_transaction_date ON finapp.transactions USING btree (transaction_date);


--
-- Name: idx_transactions_transaction_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_transaction_type ON finapp.transactions USING btree (transaction_type);


--
-- Name: idx_transactions_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_user_id ON finapp.transactions USING btree (user_id);


--
-- Name: idx_treasury_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_treasury_details_asset ON finapp.treasury_details USING btree (asset_id);


--
-- Name: idx_treasury_details_maturity; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_treasury_details_maturity ON finapp.treasury_details USING btree (maturity_date);


--
-- Name: idx_treasury_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_treasury_details_type ON finapp.treasury_details USING btree (treasury_type);


--
-- Name: idx_user_roles_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_roles_is_active ON finapp.user_roles USING btree (is_active);


--
-- Name: idx_user_roles_role_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_roles_role_id ON finapp.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_roles_user_id ON finapp.user_roles USING btree (user_id);


--
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_expires_at ON finapp.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_is_active ON finapp.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_token_hash; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_token_hash ON finapp.user_sessions USING btree (token_hash);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_user_id ON finapp.user_sessions USING btree (user_id);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_created_at ON finapp.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_email ON finapp.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_is_active ON finapp.users USING btree (is_active);


--
-- Name: idx_users_last_login_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_last_login_at ON finapp.users USING btree (last_login_at);


--
-- Name: idx_users_username; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_username ON finapp.users USING btree (username);


--
-- Name: idx_wealth_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_wealth_details_asset ON finapp.wealth_product_details USING btree (asset_id);


--
-- Name: idx_wealth_details_risk; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_wealth_details_risk ON finapp.wealth_product_details USING btree (risk_level);


--
-- Name: idx_wealth_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_wealth_details_type ON finapp.wealth_product_details USING btree (product_type);


--
-- Name: liquidity_tags_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX liquidity_tags_name_key ON finapp.liquidity_tags USING btree (name);


--
-- Name: markets_code_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX markets_code_key ON finapp.markets USING btree (code);


--
-- Name: performance_metrics_portfolio_id_metric_type_period_type_pe_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX performance_metrics_portfolio_id_metric_type_period_type_pe_key ON finapp.performance_metrics USING btree (portfolio_id, metric_type, period_type, period_start, period_end);


--
-- Name: permissions_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX permissions_name_key ON finapp.permissions USING btree (name);


--
-- Name: portfolio_snapshots_portfolio_id_snapshot_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX portfolio_snapshots_portfolio_id_snapshot_date_key ON finapp.portfolio_snapshots USING btree (portfolio_id, snapshot_date);


--
-- Name: portfolio_tags_portfolio_id_tag_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX portfolio_tags_portfolio_id_tag_id_key ON finapp.portfolio_tags USING btree (portfolio_id, tag_id);


--
-- Name: portfolios_user_id_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX portfolios_user_id_name_key ON finapp.portfolios USING btree (user_id, name);


--
-- Name: positions_portfolio_id_trading_account_id_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX positions_portfolio_id_trading_account_id_asset_id_key ON finapp.positions USING btree (portfolio_id, trading_account_id, asset_id);


--
-- Name: price_data_sources_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX price_data_sources_name_key ON finapp.price_data_sources USING btree (name);


--
-- Name: role_permissions_role_id_permission_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX role_permissions_role_id_permission_id_key ON finapp.role_permissions USING btree (role_id, permission_id);


--
-- Name: roles_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX roles_name_key ON finapp.roles USING btree (name);


--
-- Name: stock_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX stock_details_asset_id_key ON finapp.stock_details USING btree (asset_id);


--
-- Name: stock_option_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX stock_option_details_asset_id_key ON finapp.stock_option_details USING btree (asset_id);


--
-- Name: tag_categories_user_id_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX tag_categories_user_id_name_key ON finapp.tag_categories USING btree (user_id, name);


--
-- Name: tags_user_id_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX tags_user_id_name_key ON finapp.tags USING btree (user_id, name);


--
-- Name: treasury_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX treasury_details_asset_id_key ON finapp.treasury_details USING btree (asset_id);


--
-- Name: user_roles_user_id_role_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX user_roles_user_id_role_id_key ON finapp.user_roles USING btree (user_id, role_id);


--
-- Name: users_email_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX users_email_key ON finapp.users USING btree (email);


--
-- Name: users_username_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX users_username_key ON finapp.users USING btree (username);


--
-- Name: wealth_product_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX wealth_product_details_asset_id_key ON finapp.wealth_product_details USING btree (asset_id);


--
-- Name: idx_assets_asset_type_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_asset_type_id ON public.assets USING btree (asset_type_id);


--
-- Name: idx_assets_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_is_active ON public.assets USING btree (is_active);


--
-- Name: idx_assets_market_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_market_id ON public.assets USING btree (market_id);


--
-- Name: idx_assets_symbol; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_symbol ON public.assets USING btree (symbol);


--
-- Name: idx_assets_symbol_market; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_symbol_market ON public.assets USING btree (symbol, market_id);


--
-- Name: idx_email_verification_tokens_expires_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_email_verification_tokens_expires_at ON public.email_verification_tokens USING btree (expires_at);


--
-- Name: idx_email_verification_tokens_token_hash; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_email_verification_tokens_token_hash ON public.email_verification_tokens USING btree (token_hash);


--
-- Name: idx_email_verification_tokens_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_email_verification_tokens_user_id ON public.email_verification_tokens USING btree (user_id);


--
-- Name: idx_option_details_asset_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_option_details_asset_id ON public.option_details USING btree (asset_id);


--
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_password_reset_tokens_expires_at ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token_hash; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_password_reset_tokens_token_hash ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_password_reset_tokens_user_id ON public.password_reset_tokens USING btree (user_id);


--
-- Name: idx_portfolios_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_portfolios_is_active ON public.portfolios USING btree (is_active);


--
-- Name: idx_portfolios_is_default; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_portfolios_is_default ON public.portfolios USING btree (is_default);


--
-- Name: idx_portfolios_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_portfolios_user_id ON public.portfolios USING btree (user_id);


--
-- Name: idx_role_permissions_permission_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_role_permissions_permission_id ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_role_permissions_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: idx_trading_accounts_account_type; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_trading_accounts_account_type ON public.trading_accounts USING btree (account_type);


--
-- Name: idx_trading_accounts_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_trading_accounts_is_active ON public.trading_accounts USING btree (is_active);


--
-- Name: idx_trading_accounts_portfolio_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_trading_accounts_portfolio_id ON public.trading_accounts USING btree (portfolio_id);


--
-- Name: idx_user_roles_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_roles_is_active ON public.user_roles USING btree (is_active);


--
-- Name: idx_user_roles_role_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_roles_role_id ON public.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_roles_user_id ON public.user_roles USING btree (user_id);


--
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_expires_at ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_token_hash; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_token_hash ON public.user_sessions USING btree (token_hash);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_last_login_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_last_login_at ON public.users USING btree (last_login_at);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: roles update_roles_updated_at; Type: TRIGGER; Schema: public; Owner: caojun
--

CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: caojun
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: asset_prices asset_prices_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.asset_prices
    ADD CONSTRAINT asset_prices_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: assets assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES finapp.asset_types(id);


--
-- Name: assets assets_country_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_country_id_fkey FOREIGN KEY (country_id) REFERENCES finapp.countries(id) ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id);


--
-- Name: benchmark_prices benchmark_prices_benchmark_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.benchmark_prices
    ADD CONSTRAINT benchmark_prices_benchmark_id_fkey FOREIGN KEY (benchmark_id) REFERENCES finapp.benchmarks(id) ON DELETE CASCADE;


--
-- Name: bond_details bond_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.bond_details
    ADD CONSTRAINT bond_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: cash_flows cash_flows_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id);


--
-- Name: cash_flows cash_flows_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: cash_flows cash_flows_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES finapp.trading_accounts(id);


--
-- Name: cash_flows cash_flows_transaction_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES finapp.transactions(id);


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: assets fk_assets_liquidity_tag; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT fk_assets_liquidity_tag FOREIGN KEY (liquidity_tag) REFERENCES finapp.liquidity_tags(id);


--
-- Name: fund_details fund_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.fund_details
    ADD CONSTRAINT fund_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: futures_details futures_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.futures_details
    ADD CONSTRAINT futures_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.option_details
    ADD CONSTRAINT option_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_underlying_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.option_details
    ADD CONSTRAINT option_details_underlying_asset_id_fkey FOREIGN KEY (underlying_asset_id) REFERENCES finapp.assets(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: performance_metrics performance_metrics_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.performance_metrics
    ADD CONSTRAINT performance_metrics_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: portfolio_snapshots portfolio_snapshots_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_snapshots
    ADD CONSTRAINT portfolio_snapshots_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: portfolio_tags portfolio_tags_created_by_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_created_by_fkey FOREIGN KEY (created_by) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: portfolio_tags portfolio_tags_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: portfolio_tags portfolio_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES finapp.tags(id) ON DELETE CASCADE;


--
-- Name: portfolios portfolios_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolios
    ADD CONSTRAINT portfolios_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: position_snapshots position_snapshots_portfolio_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.position_snapshots
    ADD CONSTRAINT position_snapshots_portfolio_snapshot_id_fkey FOREIGN KEY (portfolio_snapshot_id) REFERENCES finapp.portfolio_snapshots(id) ON DELETE CASCADE;


--
-- Name: position_snapshots position_snapshots_position_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.position_snapshots
    ADD CONSTRAINT position_snapshots_position_id_fkey FOREIGN KEY (position_id) REFERENCES finapp.positions(id) ON DELETE CASCADE;


--
-- Name: positions positions_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id);


--
-- Name: positions positions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: positions positions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES finapp.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: price_sync_errors price_sync_errors_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_errors
    ADD CONSTRAINT price_sync_errors_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE SET NULL;


--
-- Name: price_sync_errors price_sync_errors_log_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_errors
    ADD CONSTRAINT price_sync_errors_log_id_fkey FOREIGN KEY (log_id) REFERENCES finapp.price_sync_logs(id) ON DELETE CASCADE;


--
-- Name: price_sync_logs price_sync_logs_data_source_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_logs
    ADD CONSTRAINT price_sync_logs_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES finapp.price_data_sources(id) ON DELETE SET NULL;


--
-- Name: price_sync_logs price_sync_logs_task_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_logs
    ADD CONSTRAINT price_sync_logs_task_id_fkey FOREIGN KEY (task_id) REFERENCES finapp.price_sync_tasks(id) ON DELETE CASCADE;


--
-- Name: price_sync_tasks price_sync_tasks_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES finapp.asset_types(id);


--
-- Name: price_sync_tasks price_sync_tasks_country_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_country_id_fkey FOREIGN KEY (country_id) REFERENCES finapp.countries(id);


--
-- Name: price_sync_tasks price_sync_tasks_data_source_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES finapp.price_data_sources(id) ON DELETE CASCADE;


--
-- Name: report_executions report_executions_report_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.report_executions
    ADD CONSTRAINT report_executions_report_id_fkey FOREIGN KEY (report_id) REFERENCES finapp.reports(id) ON DELETE CASCADE;


--
-- Name: reports reports_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.reports
    ADD CONSTRAINT reports_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: reports reports_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.reports
    ADD CONSTRAINT reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES finapp.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES finapp.roles(id) ON DELETE CASCADE;


--
-- Name: stock_details stock_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_details
    ADD CONSTRAINT stock_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: stock_option_details stock_option_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_option_details
    ADD CONSTRAINT stock_option_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: stock_option_details stock_option_details_underlying_stock_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_option_details
    ADD CONSTRAINT stock_option_details_underlying_stock_id_fkey FOREIGN KEY (underlying_stock_id) REFERENCES finapp.assets(id);


--
-- Name: tag_categories tag_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories
    ADD CONSTRAINT tag_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES finapp.tag_categories(id) ON DELETE SET NULL;


--
-- Name: tag_categories tag_categories_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories
    ADD CONSTRAINT tag_categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: tags tags_category_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags
    ADD CONSTRAINT tags_category_id_fkey FOREIGN KEY (category_id) REFERENCES finapp.tag_categories(id) ON DELETE SET NULL;


--
-- Name: tags tags_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags
    ADD CONSTRAINT tags_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: trading_accounts trading_accounts_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.trading_accounts
    ADD CONSTRAINT trading_accounts_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: transaction_tag_mappings transaction_tag_mappings_tag_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transaction_tag_mappings
    ADD CONSTRAINT transaction_tag_mappings_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES finapp.tags(id) ON DELETE CASCADE;


--
-- Name: transaction_tag_mappings transaction_tag_mappings_transaction_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transaction_tag_mappings
    ADD CONSTRAINT transaction_tag_mappings_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES finapp.transactions(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id);


--
-- Name: transactions transactions_liquidity_tag_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_liquidity_tag_id_fkey FOREIGN KEY (liquidity_tag_id) REFERENCES finapp.liquidity_tags(id);


--
-- Name: transactions transactions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES finapp.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: treasury_details treasury_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.treasury_details
    ADD CONSTRAINT treasury_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES finapp.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES finapp.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: wealth_product_details wealth_product_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.wealth_product_details
    ADD CONSTRAINT wealth_product_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: asset_prices asset_prices_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: assets assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.asset_types(id);


--
-- Name: assets assets_market_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_market_id_fkey FOREIGN KEY (market_id) REFERENCES public.markets(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: benchmark_prices benchmark_prices_benchmark_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmark_prices
    ADD CONSTRAINT benchmark_prices_benchmark_id_fkey FOREIGN KEY (benchmark_id) REFERENCES public.benchmarks(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.option_details
    ADD CONSTRAINT option_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_underlying_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.option_details
    ADD CONSTRAINT option_details_underlying_asset_id_fkey FOREIGN KEY (underlying_asset_id) REFERENCES public.assets(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: portfolios portfolios_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: positions positions_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: positions positions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: positions positions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES public.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: report_executions report_executions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: reports reports_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: reports reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: trading_accounts trading_accounts_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.trading_accounts
    ADD CONSTRAINT trading_accounts_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: transactions transactions_liquidity_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_liquidity_tag_id_fkey FOREIGN KEY (liquidity_tag_id) REFERENCES public.liquidity_tags(id);


--
-- Name: transactions transactions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES public.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: caojun
--

GRANT USAGE ON SCHEMA public TO finapp_user;


--
-- Name: TABLE asset_prices; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.asset_prices TO finapp_user;


--
-- Name: TABLE asset_types; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.asset_types TO finapp_user;


--
-- Name: TABLE assets; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.assets TO finapp_user;


--
-- Name: TABLE audit_logs; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.audit_logs TO finapp_user;


--
-- Name: TABLE benchmark_prices; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.benchmark_prices TO finapp_user;


--
-- Name: TABLE benchmarks; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.benchmarks TO finapp_user;


--
-- Name: TABLE email_verification_tokens; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.email_verification_tokens TO finapp_user;


--
-- Name: TABLE exchange_rates; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.exchange_rates TO finapp_user;


--
-- Name: TABLE liquidity_tags; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.liquidity_tags TO finapp_user;


--
-- Name: TABLE markets; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.markets TO finapp_user;


--
-- Name: TABLE option_details; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.option_details TO finapp_user;


--
-- Name: TABLE password_reset_tokens; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.password_reset_tokens TO finapp_user;


--
-- Name: TABLE permissions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.permissions TO finapp_user;


--
-- Name: TABLE portfolios; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.portfolios TO finapp_user;


--
-- Name: TABLE positions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.positions TO finapp_user;


--
-- Name: TABLE report_executions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.report_executions TO finapp_user;


--
-- Name: TABLE reports; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.reports TO finapp_user;


--
-- Name: TABLE role_permissions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.role_permissions TO finapp_user;


--
-- Name: TABLE roles; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.roles TO finapp_user;


--
-- Name: TABLE trading_accounts; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.trading_accounts TO finapp_user;


--
-- Name: TABLE transactions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.transactions TO finapp_user;


--
-- Name: TABLE user_roles; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.user_roles TO finapp_user;


--
-- Name: TABLE user_sessions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.user_sessions TO finapp_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.users TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: finapp; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA finapp GRANT SELECT,USAGE ON SEQUENCES  TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: finapp; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA finapp GRANT SELECT ON TABLES  TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES  TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA public GRANT SELECT ON TABLES  TO finapp_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 7NJDb3L5mgWV2nRia68Ssj4egjxpcQ5uuvAamrdW2UxnFWBkxE7179vgFQYaTLJ

