--
-- PostgreSQL database dump
--

\restrict mhwxBnJLNwqT3LeJiZkCRa2lxcrTnZxFN48iQsb26CJTKWJxQETVWd2STPGpBh7

-- Dumped from database version 13.22
-- Dumped by pg_dump version 13.22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: audit; Type: SCHEMA; Schema: -; Owner: finapp_user
--

CREATE SCHEMA audit;


ALTER SCHEMA audit OWNER TO finapp_user;

--
-- Name: finapp; Type: SCHEMA; Schema: -; Owner: finapp_user
--

CREATE SCHEMA finapp;


ALTER SCHEMA finapp OWNER TO finapp_user;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: caojun
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO caojun;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE finapp._prisma_migrations OWNER TO finapp_user;

--
-- Name: asset_prices; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.asset_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    price_date date NOT NULL,
    open_price numeric(20,8),
    high_price numeric(20,8),
    low_price numeric(20,8),
    close_price numeric(20,8) NOT NULL,
    volume bigint,
    adjusted_close numeric(20,8),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.asset_prices OWNER TO finapp_user;

--
-- Name: asset_types; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.asset_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    location_dimension character varying(20) DEFAULT 'market'::character varying
);


ALTER TABLE finapp.asset_types OWNER TO finapp_user;

--
-- Name: COLUMN asset_types.location_dimension; Type: COMMENT; Schema: finapp; Owner: finapp_user
--

COMMENT ON COLUMN finapp.asset_types.location_dimension IS 'Location dimension for asset type: market (交易市场), country (国家), or global (全球)';


--
-- Name: assets; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.assets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    symbol character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    asset_type_id uuid NOT NULL,
    currency character varying(3) NOT NULL,
    isin character varying(12),
    cusip character varying(9),
    sector character varying(100),
    industry character varying(100),
    description text,
    metadata jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    risk_level character varying(20) DEFAULT 'MEDIUM'::character varying,
    lot_size integer DEFAULT 1,
    tick_size numeric(10,6) DEFAULT 0.01,
    listing_date date,
    delisting_date date,
    tags text[],
    created_by uuid,
    updated_by uuid,
    liquidity_tag uuid,
    country_id uuid
);


ALTER TABLE finapp.assets OWNER TO finapp_user;

--
-- Name: audit_logs; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    table_name character varying(100) NOT NULL,
    record_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.audit_logs OWNER TO finapp_user;

--
-- Name: benchmark_prices; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.benchmark_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    benchmark_id uuid NOT NULL,
    price_date date NOT NULL,
    price numeric(20,8) NOT NULL,
    currency character varying(3) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.benchmark_prices OWNER TO finapp_user;

--
-- Name: benchmarks; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.benchmarks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(20) NOT NULL,
    description text,
    asset_class character varying(50),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.benchmarks OWNER TO finapp_user;

--
-- Name: bond_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.bond_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    bond_type character varying(50) NOT NULL,
    credit_rating character varying(10),
    face_value numeric(20,2) NOT NULL,
    coupon_rate numeric(5,2) NOT NULL,
    coupon_frequency character varying(20),
    issue_date date NOT NULL,
    maturity_date date NOT NULL,
    years_to_maturity numeric(5,2),
    yield_to_maturity numeric(5,2),
    current_yield numeric(5,2),
    issuer character varying(200),
    issue_price numeric(20,2),
    issue_size numeric(20,2),
    callable boolean DEFAULT false,
    call_date date,
    call_price numeric(20,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.bond_details OWNER TO finapp_user;

--
-- Name: cash_flows; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.cash_flows (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid,
    asset_id uuid,
    flow_type character varying(20) NOT NULL,
    amount numeric(20,8) NOT NULL,
    currency character varying(3) NOT NULL,
    flow_date date NOT NULL,
    description text,
    transaction_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    date timestamp(6) with time zone,
    category character varying(50)
);


ALTER TABLE finapp.cash_flows OWNER TO finapp_user;

--
-- Name: countries; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.countries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(3) NOT NULL,
    name character varying(100) NOT NULL,
    currency character varying(3),
    timezone character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.countries OWNER TO finapp_user;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.email_verification_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    verified_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.email_verification_tokens OWNER TO finapp_user;

--
-- Name: exchange_rates; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.exchange_rates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_currency character varying(3) NOT NULL,
    to_currency character varying(3) NOT NULL,
    rate_date date NOT NULL,
    rate numeric(20,8) NOT NULL,
    data_source character varying(50),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.exchange_rates OWNER TO finapp_user;

--
-- Name: fund_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.fund_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    fund_type character varying(50) NOT NULL,
    fund_category character varying(50),
    management_fee numeric(5,2),
    custodian_fee numeric(5,2),
    subscription_fee numeric(5,2),
    redemption_fee numeric(5,2),
    nav numeric(20,4),
    nav_date date,
    accumulated_nav numeric(20,4),
    fund_size numeric(20,2),
    inception_date date,
    fund_manager character varying(200),
    fund_company character varying(200),
    min_investment numeric(20,2),
    min_redemption numeric(20,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.fund_details OWNER TO finapp_user;

--
-- Name: futures_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.futures_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    futures_type character varying(50) NOT NULL,
    underlying_asset character varying(200),
    contract_month character varying(10) NOT NULL,
    contract_size numeric(20,4),
    tick_size numeric(20,8),
    tick_value numeric(20,2),
    trading_hours character varying(100),
    last_trading_date date,
    delivery_date date,
    delivery_method character varying(50),
    initial_margin numeric(20,2),
    maintenance_margin numeric(20,2),
    margin_rate numeric(5,2),
    position_limit integer,
    daily_price_limit numeric(5,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.futures_details OWNER TO finapp_user;

--
-- Name: liquidity_tags; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.liquidity_tags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color character varying(7),
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.liquidity_tags OWNER TO finapp_user;

--
-- Name: markets; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.markets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(3) NOT NULL,
    currency character varying(3) NOT NULL,
    timezone character varying(50) NOT NULL,
    trading_hours jsonb,
    holidays jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.markets OWNER TO finapp_user;

--
-- Name: option_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.option_details (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    underlying_asset_id uuid,
    option_type character varying(10) NOT NULL,
    strike_price numeric(20,8) NOT NULL,
    expiration_date date NOT NULL,
    contract_size integer DEFAULT 100,
    exercise_style character varying(20) DEFAULT 'american'::character varying,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.option_details OWNER TO finapp_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.password_reset_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    used_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.password_reset_tokens OWNER TO finapp_user;

--
-- Name: performance_metrics; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.performance_metrics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    metric_type character varying(50) NOT NULL,
    period_type character varying(20) NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    value numeric(20,8) NOT NULL,
    currency character varying(3),
    metadata jsonb,
    calculated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.performance_metrics OWNER TO finapp_user;

--
-- Name: permissions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.permissions OWNER TO finapp_user;

--
-- Name: portfolio_snapshots; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.portfolio_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    total_value numeric(20,8) NOT NULL,
    cash_value numeric(20,8) DEFAULT 0 NOT NULL,
    invested_value numeric(20,8) DEFAULT 0 NOT NULL,
    unrealized_gain_loss numeric(20,8) DEFAULT 0 NOT NULL,
    realized_gain_loss numeric(20,8) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.portfolio_snapshots OWNER TO finapp_user;

--
-- Name: portfolio_tags; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.portfolio_tags (
    id integer NOT NULL,
    portfolio_id uuid NOT NULL,
    tag_id integer NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.portfolio_tags OWNER TO finapp_user;

--
-- Name: portfolio_tags_id_seq; Type: SEQUENCE; Schema: finapp; Owner: finapp_user
--

CREATE SEQUENCE finapp.portfolio_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE finapp.portfolio_tags_id_seq OWNER TO finapp_user;

--
-- Name: portfolio_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: finapp; Owner: finapp_user
--

ALTER SEQUENCE finapp.portfolio_tags_id_seq OWNED BY finapp.portfolio_tags.id;


--
-- Name: portfolios; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.portfolios (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    base_currency character varying(3) DEFAULT 'CNY'::character varying NOT NULL,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    sort_order integer DEFAULT 0
);


ALTER TABLE finapp.portfolios OWNER TO finapp_user;

--
-- Name: position_snapshots; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.position_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    position_id uuid NOT NULL,
    portfolio_snapshot_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    quantity numeric(20,8) NOT NULL,
    market_price numeric(20,8),
    market_value numeric(20,8),
    average_cost numeric(20,8) NOT NULL,
    total_cost numeric(20,8) NOT NULL,
    unrealized_gain_loss numeric(20,8),
    currency character varying(3) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.position_snapshots OWNER TO finapp_user;

--
-- Name: positions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.positions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    quantity numeric(20,8) DEFAULT 0 NOT NULL,
    average_cost numeric(20,8) DEFAULT 0 NOT NULL,
    total_cost numeric(20,8) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    first_purchase_date date,
    last_transaction_date date,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.positions OWNER TO finapp_user;

--
-- Name: price_data_sources; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_data_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    provider character varying(50) NOT NULL,
    api_endpoint character varying(500),
    api_key_encrypted text,
    config jsonb DEFAULT '{}'::jsonb,
    rate_limit integer DEFAULT 60,
    timeout_seconds integer DEFAULT 30,
    is_active boolean DEFAULT true,
    last_sync_at timestamp(6) without time zone,
    last_sync_status character varying(20),
    last_error_message text,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE finapp.price_data_sources OWNER TO finapp_user;

--
-- Name: price_sync_errors; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_errors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    log_id uuid NOT NULL,
    asset_id uuid,
    asset_symbol character varying(50),
    error_type character varying(50),
    error_message text NOT NULL,
    error_details jsonb,
    occurred_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.price_sync_errors OWNER TO finapp_user;

--
-- Name: price_sync_logs; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id uuid,
    data_source_id uuid,
    started_at timestamp(6) without time zone DEFAULT timezone('Asia/Shanghai'::text, CURRENT_TIMESTAMP) NOT NULL,
    completed_at timestamp(6) without time zone,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    total_assets integer DEFAULT 0,
    total_records integer DEFAULT 0,
    success_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    skipped_count integer DEFAULT 0,
    result_summary jsonb,
    error_message text
);


ALTER TABLE finapp.price_sync_logs OWNER TO finapp_user;

--
-- Name: price_sync_logs_backup; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_logs_backup (
    id uuid,
    task_id uuid,
    data_source_id uuid,
    started_at timestamp(6) without time zone,
    completed_at timestamp(6) without time zone,
    status character varying(20),
    total_assets integer,
    total_records integer,
    success_count integer,
    failed_count integer,
    skipped_count integer,
    result_summary jsonb,
    error_message text
);


ALTER TABLE finapp.price_sync_logs_backup OWNER TO finapp_user;

--
-- Name: price_sync_tasks; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.price_sync_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    data_source_id uuid NOT NULL,
    asset_type_id uuid,
    asset_ids uuid[],
    schedule_type character varying(20) DEFAULT 'manual'::character varying NOT NULL,
    cron_expression character varying(100),
    interval_minutes integer,
    sync_days_back integer DEFAULT 1,
    overwrite_existing boolean DEFAULT false,
    is_active boolean DEFAULT true,
    last_run_at timestamp(6) without time zone,
    next_run_at timestamp(6) without time zone,
    last_run_status character varying(20),
    last_run_result jsonb,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    country_id uuid
);


ALTER TABLE finapp.price_sync_tasks OWNER TO finapp_user;

--
-- Name: report_executions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.report_executions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    execution_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    started_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp(6) with time zone,
    file_path text,
    file_size bigint,
    error_message text,
    metadata jsonb
);


ALTER TABLE finapp.report_executions OWNER TO finapp_user;

--
-- Name: reports; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    portfolio_id uuid,
    name character varying(200) NOT NULL,
    description text,
    report_type character varying(50) NOT NULL,
    parameters jsonb NOT NULL,
    schedule jsonb,
    is_scheduled boolean DEFAULT false,
    is_active boolean DEFAULT true,
    last_generated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.reports OWNER TO finapp_user;

--
-- Name: role_permissions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.role_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.role_permissions OWNER TO finapp_user;

--
-- Name: roles; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.roles OWNER TO finapp_user;

--
-- Name: stock_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.stock_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    sector character varying(100),
    industry character varying(100),
    market_cap numeric(20,2),
    shares_outstanding bigint,
    pe_ratio numeric(10,2),
    pb_ratio numeric(10,2),
    dividend_yield numeric(5,2),
    company_website character varying(200),
    headquarters character varying(200),
    founded_year integer,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.stock_details OWNER TO finapp_user;

--
-- Name: stock_option_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.stock_option_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    underlying_stock_id uuid,
    underlying_stock_symbol character varying(50),
    underlying_stock_name character varying(200),
    option_type character varying(10) NOT NULL,
    strike_price numeric(20,8) NOT NULL,
    expiration_date date NOT NULL,
    contract_size integer DEFAULT 100,
    exercise_style character varying(20) DEFAULT 'AMERICAN'::character varying,
    settlement_type character varying(20) DEFAULT 'PHYSICAL'::character varying,
    multiplier numeric(10,4) DEFAULT 1.0,
    trading_unit character varying(20) DEFAULT '手'::character varying,
    min_price_change numeric(20,8),
    margin_requirement numeric(20,2),
    commission_rate numeric(5,4),
    delta numeric(10,6),
    gamma numeric(10,6),
    theta numeric(10,6),
    vega numeric(10,6),
    rho numeric(10,6),
    implied_volatility numeric(10,6),
    historical_volatility numeric(10,6),
    premium_currency character varying(10) DEFAULT 'CNY'::character varying,
    intrinsic_value numeric(20,8),
    time_value numeric(20,8),
    cost_divisor numeric(10,2) DEFAULT 3.5,
    notes text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.stock_option_details OWNER TO finapp_user;

--
-- Name: tag_categories; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.tag_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#52c41a'::character varying,
    icon character varying(50),
    user_id uuid NOT NULL,
    parent_id integer,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.tag_categories OWNER TO finapp_user;

--
-- Name: tag_categories_id_seq; Type: SEQUENCE; Schema: finapp; Owner: finapp_user
--

CREATE SEQUENCE finapp.tag_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE finapp.tag_categories_id_seq OWNER TO finapp_user;

--
-- Name: tag_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: finapp; Owner: finapp_user
--

ALTER SEQUENCE finapp.tag_categories_id_seq OWNED BY finapp.tag_categories.id;


--
-- Name: tags; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.tags (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#1890ff'::character varying,
    icon character varying(50),
    user_id uuid NOT NULL,
    category_id integer,
    is_system boolean DEFAULT false,
    is_active boolean DEFAULT true,
    usage_count integer DEFAULT 0,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.tags OWNER TO finapp_user;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: finapp; Owner: finapp_user
--

CREATE SEQUENCE finapp.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE finapp.tags_id_seq OWNER TO finapp_user;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: finapp; Owner: finapp_user
--

ALTER SEQUENCE finapp.tags_id_seq OWNED BY finapp.tags.id;


--
-- Name: trading_accounts; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.trading_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    account_type character varying(50) NOT NULL,
    broker_name character varying(100),
    account_number character varying(100),
    currency character varying(3) NOT NULL,
    initial_balance numeric(20,8) DEFAULT 0,
    current_balance numeric(20,8) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.trading_accounts OWNER TO finapp_user;

--
-- Name: transaction_tag_mappings; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.transaction_tag_mappings (
    transaction_id uuid NOT NULL,
    tag_id integer NOT NULL,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.transaction_tag_mappings OWNER TO finapp_user;

--
-- Name: transactions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    transaction_type character varying(20) NOT NULL,
    quantity numeric(20,8) NOT NULL,
    price numeric(20,8),
    total_amount numeric(20,8) NOT NULL,
    fees numeric(20,8) DEFAULT 0,
    taxes numeric(20,8) DEFAULT 0,
    currency character varying(3) NOT NULL,
    exchange_rate numeric(20,8) DEFAULT 1,
    transaction_date date NOT NULL,
    settlement_date date,
    notes text,
    tags text[],
    liquidity_tag_id uuid,
    external_id character varying(100),
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    user_id uuid,
    side character varying(20),
    executed_at timestamp(6) with time zone,
    settled_at timestamp(6) with time zone,
    status character varying(20) DEFAULT 'EXECUTED'::character varying,
    liquidity_tag character varying(20)
);


ALTER TABLE finapp.transactions OWNER TO finapp_user;

--
-- Name: treasury_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.treasury_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    treasury_type character varying(50) NOT NULL,
    term_type character varying(20),
    face_value numeric(20,2) NOT NULL,
    coupon_rate numeric(5,2) NOT NULL,
    coupon_frequency character varying(20),
    issue_date date NOT NULL,
    maturity_date date NOT NULL,
    term_years integer,
    issue_price numeric(20,2),
    issue_number character varying(50),
    yield_to_maturity numeric(5,2),
    tradable boolean DEFAULT true,
    min_holding_period integer,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.treasury_details OWNER TO finapp_user;

--
-- Name: user_roles; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid,
    assigned_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp(6) with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE finapp.user_roles OWNER TO finapp_user;

--
-- Name: user_sessions; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    refresh_token_hash character varying(255),
    device_info jsonb,
    ip_address inet,
    user_agent text,
    is_active boolean DEFAULT true,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    last_used_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.user_sessions OWNER TO finapp_user;

--
-- Name: users; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(50),
    password_hash character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(20),
    avatar_url text,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    language character varying(10) DEFAULT 'zh-CN'::character varying,
    currency_preference character varying(3) DEFAULT 'CNY'::character varying,
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    email_verified_at timestamp(6) with time zone,
    last_login_at timestamp(6) with time zone,
    login_count integer DEFAULT 0,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.users OWNER TO finapp_user;

--
-- Name: v_data_source_market_coverage; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_market_coverage AS
 SELECT ds.id,
    ds.name,
    ds.provider,
    ds.is_active,
    jsonb_array_elements_text((ds.config -> 'supports_markets'::text)) AS market_code,
    m.name AS market_name,
    m.country,
    m.currency
   FROM ((finapp.price_data_sources ds
     LEFT JOIN LATERAL jsonb_array_elements_text((ds.config -> 'supports_markets'::text)) market_code(value) ON (true))
     LEFT JOIN finapp.markets m ON (((m.code)::text = market_code.value)))
  WHERE ((ds.config -> 'supports_markets'::text) IS NOT NULL)
  ORDER BY ds.name, (jsonb_array_elements_text((ds.config -> 'supports_markets'::text)));


ALTER TABLE finapp.v_data_source_market_coverage OWNER TO finapp_user;

--
-- Name: v_data_source_product_coverage; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_product_coverage AS
 SELECT ds.id,
    ds.name,
    ds.provider,
    ds.is_active,
    jsonb_array_elements_text((ds.config -> 'supports_products'::text)) AS product_type
   FROM finapp.price_data_sources ds
  WHERE ((ds.config -> 'supports_products'::text) IS NOT NULL)
  ORDER BY ds.name, (jsonb_array_elements_text((ds.config -> 'supports_products'::text)));


ALTER TABLE finapp.v_data_source_product_coverage OWNER TO finapp_user;

--
-- Name: v_data_source_comparison; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_comparison AS
 SELECT ds.name,
    ds.provider,
        CASE
            WHEN ds.is_active THEN '✅ 激活'::text
            ELSE '❌ 未激活'::text
        END AS status,
        CASE
            WHEN (ds.api_key_encrypted IS NOT NULL) THEN '已配置'::text
            ELSE '未配置'::text
        END AS api_key,
    ds.rate_limit AS rate_limit_per_minute,
    (ds.config ->> 'free_plan'::text) AS free_plan,
    (ds.config ->> 'requires_api_key'::text) AS requires_api_key,
    ( SELECT count(*) AS count
           FROM finapp.v_data_source_product_coverage
          WHERE (v_data_source_product_coverage.id = ds.id)) AS product_count,
    ( SELECT count(*) AS count
           FROM finapp.v_data_source_market_coverage
          WHERE (v_data_source_market_coverage.id = ds.id)) AS market_count,
    ds.last_sync_at,
    ds.last_sync_status
   FROM finapp.price_data_sources ds
  ORDER BY ds.is_active DESC, ds.name;


ALTER TABLE finapp.v_data_source_comparison OWNER TO finapp_user;

--
-- Name: v_data_source_config; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_data_source_config AS
 SELECT ds.id,
    ds.name,
    ds.provider,
    ds.is_active,
    ds.api_endpoint,
        CASE
            WHEN (ds.api_key_encrypted IS NOT NULL) THEN '已配置'::text
            ELSE '未配置'::text
        END AS api_key_status,
    ds.rate_limit,
    ds.timeout_seconds,
    (ds.config -> 'description'::text) AS description,
    (ds.config -> 'requires_api_key'::text) AS requires_api_key,
    (ds.config -> 'free_plan'::text) AS free_plan,
    (ds.config -> 'features'::text) AS features,
    ds.last_sync_at,
    ds.last_sync_status,
    COALESCE(ds.last_error_message, '无'::text) AS last_error_message,
    ds.created_at,
    ds.updated_at
   FROM finapp.price_data_sources ds
  ORDER BY ds.created_at DESC;


ALTER TABLE finapp.v_data_source_config OWNER TO finapp_user;

--
-- Name: v_market_source_count; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_market_source_count AS
 SELECT v_data_source_market_coverage.market_code,
    v_data_source_market_coverage.market_name,
    v_data_source_market_coverage.country,
    v_data_source_market_coverage.currency,
    count(DISTINCT v_data_source_market_coverage.id) AS source_count,
    string_agg(DISTINCT (v_data_source_market_coverage.name)::text, ', '::text ORDER BY (v_data_source_market_coverage.name)::text) AS source_names,
    (max(
        CASE
            WHEN v_data_source_market_coverage.is_active THEN 1
            ELSE 0
        END) > 0) AS has_active_source
   FROM finapp.v_data_source_market_coverage
  GROUP BY v_data_source_market_coverage.market_code, v_data_source_market_coverage.market_name, v_data_source_market_coverage.country, v_data_source_market_coverage.currency
  ORDER BY (count(DISTINCT v_data_source_market_coverage.id)) DESC, v_data_source_market_coverage.market_code;


ALTER TABLE finapp.v_market_source_count OWNER TO finapp_user;

--
-- Name: v_product_type_source_count; Type: VIEW; Schema: finapp; Owner: finapp_user
--

CREATE VIEW finapp.v_product_type_source_count AS
 SELECT COALESCE(pct.product_type, 'UNKNOWN'::text) AS product_type,
    count(DISTINCT pct.id) AS source_count,
    string_agg(DISTINCT (pct.name)::text, ', '::text ORDER BY (pct.name)::text) AS source_names,
    (max(
        CASE
            WHEN pct.is_active THEN 1
            ELSE 0
        END) > 0) AS has_active_source
   FROM finapp.v_data_source_product_coverage pct
  GROUP BY pct.product_type
  ORDER BY (count(DISTINCT pct.id)) DESC, COALESCE(pct.product_type, 'UNKNOWN'::text);


ALTER TABLE finapp.v_product_type_source_count OWNER TO finapp_user;

--
-- Name: wealth_product_details; Type: TABLE; Schema: finapp; Owner: finapp_user
--

CREATE TABLE finapp.wealth_product_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    product_type character varying(50) NOT NULL,
    risk_level character varying(20) NOT NULL,
    expected_return numeric(5,2),
    min_return numeric(5,2),
    max_return numeric(5,2),
    return_type character varying(20),
    issue_date date NOT NULL,
    start_date date NOT NULL,
    maturity_date date NOT NULL,
    lock_period integer,
    min_investment numeric(20,2),
    max_investment numeric(20,2),
    investment_increment numeric(20,2),
    issuer character varying(200),
    product_code character varying(50),
    early_redemption boolean DEFAULT false,
    redemption_fee numeric(5,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE finapp.wealth_product_details OWNER TO finapp_user;

--
-- Name: asset_prices; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.asset_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    price_date date NOT NULL,
    open_price numeric(20,8),
    high_price numeric(20,8),
    low_price numeric(20,8),
    close_price numeric(20,8) NOT NULL,
    volume bigint,
    adjusted_close numeric(20,8),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.asset_prices OWNER TO caojun;

--
-- Name: asset_types; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.asset_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.asset_types OWNER TO caojun;

--
-- Name: assets; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.assets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    symbol character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    asset_type_id uuid NOT NULL,
    market_id uuid,
    currency character varying(3) NOT NULL,
    isin character varying(12),
    cusip character varying(9),
    sector character varying(100),
    industry character varying(100),
    description text,
    metadata jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.assets OWNER TO caojun;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    table_name character varying(100) NOT NULL,
    record_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO caojun;

--
-- Name: benchmark_prices; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.benchmark_prices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    benchmark_id uuid NOT NULL,
    price_date date NOT NULL,
    price numeric(20,8) NOT NULL,
    currency character varying(3) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.benchmark_prices OWNER TO caojun;

--
-- Name: benchmarks; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.benchmarks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(20) NOT NULL,
    description text,
    asset_class character varying(50),
    currency character varying(3) NOT NULL,
    data_source character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.benchmarks OWNER TO caojun;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.email_verification_tokens OWNER TO caojun;

--
-- Name: TABLE email_verification_tokens; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.email_verification_tokens IS '邮箱验证令牌表';


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.exchange_rates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_currency character varying(3) NOT NULL,
    to_currency character varying(3) NOT NULL,
    rate_date date NOT NULL,
    rate numeric(20,8) NOT NULL,
    data_source character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.exchange_rates OWNER TO caojun;

--
-- Name: liquidity_tags; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.liquidity_tags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color character varying(7),
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.liquidity_tags OWNER TO caojun;

--
-- Name: markets; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.markets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(3) NOT NULL,
    currency character varying(3) NOT NULL,
    timezone character varying(50) NOT NULL,
    trading_hours jsonb,
    holidays jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.markets OWNER TO caojun;

--
-- Name: option_details; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.option_details (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    asset_id uuid NOT NULL,
    underlying_asset_id uuid,
    option_type character varying(10) NOT NULL,
    strike_price numeric(20,8) NOT NULL,
    expiration_date date NOT NULL,
    contract_size integer DEFAULT 100,
    exercise_style character varying(20) DEFAULT 'american'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT option_details_option_type_check CHECK (((option_type)::text = ANY ((ARRAY['call'::character varying, 'put'::character varying])::text[])))
);


ALTER TABLE public.option_details OWNER TO caojun;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.password_reset_tokens OWNER TO caojun;

--
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.password_reset_tokens IS '密码重置令牌表';


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO caojun;

--
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.permissions IS '权限表';


--
-- Name: portfolios; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.portfolios (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    base_currency character varying(3) DEFAULT 'CNY'::character varying NOT NULL,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.portfolios OWNER TO caojun;

--
-- Name: positions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.positions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    quantity numeric(20,8) DEFAULT 0 NOT NULL,
    average_cost numeric(20,8) DEFAULT 0 NOT NULL,
    total_cost numeric(20,8) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    first_purchase_date date,
    last_transaction_date date,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.positions OWNER TO caojun;

--
-- Name: report_executions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.report_executions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    execution_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    file_path text,
    file_size bigint,
    error_message text,
    metadata jsonb
);


ALTER TABLE public.report_executions OWNER TO caojun;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    portfolio_id uuid,
    name character varying(200) NOT NULL,
    description text,
    report_type character varying(50) NOT NULL,
    parameters jsonb NOT NULL,
    schedule jsonb,
    is_scheduled boolean DEFAULT false,
    is_active boolean DEFAULT true,
    last_generated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.reports OWNER TO caojun;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.role_permissions OWNER TO caojun;

--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.role_permissions IS '角色权限关联表';


--
-- Name: roles; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO caojun;

--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.roles IS '角色表';


--
-- Name: trading_accounts; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.trading_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    account_type character varying(50) NOT NULL,
    broker_name character varying(100),
    account_number character varying(100),
    currency character varying(3) NOT NULL,
    initial_balance numeric(20,8) DEFAULT 0,
    current_balance numeric(20,8) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.trading_accounts OWNER TO caojun;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    portfolio_id uuid NOT NULL,
    trading_account_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    transaction_type character varying(20) NOT NULL,
    quantity numeric(20,8) NOT NULL,
    price numeric(20,8),
    total_amount numeric(20,8) NOT NULL,
    fees numeric(20,8) DEFAULT 0,
    taxes numeric(20,8) DEFAULT 0,
    currency character varying(3) NOT NULL,
    exchange_rate numeric(20,8) DEFAULT 1,
    transaction_date date NOT NULL,
    settlement_date date,
    notes text,
    tags text[],
    liquidity_tag_id uuid,
    external_id character varying(100),
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['buy'::character varying, 'sell'::character varying, 'dividend'::character varying, 'split'::character varying, 'merger'::character varying, 'spin_off'::character varying, 'deposit'::character varying, 'withdrawal'::character varying])::text[])))
);


ALTER TABLE public.transactions OWNER TO caojun;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE public.user_roles OWNER TO caojun;

--
-- Name: TABLE user_roles; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.user_roles IS '用户角色关联表';


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    refresh_token_hash character varying(255),
    device_info jsonb,
    ip_address inet,
    user_agent text,
    is_active boolean DEFAULT true,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_used_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_sessions OWNER TO caojun;

--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.user_sessions IS '用户会话表，用于JWT令牌管理';


--
-- Name: users; Type: TABLE; Schema: public; Owner: caojun
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(50),
    password_hash character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(20),
    avatar_url text,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    language character varying(10) DEFAULT 'zh-CN'::character varying,
    currency_preference character varying(3) DEFAULT 'CNY'::character varying,
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    email_verified_at timestamp with time zone,
    last_login_at timestamp with time zone,
    login_count integer DEFAULT 0,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO caojun;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: caojun
--

COMMENT ON TABLE public.users IS '用户基础信息表';


--
-- Name: portfolio_tags id; Type: DEFAULT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags ALTER COLUMN id SET DEFAULT nextval('finapp.portfolio_tags_id_seq'::regclass);


--
-- Name: tag_categories id; Type: DEFAULT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories ALTER COLUMN id SET DEFAULT nextval('finapp.tag_categories_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags ALTER COLUMN id SET DEFAULT nextval('finapp.tags_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: asset_prices; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.asset_prices (id, asset_id, price_date, open_price, high_price, low_price, close_price, volume, adjusted_close, currency, data_source, created_at) FROM stdin;
608d490d-41e0-4a74-8b21-ae900678c7ca	e9919f45-1585-4645-8a62-036c08865605	2025-11-07	\N	\N	\N	4.35000000	\N	\N	CNY	test_data	2025-11-07 21:06:05.825332+08
2db2d128-b1ae-429b-b930-55c9797986a2	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-11-07	269.79998779	272.29000854	266.76998901	268.47000122	48203600	\N	USD	api	2025-11-07 21:06:05.825332+08
cbd66c85-ade5-4dd3-89d7-2370e587d8b7	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-11-07	437.92001343	439.35998535	421.88000488	429.51998901	103091100	\N	USD	api	2025-11-07 21:06:05.825332+08
42889538-2060-4d90-a7db-9fb1db93a939	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-04	12.23999977	12.38000011	12.21000004	12.30000019	103268969	\N	CNY	api	2025-11-07 23:30:10.477117+08
19a34f68-1f8d-46d3-a298-296e0a76d07b	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-05	12.30000019	12.50000000	12.27999973	12.47000027	113207820	\N	CNY	api	2025-11-07 23:30:10.477836+08
d9fe6507-6918-4968-b49d-173ca47e0207	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-06	12.47000027	12.52000046	12.39999962	12.46000004	69044765	\N	CNY	api	2025-11-07 23:30:10.478216+08
f304e4a6-1a6e-4d2d-9406-d94a7504ff4e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-07	12.43999958	12.52999973	12.39000034	12.47000027	72205305	\N	CNY	api	2025-11-07 23:30:10.478681+08
55fa6b1c-0a29-4a26-9de4-4d9e6d2079b2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-08	12.47999954	12.52999973	12.39000034	12.39999962	82979591	\N	CNY	api	2025-11-07 23:30:10.478985+08
74d09b7b-b3fe-42ca-896e-d9f683c52747	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-11	12.39999962	12.42000008	12.27000046	12.30000019	93435315	\N	CNY	api	2025-11-07 23:30:10.479383+08
10546181-4c60-4371-8bfb-12ed9f4030ff	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-12	12.30000019	12.39999962	12.30000019	12.32999992	68005619	\N	CNY	api	2025-11-07 23:30:10.479923+08
08324c37-c14a-4686-b82b-d646474be630	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-13	12.36999989	12.39999962	12.22999954	12.26000023	111981305	\N	CNY	api	2025-11-07 23:30:10.480546+08
590c47ec-3755-4f02-ba58-88fd64987446	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-14	12.27000046	12.34000015	12.18999958	12.19999981	124104129	\N	CNY	api	2025-11-07 23:30:10.480957+08
ee6d59d6-0217-4740-95c5-fd389bde350a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-15	12.22999954	12.22999954	11.93999958	12.07999992	194850295	\N	CNY	api	2025-11-07 23:30:10.481347+08
f4b90e72-8321-4518-8890-cbf38e5687c6	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-18	12.06000042	12.14999962	12.02999973	12.07999992	123905837	\N	CNY	api	2025-11-07 23:30:10.481704+08
d735382b-9de8-42af-bc06-95532e49f593	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-19	12.10000038	12.11999989	12.02000046	12.06000042	89285989	\N	CNY	api	2025-11-07 23:30:10.482098+08
5ea45c85-7a4e-48c0-974a-e07f8f5622ae	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-20	12.06000042	12.11999989	11.97999954	12.06999969	104873853	\N	CNY	api	2025-11-07 23:30:10.482497+08
41b57567-f80a-4002-9134-459441b0247e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-21	12.05000019	12.18999958	12.02999973	12.14999962	121741825	\N	CNY	api	2025-11-07 23:30:10.482909+08
6850636e-d169-40ba-a54f-7c1ad73c6dcd	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-22	12.14999962	12.17000008	11.97999954	12.06000042	164425977	\N	CNY	api	2025-11-07 23:30:10.483154+08
33632ecf-7402-4c00-a01c-70e602baabf0	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-25	12.11999989	12.52999973	12.10000038	12.44999981	304508753	\N	CNY	api	2025-11-07 23:30:10.483377+08
5de25558-bd53-417d-b490-461e55f65028	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-26	12.44999981	12.50000000	12.30000019	12.35999966	138359861	\N	CNY	api	2025-11-07 23:30:10.483614+08
61c33c1a-3f5f-409d-8cc1-e30bdf274fd3	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-27	12.31999969	12.35999966	12.05000019	12.06000042	186004950	\N	CNY	api	2025-11-07 23:30:10.483841+08
328b33bc-1dec-4603-a3df-ee7c67cbb2e2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-28	12.09000015	12.14000034	11.97000027	12.07999992	165358793	\N	CNY	api	2025-11-07 23:30:10.484076+08
e08513cd-6a5a-4887-93a7-8a983d127af2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-29	12.05000019	12.22000027	12.02999973	12.05000019	180512568	\N	CNY	api	2025-11-07 23:30:10.484297+08
88b5bad0-7ce1-422a-92c4-91e856ed4640	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-01	12.05000019	12.05000019	11.85000038	11.89000034	185845902	\N	CNY	api	2025-11-07 23:30:10.484535+08
2807ab25-3603-4bf8-bf27-e5e8f49e9612	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-02	11.85000038	11.98999977	11.84000015	11.97999954	149271566	\N	CNY	api	2025-11-07 23:30:10.484752+08
ca7ed518-956d-459d-8de2-d5cd89ce25e5	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-03	11.97999954	12.01000023	11.73999977	11.75000000	136723249	\N	CNY	api	2025-11-07 23:30:10.484973+08
f2640c66-f686-4aef-bf1a-02a459fa30d0	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-04	11.76000023	11.77000046	11.60000038	11.73999977	129530002	\N	CNY	api	2025-11-07 23:30:10.485191+08
582c1c88-7eda-4622-bf3a-99b53dee5c09	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-05	11.72999954	11.73999977	11.63000011	11.72000027	81966156	\N	CNY	api	2025-11-07 23:30:10.485474+08
3c067c65-e503-4a4f-9ccb-9d493d5d68e2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-08	11.71000004	11.77999973	11.67000008	11.69999981	92443104	\N	CNY	api	2025-11-07 23:30:10.485828+08
c6627f7b-48d6-417a-a2c3-33251d4333d8	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-09	11.71000004	11.77999973	11.68000031	11.75000000	86053917	\N	CNY	api	2025-11-07 23:30:10.486203+08
30de1b34-954d-4bb2-9256-dce51bcee85a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-10	11.73999977	11.78999996	11.71000004	11.77000046	79266839	\N	CNY	api	2025-11-07 23:30:10.486566+08
2640affe-fc86-4b79-b2d6-6553b17f597e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-11	11.77000046	11.85000038	11.71000004	11.85000038	96393163	\N	CNY	api	2025-11-07 23:30:10.487086+08
02246d29-8d4b-4b59-a8c4-c3e52f0a9848	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-12	11.82999992	11.88000011	11.69999981	11.72000027	94038510	\N	CNY	api	2025-11-07 23:30:10.487455+08
35f98fcd-6249-437b-a2c5-71c65f1aa305	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-15	11.69999981	11.72000027	11.63000011	11.64999962	84038656	\N	CNY	api	2025-11-07 23:30:10.487774+08
dd8c7402-74d4-428a-b617-415a0232ec17	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-17	11.64000034	11.67000008	11.57999992	11.64000034	77112893	\N	CNY	api	2025-11-07 23:30:10.488351+08
9c85476c-c36b-439b-ba94-4096ebff5e0d	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-18	11.64999962	11.65999985	11.38000011	11.40999985	138616040	\N	CNY	api	2025-11-07 23:30:10.488754+08
6068b4c8-da53-452a-aa09-56a18ac9fd56	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-19	11.40999985	11.51000023	11.36999989	11.44999981	83465123	\N	CNY	api	2025-11-07 23:30:10.48911+08
22fa9fbb-0def-4721-827e-2d1e2194b5a4	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-22	11.43999958	11.47000027	11.36999989	11.38000011	59640232	\N	CNY	api	2025-11-07 23:30:10.489741+08
5f0ff303-b0f0-4fcf-98b7-2d39dac91107	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-23	11.36999989	11.57999992	11.31999969	11.52000046	134143022	\N	CNY	api	2025-11-07 23:30:10.490082+08
bce090c0-8a03-4d89-bda8-2e6c277965a1	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-24	11.51000023	11.61999989	11.43000031	11.46000004	113958347	\N	CNY	api	2025-11-07 23:30:10.490341+08
eddac0d0-3877-4601-a05c-145b336853e8	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-25	11.43000031	11.47000027	11.35999966	11.39999962	77327594	\N	CNY	api	2025-11-07 23:30:10.49063+08
0a514755-61dc-4084-92b2-b927e3aa59b8	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-26	11.39000034	11.43999958	11.31999969	11.39999962	75323875	\N	CNY	api	2025-11-07 23:30:10.491026+08
c4200664-5b88-4f64-85a7-4b46b4d9c9ed	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-29	11.39999962	11.47999954	11.27000046	11.36999989	117601243	\N	CNY	api	2025-11-07 23:30:10.491438+08
f4480f4c-0e4f-476c-b715-3ae02610ec1d	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-30	11.36999989	11.36999989	11.28999996	11.34000015	83247947	\N	CNY	api	2025-11-07 23:30:10.491719+08
b09d84b0-9e35-42d9-a84a-a0208e35914e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-09	11.32999992	11.40999985	11.27000046	11.39999962	104746906	\N	CNY	api	2025-11-07 23:30:10.491978+08
b0d75fef-d1d6-4590-b1fa-a6d3d8d3f363	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-10	11.36999989	11.48999977	11.35999966	11.43000031	108794775	\N	CNY	api	2025-11-07 23:30:10.492252+08
84e90224-97b6-46d5-ac26-da98d75ab155	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-13	11.31999969	11.46000004	11.27999973	11.39999962	116880173	\N	CNY	api	2025-11-07 23:30:10.492519+08
ec7231cb-9376-4ba2-95a0-b2e37ff1aefc	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-14	11.39000034	11.60000038	11.35999966	11.56999969	184342836	\N	CNY	api	2025-11-07 23:30:10.492812+08
9316cd51-1665-49e0-a129-7136749be6d0	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-15	11.34000015	11.42000008	11.26000023	11.39999962	127106103	\N	CNY	api	2025-11-07 23:30:10.493111+08
23092d30-d0fd-4cda-a920-38c47d6f7e0f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-16	11.38000011	11.55000019	11.35999966	11.53999996	126193687	\N	CNY	api	2025-11-07 23:30:10.493399+08
a63af8b0-640d-4174-b8eb-9f6fc5ba6b6a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-17	11.50000000	11.57999992	11.38000011	11.39999962	103966632	\N	CNY	api	2025-11-07 23:30:10.493895+08
de2d9150-f8ed-4bc0-b0c1-6cf5783eba94	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-20	11.40999985	11.44999981	11.27000046	11.42000008	95264110	\N	CNY	api	2025-11-07 23:30:10.494181+08
5e13e077-3a07-43b9-ad04-5d7d3343b008	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-21	11.39999962	11.47000027	11.39000034	11.43000031	76116462	\N	CNY	api	2025-11-07 23:30:10.49445+08
fe83daff-8443-4287-894a-e53186d83d09	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-22	11.39999962	11.53999996	11.39999962	11.52000046	83370319	\N	CNY	api	2025-11-07 23:30:10.494724+08
5e3c823e-861b-4053-bd7e-882404c58df4	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-23	11.52000046	11.71000004	11.50000000	11.63000011	137311158	\N	CNY	api	2025-11-07 23:30:10.494985+08
a042cd0f-bd99-4ebd-990f-aeadb000a6c2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-24	11.60000038	11.68000031	11.55000019	11.56000042	98047530	\N	CNY	api	2025-11-07 23:30:10.495247+08
a30d3056-3d8b-42eb-826c-12496e40fc93	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-27	11.53999996	11.60999966	11.43999958	11.52000046	123948526	\N	CNY	api	2025-11-07 23:30:10.495497+08
fd4623bd-0757-4e7d-8ac4-b67bb4bf91bd	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-30	12.35000038	12.64000034	12.34000015	12.48999977	171516360	\N	CNY	api	2025-11-07 23:30:10.472394+08
54dc7cf4-c6ad-4880-834e-704c4d0ed774	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-08-01	12.23999977	12.32999992	12.14999962	12.27999973	101218698	\N	CNY	api	2025-11-07 23:30:10.476438+08
b1626410-41bb-40bf-8281-bd44cd81b0e4	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-30	11.38000011	11.47000027	11.35999966	11.38000011	94377015	\N	CNY	api	2025-11-07 23:30:10.496781+08
a4fed9b4-7dce-4dd7-8a74-cac449901923	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-31	11.38000011	11.39999962	11.30000019	11.31999969	97019293	\N	CNY	api	2025-11-07 23:30:10.497015+08
9d6d24df-3465-4448-8ce5-2c7b6c6c7868	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-11-03	11.34000015	11.43999958	11.30000019	11.43000031	95232643	\N	CNY	api	2025-11-07 23:30:10.497249+08
c6464aed-40bb-45de-9c8f-2a7e12d5eb17	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-11-04	11.42000008	11.64000034	11.39999962	11.59000015	150300748	\N	CNY	api	2025-11-07 23:30:10.497518+08
ea802138-6443-4763-9ee1-12c499e62523	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-11-07	11.52000046	11.57999992	11.50000000	11.55000019	73485055	\N	CNY	api	2025-11-07 21:06:05.825332+08
2cd2f46b-07c5-428f-8894-98ca086d06ea	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-30	6.80000019	6.88000011	6.69000006	6.69999981	158927796	\N	CNY	api	2025-11-07 23:30:10.758498+08
fcb0c6b3-461d-497d-a01f-53c8cf21c7a5	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-01	6.44000006	6.46000004	6.38999987	6.38999987	92360371	\N	CNY	api	2025-11-07 23:30:10.760423+08
8b344d30-cff3-43f1-9ac0-6bd6d7785dc5	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-04	6.36999989	6.40999985	6.34999990	6.40999985	59030369	\N	CNY	api	2025-11-07 23:30:10.760789+08
c80832e8-425a-4e8c-8ffc-5a98854a0657	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-05	6.40999985	6.44999981	6.38999987	6.44999981	65263413	\N	CNY	api	2025-11-07 23:30:10.76125+08
6d42597d-d0f6-4ad4-905b-2981e1701039	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-06	6.42999983	6.44999981	6.40000010	6.44000006	56847005	\N	CNY	api	2025-11-07 23:30:10.761699+08
8c2f5cef-e305-40a7-876e-50b2745c8058	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-07	6.42999983	6.48000002	6.40000010	6.46999979	77603831	\N	CNY	api	2025-11-07 23:30:10.762083+08
f58b2b84-3fb0-4ace-82c2-e8ea47362c40	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-08	6.46000004	6.46999979	6.42000008	6.44999981	51430738	\N	CNY	api	2025-11-07 23:30:10.763285+08
4664d895-6415-435b-bdef-8b1769f6f5ab	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-11	6.48000002	6.51999998	6.46999979	6.48000002	82178878	\N	CNY	api	2025-11-07 23:30:10.763727+08
7bcb4491-b21d-41c3-94e6-814eb18e11ea	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-12	6.46000004	6.50000000	6.44999981	6.46999979	73421761	\N	CNY	api	2025-11-07 23:30:10.764103+08
f7ed5bd5-632d-4804-aa03-962deccc5124	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-13	6.48000002	6.50000000	6.42999983	6.46000004	81074221	\N	CNY	api	2025-11-07 23:30:10.764473+08
30034e39-3a41-4b9f-9788-c2603ec1a8f8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-14	6.46000004	6.55000019	6.42999983	6.42999983	120142307	\N	CNY	api	2025-11-07 23:30:10.764831+08
90e761e4-2088-480c-99f4-f30062a41b98	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-15	6.42999983	6.59000015	6.42000008	6.53000021	159536835	\N	CNY	api	2025-11-07 23:30:10.765176+08
6a2cb7ed-7f0f-4e78-9856-4a7d39e85ae0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-18	6.53000021	6.55999994	6.48000002	6.50000000	138162542	\N	CNY	api	2025-11-07 23:30:10.765533+08
79cac6d5-eae8-4452-b3f2-8b3e8fef6327	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-19	6.53999996	6.61000013	6.51000023	6.53000021	162418652	\N	CNY	api	2025-11-07 23:30:10.765899+08
7190f6c9-20e0-49f6-8758-5ed8e7ef0c11	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-20	6.51999998	6.59999990	6.48999977	6.55000019	129958230	\N	CNY	api	2025-11-07 23:30:10.766276+08
92ad8c03-de0d-4597-a191-3c19552ca14c	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-21	6.55000019	6.59000015	6.53000021	6.55999994	129478430	\N	CNY	api	2025-11-07 23:30:10.766622+08
42b8b9a7-3856-4dd9-b666-bbcb39b17bc5	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-22	6.55999994	6.55999994	6.51000023	6.55999994	130769944	\N	CNY	api	2025-11-07 23:30:10.766995+08
873b6f2d-bbe3-4974-8772-02ce8bf82093	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-25	6.65999985	7.21999979	6.65000010	7.15999985	792389790	\N	CNY	api	2025-11-07 23:30:10.767339+08
4db84217-4c28-42ca-b3af-441f49d56082	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-26	6.98000002	7.03000021	6.90000010	6.98999977	437946406	\N	CNY	api	2025-11-07 23:30:10.767696+08
d065eb68-ddad-4cf7-b625-1e591953f716	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-27	6.94999981	7.01000023	6.73999977	6.73999977	297615220	\N	CNY	api	2025-11-07 23:30:10.768116+08
42b1acfd-4226-4907-b951-4eb719e0c0bf	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-28	6.75000000	6.80999994	6.61999989	6.76999998	211908852	\N	CNY	api	2025-11-07 23:30:10.768368+08
c4a9d44a-d404-4f4a-9508-e98d58cace36	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-08-29	6.88999987	6.92000008	6.78000021	6.78999996	197939254	\N	CNY	api	2025-11-07 23:30:10.768596+08
0cdc9c0b-8353-407e-939b-f1e7fe180250	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-01	6.76000023	6.86000013	6.69999981	6.80999994	140682543	\N	CNY	api	2025-11-07 23:30:10.768809+08
9b29ebbd-3638-47c9-9fbb-a6bec1c2275b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-03	6.75000000	6.78999996	6.55999994	6.57999992	174594262	\N	CNY	api	2025-11-07 23:30:10.769411+08
46fdd6c8-d4b0-4e6f-ac54-bc7c9ea94b18	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-04	6.59000015	6.59999990	6.48000002	6.53000021	153722519	\N	CNY	api	2025-11-07 23:30:10.769771+08
6c65ed46-6e72-46dd-b789-d2b58df08437	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-05	6.53000021	6.59000015	6.48999977	6.59000015	117109143	\N	CNY	api	2025-11-07 23:30:10.770438+08
03f2866a-d461-4b9d-b3fb-90c2e0e700b9	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-08	6.71999979	6.88999987	6.71999979	6.76000023	232037715	\N	CNY	api	2025-11-07 23:30:10.770809+08
265d5fb3-6827-43af-95c3-69bcacca8be2	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-09	6.78999996	6.90999985	6.73999977	6.86000013	217939804	\N	CNY	api	2025-11-07 23:30:10.771386+08
ae5b1ea2-3b70-4fe2-8b5d-7e1cbe2c5697	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-10	6.80999994	6.86000013	6.76000023	6.86000013	139719676	\N	CNY	api	2025-11-07 23:30:10.771779+08
8957b6fc-0aac-42c8-82b3-f99271bd7c82	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-11	6.82000017	6.84000015	6.73000002	6.82999992	146290475	\N	CNY	api	2025-11-07 23:30:10.772202+08
028deb47-960e-4635-93ef-db944e9cdd63	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-12	6.82999992	7.13999987	6.82999992	6.94000006	322089159	\N	CNY	api	2025-11-07 23:30:10.772591+08
eab7528d-2806-4000-8cbd-88708a80e3e7	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-15	6.92000008	7.03999996	6.82000017	6.96999979	228923025	\N	CNY	api	2025-11-07 23:30:10.772956+08
96da59e7-bee5-480a-80ee-2062a9825172	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-16	6.94999981	7.05000019	6.88999987	7.03999996	222680538	\N	CNY	api	2025-11-07 23:30:10.77333+08
3a8178d9-a624-42da-9de5-e99b1fe92dba	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-17	7.03000021	7.07999992	6.92999983	7.05000019	166363987	\N	CNY	api	2025-11-07 23:30:10.773712+08
00a87c49-e0c5-4977-bb5d-69109d367f44	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-18	6.98000002	6.98999977	6.71999979	6.76999998	255296864	\N	CNY	api	2025-11-07 23:30:10.774523+08
e395e276-6956-4b66-812f-9c88f87cd870	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-19	6.75000000	7.03999996	6.67999983	6.98000002	273315185	\N	CNY	api	2025-11-07 23:30:10.77509+08
ce5efa6e-915f-4cd1-b91a-56a88658eb87	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-22	6.90000010	7.09999990	6.82999992	7.00000000	225903866	\N	CNY	api	2025-11-07 23:30:10.775347+08
616627b8-eb91-40fa-9f29-5b0692ce47b6	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-23	6.94000006	6.94999981	6.67999983	6.76000023	184520337	\N	CNY	api	2025-11-07 23:30:10.775582+08
a1415cc5-1367-430b-95dc-c198f21e93ec	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-24	6.71000004	6.94000006	6.69000006	6.84000015	157167516	\N	CNY	api	2025-11-07 23:30:10.775834+08
8622bf4e-48c6-4b3a-b75a-bc6a25f63400	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-25	6.82999992	6.90000010	6.76000023	6.80000019	123401975	\N	CNY	api	2025-11-07 23:30:10.776153+08
45368b33-831d-4a87-816f-700a44b9afad	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-26	6.76000023	6.98000002	6.73000002	6.80000019	150902413	\N	CNY	api	2025-11-07 23:30:10.776456+08
fed1f76f-3dc3-4b32-b7b3-06310f26cf12	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-29	6.78000021	6.86999989	6.65000010	6.80999994	163457195	\N	CNY	api	2025-11-07 23:30:10.776777+08
bb6f1f9a-2955-4f19-9115-6c636a32187b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-30	6.80000019	6.92999983	6.76000023	6.88999987	176304882	\N	CNY	api	2025-11-07 23:30:10.777086+08
da575a28-8dcf-440b-b08f-bc107717d523	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-09	6.80000019	6.80999994	6.59999990	6.78999996	252340339	\N	CNY	api	2025-11-07 23:30:10.777411+08
e950945f-9120-4423-a203-88ee376e88c9	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-10	6.71999979	6.88999987	6.71999979	6.75000000	154834035	\N	CNY	api	2025-11-07 23:30:10.777939+08
e55e848f-6d0c-4d65-b5ca-7e8eac2a9f09	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-13	6.51999998	6.63000011	6.46999979	6.57000017	217774292	\N	CNY	api	2025-11-07 23:30:10.778567+08
643c6b77-fb01-42bf-8a8b-33b36142e758	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-14	6.57000017	6.69000006	6.51999998	6.53000021	191306411	\N	CNY	api	2025-11-07 23:30:10.778782+08
5276d9c9-5226-4c17-adf6-0dedac0bcfcf	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-15	6.51999998	6.57000017	6.42000008	6.48999977	176606612	\N	CNY	api	2025-11-07 23:30:10.778999+08
42c2ee59-0366-42f6-8e7e-d1e623ce88c0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-16	6.46999979	6.48000002	6.38000011	6.40000010	143472425	\N	CNY	api	2025-11-07 23:30:10.779334+08
3eca8dd0-7805-45d8-8a30-6b6bdf73dabd	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-17	6.38999987	6.42999983	6.30999994	6.32000017	142901329	\N	CNY	api	2025-11-07 23:30:10.779594+08
116d914a-3337-4d4b-820d-c2be4de1c30b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-20	6.32999992	6.34999990	6.30000019	6.34000015	86861280	\N	CNY	api	2025-11-07 23:30:10.779883+08
2f479512-ba0c-4f34-9b4d-a7764401c47d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-21	6.32999992	6.40999985	6.30999994	6.40000010	101903523	\N	CNY	api	2025-11-07 23:30:10.780177+08
70bbcd88-0cdd-45b5-83f0-2c7e3325a45a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-29	11.46000004	11.46000004	11.35999966	11.39000034	96621364	\N	CNY	api	2025-11-07 23:30:10.496545+08
24022865-606c-480c-8863-8a73fce2c558	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-31	6.67000008	6.67999983	6.42000008	6.44000006	229951072	\N	CNY	api	2025-11-07 23:30:10.759773+08
feb8b27a-1af8-42f2-b775-3f66ac1755e9	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-27	6.36999989	6.38000011	6.30999994	6.32000017	105394409	\N	CNY	api	2025-11-07 23:30:10.781377+08
a73a7722-e16f-496d-a9f2-5157434162df	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-28	6.32000017	6.32999992	6.26000023	6.26999998	91790019	\N	CNY	api	2025-11-07 23:30:10.781663+08
8de25e62-4004-4e22-a434-c28cb6ab636c	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-29	6.26000023	6.32000017	6.23999977	6.30999994	85716082	\N	CNY	api	2025-11-07 23:30:10.781956+08
b511f970-0eb2-490a-aa43-bf7b3352aeb1	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-30	6.30999994	6.32000017	6.26000023	6.26999998	73745911	\N	CNY	api	2025-11-07 23:30:10.782241+08
576ff6f4-769b-46bd-93b2-bfdcb8dd55da	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-31	6.23999977	6.30000019	6.19999981	6.26999998	84510209	\N	CNY	api	2025-11-07 23:30:10.782526+08
3f80a743-5c1f-4a37-a223-eef85c509221	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-11-03	6.28000021	6.32000017	6.26000023	6.30000019	68957100	\N	CNY	api	2025-11-07 23:30:10.782873+08
bf974c6b-9f33-455a-828e-846be7522f6f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-11-04	6.28000021	6.30000019	6.21000004	6.23000002	107737250	\N	CNY	api	2025-11-07 23:30:10.783119+08
592e25c9-42b5-4b5d-91ad-18fde417177a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-11-07	6.17000008	6.21999979	6.15000010	6.17999983	73308192	\N	CNY	api	2025-11-07 23:30:10.783342+08
8d6e1725-34f6-4635-8189-3236012fc2a9	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-30	44.16999817	44.75000000	43.93000031	44.41999817	72546085	\N	CNY	api	2025-11-07 23:30:11.131917+08
6f06566e-9802-4303-9eca-b83c854dc6bc	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-01	44.50000000	44.97000122	44.34999847	44.41999817	59462094	\N	CNY	api	2025-11-07 23:30:11.133506+08
56c8fabe-f606-4b57-9549-cd8a4ba6a1ee	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-04	44.31000137	44.97000122	44.31000137	44.90000153	49800832	\N	CNY	api	2025-11-07 23:30:11.134289+08
0dca032b-51d8-45b6-8566-a5d65578812b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-05	44.77999878	45.40000153	44.63999939	45.25000000	55525830	\N	CNY	api	2025-11-07 23:30:11.134638+08
e2008974-cb26-4217-ab6f-c2d699536b39	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-06	45.29000092	45.72999954	45.11000061	45.11999893	43029640	\N	CNY	api	2025-11-07 23:30:11.13494+08
b64eb44d-d257-4ff6-9157-aa2cfe40e9d9	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-07	45.11999893	45.59999847	44.95999908	45.15000153	44064325	\N	CNY	api	2025-11-07 23:30:11.135279+08
e7694d0c-bc91-49a2-ade4-470641fd8a42	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-08	45.20000076	45.27999878	44.52999878	44.52999878	45642153	\N	CNY	api	2025-11-07 23:30:11.135617+08
0161550a-e702-49c8-823d-690a095ea5f1	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-11	44.52999878	44.63000107	44.09999847	44.09999847	53672371	\N	CNY	api	2025-11-07 23:30:11.135897+08
8bb8c34a-13d1-4e22-9a6e-4d5e492d0d65	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-12	44.13000107	44.47999954	44.00000000	44.00000000	56225243	\N	CNY	api	2025-11-07 23:30:11.136394+08
c41d0ddf-379d-4164-9d96-c59dc570ff8f	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-13	44.13999939	44.25000000	43.49000168	43.54000092	87673736	\N	CNY	api	2025-11-07 23:30:11.136755+08
e0cda84c-f914-41aa-8c18-8d3d41d0653c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-14	43.54999924	43.93999863	43.50000000	43.77999878	67635168	\N	CNY	api	2025-11-07 23:30:11.137035+08
a8ef2cb0-ea73-41ed-b0a3-90f3337c8726	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-15	43.65999985	43.74000168	43.29999924	43.29999924	93295684	\N	CNY	api	2025-11-07 23:30:11.137338+08
34eed319-9e2d-4259-9605-3b717f662b93	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-18	43.09999847	43.66999817	42.88999939	43.50999832	92639738	\N	CNY	api	2025-11-07 23:30:11.137658+08
654f7425-7be6-4fc7-9bfa-3c1a845ec192	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-19	43.45000076	43.70000076	43.29000092	43.40000153	57411852	\N	CNY	api	2025-11-07 23:30:11.138063+08
ea714b4f-0210-4335-9567-1d4c9e41310e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-20	43.29999924	43.63000107	43.15000153	43.45000076	54724013	\N	CNY	api	2025-11-07 23:30:11.138365+08
730ff840-5238-460c-954e-45901a92c324	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-21	43.50000000	43.59000015	43.22999954	43.47000122	57854002	\N	CNY	api	2025-11-07 23:30:11.138646+08
98edc79e-4658-4025-bd6b-6c14376729af	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-22	43.47000122	43.47999954	43.04000092	43.25999832	79449625	\N	CNY	api	2025-11-07 23:30:11.139083+08
358d25b3-e432-4b3c-9baa-9f6567b97e6e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-25	43.31999969	43.86999893	43.11000061	43.86999893	90738990	\N	CNY	api	2025-11-07 23:30:11.139382+08
047f0568-a44d-442b-af50-f9f61ad80554	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-26	43.88999939	44.02000046	43.41999817	43.52000046	75572231	\N	CNY	api	2025-11-07 23:30:11.139707+08
62f00f42-9e6a-41fa-9671-6f7de754013e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-27	43.50000000	43.65999985	43.00000000	43.00000000	75814078	\N	CNY	api	2025-11-07 23:30:11.140107+08
a9277b1a-6f3f-48f5-ab6a-8e0a2c469b28	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-28	43.02000046	43.29999924	42.59999847	42.97999954	82242557	\N	CNY	api	2025-11-07 23:30:11.140474+08
d1a17a98-2dbd-43b5-8546-f717a74ac703	a7569e62-8eec-4468-8798-d1e948ef4679	2025-08-29	42.97999954	43.99000168	42.88999939	42.88999939	136087899	\N	CNY	api	2025-11-07 23:30:11.140775+08
125632df-8ca3-48da-bc70-06c83e710e5e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-01	42.61999893	42.63999939	41.88000107	41.97999954	127633329	\N	CNY	api	2025-11-07 23:30:11.141476+08
98a1e437-06fa-4dcc-a249-a94da7e5fbb9	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-03	43.43999863	43.56999969	42.70000076	42.90000153	81840560	\N	CNY	api	2025-11-07 23:30:11.142291+08
deda183b-9ed7-4bc6-ae8c-58d67ee69ee8	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-04	42.81000137	43.31999969	42.13999939	43.04999924	93536328	\N	CNY	api	2025-11-07 23:30:11.14267+08
e3867585-28f8-4e89-b922-367f7ef971d0	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-05	43.00000000	43.02000046	42.52999878	42.75999832	57232838	\N	CNY	api	2025-11-07 23:30:11.143038+08
95266ec4-0e43-418e-ada9-fa01210ddb2b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-08	42.70000076	43.09999847	42.36999893	42.43000031	85168162	\N	CNY	api	2025-11-07 23:30:11.14355+08
0182565c-e362-42f0-b978-9acd84ec5e84	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-09	42.41999817	42.88000107	42.40000153	42.83000183	58952653	\N	CNY	api	2025-11-07 23:30:11.143941+08
63c2ea2c-834a-480a-a3c8-ee84efe69f5d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-10	42.79999924	43.15000153	42.56000137	43.00000000	47138694	\N	CNY	api	2025-11-07 23:30:11.144626+08
c74123b5-7a37-405a-a243-7e59beeb7d2e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-11	43.13000107	43.33000183	42.77999878	43.29999924	65073072	\N	CNY	api	2025-11-07 23:30:11.145096+08
c4b3f85a-1cbc-4967-95bf-b8685a7b15e9	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-12	43.38000107	43.47000122	42.41999817	42.54000092	82314003	\N	CNY	api	2025-11-07 23:30:11.145462+08
c4e43b1f-89bf-4d2f-9a7c-11dc9ecea615	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-15	42.47999954	42.79000092	42.11000061	42.22000122	69949106	\N	CNY	api	2025-11-07 23:30:11.145829+08
e9369f56-4062-466f-a69e-4d94702597ca	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-16	42.31999969	42.43000031	41.65999985	41.75000000	85905078	\N	CNY	api	2025-11-07 23:30:11.146143+08
6e2156a1-aadb-4b7b-86d9-12f9d2685a0d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-17	41.75999832	42.18999863	41.70000076	41.75999832	57236258	\N	CNY	api	2025-11-07 23:30:11.146442+08
c9353400-0a41-47a7-b4b2-65b59864b4f5	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-18	41.77999878	41.84000015	40.79999924	40.83000183	100352240	\N	CNY	api	2025-11-07 23:30:11.146731+08
8c0df1a6-67ac-44cb-9e6f-b1e69813ba4c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-19	40.79999924	41.52999878	40.54999924	41.00000000	83656307	\N	CNY	api	2025-11-07 23:30:11.147019+08
7cd17d93-a3e9-4eee-9fc5-4e8f8cda752b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-22	41.15000153	41.36999893	40.79999924	40.91999817	65611030	\N	CNY	api	2025-11-07 23:30:11.147369+08
aadc3b5a-c9de-450f-bbc0-36de46e4a53b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-23	40.97999954	41.75000000	40.63000107	41.54999924	93885081	\N	CNY	api	2025-11-07 23:30:11.147677+08
748a22bc-e18a-4b95-a208-fd57f3157202	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-24	41.50000000	41.88999939	41.29000092	41.31999969	64389951	\N	CNY	api	2025-11-07 23:30:11.147976+08
9a3bf139-3543-4b95-a4f7-477f8af29b86	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-25	41.31999969	41.36000061	40.81000137	40.81999969	66694887	\N	CNY	api	2025-11-07 23:30:11.148273+08
5b3a026a-7f44-4b5a-a3e3-2e17f2e0c752	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-26	40.81000137	41.00000000	40.29999924	40.79999924	68276667	\N	CNY	api	2025-11-07 23:30:11.148589+08
13cfb1df-8060-4554-b7e5-e41003411bd9	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-29	40.77000046	41.29000092	40.36000061	40.68000031	83555055	\N	CNY	api	2025-11-07 23:30:11.148971+08
2927a5cb-4eef-4462-a40c-cbc1c50d8a0f	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-30	40.65000153	40.79000092	40.40999985	40.40999985	70002520	\N	CNY	api	2025-11-07 23:30:11.149467+08
908033bb-5267-4cb1-9cc6-c37ed5b9ae0c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-09	40.20999908	40.43999863	39.81999969	40.33000183	97231953	\N	CNY	api	2025-11-07 23:30:11.149761+08
c5810372-2c8f-4ba2-aa83-abf188266e58	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-10	40.29999924	40.65000153	40.13000107	40.18000031	95504979	\N	CNY	api	2025-11-07 23:30:11.150056+08
2869395a-e325-432a-af24-76ee87021532	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-13	39.75999832	40.29999924	39.70000076	40.11000061	106593617	\N	CNY	api	2025-11-07 23:30:11.150356+08
86a5965d-bd27-4dc9-bcf3-5ed4d377563e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-14	40.09000015	41.49000168	39.83000183	41.25999832	173382668	\N	CNY	api	2025-11-07 23:30:11.150638+08
0ba17f71-2bdd-4786-ace6-7477a2985081	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-15	41.25000000	41.56999969	41.00999832	41.50000000	106276702	\N	CNY	api	2025-11-07 23:30:11.150931+08
d096f1dc-bfa1-47c7-bbd2-8dabf76f3f2d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-16	41.50000000	41.99000168	41.13000107	41.93000031	106248776	\N	CNY	api	2025-11-07 23:30:11.151164+08
b0364df3-da00-4333-814a-812dfadd5d4b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-24	6.36000013	6.38999987	6.34000015	6.36000013	73857863	\N	CNY	api	2025-11-07 23:30:10.781096+08
5251fbcd-cbc0-456b-9625-e54a3d191303	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-31	44.40000153	44.56000137	43.84999847	44.47999954	73319517	\N	CNY	api	2025-11-07 23:30:11.132993+08
e6c6cfc3-3f9c-4957-9b87-37b48c0e2d9d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-21	41.49000168	42.09999847	41.49000168	41.97999954	75993124	\N	CNY	api	2025-11-07 23:30:11.151947+08
8ef0a0a8-3f4b-4155-af2f-a2e522e7e308	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-22	41.97999954	42.20000076	41.72999954	41.95000076	55133364	\N	CNY	api	2025-11-07 23:30:11.152182+08
aa085a56-8014-4531-9c3b-127b26d415fd	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-23	41.95000076	42.49000168	41.77999878	42.24000168	71317373	\N	CNY	api	2025-11-07 23:30:11.152422+08
96a0f98d-50b6-4b70-8fa9-ef27f0b39059	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-24	42.34999847	42.45000076	41.84999847	41.95000076	69883194	\N	CNY	api	2025-11-07 23:30:11.152649+08
32d02d1e-8979-4171-9b40-d610abe98bd8	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-27	41.90000153	41.97000122	41.41999817	41.59000015	98894862	\N	CNY	api	2025-11-07 23:30:11.152905+08
29ed36ee-21e7-4204-80a2-89533aac8f18	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-28	41.61999893	41.72000122	41.22999954	41.59999847	70595074	\N	CNY	api	2025-11-07 23:30:11.153174+08
d94eced6-2bab-49da-82ff-fe01d4b7535a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-30	40.79999924	41.36000061	40.72999954	41.20000076	113153844	\N	CNY	api	2025-11-07 23:30:11.153708+08
6c03c046-f9b4-46d9-9139-6bdc41b17e58	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-31	41.25999832	41.29999924	40.84000015	40.88999939	70260700	\N	CNY	api	2025-11-07 23:30:11.154018+08
e437e44b-69dd-41be-ba5a-afc1458e8991	a7569e62-8eec-4468-8798-d1e948ef4679	2025-11-03	41.13999939	41.97000122	41.06000137	41.79000092	92198068	\N	CNY	api	2025-11-07 23:30:11.154326+08
7148d4ea-fb3b-4472-b3cb-abe15c426423	a7569e62-8eec-4468-8798-d1e948ef4679	2025-11-04	41.84000015	43.11000061	41.81000137	43.00999832	134003592	\N	CNY	api	2025-11-07 23:30:11.154717+08
a00f0c42-6146-4abf-9547-d0dbb4c4a2c1	a7569e62-8eec-4468-8798-d1e948ef4679	2025-11-07	42.40000153	42.72000122	42.27999878	42.50999832	59319118	\N	CNY	api	2025-11-07 23:30:11.155242+08
ea775cef-3204-4c54-a9ac-7e610372cca1	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-30	1444.00000000	1457.16003418	1437.00000000	1449.43994141	3186771	\N	CNY	api	2025-11-07 23:30:11.539482+08
66c495f4-31b7-41d3-9fc6-029a84e385bc	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-01	1421.86999512	1425.95996094	1414.00000000	1417.00000000	2963559	\N	CNY	api	2025-11-07 23:30:11.541272+08
28e78794-b07e-4023-be0c-efc334954fd4	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-04	1415.00000000	1419.80004883	1414.00000000	1419.00000000	1868795	\N	CNY	api	2025-11-07 23:30:11.541945+08
ae286b61-af01-457b-a721-b62b370af9b6	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-05	1421.00000000	1429.93994141	1417.10998535	1427.73999023	2534227	\N	CNY	api	2025-11-07 23:30:11.542296+08
15747073-1c4d-4337-8f10-c53c6be42da6	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-06	1429.00000000	1429.00000000	1419.30004883	1423.88000488	2369928	\N	CNY	api	2025-11-07 23:30:11.542951+08
829af51a-4c97-477d-bbbe-7eed9b60f072	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-07	1423.88000488	1427.69995117	1420.06005859	1422.34997559	2800134	\N	CNY	api	2025-11-07 23:30:11.5436+08
5c8c5d98-5e3e-4fde-9b38-79e3de4d5c74	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-08	1423.05004883	1426.50000000	1418.00000000	1420.96997070	1865528	\N	CNY	api	2025-11-07 23:30:11.5442+08
6c691df9-944e-4ac4-9569-775a8cc6c762	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-11	1423.50000000	1451.98999023	1423.00000000	1445.00000000	4715907	\N	CNY	api	2025-11-07 23:30:11.544727+08
6a9fefc4-52f1-48dc-b50f-5b8e146b4fb2	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-12	1449.00000000	1465.06994629	1436.00000000	1437.04003906	4201923	\N	CNY	api	2025-11-07 23:30:11.545198+08
faba8751-47b1-4ac8-8494-0201207bf83d	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-13	1425.00000000	1433.68005371	1420.00000000	1420.05004883	6552754	\N	CNY	api	2025-11-07 23:30:11.545658+08
902aa81e-85ca-4dc6-a24d-d55a3dc29508	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-14	1420.93994141	1447.51000977	1420.93994141	1426.98999023	4812930	\N	CNY	api	2025-11-07 23:30:11.546107+08
b01bf9f0-cb0e-4144-8423-41fdd157d2fa	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-15	1426.01000977	1428.66003418	1420.21997070	1422.07995605	4758165	\N	CNY	api	2025-11-07 23:30:11.546801+08
9188aca9-123f-43a5-a918-6d2b2304cdc3	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-18	1426.98999023	1436.64001465	1423.09997559	1428.50000000	4737798	\N	CNY	api	2025-11-07 23:30:11.547174+08
7e16dbd2-c8e4-4e06-810d-7bfcfcc8c8f3	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-19	1433.50000000	1446.66003418	1432.00000000	1438.00000000	4637186	\N	CNY	api	2025-11-07 23:30:11.547535+08
b766291a-0dfd-4c9f-a141-44c2d7644d4a	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-20	1438.00000000	1452.80004883	1430.02001953	1450.00000000	4580466	\N	CNY	api	2025-11-07 23:30:11.548177+08
13fc75f3-4d90-4650-96e9-7f83d1d11769	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-21	1453.44995117	1454.98999023	1443.65002441	1448.25000000	3089057	\N	CNY	api	2025-11-07 23:30:11.548599+08
a3a21792-a7af-483c-9066-b87c604c8d59	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-22	1448.88000488	1464.00000000	1444.77001953	1463.94995117	4497058	\N	CNY	api	2025-11-07 23:30:11.548949+08
54005ae1-fb87-4f50-aefc-cf2dd1c66c11	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-25	1470.01000977	1496.00000000	1466.00000000	1490.32995605	6532455	\N	CNY	api	2025-11-07 23:30:11.549653+08
49334e0a-4330-4056-b9f5-1671e1127fe2	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-26	1490.31994629	1494.22998047	1480.01000977	1481.60998535	3960213	\N	CNY	api	2025-11-07 23:30:11.550122+08
8a1a5805-497c-463f-af59-11892133b6ee	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-27	1481.88000488	1484.93005371	1448.00000000	1448.00000000	5600609	\N	CNY	api	2025-11-07 23:30:11.550477+08
22b9a490-b875-4cbd-b3e9-531e9071211b	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-28	1447.96997070	1456.09997559	1438.77001953	1446.09997559	3928177	\N	CNY	api	2025-11-07 23:30:11.550904+08
293290d4-565a-49d9-916e-95bb943395d4	49589118-facc-4785-abf3-3d2d4d054f17	2025-08-29	1453.00000000	1482.57995605	1452.00000000	1480.00000000	6225648	\N	CNY	api	2025-11-07 23:30:11.551158+08
e9f1dc7f-ab9d-407d-a90b-f5da8dff61b5	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-01	1482.19995117	1488.00000000	1465.69995117	1476.09997559	4512338	\N	CNY	api	2025-11-07 23:30:11.551431+08
f5cc4490-d637-4b26-bd34-c9ceca75c908	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-02	1478.66003418	1509.00000000	1478.00000000	1491.30004883	5668837	\N	CNY	api	2025-11-07 23:30:11.551713+08
44a0e96a-e758-42c4-a590-cf7db09c53ed	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-03	1491.00000000	1503.50000000	1466.00000000	1480.55004883	4504503	\N	CNY	api	2025-11-07 23:30:11.552141+08
cca4af4f-dbc0-4608-9bab-648a4595aba6	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-04	1472.00000000	1479.30004883	1460.46997070	1472.66003418	4774676	\N	CNY	api	2025-11-07 23:30:11.552582+08
c46eb38b-8f80-4c59-a04a-7e6c0d3d0d99	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-05	1471.00000000	1486.96997070	1464.00000000	1483.00000000	3738848	\N	CNY	api	2025-11-07 23:30:11.553028+08
9dc44392-e097-4a3e-9762-e7c6732cb520	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-09	1505.00000000	1509.94995117	1493.42004395	1505.00000000	3574277	\N	CNY	api	2025-11-07 23:30:11.554547+08
5ed99987-9e2c-4e3a-88b5-3954170dbfd6	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-10	1506.66003418	1529.94995117	1496.00000000	1522.01000977	4966331	\N	CNY	api	2025-11-07 23:30:11.555151+08
9aeef414-2e2d-40c2-9529-ab8b18398bf9	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-11	1522.01000977	1526.02001953	1508.50000000	1523.50000000	3723896	\N	CNY	api	2025-11-07 23:30:11.555514+08
59d4e136-fe1b-4e36-b16f-e13ce7dfffa5	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-12	1526.00000000	1538.02001953	1510.53002930	1516.00000000	3372209	\N	CNY	api	2025-11-07 23:30:11.55585+08
7af22254-9853-4697-9fdf-18a305f94e89	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-15	1515.86999512	1517.47998047	1501.50000000	1515.09997559	2582703	\N	CNY	api	2025-11-07 23:30:11.556252+08
e0aa53fb-a8d4-4b70-8f3d-37eb5ceba9c4	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-16	1515.09997559	1520.98999023	1496.20996094	1499.97998047	3271789	\N	CNY	api	2025-11-07 23:30:11.556553+08
ae527b3d-3c10-4b89-8ef1-685efe675fc1	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-17	1499.98999023	1510.28002930	1490.01000977	1493.00000000	3033054	\N	CNY	api	2025-11-07 23:30:11.556872+08
cc491a14-0123-46e3-866c-7bff16c3eb50	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-18	1492.00000000	1497.80004883	1463.50000000	1467.95996094	4972125	\N	CNY	api	2025-11-07 23:30:11.557332+08
16cf5af1-4a29-4ce1-b6a5-bee8ed4f3405	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-19	1467.98999023	1475.50000000	1457.01000977	1467.96997070	3263662	\N	CNY	api	2025-11-07 23:30:11.557708+08
3285c468-e23f-44db-a2b8-ed43126b86e0	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-22	1465.08996582	1467.96997070	1450.01000977	1453.34997559	3494708	\N	CNY	api	2025-11-07 23:30:11.558053+08
5159316f-f2ba-4f63-9c6a-567fc611dcd6	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-23	1450.50000000	1457.50000000	1440.00000000	1447.42004395	3866300	\N	CNY	api	2025-11-07 23:30:11.558381+08
c98abd17-74c5-434e-af45-6e7ffc7dfe51	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-24	1434.06994629	1456.78002930	1434.06994629	1442.00000000	3074350	\N	CNY	api	2025-11-07 23:30:11.55909+08
d1d37950-5088-4bbb-a3f7-cd8639bcccd4	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-25	1442.82995605	1445.20996094	1436.00000000	1439.00000000	3386973	\N	CNY	api	2025-11-07 23:30:11.559441+08
b096ad68-e427-4efa-92d9-f1a29f391997	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-26	1441.18005371	1447.10998535	1428.01000977	1435.00000000	4512071	\N	CNY	api	2025-11-07 23:30:11.559685+08
61623095-de0c-49cd-8763-6b15f3dc3121	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-29	1439.38000488	1469.98999023	1435.00000000	1460.85998535	5368403	\N	CNY	api	2025-11-07 23:30:11.55993+08
665c865f-92f1-42c2-a51d-70d87b188310	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-30	1460.00000000	1460.76000977	1440.00000000	1443.98999023	3936362	\N	CNY	api	2025-11-07 23:30:11.560171+08
97b2230b-7beb-40af-ae5f-90b8a349ac8c	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-09	1436.00000000	1439.38000488	1420.00000000	1436.78002930	5491812	\N	CNY	api	2025-11-07 23:30:11.560443+08
ba62e979-fe84-4570-a66f-32a0e1fa22f2	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-10	1437.59997559	1439.93994141	1427.50000000	1430.00000000	3600144	\N	CNY	api	2025-11-07 23:30:11.560682+08
5ebfbd71-708f-4ba9-9d07-910ee496b6c1	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-13	1415.69995117	1422.84997559	1415.11999512	1419.19995117	4606880	\N	CNY	api	2025-11-07 23:30:11.561022+08
b012c2e5-3549-4723-8a6b-d2ba3fc23c40	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-14	1429.98999023	1464.00000000	1429.98999023	1451.02001953	6667233	\N	CNY	api	2025-11-07 23:30:11.561302+08
68aac578-f90a-4631-bbd5-31ddb906d66d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-20	41.61000061	41.79000092	41.09999847	41.41999817	64947729	\N	CNY	api	2025-11-07 23:30:11.151662+08
4f6ebe67-b88e-43fd-a0f9-2e98ef6e2ab2	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-31	1443.00000000	1444.86999512	1418.00000000	1421.67004395	5179751	\N	CNY	api	2025-11-07 23:30:11.540751+08
ace01caa-f50e-4508-880d-e586e7c5a168	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-07-31	208.49000549	209.83999634	207.16000366	207.57000732	80698400	\N	USD	api	2025-11-08 15:17:05.496161+08
cbabedf3-ac1c-47ac-8adc-a32421f9c231	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-01	210.86999512	213.58000183	201.50000000	202.38000488	104434500	\N	USD	api	2025-11-08 15:17:05.512498+08
508569c4-18d2-4a41-9cf6-60b7e77bd603	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-04	204.50999451	207.88000488	201.67999268	203.35000610	75109300	\N	USD	api	2025-11-08 15:17:05.513668+08
c18fdd52-e547-4d4c-8a83-f7e7d346cc87	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-05	203.39999390	205.33999634	202.16000366	202.91999817	44155100	\N	USD	api	2025-11-08 15:17:05.514622+08
c7b6fdf2-7c7a-465d-b8e7-a4ed18086d74	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-06	205.63000488	215.38000488	205.58999634	213.25000000	108483100	\N	USD	api	2025-11-08 15:17:05.51557+08
68ded52b-6f04-4a47-a942-ab636d97f3d3	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-07	218.88000488	220.85000610	216.58000183	220.02999878	90224800	\N	USD	api	2025-11-08 15:17:05.51645+08
5806e8af-c0d4-4de3-9fe1-5c6a9640be3b	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-08	220.83000183	231.00000000	219.25000000	229.35000610	113854000	\N	USD	api	2025-11-08 15:17:05.517603+08
a270df6d-b74e-46f9-839b-22e58b918098	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-11	227.91999817	229.55999756	224.75999451	227.17999268	61806100	\N	USD	api	2025-11-08 15:17:05.518423+08
c04e80d3-04b9-456d-9f0e-12431de2301f	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-12	228.00999451	230.80000305	227.07000732	229.64999390	55626200	\N	USD	api	2025-11-08 15:17:05.519113+08
a696d007-5bda-4e7c-85c1-3bc381e065b1	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-13	231.07000732	235.00000000	230.42999268	233.33000183	69878500	\N	USD	api	2025-11-08 15:17:05.520041+08
8724a552-5f2e-4675-a3db-ebf02af96202	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-14	234.05999756	235.11999512	230.85000610	232.77999878	51916300	\N	USD	api	2025-11-08 15:17:05.520654+08
a5f1db19-3dc2-4afe-bebd-9236f1e22a57	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-15	234.00000000	234.27999878	229.33999634	231.58999634	56038700	\N	USD	api	2025-11-08 15:17:05.52169+08
73f22f41-98c7-4995-a6a1-edfe4151f423	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-18	231.69999695	233.11999512	230.11000061	230.88999939	37476200	\N	USD	api	2025-11-08 15:17:05.522275+08
6e5ae8ea-3226-4428-8dc4-69f6f2c3c4cc	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-19	231.27999878	232.86999512	229.35000610	230.55999756	39402600	\N	USD	api	2025-11-08 15:17:05.522804+08
6f981561-d6f0-418c-b2ec-c45ad4a34f50	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-20	229.97999573	230.47000122	225.77000427	226.00999451	42263900	\N	USD	api	2025-11-08 15:17:05.523239+08
c7e651a3-9932-4b99-9cc8-9ec3e8927e7c	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-21	226.27000427	226.52000427	223.77999878	224.89999390	30621200	\N	USD	api	2025-11-08 15:17:05.523664+08
b13ab1ff-a8ef-40a2-a9f8-b7604681cd44	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-22	226.16999817	229.08999634	225.41000366	227.75999451	42477800	\N	USD	api	2025-11-08 15:17:05.524235+08
ab2ae564-8bcb-4133-a195-da7cf96e568b	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-25	226.47999573	229.30000305	226.22999573	227.16000366	30983100	\N	USD	api	2025-11-08 15:17:05.524889+08
073cada8-302e-4571-812a-ffd21c3e1e22	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-26	226.86999512	229.49000549	224.69000244	229.30999756	54575100	\N	USD	api	2025-11-08 15:17:05.525597+08
7f46f2c1-04e5-494e-8d27-0aff183b3655	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-27	228.61000061	230.89999390	228.25999451	230.49000549	31259500	\N	USD	api	2025-11-08 15:17:05.526269+08
1765c6d5-0519-4de1-b1a2-7a8d9d763061	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-28	230.82000732	233.41000366	229.33999634	232.55999756	38074700	\N	USD	api	2025-11-08 15:17:05.526686+08
bcfd0636-d53c-446f-aa89-9904c93a7692	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-08-29	232.50999451	233.38000488	231.36999512	232.13999939	39418400	\N	USD	api	2025-11-08 15:17:05.527086+08
1bee0916-4633-4cda-be9e-35fc4368b2a0	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-02	229.25000000	230.85000610	226.97000122	229.72000122	44075600	\N	USD	api	2025-11-08 15:17:05.527636+08
c9e4c464-ac6e-4562-9989-7a005b2ca70d	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-03	237.21000671	238.85000610	234.36000061	238.47000122	66427800	\N	USD	api	2025-11-08 15:17:05.528166+08
13931f05-d357-4035-aa6e-835e68bfe972	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-04	238.44999695	239.89999390	236.74000549	239.77999878	47549400	\N	USD	api	2025-11-08 15:17:05.528593+08
36211dcf-de7a-4363-9b46-ae2001583bf7	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-05	240.00000000	241.32000732	238.49000549	239.69000244	54870400	\N	USD	api	2025-11-08 15:17:05.528876+08
bd258a92-9d00-4bff-b188-463970900aba	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-08	239.30000305	240.14999390	236.33999634	237.88000488	48999500	\N	USD	api	2025-11-08 15:17:05.529227+08
0dd68ded-78b8-4f65-a1d4-c004f1d5bd72	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-09	237.00000000	238.77999878	233.36000061	234.35000610	66313900	\N	USD	api	2025-11-08 15:17:05.530969+08
773fa7b4-007e-4741-8ce2-59e52665b074	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-10	232.19000244	232.41999817	225.94999695	226.78999329	83440800	\N	USD	api	2025-11-08 15:17:05.531918+08
da3ee903-3bb0-4806-93d4-3d63dc46eb0c	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-11	226.88000488	230.44999695	226.64999390	230.02999878	50208600	\N	USD	api	2025-11-08 15:17:05.532428+08
97f922cb-aa75-4ca3-a67f-d0b96819b670	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-12	229.22000122	234.50999451	229.02000427	234.07000732	55824200	\N	USD	api	2025-11-08 15:17:05.533065+08
23c5c921-64a9-4e2c-a011-14abfe4a33cc	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-15	237.00000000	238.19000244	235.02999878	236.69999695	42699500	\N	USD	api	2025-11-08 15:17:05.53357+08
17331bc0-36c7-4106-9ba7-1aa6fc46e016	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-16	237.17999268	241.22000122	236.32000732	238.14999390	63421100	\N	USD	api	2025-11-08 15:17:05.534185+08
2d3e555c-40af-4da7-81ab-bc3251ed689e	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-17	238.97000122	240.10000610	237.72999573	238.99000549	46508000	\N	USD	api	2025-11-08 15:17:05.534758+08
c2c31d19-ea43-4ce3-919f-797185d4b5e1	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-18	239.97000122	241.19999695	236.64999390	237.88000488	44249600	\N	USD	api	2025-11-08 15:17:05.535255+08
ee1b9ff2-dec1-43d6-a6d9-1dbd16349113	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-19	241.22999573	246.30000305	240.21000671	245.50000000	163741300	\N	USD	api	2025-11-08 15:17:05.535708+08
e1f8cd62-6e18-4eaa-898d-52ba63adfd28	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-22	248.30000305	256.64001465	248.11999512	256.07998657	105517400	\N	USD	api	2025-11-08 15:17:05.536071+08
b14d2df8-1342-4c1f-bc3c-299ecac93668	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-23	255.88000488	257.33999634	253.58000183	254.42999268	60275200	\N	USD	api	2025-11-08 15:17:05.536495+08
5ac35fd9-149b-4bf7-a4b5-0a0b6366e9bc	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-24	255.22000122	255.74000549	251.03999329	252.30999756	42303700	\N	USD	api	2025-11-08 15:17:05.536983+08
a1ea8578-3d93-46db-b8fe-d1fc71cd778c	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-25	253.21000671	257.17001343	251.71000671	256.86999512	55202100	\N	USD	api	2025-11-08 15:17:05.537438+08
a9a172dd-f4f6-4c97-a3e0-c1c1dd8102e2	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-26	254.10000610	257.60000610	253.77999878	255.46000671	46076300	\N	USD	api	2025-11-08 15:17:05.537916+08
69cb1c6e-7db4-43a9-9a90-ac74a10e5605	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-29	254.55999756	255.00000000	253.00999451	254.42999268	40127700	\N	USD	api	2025-11-08 15:17:05.538295+08
cd6a5442-3e25-43eb-994d-875d2a5fa4f7	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-09-30	254.86000061	255.91999817	253.11000061	254.63000488	37704300	\N	USD	api	2025-11-08 15:17:05.538694+08
a2939429-92f9-40f3-966b-9d2a5550bce0	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-01	255.03999329	258.79000854	254.92999268	255.44999695	48713900	\N	USD	api	2025-11-08 15:17:05.539075+08
ec35f426-4dce-4439-b718-9a0b79ae4ce3	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-02	256.57998657	258.17999268	254.14999390	257.13000488	42630200	\N	USD	api	2025-11-08 15:17:05.539621+08
7e7b1180-f0f9-4993-9b37-34220a52ac0d	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-17	1483.09997559	1488.00000000	1454.03002930	1455.00000000	3808589	\N	CNY	api	2025-11-07 23:30:11.562916+08
a9ce30d1-0374-466a-864a-b66dc9226ec8	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-21	1459.00000000	1469.93994141	1455.50000000	1462.26000977	2544267	\N	CNY	api	2025-11-07 23:30:11.563542+08
256c13fb-079d-42bd-b510-e17424914722	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-22	1462.07995605	1465.72998047	1456.00000000	1458.69995117	1819492	\N	CNY	api	2025-11-07 23:30:11.563794+08
cc3f9075-5b93-4589-81aa-78167c8d3340	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-23	1455.00000000	1468.80004883	1447.19995117	1467.97998047	2932235	\N	CNY	api	2025-11-07 23:30:11.564081+08
3ea6d25c-fa94-4ff7-a400-04f48b42f93b	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-24	1467.94995117	1478.88000488	1449.33996582	1450.00000000	3822583	\N	CNY	api	2025-11-07 23:30:11.564472+08
32223e91-60f7-41fd-ac0e-32448b47788d	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-27	1440.00000000	1452.48999023	1435.98999023	1440.41003418	3710239	\N	CNY	api	2025-11-07 23:30:11.564727+08
73a9333d-f12c-4da9-acab-e2da11543a6a	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-28	1442.00000000	1451.19995117	1441.09997559	1445.00000000	2712433	\N	CNY	api	2025-11-07 23:30:11.564979+08
1e01c6e5-443c-4dde-a6e8-32fde2001bf3	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-29	1440.02001953	1446.55004883	1430.04003906	1431.90002441	3393711	\N	CNY	api	2025-11-07 23:30:11.565285+08
cfc7e587-c051-4059-9079-c3bfba3bf46c	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-30	1421.81005859	1436.63000488	1421.81005859	1426.73999023	4745610	\N	CNY	api	2025-11-07 23:30:11.565544+08
86479536-1688-4922-a78e-fefed2a89fe9	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-31	1422.00000000	1435.97998047	1420.10998535	1430.01000977	3569377	\N	CNY	api	2025-11-07 23:30:11.565787+08
6dea62cf-c2c5-411e-8330-5390c32c2ffd	49589118-facc-4785-abf3-3d2d4d054f17	2025-11-03	1431.00000000	1448.00000000	1420.09997559	1435.00000000	3454766	\N	CNY	api	2025-11-07 23:30:11.566347+08
6896847f-0d72-4008-ba5d-43da49151cb3	49589118-facc-4785-abf3-3d2d4d054f17	2025-11-04	1435.09997559	1435.78002930	1423.78002930	1429.00000000	2656572	\N	CNY	api	2025-11-07 23:30:11.566642+08
99b14a89-0eab-44c4-b6ab-b0288a1b6978	49589118-facc-4785-abf3-3d2d4d054f17	2025-11-05	1425.89001465	1430.98999023	1420.01000977	1420.07995605	3447527	\N	CNY	api	2025-11-07 23:30:11.566902+08
67714fa0-fc69-4ebe-b2bf-3bd152c8708c	49589118-facc-4785-abf3-3d2d4d054f17	2025-11-07	1435.10998535	1439.78002930	1431.10998535	1433.32995605	1886139	\N	CNY	api	2025-11-07 23:30:11.567155+08
74490583-3cb2-4052-a86a-30c21c48ea7a	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-16	1461.92004395	1484.94995117	1458.88000488	1484.91003418	4573015	\N	CNY	api	2025-11-07 23:30:11.562377+08
945ee5ad-25c6-4cef-8d13-d1323e2e3231	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-03	254.66999817	259.23999023	253.94999695	258.01998901	49155600	\N	USD	api	2025-11-08 15:17:05.539984+08
3438690c-094c-4530-b622-e02652271681	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-06	257.98999023	259.07000732	255.05000305	256.69000244	44664100	\N	USD	api	2025-11-08 15:17:05.54069+08
85fda8cd-cb7d-47f1-9a8d-6927a2b7200b	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-07	256.80999756	257.39999390	255.42999268	256.48001099	31955800	\N	USD	api	2025-11-08 15:17:05.541186+08
a99a07ad-695c-488c-bc3d-121f4bd08e13	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-08	256.51998901	258.51998901	256.10998535	258.05999756	36496900	\N	USD	api	2025-11-08 15:17:05.541926+08
58e856d9-6ab6-493f-9814-b85232d08bd0	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-09	257.80999756	258.00000000	253.13999939	254.03999329	38322000	\N	USD	api	2025-11-08 15:17:05.543764+08
32d732c6-3ab6-4886-b22f-e5d402e49b1f	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-10	254.94000244	256.38000488	244.00000000	245.27000427	61999100	\N	USD	api	2025-11-08 15:17:05.544767+08
83969812-a211-43ca-b971-e6084ea3b92e	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-13	249.38000488	249.69000244	245.55999756	247.66000366	38142900	\N	USD	api	2025-11-08 15:17:05.54523+08
075b15eb-4fe9-45d4-bf3f-c9d41888f2b9	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-14	246.60000610	248.85000610	244.69999695	247.77000427	35478000	\N	USD	api	2025-11-08 15:17:05.545507+08
4b8f312d-e74c-4934-9171-b08ccdcb6199	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-15	249.49000549	251.82000732	247.47000122	249.33999634	33893600	\N	USD	api	2025-11-08 15:17:05.545816+08
4200bc1c-000a-43b4-9156-137de852a5f2	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-16	248.25000000	249.03999329	245.13000488	247.44999695	39777000	\N	USD	api	2025-11-08 15:17:05.546219+08
fdcdc5f5-b1c8-4481-b1b8-64ec7b436f1f	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-17	248.02000427	253.38000488	247.27000427	252.28999329	49147000	\N	USD	api	2025-11-08 15:17:05.546696+08
412790f0-d98b-4e53-9c0c-747ece1de74e	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-20	255.88999939	264.38000488	255.63000488	262.23999023	90483000	\N	USD	api	2025-11-08 15:17:05.547173+08
817edef4-b998-4587-bc2a-b33864fb92e4	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-21	261.88000488	265.29000854	261.82998657	262.76998901	46695900	\N	USD	api	2025-11-08 15:17:05.547649+08
119e1ea1-dfea-47a0-ab18-af8cdd24bff4	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-22	262.64999390	262.85000610	255.42999268	258.45001221	45015300	\N	USD	api	2025-11-08 15:17:05.548123+08
fcfc3bd6-dcee-45e2-bedd-484eff17b1ac	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-23	259.94000244	260.61999512	258.01000977	259.57998657	32754900	\N	USD	api	2025-11-08 15:17:05.548667+08
ef25325a-695e-4723-9b5f-e042351f1472	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-24	261.19000244	264.13000488	259.17999268	262.82000732	38253700	\N	USD	api	2025-11-08 15:17:05.549093+08
9b34370a-2fd5-4815-a3d4-05c4f6c4a2f8	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-27	264.88000488	269.11999512	264.64999390	268.80999756	44888200	\N	USD	api	2025-11-08 15:17:05.549515+08
dfe02d9c-0c66-4130-acef-cb1511b73178	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-28	268.98999023	269.89001465	268.14999390	269.00000000	41534800	\N	USD	api	2025-11-08 15:17:05.550497+08
10d6d549-7617-4186-bc3e-c72d79e6dc87	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-29	269.27999878	271.41000366	267.10998535	269.70001221	51086700	\N	USD	api	2025-11-08 15:17:05.551044+08
ad79d7b7-3a53-498c-a227-e9f18dca4c6a	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-30	271.98999023	274.14001465	268.48001099	271.39999390	69886500	\N	USD	api	2025-11-08 15:17:05.551819+08
fe37a344-ab02-459f-a486-27e73cd0d631	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-10-31	276.98999023	277.32000732	269.16000366	270.36999512	86167100	\N	USD	api	2025-11-08 15:17:05.552581+08
74ad39b5-3a1d-4cf1-903a-22afb9175dbd	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-11-03	270.42001343	270.85000610	266.25000000	269.04998779	50194600	\N	USD	api	2025-11-08 15:17:05.552946+08
c452fe7f-b1ce-4e7f-aa93-530fea6fc42d	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-11-04	268.32998657	271.48999023	267.61999512	270.04000854	49274800	\N	USD	api	2025-11-08 15:17:05.553379+08
2f2dcea7-b3eb-481c-96f0-95d24721eedf	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-11-05	268.60998535	271.70001221	266.92999268	270.14001465	43683100	\N	USD	api	2025-11-08 15:17:05.553816+08
de8ba660-a8c4-4657-bb43-b81dae89b24f	9dd1720a-bd8f-4810-9648-b47b516d82cb	2025-11-06	267.89001465	273.39999390	267.89001465	269.76998901	51157400	\N	USD	api	2025-11-08 15:17:05.554143+08
6727f41d-902b-41e2-8250-e563b044821d	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-07-31	195.71000671	195.99000549	191.08999634	191.89999390	51329200	\N	USD	api	2025-11-08 15:17:05.765667+08
4ba43774-aa29-47b0-a920-69a62ab691b2	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-01	189.02999878	190.83000183	187.82000732	189.13000488	34832200	\N	USD	api	2025-11-08 15:17:05.767434+08
124aebe9-9ee1-467b-b474-492bf23a8df8	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-04	190.28999329	195.27000427	190.11999512	195.03999329	31547400	\N	USD	api	2025-11-08 15:17:05.76872+08
653837f9-b46b-4bfc-9d20-602ea92e0f5c	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-05	194.71000671	197.86000061	193.88999939	194.66999817	31602300	\N	USD	api	2025-11-08 15:17:05.769548+08
734df154-fd37-42a1-8fe2-00360dbcc359	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-06	194.50000000	196.63000488	193.66999817	196.08999634	21562900	\N	USD	api	2025-11-08 15:17:05.770259+08
f92911f4-4024-480c-904e-712530f6c38a	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-07	197.05999756	197.53999329	194.33000183	196.52000427	26321800	\N	USD	api	2025-11-08 15:17:05.770767+08
a91663da-902c-4bc1-bd62-8c09e76ba5d7	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-08	197.22000122	202.61000061	197.16999817	201.41999817	39161800	\N	USD	api	2025-11-08 15:17:05.771324+08
cdd7a101-e4db-4e42-9a7e-751182ed8d08	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-11	200.94000244	201.47999573	199.07000732	201.00000000	25832400	\N	USD	api	2025-11-08 15:17:05.771956+08
0652c647-d772-4b8a-89dc-1e24ea68600c	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-12	201.36999512	204.50000000	200.58999634	203.33999634	30397900	\N	USD	api	2025-11-08 15:17:05.772676+08
2810fcae-af76-4637-ac1e-09e4a242d4d7	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-13	204.13000488	204.52999878	197.50999451	201.96000671	28342900	\N	USD	api	2025-11-08 15:17:05.773278+08
01174f5b-9ef8-4845-9ca4-0a1688f2a5b4	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-14	201.50000000	204.44000244	201.22999573	202.94000244	25230400	\N	USD	api	2025-11-08 15:17:05.773823+08
aada027c-19a1-4eb4-a996-f0752875739c	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-15	203.85000610	206.44000244	201.27999878	203.89999390	34931400	\N	USD	api	2025-11-08 15:17:05.77443+08
67c3ee0b-e927-4101-b0d4-cf59977007f2	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-18	204.19999695	205.27000427	202.49000549	203.50000000	18526600	\N	USD	api	2025-11-08 15:17:05.774944+08
f4c2254e-9e7e-4fa7-a464-857a2577a405	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-19	203.02999878	203.44000244	199.96000671	201.57000732	24240200	\N	USD	api	2025-11-08 15:17:05.775547+08
e9b97dac-2a5d-4cf7-8123-50ba8e07c413	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-20	200.72999573	201.27999878	196.60000610	199.32000732	28955500	\N	USD	api	2025-11-08 15:17:05.776229+08
d961b077-0aca-4557-b110-ea06f812a583	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-21	199.75000000	202.47999573	199.42999268	199.75000000	19774600	\N	USD	api	2025-11-08 15:17:05.77677+08
985a37c7-43df-4590-be9f-e34e32601d43	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-22	202.72999573	208.53999329	201.30000305	206.08999634	42827000	\N	USD	api	2025-11-08 15:17:05.777334+08
ede14b8e-6d74-48b0-a23f-8d64f1493f5b	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-25	206.42999268	210.52000427	205.27999878	208.49000549	29928900	\N	USD	api	2025-11-08 15:17:05.777916+08
e6882463-99a9-42da-9166-e9f11d10f64a	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-26	207.50999451	207.85000610	205.69999695	207.13999939	28464100	\N	USD	api	2025-11-08 15:17:05.77854+08
dd415657-b09b-452a-a01a-d0dd0b453bcb	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-27	205.69999695	208.91000366	205.64999390	207.47999573	23022900	\N	USD	api	2025-11-08 15:17:05.779254+08
b31fe9fb-8eca-46db-aa7f-6b04b256f9ad	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-28	207.25000000	212.22000122	206.89999390	211.63999939	32339300	\N	USD	api	2025-11-08 15:17:05.780175+08
b1f42fd1-bd8c-4cc1-b641-b395895369e6	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-08-29	210.50999451	214.64999390	210.19999695	212.91000366	39728400	\N	USD	api	2025-11-08 15:17:05.780938+08
ced4cae7-b543-4a17-b767-58d69735ec4d	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-02	208.44000244	211.67999268	206.19999695	211.35000610	47523000	\N	USD	api	2025-11-08 15:17:05.781928+08
dfeb63b4-78af-43c1-969e-7cde900794e8	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-03	226.21000671	231.30999756	224.78999329	230.66000366	103336100	\N	USD	api	2025-11-08 15:17:05.782471+08
7235d7fe-3df3-4316-b7c3-c72e044645fb	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-04	229.64999390	232.36999512	226.11000061	232.30000305	51684200	\N	USD	api	2025-11-08 15:17:05.782888+08
6ae3a073-58eb-4652-9697-2c1e35c8c05f	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-05	232.19999695	235.75999451	231.89999390	235.00000000	46588900	\N	USD	api	2025-11-08 15:17:05.783304+08
b0fd723b-3942-4b9e-a8cd-fb156629e692	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-08	235.47000122	238.13000488	233.66999817	234.03999329	32474700	\N	USD	api	2025-11-08 15:17:05.783964+08
fa1b6a04-9848-4c25-b366-3fc7adde4f93	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-09	234.16999817	240.47000122	233.22999573	239.63000488	38061000	\N	USD	api	2025-11-08 15:17:05.784484+08
bcadf66f-17ab-4459-a796-a037a0b3fcb7	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-10	238.89999390	241.66000366	237.85000610	239.16999817	35141100	\N	USD	api	2025-11-08 15:17:05.784981+08
99c0c95a-787a-40be-a198-2a184a707f71	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-11	239.88000488	242.25000000	236.25000000	240.36999512	30599300	\N	USD	api	2025-11-08 15:17:05.78546+08
d3ade175-7cbd-40ad-8d07-caff9e6a8770	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-12	240.36999512	242.08000183	238.00000000	240.80000305	26771600	\N	USD	api	2025-11-08 15:17:05.785936+08
0c5802b1-0ee7-434e-9a4d-693ccc12c481	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-15	244.66000366	252.41000366	244.66000366	251.61000061	58383800	\N	USD	api	2025-11-08 15:17:05.786497+08
72229223-1f3b-4340-989f-739e8cb45777	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-16	252.08000183	253.03999329	249.47000122	251.16000366	34109700	\N	USD	api	2025-11-08 15:17:05.786967+08
d618d738-406d-4dff-b818-96275cf79e5b	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-17	251.22000122	251.60000610	246.27999878	249.52999878	34108000	\N	USD	api	2025-11-08 15:17:05.787457+08
ebac9fb8-77f3-493e-afa0-8aab9b986c6e	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-18	251.67999268	253.99000549	249.80000305	252.02999878	31239500	\N	USD	api	2025-11-08 15:17:05.787909+08
be98bd67-f5a6-46dc-8eb6-70ab7dc1ca31	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-19	253.25000000	256.00000000	251.80999756	254.72000122	55571400	\N	USD	api	2025-11-08 15:17:05.788252+08
9958c2b5-a67e-4039-a483-c1c68fbca662	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-22	254.42999268	255.77999878	250.30000305	252.52999878	32290500	\N	USD	api	2025-11-08 15:17:05.788671+08
6382c206-69b5-49b8-91d0-bd7754188639	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-23	253.03999329	254.36000061	250.47999573	251.66000366	26628000	\N	USD	api	2025-11-08 15:17:05.78924+08
56b6c9af-61a2-4162-8241-747d46e7ecfa	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-24	251.66000366	252.35000610	246.44000244	247.13999939	28201000	\N	USD	api	2025-11-08 15:17:05.789773+08
ace56d9d-260f-4457-841f-777d2d11e4b0	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-25	244.39999390	246.49000549	240.74000549	245.78999329	31020400	\N	USD	api	2025-11-08 15:17:05.790252+08
c92000ec-1870-4aff-ac00-e00758b747c2	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-26	247.07000732	249.41999817	245.97000122	246.53999329	18503200	\N	USD	api	2025-11-08 15:17:05.790729+08
a91342d6-6d11-4929-b7e7-ee00cfb9ec9c	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-29	247.85000610	251.14999390	242.77000427	244.05000305	32505800	\N	USD	api	2025-11-08 15:17:05.791197+08
fb441786-ef00-41e2-934e-fe289c5ee517	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-09-30	242.80999756	243.28999329	239.25000000	243.10000610	34724300	\N	USD	api	2025-11-08 15:17:05.791718+08
8baf05d9-5903-4c16-b34a-37331af3fcdf	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-01	240.75000000	246.30000305	238.61000061	244.89999390	31658200	\N	USD	api	2025-11-08 15:17:05.792702+08
eba4077a-3791-4dd4-9502-f868600eb467	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-02	245.14999390	246.80999756	242.30000305	245.69000244	25483300	\N	USD	api	2025-11-08 15:17:05.793314+08
1e6d832a-c833-4ddc-bf22-287dbd281430	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-03	244.49000549	246.30000305	241.66000366	245.35000610	30249600	\N	USD	api	2025-11-08 15:17:05.79384+08
575f2573-8027-4db3-8ee0-75ebeed880a6	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-06	244.77999878	251.32000732	244.58000183	250.42999268	28894700	\N	USD	api	2025-11-08 15:17:05.794647+08
2e534704-c3ad-417d-9693-9f0ec2f54630	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-07	248.27000427	250.44000244	245.52000427	245.75999451	23181300	\N	USD	api	2025-11-08 15:17:05.79528+08
ec86c605-2a9a-469e-ae8f-837c2d10e62d	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-08	244.96000671	246.00999451	243.82000732	244.61999512	21307100	\N	USD	api	2025-11-08 15:17:05.796042+08
6fcad347-b708-48eb-9928-4b03989bdf9a	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-09	244.47000122	244.75999451	239.14999390	241.52999878	27892100	\N	USD	api	2025-11-08 15:17:05.796589+08
cbbeac23-9b18-48f0-a18b-b1b69ee7a1d1	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-10	241.42999268	244.08999634	235.83999634	236.57000732	33180300	\N	USD	api	2025-11-08 15:17:05.797128+08
8e805b4f-7a2c-40f4-8de6-a8643381aea8	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-13	240.21000671	244.50000000	239.71000671	244.14999390	24995000	\N	USD	api	2025-11-08 15:17:05.797697+08
5410cbf0-5532-4dd2-a980-cd66beff2f27	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-14	241.22999573	247.11999512	240.50999451	245.44999695	22111600	\N	USD	api	2025-11-08 15:17:05.798197+08
54f2d7ea-5890-47f1-8871-5c12b846af25	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-15	247.25000000	252.11000061	245.99000549	251.02999878	27007700	\N	USD	api	2025-11-08 15:17:05.798731+08
75976dff-c260-4d65-8031-e088e3b482b4	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-16	251.77000427	256.95999146	250.10000610	251.46000671	27997200	\N	USD	api	2025-11-08 15:17:05.799273+08
08810610-e34b-4918-b45a-c43c93b37389	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-17	250.75999451	254.22000122	247.80999756	253.30000305	29671600	\N	USD	api	2025-11-08 15:17:05.799827+08
452d8b45-f49e-4186-a7c5-d0182127dfab	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-20	254.69000244	257.32998657	254.22999573	256.54998779	22350200	\N	USD	api	2025-11-08 15:17:05.800314+08
dfe43fee-c964-44cc-9ec9-0fd1b7441502	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-21	254.74000549	254.88000488	244.14999390	250.46000671	47312100	\N	USD	api	2025-11-08 15:17:05.800853+08
64d0bb5d-237d-46c0-aff1-f589def6c536	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-22	254.36999512	256.35998535	249.28999329	251.69000244	35029400	\N	USD	api	2025-11-08 15:17:05.801347+08
56596578-809a-4528-9523-9a7ce5111e5e	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-23	252.97999573	255.03999329	251.85000610	253.08000183	19901400	\N	USD	api	2025-11-08 15:17:05.801829+08
a469377e-61b7-4e2d-86d6-8b424d56a8d7	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-24	256.57998657	261.67999268	255.32000732	259.92001343	28655100	\N	USD	api	2025-11-08 15:17:05.8023+08
a5056406-5bc8-41d2-9715-3a138cf5c3ac	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-27	264.82000732	270.14001465	264.27999878	269.26998901	35235200	\N	USD	api	2025-11-08 15:17:05.802718+08
eb9d48ab-8bf5-4763-ab92-9b6b8ed05b9a	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-28	269.69000244	270.73001099	266.50000000	267.47000122	29738600	\N	USD	api	2025-11-08 15:17:05.80314+08
fc89d116-540e-4aeb-9cc3-57618a7c600c	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-29	267.75000000	275.33999634	267.67001343	274.57000732	43580300	\N	USD	api	2025-11-08 15:17:05.803722+08
61cc9f0b-7496-47e4-96e9-5acf00bc89f3	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-30	291.58999634	291.58999634	280.05999756	281.48001099	74876000	\N	USD	api	2025-11-08 15:17:05.804114+08
2f56d42f-0159-41b5-ae11-2623e0a4c88d	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-10-31	283.20999146	286.00000000	277.02999878	281.19000244	39267900	\N	USD	api	2025-11-08 15:17:05.804618+08
93aea98a-3b63-4ec2-bbe3-1f1074a29ef0	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-11-03	282.17999268	285.52999878	279.79998779	283.72000122	29786000	\N	USD	api	2025-11-08 15:17:05.805134+08
38c7f576-244b-4a42-bf12-a06ee1fb0950	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-11-04	276.75000000	281.26998901	276.26000977	277.54000854	30078400	\N	USD	api	2025-11-08 15:17:05.805492+08
9c8efd8e-4cd7-4577-8493-1120ae60840a	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-11-05	278.86999512	286.42001343	277.33999634	284.30999756	31010300	\N	USD	api	2025-11-08 15:17:05.805923+08
7c094285-b824-40aa-9e02-92eccd9a53d6	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-11-06	285.32998657	288.35000610	281.14001465	284.75000000	37173600	\N	USD	api	2025-11-08 15:17:05.806423+08
d0a56650-b852-4d94-ac75-516e55de258d	e18a110d-3daa-4d2f-9880-c3985dce8bbf	2025-11-07	283.20999146	283.77999878	275.19000244	278.82998657	34440600	\N	USD	api	2025-11-08 15:17:05.806918+08
08c080f9-6b97-4d87-8c63-be141ad75aea	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-07-31	555.22998047	555.45001221	531.90002441	533.50000000	51617300	\N	USD	api	2025-11-08 15:17:06.047949+08
eeb79256-4220-4c80-8978-ce35eeb84fb4	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-01	535.00000000	535.79998779	520.85998535	524.10998535	28977600	\N	USD	api	2025-11-08 15:17:06.049809+08
1d267b4f-c72e-4715-973b-d3db22ed9637	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-04	528.27001953	538.25000000	528.13000488	535.64001465	25349000	\N	USD	api	2025-11-08 15:17:06.050897+08
5b39640e-3b8c-4a61-98e9-0bcd42c4b79f	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-05	537.17999268	537.29998779	527.23999023	527.75000000	19171600	\N	USD	api	2025-11-08 15:17:06.051472+08
3614d534-8254-4298-a2ff-47847b75f260	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-06	530.90002441	531.70001221	524.03002930	524.94000244	21355700	\N	USD	api	2025-11-08 15:17:06.052073+08
a5d25954-7393-419e-a0f2-9981c01e0539	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-07	526.79998779	528.09002686	517.54998779	520.84002686	16079100	\N	USD	api	2025-11-08 15:17:06.053934+08
c53296f9-911a-43b6-98f5-889c8a391893	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-08	522.59997559	524.65997314	519.40997314	522.03997803	15531000	\N	USD	api	2025-11-08 15:17:06.05452+08
8ee73fe5-bcb4-4286-aa78-f314513594ea	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-11	522.29998779	527.59002686	519.71997070	521.77001953	20194400	\N	USD	api	2025-11-08 15:17:06.055054+08
954f418b-8744-457a-a892-d189bf3866c7	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-12	523.75000000	530.97998047	522.70001221	529.23999023	18667000	\N	USD	api	2025-11-08 15:17:06.055536+08
c1acd796-5048-421a-998c-1923c4c9c942	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-13	532.10998535	532.70001221	519.36999512	520.58001709	19619200	\N	USD	api	2025-11-08 15:17:06.056033+08
63adb338-76f0-403e-b397-cffaef64dc6b	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-14	522.55999756	525.95001221	520.14001465	522.47998047	20269100	\N	USD	api	2025-11-08 15:17:06.056491+08
666ed2d9-7b23-407f-bbf5-7e98f7eb020b	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-15	522.77001953	526.09997559	519.08001709	520.16998291	25213300	\N	USD	api	2025-11-08 15:17:06.05705+08
aaf53b74-09ca-4205-a600-7b1bec5b5b72	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-18	521.59002686	522.82000732	514.02001953	517.09997559	23760600	\N	USD	api	2025-11-08 15:17:06.057838+08
a7f341d7-bdf0-4036-95b6-c59714281afc	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-19	515.00000000	515.15997314	508.54998779	509.76998901	21481000	\N	USD	api	2025-11-08 15:17:06.058671+08
37f49e28-aa09-4c61-a9f2-ff0cc2e504ed	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-20	509.86999512	511.00000000	504.44000244	505.72000122	27723000	\N	USD	api	2025-11-08 15:17:06.059331+08
8dc048e8-0f73-4dab-b0cb-a2e15efb153a	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-21	503.69000244	507.63000488	502.72000122	504.23999023	18443300	\N	USD	api	2025-11-08 15:17:06.059904+08
e3c008af-22b6-40a2-b4c4-b652e6085703	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-22	504.25000000	510.73001099	502.41000366	507.23001099	24324200	\N	USD	api	2025-11-08 15:17:06.060429+08
09a4d1e2-c54a-499a-8560-b293633482eb	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-25	506.63000488	508.19000244	504.11999512	504.26000977	21638600	\N	USD	api	2025-11-08 15:17:06.060989+08
2e56da8d-addb-4479-b3de-fad729a7e70f	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-26	504.35998535	504.98001099	498.51000977	502.04000854	30835700	\N	USD	api	2025-11-08 15:17:06.06149+08
3d748c8f-a54d-4891-aeb6-adbf61481717	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-27	502.00000000	507.29000854	499.89999390	506.73999023	17277900	\N	USD	api	2025-11-08 15:17:06.062511+08
a06130aa-3cef-457a-8ab0-ba028bbbf2ef	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-28	507.08999634	511.08999634	505.50000000	509.64001465	18015600	\N	USD	api	2025-11-08 15:17:06.06351+08
c025e864-1c9e-4bbb-bc4b-153452a611d5	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-08-29	508.66000366	509.60000610	504.48999023	506.69000244	20961600	\N	USD	api	2025-11-08 15:17:06.064274+08
ff26a19a-fafe-431a-8f5c-738de7294031	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-02	500.47000122	506.00000000	496.80999756	505.11999512	18128000	\N	USD	api	2025-11-08 15:17:06.064816+08
2912d248-51e5-4447-abfe-64e24909a8ee	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-03	503.79000854	507.79000854	502.32000732	505.35000610	16345100	\N	USD	api	2025-11-08 15:17:06.065286+08
efeb03df-d1a4-4823-9454-61599520c71d	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-04	504.29998779	508.14999390	503.14999390	507.97000122	15509500	\N	USD	api	2025-11-08 15:17:06.065681+08
4c38ca16-f01e-480c-a9b3-196457ca51a1	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-05	509.07000732	511.97000122	492.36999512	495.00000000	31994800	\N	USD	api	2025-11-08 15:17:06.066085+08
1f5cc68f-ecba-433a-b654-be4e5ce30880	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-08	498.10998535	501.20001221	495.02999878	498.20001221	16771000	\N	USD	api	2025-11-08 15:17:06.066583+08
b182a052-1831-4bdb-a5a9-42cb37efce94	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-09	501.42999268	502.25000000	497.70001221	498.41000366	14410500	\N	USD	api	2025-11-08 15:17:06.067059+08
8a28b9ae-aae7-4f73-9cdd-0b0243bc480d	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-10	502.98001099	503.23001099	496.72000122	500.36999512	21611800	\N	USD	api	2025-11-08 15:17:06.067442+08
5fe6bc1d-dbae-4927-8c0e-0fd630f9c246	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-11	502.25000000	503.17001343	497.88000488	501.01000977	18881600	\N	USD	api	2025-11-08 15:17:06.067823+08
56f5699a-5b66-4ada-a7df-63b5912b6e86	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-12	506.64999390	512.54998779	503.85000610	509.89999390	23624900	\N	USD	api	2025-11-08 15:17:06.068178+08
8d393e7b-814c-4c29-9d63-c1974337aab4	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-15	508.79000854	515.46997070	507.00000000	515.35998535	17143800	\N	USD	api	2025-11-08 15:17:06.068553+08
b8c814ec-5a54-496b-82de-493890639e48	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-16	516.88000488	517.22998047	508.60000610	509.04000854	19711900	\N	USD	api	2025-11-08 15:17:06.068975+08
fb247a83-c759-4ba7-85dd-91994a163eef	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-17	510.61999512	511.29000854	505.92999268	510.01998901	15816600	\N	USD	api	2025-11-08 15:17:06.06934+08
95079b3b-4037-4457-bd03-e875013e67a1	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-18	511.48999023	513.07000732	507.66000366	508.45001221	18913700	\N	USD	api	2025-11-08 15:17:06.069716+08
9b9a5d50-d4bb-40a6-aec9-70a8a0ab3886	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-19	510.55999756	519.29998779	510.30999756	517.92999268	52474100	\N	USD	api	2025-11-08 15:17:06.07008+08
5a9b224c-4a5e-4f26-9936-7413a3632002	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-22	515.59002686	517.73999023	512.53997803	514.45001221	20009300	\N	USD	api	2025-11-08 15:17:06.070665+08
a4a1b3b3-c7ff-4cee-9f35-429aec793524	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-23	513.79998779	514.59002686	507.30999756	509.23001099	19799600	\N	USD	api	2025-11-08 15:17:06.071249+08
5fae0276-95ea-461b-9f25-e9b5e170fcd3	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-24	510.38000488	512.47998047	506.92001343	510.14999390	13533700	\N	USD	api	2025-11-08 15:17:06.071714+08
b9a03200-03c3-4d52-af21-45ddcd3d9378	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-25	508.29998779	510.01000977	505.04000854	507.02999878	15786500	\N	USD	api	2025-11-08 15:17:06.072421+08
4c5a3469-1561-457a-bdfb-b598877f7440	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-26	510.05999756	513.94000244	506.61999512	511.45999146	16213100	\N	USD	api	2025-11-08 15:17:06.072801+08
430e2e9c-9d04-44e9-8d50-def85d8d7261	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-29	511.50000000	516.84997559	508.88000488	514.59997559	17617800	\N	USD	api	2025-11-08 15:17:06.073283+08
4084183c-6b3d-4a99-9e6e-a40608419712	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-09-30	513.23999023	518.15997314	509.66000366	517.95001221	19728200	\N	USD	api	2025-11-08 15:17:06.073597+08
d95c7d20-382c-474d-bf53-e20edd61579e	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-01	514.79998779	520.51000977	511.69000244	519.71002197	22632300	\N	USD	api	2025-11-08 15:17:06.073903+08
722e3400-c779-4e8d-8a3e-933627930d44	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-02	517.64001465	521.59997559	510.67999268	515.73999023	21222900	\N	USD	api	2025-11-08 15:17:06.07432+08
8241b356-50da-44ee-aa44-d45c38452dd4	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-03	517.09997559	520.48999023	515.00000000	517.34997559	15112300	\N	USD	api	2025-11-08 15:17:06.07469+08
bddf0adf-5413-4bb8-9937-b31cdeced158	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-06	518.60998535	531.03002930	518.20001221	528.57000732	21388600	\N	USD	api	2025-11-08 15:17:06.075184+08
8dcbfd39-64e1-4d31-8578-d0f0313e68bc	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-07	528.28997803	529.79998779	521.44000244	523.97998047	14615200	\N	USD	api	2025-11-08 15:17:06.075564+08
e80d3ebe-eeb3-4dcc-8f33-12612757e274	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-08	523.28002930	526.95001221	523.09002686	524.84997559	13363400	\N	USD	api	2025-11-08 15:17:06.076025+08
a5098334-640c-46a0-ab0b-e91547da6e42	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-09	522.34002686	524.33001709	517.40002441	522.40002441	18343600	\N	USD	api	2025-11-08 15:17:06.07643+08
c4b21ad0-bad1-43c8-b8fb-9fbad69135bf	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-10	519.64001465	523.58001709	509.63000488	510.95999146	24133800	\N	USD	api	2025-11-08 15:17:06.076851+08
501730a2-c2f8-407a-8b1d-fae0702b885a	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-13	516.40997314	516.40997314	511.67999268	514.04998779	14284200	\N	USD	api	2025-11-08 15:17:06.077418+08
6f853044-0f2f-4eca-b19a-9218110fc8de	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-14	510.23001099	515.28002930	506.00000000	513.57000732	14684300	\N	USD	api	2025-11-08 15:17:06.077939+08
11d4024e-17c0-40df-bf50-ca5410eff0b5	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-15	514.96002197	517.19000244	510.00000000	513.42999268	14694700	\N	USD	api	2025-11-08 15:17:06.078441+08
97cef788-988f-4f7c-a838-dfab223bb25f	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-16	512.58001709	516.84997559	508.13000488	511.60998535	15559600	\N	USD	api	2025-11-08 15:17:06.079062+08
197655c2-4a50-40db-b623-aa69ff29c9bd	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-17	509.04000854	515.47998047	507.30999756	513.58001709	19867800	\N	USD	api	2025-11-08 15:17:06.079784+08
d642ce7c-fd8a-4372-a5cc-1454102b0245	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-20	514.60998535	518.70001221	513.42999268	516.78997803	14665600	\N	USD	api	2025-11-08 15:17:06.080223+08
8f98f70c-1f4a-4628-8423-a3a848c65f75	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-21	517.50000000	518.69000244	513.03997803	517.65997314	15586200	\N	USD	api	2025-11-08 15:17:06.080732+08
c6414894-ed46-4200-b38a-f981227f3b54	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-22	521.15002441	525.22998047	517.71002197	520.53997803	18962700	\N	USD	api	2025-11-08 15:17:06.081137+08
fa334da6-b081-4eeb-abc5-300e724eb085	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-23	522.46002197	523.95001221	518.60998535	520.55999756	14023500	\N	USD	api	2025-11-08 15:17:06.081518+08
ea0aeba1-d3a4-413f-9e3a-91bf69801510	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-24	522.78997803	525.34997559	520.71002197	523.60998535	15532400	\N	USD	api	2025-11-08 15:17:06.082219+08
91da6e24-32e8-4caf-939c-2f9241c58a1c	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-27	531.78002930	534.58001709	529.01000977	531.52001953	18734700	\N	USD	api	2025-11-08 15:17:06.082579+08
89e15467-cbb2-4af6-abcc-8b5ad0ec6f35	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-28	550.00000000	553.71997070	540.77001953	542.07000732	29986700	\N	USD	api	2025-11-08 15:17:06.082916+08
8ba3a7f8-904f-4cb2-b75f-f289ceacfc6d	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-29	544.94000244	546.27001953	536.72998047	541.54998779	36023000	\N	USD	api	2025-11-08 15:17:06.083287+08
b73fb713-2eeb-4a44-8a7f-04f6471ea079	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-30	530.47998047	534.96997070	522.11999512	525.76000977	41023100	\N	USD	api	2025-11-08 15:17:06.083638+08
511f8018-1165-4941-a24d-e7285ac8e8e0	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-10-31	528.88000488	529.32000732	515.09997559	517.80999756	34006400	\N	USD	api	2025-11-08 15:17:06.08398+08
7a0ea510-61db-4aa0-aafb-2b924addf10d	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-11-03	519.80999756	524.96002197	514.59002686	517.03002930	22374700	\N	USD	api	2025-11-08 15:17:06.084326+08
7342c8dc-0e04-4918-ad34-3a58a6dc45aa	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-11-04	511.76000977	515.54998779	507.83999634	514.33001709	20958700	\N	USD	api	2025-11-08 15:17:06.084667+08
aa72d41f-99f5-4ac9-b91b-8150c3388661	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-11-05	513.29998779	514.83001709	506.57998657	507.16000366	23024300	\N	USD	api	2025-11-08 15:17:06.085004+08
a2fa2e21-6481-4fc3-b96d-ce2fc5ae45f0	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-11-06	505.66000366	505.70001221	495.80999756	497.10000610	27375300	\N	USD	api	2025-11-08 15:17:06.085354+08
3be1ccd4-1d6a-43e4-972d-9fc9db36d2c3	43fc85a9-db6d-4390-a6ef-7b4b5979fdda	2025-11-07	496.95001221	499.38000488	493.25000000	496.82000732	23980600	\N	USD	api	2025-11-08 15:17:06.085693+08
3f402407-a47b-4e6e-b583-e192f434b1b0	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-07-31	319.60998535	321.36999512	306.10000610	308.26998901	85270900	\N	USD	api	2025-11-08 15:17:06.296188+08
f2f3b8ed-a307-44d6-90b2-52dabbfbae66	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-01	306.20999146	309.30999756	297.82000732	302.63000488	89121400	\N	USD	api	2025-11-08 15:17:06.297506+08
e5e297e6-c3c0-4608-9a80-30d5bc375c1a	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-04	309.07998657	312.11999512	303.00000000	309.26000977	78683900	\N	USD	api	2025-11-08 15:17:06.298215+08
5f8ea233-5a92-4573-b517-a83686805b5a	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-05	308.95001221	312.45001221	305.50000000	308.72000122	57961300	\N	USD	api	2025-11-08 15:17:06.298864+08
72149d6c-5d3e-4a1a-8b4d-8ea893f182e1	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-06	307.89001465	320.47000122	306.92999268	319.91000366	78523600	\N	USD	api	2025-11-08 15:17:06.299343+08
db4287d1-5cdd-45bd-ad2d-599dae758d9c	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-07	319.79000854	322.39999390	316.16000366	322.26998901	66658700	\N	USD	api	2025-11-08 15:17:06.299957+08
a3f9bf65-7813-4a85-9d0f-a8a3877673eb	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-08	321.42999268	335.14999390	320.98001099	329.64999390	91200300	\N	USD	api	2025-11-08 15:17:06.300447+08
35942172-d148-4f88-bcff-aab1a65df2cd	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-11	335.00000000	346.64001465	334.14999390	339.02999878	105320200	\N	USD	api	2025-11-08 15:17:06.300913+08
8fd62a04-22a0-42d0-9566-a02b75654c18	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-12	345.00000000	345.26000977	332.94000244	340.83999634	80522100	\N	USD	api	2025-11-08 15:17:06.301417+08
55756569-863f-4853-80d9-b7f80f24ec5d	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-13	341.50000000	348.98001099	338.20001221	339.38000488	67838900	\N	USD	api	2025-11-08 15:17:06.302258+08
3bdaf723-dc94-42e1-aff7-6270516e1705	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-14	335.76000977	340.47000122	330.39999390	335.57998657	75000700	\N	USD	api	2025-11-08 15:17:06.302676+08
a8edda8b-9d34-47ad-8828-ff132bdbc6f9	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-15	337.66000366	339.29998779	327.01998901	330.55999756	74319800	\N	USD	api	2025-11-08 15:17:06.30308+08
c0ded01a-37b5-4a76-9d57-00e7a33b4d0a	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-18	329.61999512	336.26998901	329.58999634	335.16000366	56956600	\N	USD	api	2025-11-08 15:17:06.303521+08
1214f78e-228f-40a6-8458-15ff95c7cb7e	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-19	335.79000854	340.54998779	327.85000610	329.30999756	75956000	\N	USD	api	2025-11-08 15:17:06.303947+08
41d315e1-deb1-4133-88f1-724daa8e4767	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-20	329.22000122	331.36999512	314.60000610	323.89999390	77481800	\N	USD	api	2025-11-08 15:17:06.304375+08
19a1f294-0d0b-421f-8b61-6781d51ff6e8	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-21	322.07998657	324.89999390	318.67999268	320.10998535	55744400	\N	USD	api	2025-11-08 15:17:06.304863+08
97c0c4b2-dd6f-4e6c-842f-f9df0b3c8fae	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-22	321.66000366	340.25000000	319.69000244	340.01000977	94016300	\N	USD	api	2025-11-08 15:17:06.305336+08
ec036f52-2d41-45a4-a8d9-a55ef177657b	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-25	338.89999390	349.52999878	335.02999878	346.60000610	86670000	\N	USD	api	2025-11-08 15:17:06.305943+08
437a11d1-3911-4308-be9a-41149f10aa25	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-26	344.92999268	351.89999390	343.72000122	351.67001343	76651600	\N	USD	api	2025-11-08 15:17:06.306464+08
988e9ca5-318a-42f2-8a1a-1f714dfd3411	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-27	351.94000244	355.39001465	349.16000366	349.60000610	65519000	\N	USD	api	2025-11-08 15:17:06.306925+08
c552ddc2-e252-45f5-ba8b-686beb497118	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-28	350.91000366	353.54998779	340.26000977	345.98001099	67903200	\N	USD	api	2025-11-08 15:17:06.307299+08
7c699657-d169-4644-b95a-9d313204f41a	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-08-29	347.23001099	348.75000000	331.70001221	333.86999512	81145700	\N	USD	api	2025-11-08 15:17:06.307729+08
b6f0e472-239d-4816-8ba0-9a70e4cf0e77	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-02	328.23001099	333.32998657	325.60000610	329.35998535	58392000	\N	USD	api	2025-11-08 15:17:06.30934+08
30e71946-cad5-44c1-845d-8695146479ab	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-03	335.20001221	343.32998657	328.51000977	334.08999634	88733300	\N	USD	api	2025-11-08 15:17:06.310828+08
9e6a6d58-34b5-4a9a-adf0-0eb96ec19e8e	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-04	336.14999390	338.89001465	331.48001099	338.52999878	60711000	\N	USD	api	2025-11-08 15:17:06.311382+08
8d014d4b-3927-4924-beb3-71eb093e08d6	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-05	348.00000000	355.86999512	344.67999268	350.83999634	108989800	\N	USD	api	2025-11-08 15:17:06.311915+08
ae64364c-fe84-4f3c-9412-8bef67d16f80	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-08	354.64001465	358.44000244	344.83999634	346.39999390	75208300	\N	USD	api	2025-11-08 15:17:06.312646+08
b7920dbb-ea7e-4357-b49b-0636d6b70938	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-09	348.44000244	350.76998901	343.82000732	346.97000122	53816000	\N	USD	api	2025-11-08 15:17:06.313386+08
4729e348-5851-40db-8f9e-592da4608ea1	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-10	350.54998779	356.32998657	346.07000732	347.79000854	72121700	\N	USD	api	2025-11-08 15:17:06.314205+08
81d316eb-07e9-4931-b373-59ebe478b180	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-11	350.17001343	368.98999023	347.60000610	368.80999756	103756000	\N	USD	api	2025-11-08 15:17:06.314875+08
1cdc4f73-e540-48d4-bee0-97ff94c864c0	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-12	370.94000244	396.69000244	370.23999023	395.94000244	168156400	\N	USD	api	2025-11-08 15:17:06.315321+08
e18c52ef-d404-424a-bb57-bf4df114904c	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-15	423.13000488	425.70001221	402.42999268	410.04000854	163823700	\N	USD	api	2025-11-08 15:17:06.315701+08
f1a1f604-002c-4a20-8e63-3742f47cdbf1	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-16	414.50000000	423.25000000	411.42999268	421.61999512	104285700	\N	USD	api	2025-11-08 15:17:06.316017+08
88662f85-fc86-419c-8112-81f91ab4e04a	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-17	415.75000000	428.30999756	409.67001343	425.85998535	106133500	\N	USD	api	2025-11-08 15:17:06.316372+08
0ab8989a-7842-4ef1-a629-52712088736f	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-18	428.86999512	432.22000122	416.55999756	416.85000610	90454500	\N	USD	api	2025-11-08 15:17:06.316812+08
a31ca49b-478b-4af9-adc6-2be13e2dc103	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-19	421.82000732	429.47000122	421.72000122	426.07000732	93131000	\N	USD	api	2025-11-08 15:17:06.317261+08
401406b8-b780-4355-9879-c6c3aa29d15a	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-22	431.10998535	444.98001099	429.13000488	434.20999146	97108800	\N	USD	api	2025-11-08 15:17:06.317757+08
d284b755-89c8-4c8d-9427-b1584f8803ad	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-23	439.88000488	440.97000122	423.72000122	425.85000610	83422700	\N	USD	api	2025-11-08 15:17:06.318183+08
cc1607b6-ecdc-4fc1-af59-5f280dc7a6ac	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-24	429.82998657	444.20999146	429.02999878	442.79000854	93133600	\N	USD	api	2025-11-08 15:17:06.318603+08
b41eb06b-e895-4efa-9368-2f1e488ef415	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-25	435.23999023	435.35000610	419.07998657	423.39001465	96746400	\N	USD	api	2025-11-08 15:17:06.319021+08
e5465de1-87b4-461e-b381-e97403e80eb1	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-26	428.29998779	440.47000122	421.01998901	440.39999390	101628200	\N	USD	api	2025-11-08 15:17:06.319675+08
179b1e46-3472-453d-b579-c07bea1cb98b	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-29	444.35000610	450.98001099	439.50000000	443.20999146	79491500	\N	USD	api	2025-11-08 15:17:06.320119+08
24baa95f-954c-4d44-ad75-adce929c2bf1	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-09-30	441.51998901	445.00000000	433.11999512	444.72000122	74358000	\N	USD	api	2025-11-08 15:17:06.320398+08
4ad06612-7753-4424-ac90-f8addefc0032	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-01	443.79998779	462.29000854	440.75000000	459.45999146	98122300	\N	USD	api	2025-11-08 15:17:06.320677+08
e9e154ba-9107-4999-b390-4c8e3f654300	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-02	470.54000854	470.75000000	435.57000732	436.00000000	137009000	\N	USD	api	2025-11-08 15:17:06.321+08
d434220f-5158-4969-a664-5142abbbd10f	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-03	443.29000854	446.76998901	416.57998657	429.82998657	133188200	\N	USD	api	2025-11-08 15:17:06.321577+08
39bdd1f5-d6bb-4fb8-ae70-f8352bd0e420	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-06	440.75000000	453.54998779	436.69000244	453.25000000	85324900	\N	USD	api	2025-11-08 15:17:06.321998+08
31249503-ddba-4350-849e-475d3ca9af94	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-07	447.82000732	452.67999268	432.45001221	433.08999634	102296100	\N	USD	api	2025-11-08 15:17:06.322413+08
83acdfcd-d447-4819-986d-86d663e5defa	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-08	437.57000732	441.32998657	425.23001099	438.69000244	71192100	\N	USD	api	2025-11-08 15:17:06.322847+08
aef2f5ca-f2b9-407d-9681-c99a301d08bf	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-09	431.80999756	436.35000610	426.17999268	435.54000854	69339900	\N	USD	api	2025-11-08 15:17:06.323259+08
e4229efc-bf5a-4447-bbee-07f3aad2fa7a	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-10	436.54000854	443.13000488	411.45001221	413.48999023	112107900	\N	USD	api	2025-11-08 15:17:06.32367+08
12e77eef-1c48-4766-b726-75a7f862dc06	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-13	423.52999878	436.89001465	419.70001221	435.89999390	79552800	\N	USD	api	2025-11-08 15:17:06.323992+08
0b74c462-d32f-4c24-bac9-9d714e1af20f	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-14	426.79000854	434.20001221	417.85998535	429.23999023	72669400	\N	USD	api	2025-11-08 15:17:06.324345+08
91355fca-61c5-42fa-b707-0ab3e2c6868f	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-15	434.89999390	440.51000977	426.32998657	435.14999390	71558200	\N	USD	api	2025-11-08 15:17:06.324751+08
e90194a4-87f0-445c-8fef-68a9bbb10b47	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-16	434.73001099	439.35000610	421.30999756	428.75000000	77189900	\N	USD	api	2025-11-08 15:17:06.325145+08
991bfcc7-6ebc-43a6-9ac7-86bddc642ca7	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-17	425.50000000	441.45999146	423.60000610	439.30999756	89331600	\N	USD	api	2025-11-08 15:17:06.325613+08
79446220-4f20-49eb-8b84-7df35e1b6fb8	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-20	443.86999512	449.79998779	440.60998535	447.42999268	63719000	\N	USD	api	2025-11-08 15:17:06.326094+08
076c82eb-5e70-4226-a42e-6dea90865394	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-21	445.76000977	449.29998779	442.04998779	442.60000610	54412200	\N	USD	api	2025-11-08 15:17:06.326559+08
bf28e270-ed64-4e7e-aff1-b4f7b2782961	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-22	443.45001221	445.54000854	429.00000000	438.97000122	84023500	\N	USD	api	2025-11-08 15:17:06.327026+08
aa41f39a-c350-4a14-9a0a-730fe9bd608e	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-23	420.00000000	449.39999390	413.89999390	448.98001099	126709800	\N	USD	api	2025-11-08 15:17:06.32758+08
fe43f528-3096-40cd-b31b-d4df7333099b	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-24	446.82998657	451.67999268	430.17001343	433.72000122	94727800	\N	USD	api	2025-11-08 15:17:06.328051+08
5d355e5c-d64e-4809-83d6-09f3c95007d9	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-27	439.98001099	460.16000366	438.69000244	452.42001343	105867500	\N	USD	api	2025-11-08 15:17:06.32892+08
5699a9dc-edd4-49eb-947e-50857e0312f1	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-28	454.77999878	467.00000000	451.60000610	460.54998779	80185700	\N	USD	api	2025-11-08 15:17:06.329727+08
44cb2e3d-fc8c-4590-bc30-a2b58eeb4f09	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-29	462.50000000	465.70001221	452.64999390	461.51000977	67983500	\N	USD	api	2025-11-08 15:17:06.330136+08
58dd5982-460f-42d3-a19b-dca9ea04a838	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-30	451.04998779	455.05999756	439.60998535	440.10000610	72447900	\N	USD	api	2025-11-08 15:17:06.33061+08
b6964f74-be01-44c4-a993-b0b0293a5b72	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-10-31	446.75000000	458.00000000	443.69000244	456.55999756	83135800	\N	USD	api	2025-11-08 15:17:06.331053+08
a637151b-b1b0-47da-9257-38140b2684ac	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-11-03	455.98999023	474.07000732	453.79998779	468.36999512	84595200	\N	USD	api	2025-11-08 15:17:06.331427+08
7692d09f-9f17-49ae-b45a-abf094587b5b	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-11-04	454.45999146	460.22000122	443.60000610	444.26000977	87756600	\N	USD	api	2025-11-08 15:17:06.331747+08
50c5e657-dbfe-4fbb-9321-1ca7bf99d1c3	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-11-05	452.04998779	466.32998657	440.70999146	462.07000732	85573000	\N	USD	api	2025-11-08 15:17:06.3321+08
62df9f6b-5b7f-44b8-bc58-ea8e7fa3b23c	0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	2025-11-06	461.95999146	467.45001221	435.08999634	445.91000366	109622900	\N	USD	api	2025-11-08 15:17:06.332559+08
36bc8217-7ae1-4741-8615-6d7a4a6a79bb	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-09-16	11.65999985	11.71000004	11.60999966	11.64000034	70804849	\N	CNY	api	2025-11-07 23:30:10.488105+08
21897591-c992-4932-b163-4b3a4631b61e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-10-28	11.52999973	11.57999992	11.42000008	11.47000027	82156818	\N	CNY	api	2025-11-07 23:30:10.495744+08
56c2f397-5a9f-4222-aefe-c52b982539c5	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-11-05	11.59000015	11.60000038	11.50000000	11.52000046	79492605	\N	CNY	api	2025-11-08 20:55:04.973837+08
0fd58c42-3e3c-4ff5-8af5-146217628a3a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-11-06	11.50000000	11.57999992	11.47000027	11.51000023	76658546	\N	CNY	api	2025-11-08 20:55:04.974388+08
8418593d-2c38-4bf6-92ea-9e21ecfda68d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-09-02	6.80000019	6.88999987	6.67999983	6.71999979	206024978	\N	CNY	api	2025-11-07 23:30:10.769025+08
8c37f9d6-89ce-45d2-a03f-7c2cfc3f64e8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-22	6.36000013	6.44000006	6.34999990	6.38000011	78030249	\N	CNY	api	2025-11-07 23:30:10.780464+08
6f2585a5-ae04-456e-8868-03967318c8a0	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-11	11.63000011	11.68000031	11.47000027	11.60000038	148695164	\N	CNY	api	2025-11-09 07:07:11.002551+08
de49b8b5-d284-406d-94c8-4f15d5ac64e3	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-12	11.57999992	11.84000015	11.51000023	11.53999996	171766255	\N	CNY	api	2025-11-09 07:07:11.017762+08
e99bd0e8-0dfe-4ba6-a0c7-b733f80759b1	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-13	11.50000000	11.69999981	11.47999954	11.60999966	108626328	\N	CNY	api	2025-11-09 07:07:11.0195+08
07611585-2c64-40c6-b5fa-72ff73ae91e9	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-14	11.59000015	11.69999981	11.52999973	11.53999996	115978311	\N	CNY	api	2025-11-09 07:07:11.020874+08
f5a5f09f-039a-4597-b3d9-eee6dde0b2a6	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-15	11.50000000	11.60999966	11.42000008	11.43999958	121578351	\N	CNY	api	2025-11-09 07:07:11.022122+08
37765ada-e0cc-4a59-ba87-409a9b4404ed	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-18	11.63000011	12.03999996	11.61999989	11.75000000	379732445	\N	CNY	api	2025-11-09 07:07:11.023327+08
493c1195-6d07-4686-98c7-94cde67b19c0	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-19	11.75000000	11.96000004	11.55000019	11.68000031	243003665	\N	CNY	api	2025-11-09 07:07:11.024533+08
41717872-6fa1-4c7e-a53d-d514c73804ee	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-20	11.67000008	11.75000000	11.60999966	11.64000034	128657248	\N	CNY	api	2025-11-09 07:07:11.025352+08
db5b2f3a-3796-46af-bd1a-68bbb9c0948e	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-21	11.61999989	11.64999962	11.56000042	11.59000015	88340806	\N	CNY	api	2025-11-09 07:07:11.026165+08
5eab7478-d7d8-400c-a281-000b44f07d7a	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-22	11.59000015	11.60999966	11.27999973	11.27999973	162531744	\N	CNY	api	2025-11-09 07:07:11.02705+08
b1dc3e78-6bfa-4325-af88-c7202b445ac2	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-25	11.27999973	11.34000015	11.14000034	11.18000031	116602032	\N	CNY	api	2025-11-09 07:07:11.02789+08
53c5a8bd-8365-4e4f-aff0-c0c703563564	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-26	11.18000031	11.31000042	11.14000034	11.27000046	83107820	\N	CNY	api	2025-11-09 07:07:11.028658+08
2a341984-2b99-42a2-8b4e-011c21f0e263	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-27	11.23999977	11.39000034	11.14999962	11.39000034	89517805	\N	CNY	api	2025-11-09 07:07:11.029433+08
39acc871-d5dd-47a6-be90-11e7b1af12ab	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-28	11.39000034	11.42000008	11.31999969	11.34000015	73316854	\N	CNY	api	2025-11-09 07:07:11.030532+08
8aecd4a2-89d3-4ada-b1ea-96ad64ed2ed7	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-11-29	11.36999989	11.46000004	11.34000015	11.38000011	102848758	\N	CNY	api	2025-11-09 07:07:11.031523+08
990b1001-cd4d-4198-b5e4-3ae4e30d6e0b	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-02	11.39000034	11.39999962	11.31000042	11.39000034	97543366	\N	CNY	api	2025-11-09 07:07:11.032616+08
78f921d5-0fdd-46d7-ae79-aaa07932e5c5	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-03	11.36999989	11.50000000	11.35000038	11.48999977	108255936	\N	CNY	api	2025-11-09 07:07:11.033681+08
44791aef-742b-4b1f-91ad-55871f36ae71	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-04	11.43999958	11.52999973	11.36999989	11.46000004	100747059	\N	CNY	api	2025-11-09 07:07:11.034683+08
a346089b-3bcd-411d-bc4c-b3e162e9ea7c	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-05	11.43999958	11.47999954	11.40999985	11.43999958	68710883	\N	CNY	api	2025-11-09 07:07:11.035716+08
c064d1bf-ef8b-4226-8464-73eff1d76f69	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-06	11.43999958	11.69999981	11.43000031	11.65999985	172626927	\N	CNY	api	2025-11-09 07:07:11.036775+08
ac55a350-7c29-48ca-b19d-8202ef96e4d4	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-09	11.63000011	11.72000027	11.59000015	11.67000008	96406316	\N	CNY	api	2025-11-09 07:07:11.03776+08
77e61307-99be-4608-bf98-8c7ecf676ab9	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-10	11.89999962	11.94999981	11.75000000	11.78999996	216780724	\N	CNY	api	2025-11-09 07:07:11.038602+08
799d35a6-69c7-46c1-a51b-b77bcadf3e12	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-11	11.78999996	11.82999992	11.72000027	11.72999954	96769145	\N	CNY	api	2025-11-09 07:07:11.039473+08
eb3a95df-1762-4863-95d9-9403506030fe	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-12	11.72999954	11.86999989	11.71000004	11.85000038	98623459	\N	CNY	api	2025-11-09 07:07:11.040442+08
0a8387f7-a14a-4801-8677-e3ab65440d9d	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-13	11.78999996	11.80000019	11.56000042	11.56000042	134379289	\N	CNY	api	2025-11-09 07:07:11.041287+08
828c0344-ef1d-489b-aee5-31ab177367a1	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-16	11.56000042	11.65999985	11.52999973	11.56999969	80571778	\N	CNY	api	2025-11-09 07:07:11.042157+08
ab559195-d3df-4bd0-9f23-9e4d60d42465	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-17	11.56999969	11.64999962	11.52000046	11.52999973	80211995	\N	CNY	api	2025-11-09 07:07:11.042935+08
4415e520-b81b-45e6-88d7-028f0acd8aa0	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-18	11.57999992	11.73999977	11.56999969	11.64999962	101658966	\N	CNY	api	2025-11-09 07:07:11.043686+08
1b037629-7a5f-4fef-b63e-94abd58b1397	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-19	11.59000015	11.64000034	11.53999996	11.59000015	69737904	\N	CNY	api	2025-11-09 07:07:11.044181+08
85035b0b-ab14-4af7-85f8-b0b024be970c	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-20	11.59000015	11.69999981	11.57999992	11.61999989	71464627	\N	CNY	api	2025-11-09 07:07:11.044749+08
e63bc9c9-8df6-4c06-99d4-220b2a34c953	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-23	11.64000034	11.84000015	11.64000034	11.72999954	165940476	\N	CNY	api	2025-11-09 07:07:11.04596+08
8c456f9d-1f0c-48a6-991b-0ebbf9393b1a	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-24	11.72000027	11.86999989	11.72000027	11.85999966	135083691	\N	CNY	api	2025-11-09 07:07:11.046823+08
ee7e1dc5-5fb9-4a3d-8745-aa8c2ea32086	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-25	11.85999966	12.02000046	11.84000015	11.92000008	147528294	\N	CNY	api	2025-11-09 07:07:11.047929+08
94e25bf2-f751-4bc6-b5d3-bfb25eaec6cd	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-26	11.92000008	11.93000031	11.77999973	11.85999966	100007470	\N	CNY	api	2025-11-09 07:07:11.049162+08
94f02d32-ed4a-41aa-8eec-054aead2c1bb	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-27	11.86999989	11.89999962	11.65999985	11.82999992	129001228	\N	CNY	api	2025-11-09 07:07:11.04997+08
4e073494-d397-4101-864d-ef1b8d510e1d	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-30	11.77999973	11.97000027	11.77999973	11.94999981	135184636	\N	CNY	api	2025-11-09 07:07:11.050955+08
226ab18f-19f0-43db-b337-7e6414b1c073	2aa3f894-681b-4a75-9003-ab376a35df7e	2024-12-31	11.93000031	11.98999977	11.69999981	11.69999981	147536733	\N	CNY	api	2025-11-09 07:07:11.051709+08
3d07435b-0a45-4c65-b49b-c8c58a10604e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-02	11.72999954	11.77000046	11.39000034	11.43000031	181959699	\N	CNY	api	2025-11-09 07:07:11.053035+08
f6dd39ad-b3ec-474d-a0e0-3262acb44908	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-03	11.43999958	11.53999996	11.35999966	11.38000011	115468044	\N	CNY	api	2025-11-09 07:07:11.053943+08
a9d55cf0-2bee-40d1-9056-346938dea823	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-06	11.38000011	11.47999954	11.22000027	11.43999958	108553630	\N	CNY	api	2025-11-09 07:07:11.054871+08
222138be-5864-453b-a6a4-b563acb1b7ce	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-07	11.42000008	11.52999973	11.36999989	11.51000023	74786288	\N	CNY	api	2025-11-09 07:07:11.056076+08
2add62cc-da73-4cd5-a287-ef24ae37b4b2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-08	11.50000000	11.63000011	11.39999962	11.50000000	106238601	\N	CNY	api	2025-11-09 07:07:11.057172+08
f4eb74b5-78c9-4b96-805c-7795e065ab86	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-09	11.50000000	11.50000000	11.35000038	11.39999962	75148330	\N	CNY	api	2025-11-09 07:07:11.057935+08
742e83a5-623e-4579-8f78-e4c16349d05e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-10	11.39999962	11.46000004	11.27999973	11.30000019	79813351	\N	CNY	api	2025-11-09 07:07:11.059095+08
cb5446b2-1fc7-4f8c-b649-138b26971155	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-13	11.25000000	11.26000023	11.07999992	11.19999981	93496618	\N	CNY	api	2025-11-09 07:07:11.060696+08
e6861827-5c31-4177-99e9-3077ab391ec5	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-14	11.19999981	11.39999962	11.18999958	11.38000011	82462895	\N	CNY	api	2025-11-09 07:07:11.061835+08
846694d2-2ec2-4351-813f-8198961c9b16	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-15	11.38000011	11.57999992	11.35999966	11.47999954	103163082	\N	CNY	api	2025-11-09 07:07:11.063039+08
74ff9f2f-ba06-4d28-b6fe-12e21e0048e6	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-16	11.56000042	11.59000015	11.50000000	11.56999969	87296399	\N	CNY	api	2025-11-09 07:07:11.064291+08
8f4b9b79-9ffa-4603-aa9d-7b3f0ca4e943	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-17	11.52999973	11.55000019	11.42000008	11.44999981	68976486	\N	CNY	api	2025-11-09 07:07:11.065418+08
20703ac7-8d66-4474-a9cf-ee1ecceecbab	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-11-05	6.19999981	6.23999977	6.15999985	6.21999979	69200728	\N	CNY	api	2025-11-08 20:55:05.495886+08
f728d922-45e7-4c13-b963-cc202bf535aa	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-11-06	6.19999981	6.21999979	6.17000008	6.17999983	88921853	\N	CNY	api	2025-11-08 20:55:05.496673+08
3b050872-626d-4112-92bc-3e859bf35afe	a7569e62-8eec-4468-8798-d1e948ef4679	2025-09-02	41.86000061	43.50000000	41.86000061	43.43999863	145214114	\N	CNY	api	2025-11-07 23:30:11.141896+08
960b102b-73cf-4e72-bb45-adae6982f72a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-17	41.88000107	42.22000122	41.38000107	41.59000015	82982705	\N	CNY	api	2025-11-07 23:30:11.151388+08
d90338f5-06a8-418f-907f-3fe80fd24049	a7569e62-8eec-4468-8798-d1e948ef4679	2025-10-29	41.52999878	41.52999878	40.68999863	40.77000046	91098760	\N	CNY	api	2025-11-07 23:30:11.153448+08
b4eed8fb-b0aa-46d9-9211-55fa783bd892	a7569e62-8eec-4468-8798-d1e948ef4679	2025-11-05	43.09999847	43.47000122	42.75000000	42.79999924	73171377	\N	CNY	api	2025-11-08 20:55:06.017032+08
0a5aeca3-4ae2-489c-aa17-f62900f89c31	a7569e62-8eec-4468-8798-d1e948ef4679	2025-11-06	42.65000153	42.88999939	42.31000137	42.34000015	87197274	\N	CNY	api	2025-11-08 20:55:06.017472+08
0b823c42-6d62-416b-adff-ecdcd1959269	49589118-facc-4785-abf3-3d2d4d054f17	2025-09-08	1483.00000000	1506.43994141	1477.50000000	1501.22998047	5138298	\N	CNY	api	2025-11-07 23:30:11.553758+08
c376b0d0-3c5b-4d9b-a8a6-3ce2f046d2a2	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-15	1450.97998047	1463.00000000	1445.07995605	1462.00000000	4278540	\N	CNY	api	2025-11-07 23:30:11.561783+08
8e209201-563a-4b16-89d4-8854d6703ca1	49589118-facc-4785-abf3-3d2d4d054f17	2025-10-20	1455.00000000	1469.50000000	1454.88000488	1457.93005371	2594988	\N	CNY	api	2025-11-07 23:30:11.563206+08
25445833-7b25-4484-b961-a8874e4a2dbb	49589118-facc-4785-abf3-3d2d4d054f17	2025-11-06	1430.00000000	1441.44995117	1429.98999023	1435.13000488	3834782	\N	CNY	api	2025-11-08 20:55:06.541667+08
44c607e0-e2af-4de6-95c7-bef4aa3728f5	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-20	11.50000000	11.52000046	11.39999962	11.42000008	83202913	\N	CNY	api	2025-11-09 07:07:11.066502+08
7c615c6f-1d9e-47be-9159-ae8a6739c941	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-21	11.44999981	11.44999981	11.31999969	11.32999992	90206894	\N	CNY	api	2025-11-09 07:07:11.067955+08
27955f05-1894-4ff5-a482-04a8153cf580	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-22	11.31999969	11.32999992	11.07999992	11.09000015	134712922	\N	CNY	api	2025-11-09 07:07:11.068903+08
823cbe99-2bd0-4132-8a07-dcd2fff3f722	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-23	11.17000008	11.39999962	11.17000008	11.31999969	151492027	\N	CNY	api	2025-11-09 07:07:11.069913+08
dd96c4a6-ff24-4d8b-9024-7667227902e0	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-24	11.31999969	11.39000034	11.22000027	11.34000015	94494421	\N	CNY	api	2025-11-09 07:07:11.071153+08
abb37b6f-553a-4db4-bc6c-c8ba0c22d71c	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-01-27	11.38000011	11.55000019	11.38000011	11.47000027	115193471	\N	CNY	api	2025-11-09 07:07:11.071936+08
1576a1b3-660c-4dc9-adb7-338df4f85d67	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-05	11.50000000	11.52000046	11.32999992	11.36999989	84343370	\N	CNY	api	2025-11-09 07:07:11.072713+08
7c618b25-470a-416b-81dc-887a67a8c497	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-06	11.35000038	11.44999981	11.30000019	11.35999966	95560325	\N	CNY	api	2025-11-09 07:07:11.073203+08
cb6cf824-c702-4589-a1aa-9e27199d9d74	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-07	11.35999966	11.44999981	11.31000042	11.38000011	140749262	\N	CNY	api	2025-11-09 07:07:11.073651+08
48c81c25-6955-475f-8176-7c332e02e3c8	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-10	11.38000011	11.50000000	11.35999966	11.43000031	102659093	\N	CNY	api	2025-11-09 07:07:11.07436+08
bda0f220-646e-4636-ad94-90181f68cb44	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-11	11.39999962	11.47000027	11.36999989	11.42000008	84452003	\N	CNY	api	2025-11-09 07:07:11.075282+08
95d6b6b6-ca36-499e-9fc5-9408919082f2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-12	11.40999985	11.43000031	11.34000015	11.42000008	98880683	\N	CNY	api	2025-11-09 07:07:11.076467+08
7be8950d-e733-442d-accb-abf96f0a66fd	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-13	11.42000008	11.55000019	11.39999962	11.50000000	135863927	\N	CNY	api	2025-11-09 07:07:11.077692+08
50538ca0-b934-4a37-a665-5ac07b37ac9a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-14	11.48999977	11.55000019	11.43000031	11.55000019	97305774	\N	CNY	api	2025-11-09 07:07:11.079254+08
98c8ea8f-9e6b-4c24-8dd3-3983fe303f07	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-17	11.60000038	11.80000019	11.55000019	11.77999973	206196542	\N	CNY	api	2025-11-09 07:07:11.079884+08
dafe3259-1ff3-40c0-8402-305e78892d66	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-18	11.76000023	11.96000004	11.76000023	11.81000042	199661049	\N	CNY	api	2025-11-09 07:07:11.080641+08
44155160-65c1-4bf5-9b3a-92e29b9b226e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-19	11.80000019	11.81000042	11.68000031	11.71000004	117774895	\N	CNY	api	2025-11-09 07:07:11.08137+08
052f1d3d-253f-476f-a725-808728c2582b	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-20	11.71000004	11.76000023	11.64999962	11.65999985	78439627	\N	CNY	api	2025-11-09 07:07:11.082098+08
5d7f9f53-e28c-441f-9f6f-c80bb916247f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-21	11.68999958	11.71000004	11.55000019	11.64000034	97396897	\N	CNY	api	2025-11-09 07:07:11.082912+08
c0945815-5636-431f-b058-2312f09925e0	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-24	11.63000011	11.68999958	11.56000042	11.59000015	94995617	\N	CNY	api	2025-11-09 07:07:11.083647+08
cd934d2c-4d86-440d-ac67-175c6a76b025	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-25	11.56000042	11.57999992	11.46000004	11.47000027	91715602	\N	CNY	api	2025-11-09 07:07:11.084901+08
765bb870-5733-4519-81ae-6b5ce510c31e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-26	11.47000027	11.60000038	11.47000027	11.52000046	84164552	\N	CNY	api	2025-11-09 07:07:11.085709+08
d6c6df29-5496-4b1d-8ef8-678819e028e2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-27	11.52999973	11.63000011	11.46000004	11.61999989	97730975	\N	CNY	api	2025-11-09 07:07:11.086511+08
0c568b97-6e7b-4721-a179-5b232a92de57	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-02-28	11.57999992	11.68000031	11.50000000	11.52999973	94908806	\N	CNY	api	2025-11-09 07:07:11.087351+08
c3879602-659b-4f7d-820f-55156629058c	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-03	11.52000046	11.56000042	11.44999981	11.51000023	83045695	\N	CNY	api	2025-11-09 07:07:11.088079+08
765d7e38-73b9-42e9-9261-e7bbc93564f6	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-04	11.47000027	11.55000019	11.43999958	11.51000023	68317873	\N	CNY	api	2025-11-09 07:07:11.088768+08
dcdc7180-f38d-4a95-a8fe-e0c1dbe71d38	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-05	11.52000046	11.67000008	11.47999954	11.65999985	108064544	\N	CNY	api	2025-11-09 07:07:11.089595+08
dbfefd89-be7e-4994-9c64-02b24a7e1e70	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-06	11.68999958	11.69999981	11.60000038	11.63000011	87740771	\N	CNY	api	2025-11-09 07:07:11.090973+08
03f2d855-89d8-4258-8b77-3c68bf7f1327	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-07	11.63000011	11.68999958	11.60000038	11.67000008	83553669	\N	CNY	api	2025-11-09 07:07:11.091931+08
7e0ae9f9-0520-48ab-851e-245a57f5388e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-10	11.65999985	11.67000008	11.55000019	11.59000015	66383393	\N	CNY	api	2025-11-09 07:07:11.092694+08
730710da-f5c5-469f-ba46-a7d4570b3b7c	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-11	11.53999996	11.60999966	11.52000046	11.60999966	60897527	\N	CNY	api	2025-11-09 07:07:11.093417+08
86ef6523-6619-4ec0-9f21-0be9838c8ebb	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-12	11.60000038	11.86999989	11.56000042	11.85000038	187731840	\N	CNY	api	2025-11-09 07:07:11.09432+08
14963ae8-af5c-4b04-904e-5de31e19feaf	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-13	11.81000042	11.90999985	11.77999973	11.84000015	131237121	\N	CNY	api	2025-11-09 07:07:11.095514+08
f79e280f-4101-4d60-969b-0008781855d7	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-14	11.81999969	12.00000000	11.81999969	11.97000027	172241765	\N	CNY	api	2025-11-09 07:07:11.097645+08
a9f0e805-8887-4887-8c1c-d38a88c4b06f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-17	11.63000011	11.67000008	11.46000004	11.50000000	460361210	\N	CNY	api	2025-11-09 07:07:11.098654+08
4ffa628e-1a77-423b-910a-115bb9008bad	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-18	11.52000046	11.53999996	11.47999954	11.48999977	160529000	\N	CNY	api	2025-11-09 07:07:11.09948+08
ea86d5c1-dd79-4f9d-a8bb-cfa48a921a85	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-19	11.47999954	11.52999973	11.46000004	11.52000046	136245491	\N	CNY	api	2025-11-09 07:07:11.100105+08
78fbfd43-966b-4642-a1e5-66e357a73d63	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-20	11.51000023	11.60999966	11.48999977	11.48999977	110115724	\N	CNY	api	2025-11-09 07:07:11.100993+08
9ae06ca6-b3d4-4030-8593-4388eda06e6f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-21	11.48999977	11.52000046	11.39000034	11.42000008	137638897	\N	CNY	api	2025-11-09 07:07:11.10205+08
57702b9a-a877-411a-ae7b-1af72762fae1	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-24	11.40999985	11.43999958	11.34000015	11.38000011	116457734	\N	CNY	api	2025-11-09 07:07:11.102937+08
0e160747-68c0-4d93-a32c-f0c09c9da860	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-25	11.38000011	11.43000031	11.35999966	11.43000031	73560888	\N	CNY	api	2025-11-09 07:07:11.104081+08
2d071afa-31d9-473d-b87d-16021b800021	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-26	11.42000008	11.43000031	11.36999989	11.38000011	74086307	\N	CNY	api	2025-11-09 07:07:11.10473+08
709ba18d-341e-49bc-b874-610f237e50c7	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-27	11.36999989	11.40999985	11.35000038	11.39000034	55334940	\N	CNY	api	2025-11-09 07:07:11.105172+08
b43fcae9-edb5-468e-8ed3-58c751da437c	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-28	11.39000034	11.39999962	11.34000015	11.35000038	64494555	\N	CNY	api	2025-11-09 07:07:11.105606+08
ea064c52-9e4e-4ba7-bd13-a3977c5417c7	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-03-31	11.35999966	11.38000011	11.26000023	11.26000023	111612564	\N	CNY	api	2025-11-09 07:07:11.106067+08
7dffdcda-554c-428b-8654-6d8e08a17719	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-01	11.27000046	11.30000019	11.22000027	11.27000046	68147042	\N	CNY	api	2025-11-09 07:07:11.106737+08
e125d3eb-87df-4816-8847-fdc5ce893c88	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-02	11.25000000	11.40999985	11.25000000	11.36999989	93264176	\N	CNY	api	2025-11-09 07:07:11.10749+08
7ea31781-66b9-4b8c-9046-3092627d9494	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-03	11.31000042	11.39000034	11.30000019	11.34000015	64391391	\N	CNY	api	2025-11-09 07:07:11.108218+08
83fb0d30-42dc-4595-9b3a-f07fbcd2d40a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-07	11.00000000	11.05000019	10.47999954	10.69999981	254556048	\N	CNY	api	2025-11-09 07:07:11.109383+08
f1790569-17c5-4d2e-a6e2-dcb1e249bd47	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-08	10.68000031	10.85000038	10.65999985	10.81999969	146398771	\N	CNY	api	2025-11-09 07:07:11.110361+08
da86fb8a-49d3-4cf3-9535-446fcaf8f823	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-09	10.72999954	10.82999992	10.65999985	10.80000019	106439405	\N	CNY	api	2025-11-09 07:07:11.111156+08
8097388c-e34c-4647-a791-8486ef4bcbe8	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-10	10.85999966	10.93000031	10.81999969	10.89999962	86654805	\N	CNY	api	2025-11-09 07:07:11.111864+08
afa7f0a7-9bf6-4c91-bbb7-849594a4c0d3	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-11	10.86999989	10.89999962	10.82999992	10.89000034	58387902	\N	CNY	api	2025-11-09 07:07:11.112544+08
a84ad91b-b87c-4376-b963-c7915d00dedf	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-14	10.94999981	11.03999996	10.92000008	10.93000031	78599345	\N	CNY	api	2025-11-09 07:07:11.113302+08
feaf9f07-717c-4fe5-b02a-00eda28ecca3	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-15	10.92000008	10.97000027	10.89999962	10.94999981	72275410	\N	CNY	api	2025-11-09 07:07:11.113977+08
ef78414e-4789-43af-b05c-88190038d83a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-16	10.93000031	11.01000023	10.90999985	11.00000000	84282217	\N	CNY	api	2025-11-09 07:07:11.114949+08
b6e4458f-bc8f-4da2-8607-57e54c2d5c3f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-17	10.94999981	11.07999992	10.93000031	11.06000042	82391931	\N	CNY	api	2025-11-09 07:07:11.115781+08
aff5c55e-e0d2-4522-8c91-bdc0565ea513	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-18	11.03999996	11.18999958	11.02999973	11.18000031	72709815	\N	CNY	api	2025-11-09 07:07:11.116414+08
1ba902c6-ce60-4d42-8d80-20bedc334295	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-21	11.00000000	11.13000011	10.97000027	11.02000046	111418418	\N	CNY	api	2025-11-09 07:07:11.117114+08
00160baf-513e-4806-906a-32b292b7432f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-22	11.02000046	11.06000042	10.97999954	11.03999996	83112887	\N	CNY	api	2025-11-09 07:07:11.118024+08
1bdca877-99d9-4fb9-9184-5ea2a1114721	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-23	11.03999996	11.05000019	10.97000027	11.01000023	58638293	\N	CNY	api	2025-11-09 07:07:11.119405+08
6a24e79f-f4f6-4f7e-ac79-57c54baeb087	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-24	11.00000000	11.06000042	10.98999977	11.02999973	68925613	\N	CNY	api	2025-11-09 07:07:11.120338+08
8d85a431-0a60-4b3e-b85f-2eb31a63b1c0	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-25	11.03999996	11.05000019	10.98999977	11.01000023	63754686	\N	CNY	api	2025-11-09 07:07:11.121316+08
f37b21f5-4539-4a1e-afc2-787782768361	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-28	11.00000000	11.03999996	10.96000004	11.00000000	64201837	\N	CNY	api	2025-11-09 07:07:11.122496+08
df3948e5-cec0-4ec1-a172-bbe7ac424872	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-29	11.00000000	11.02000046	10.94999981	10.97999954	64904494	\N	CNY	api	2025-11-09 07:07:11.123371+08
41201691-6daa-4c6e-aef0-b6a44ee693b2	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-04-30	10.96000004	10.97000027	10.89000034	10.90999985	86983492	\N	CNY	api	2025-11-09 07:07:11.124724+08
9453f0e0-0310-4ec3-92dc-c8b4f24fb451	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-06	10.92000008	11.00000000	10.89000034	10.96000004	85467127	\N	CNY	api	2025-11-09 07:07:11.125676+08
f291ba8c-f851-45cd-8d40-7d452b4e6528	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-07	11.01000023	11.03999996	10.97000027	11.02999973	112627001	\N	CNY	api	2025-11-09 07:07:11.126608+08
c1c9c70d-3035-4ea1-9a07-29935521af76	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-08	11.00000000	11.07999992	10.98999977	11.07999992	105661366	\N	CNY	api	2025-11-09 07:07:11.127362+08
c7d45aeb-ce1f-4d97-970f-67b944450a39	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-09	11.06999969	11.17000008	11.06000042	11.14999962	99989747	\N	CNY	api	2025-11-09 07:07:11.128275+08
0ae0c8bf-f7ca-482c-bfee-72f1750c7b89	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-12	11.15999985	11.22000027	11.13000011	11.15999985	89560460	\N	CNY	api	2025-11-09 07:07:11.129384+08
c1b82594-925b-4d15-8e66-96db38575815	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-13	11.18999958	11.32999992	11.14999962	11.28999996	126103062	\N	CNY	api	2025-11-09 07:07:11.130153+08
391a04a7-bcc9-47e9-80c2-3efe6af8ff31	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-14	11.28999996	11.47000027	11.25000000	11.43000031	168351358	\N	CNY	api	2025-11-09 07:07:11.130897+08
64c77834-8dba-4f43-bf55-56753b5b8039	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-15	11.43000031	11.50000000	11.38000011	11.39000034	103546026	\N	CNY	api	2025-11-09 07:07:11.131716+08
2deb84f2-a2e8-40c8-affc-bad65e9afb9e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-16	11.36999989	11.43000031	11.31000042	11.38000011	91474445	\N	CNY	api	2025-11-09 07:07:11.132608+08
075ca316-fa23-4b37-bf91-f1ab70602b96	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-19	11.39999962	11.47000027	11.35999966	11.36999989	83139060	\N	CNY	api	2025-11-09 07:07:11.133776+08
b504e059-4bd4-4c2a-9173-63a552c7e167	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-20	11.39999962	11.47000027	11.36999989	11.39000034	64363480	\N	CNY	api	2025-11-09 07:07:11.13485+08
1871bf78-8d8d-487c-9670-86ada87f8362	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-21	11.39999962	11.59000015	11.39000034	11.47999954	132827810	\N	CNY	api	2025-11-09 07:07:11.13607+08
d2b1093f-d5b7-4c53-b0cb-4e3c574243c5	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-22	11.44999981	11.56000042	11.43999958	11.55000019	100296806	\N	CNY	api	2025-11-09 07:07:11.136813+08
519abfa6-0da7-4dab-b6de-303c447ad4bb	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-23	11.52000046	11.52000046	11.43000031	11.46000004	96264311	\N	CNY	api	2025-11-09 07:07:11.137409+08
f50c0173-a81c-45cb-8628-367b1aa0f8f5	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-26	11.43999958	11.50000000	11.39999962	11.42000008	69915858	\N	CNY	api	2025-11-09 07:07:11.138211+08
ffe3fee7-45ff-4207-a2ed-a997de052f84	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-27	11.44999981	11.53999996	11.42000008	11.48999977	80191514	\N	CNY	api	2025-11-09 07:07:11.138636+08
5f7abf79-d8f2-42f0-ba24-371d19551860	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-28	11.50000000	11.55000019	11.43999958	11.52999973	65817947	\N	CNY	api	2025-11-09 07:07:11.139142+08
8e45b5fe-af3a-41ef-ab9c-1abfa29ec40a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-29	11.52000046	11.55000019	11.44999981	11.46000004	91980676	\N	CNY	api	2025-11-09 07:07:11.139776+08
a45340ae-b97e-4ea9-acc0-1dc2e365fac9	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-05-30	11.47000027	11.57999992	11.43999958	11.56000042	113084931	\N	CNY	api	2025-11-09 07:07:11.140213+08
11b502ae-63ce-40fa-aebc-b9a21793c737	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-03	11.53999996	11.90999985	11.52999973	11.81000042	219247966	\N	CNY	api	2025-11-09 07:07:11.140814+08
b8cc391a-b426-4c81-99c3-c1e39f57988f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-04	11.81999969	11.88000011	11.77999973	11.84000015	116795950	\N	CNY	api	2025-11-09 07:07:11.141389+08
39b651ef-585e-4d9e-9403-18909805fd35	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-05	11.88000011	11.90999985	11.65999985	11.67000008	116680349	\N	CNY	api	2025-11-09 07:07:11.141974+08
94d9d838-9131-4f77-b1af-0e3aad3c34c6	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-06	11.69999981	11.78999996	11.68000031	11.69999981	68235251	\N	CNY	api	2025-11-09 07:07:11.142474+08
92614531-b13c-4004-957f-06fe5079fbda	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-09	11.72999954	11.75000000	11.64999962	11.71000004	77325468	\N	CNY	api	2025-11-09 07:07:11.143291+08
bea2e1c8-5714-4423-a4ed-667ba735588d	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-10	11.72000027	11.89000034	11.71000004	11.81000042	142813180	\N	CNY	api	2025-11-09 07:07:11.143721+08
70d99900-6508-4b7d-82b3-3702ce518e71	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-11	11.81999969	11.93000031	11.78999996	11.85000038	109466664	\N	CNY	api	2025-11-09 07:07:11.144122+08
0ba17857-a7ea-4730-9ad0-ed1dd8ba670d	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-12	11.56000042	11.69999981	11.52000046	11.68000031	129022047	\N	CNY	api	2025-11-09 07:07:11.144595+08
22d4d381-98de-4d83-9465-f83f486c0d16	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-13	11.68000031	11.73999977	11.56000042	11.57999992	109549419	\N	CNY	api	2025-11-09 07:07:11.145051+08
281e362e-3afb-4729-b52c-290689e12725	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-16	11.56999969	11.78999996	11.52999973	11.78999996	117443827	\N	CNY	api	2025-11-09 07:07:11.145627+08
d6657d3b-0d41-4a95-92ca-1491420e6f06	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-17	11.78999996	11.88000011	11.71000004	11.76000023	89002734	\N	CNY	api	2025-11-09 07:07:11.146672+08
b4141eda-e3b9-43a5-b1b0-4612e55d076d	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-18	11.77999973	11.81000042	11.65999985	11.77000046	68352111	\N	CNY	api	2025-11-09 07:07:11.147732+08
ad453bf3-c0ef-4cfe-8194-6a011091166b	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-19	11.76000023	11.77999973	11.64999962	11.69999981	83224716	\N	CNY	api	2025-11-09 07:07:11.148301+08
efc001f5-dff2-4976-b66e-152626c9d01f	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-20	11.69999981	11.85999966	11.67000008	11.84000015	130919782	\N	CNY	api	2025-11-09 07:07:11.149035+08
25272dbc-0b4a-46e4-8520-eaf06c095243	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-23	11.81000042	11.97000027	11.67000008	11.93000031	138917048	\N	CNY	api	2025-11-09 07:07:11.150777+08
22b93778-b3bb-476f-8732-3f6c9f5385f0	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-24	11.89999962	12.01000023	11.84000015	11.93000031	130852531	\N	CNY	api	2025-11-09 07:07:11.151647+08
81cae37a-c93f-4a60-93a1-1db538ffb838	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-25	11.93000031	12.07999992	11.82999992	12.06000042	167511647	\N	CNY	api	2025-11-09 07:07:11.152438+08
826ea9a9-b123-4f97-82cc-48142b6f136d	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-26	12.05000019	12.47999954	12.01000023	12.40999985	217457766	\N	CNY	api	2025-11-09 07:07:11.153415+08
8e3d9ebb-3249-43c5-82d3-f57719be4b0e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-27	12.36999989	12.57999992	12.13000011	12.19999981	237760015	\N	CNY	api	2025-11-09 07:07:11.154368+08
43ade473-33c3-40b4-a6f6-c5b1dda56593	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-06-30	12.14000034	12.17000008	11.96000004	12.06999969	150481965	\N	CNY	api	2025-11-09 07:07:11.15531+08
c8affd51-2864-4ae7-8b45-4378409bd5ad	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-01	12.06000042	12.32999992	12.06000042	12.30000019	135434108	\N	CNY	api	2025-11-09 07:07:11.156147+08
77453ecb-e254-4e53-b921-1116a7858ea7	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-02	12.31000042	12.40999985	12.22999954	12.31999969	120041184	\N	CNY	api	2025-11-09 07:07:11.15687+08
9be57ad7-87cc-44dd-93e2-d64c0942d003	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-03	12.32999992	12.42000008	12.27999973	12.35000038	79408597	\N	CNY	api	2025-11-09 07:07:11.158302+08
05c73824-0290-4e28-8ef2-489d39c30734	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-04	12.35000038	12.72000027	12.30000019	12.60000038	177533267	\N	CNY	api	2025-11-09 07:07:11.159173+08
78a47e57-e4c9-4947-898c-942a33c4aa78	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-07	12.60000038	12.81999969	12.60000038	12.77999973	149540653	\N	CNY	api	2025-11-09 07:07:11.159968+08
8a665c97-0b68-4fe1-8111-b2e6065781a9	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-08	12.75000000	12.84000015	12.64999962	12.68999958	109098597	\N	CNY	api	2025-11-09 07:07:11.160703+08
37a4dd16-e4aa-43ee-b930-50d8b7ed1a9e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-09	12.65999985	12.89999962	12.65999985	12.84000015	120596330	\N	CNY	api	2025-11-09 07:07:11.161377+08
727e0957-b9ec-49aa-a552-ba4a0696ddeb	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-10	12.81999969	13.32999992	12.78999996	13.18000031	248141553	\N	CNY	api	2025-11-09 07:07:11.162297+08
3002df82-2001-4f62-a4ba-699497da204b	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-11	13.18999958	13.30000019	12.89000034	12.90999985	244374350	\N	CNY	api	2025-11-09 07:07:11.163175+08
cdaeed56-0210-466d-ba0a-dadcc43e2653	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-14	12.86999989	13.17000008	12.85999966	12.97999954	187289585	\N	CNY	api	2025-11-09 07:07:11.163875+08
0986d2ca-40d6-46a4-8c7f-1791186fbb97	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-15	12.98999977	13.03999996	12.71000004	12.72999954	181053131	\N	CNY	api	2025-11-09 07:07:11.16529+08
f52f86f0-0a6b-42e7-9f81-f232bed661b9	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-16	12.72999954	12.76000023	12.50000000	12.64000034	192786379	\N	CNY	api	2025-11-09 07:07:11.166234+08
d37e2061-1d79-444e-b030-fca53a9dfa6c	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-17	12.60999966	12.69999981	12.53999996	12.59000015	94464140	\N	CNY	api	2025-11-09 07:07:11.167248+08
9cb6ad80-02de-45b6-a670-d68faf021b87	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-18	12.61999989	12.75000000	12.60000038	12.69999981	124120611	\N	CNY	api	2025-11-09 07:07:11.168064+08
8b5be4d1-dbd0-4733-9991-8fef6bff1c18	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-21	12.64000034	12.71000004	12.55000019	12.60999966	107902662	\N	CNY	api	2025-11-09 07:07:11.168879+08
efe3b395-a50e-460c-9225-ebddf7eb656a	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-22	12.60000038	12.60000038	12.31999969	12.48999977	193522916	\N	CNY	api	2025-11-09 07:07:11.169772+08
86df6708-2b62-4ce8-b7b4-7a6069b582f8	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-23	12.46000004	12.63000011	12.44999981	12.52999973	137052000	\N	CNY	api	2025-11-09 07:07:11.170619+08
07e503a0-da21-42fd-92ea-173db5072b47	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-24	12.52999973	12.52999973	12.32999992	12.35000038	195935057	\N	CNY	api	2025-11-09 07:07:11.171415+08
6fe74918-af5f-46d1-b24a-803654effb75	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-25	12.32999992	12.46000004	12.31999969	12.35000038	110826666	\N	CNY	api	2025-11-09 07:07:11.172512+08
66de2aff-88e7-4d6f-9e4a-d23c59b92f9e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-28	12.35000038	12.52999973	12.31999969	12.46000004	123824278	\N	CNY	api	2025-11-09 07:07:11.173416+08
b32aa9f6-0c8b-4bcf-a88d-3b94486bb91e	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-29	12.46000004	12.51000023	12.34000015	12.34000015	101281801	\N	CNY	api	2025-11-09 07:07:11.174984+08
a11e02f2-325f-442f-83f9-97bcadcd9567	2aa3f894-681b-4a75-9003-ab376a35df7e	2025-07-31	12.51000023	12.55000019	12.22000027	12.22999954	169008125	\N	CNY	api	2025-11-07 23:30:10.475614+08
dd39ebd8-d5fd-48cb-8ead-3ebfbb52335b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-11	9.38000011	9.47999954	9.15999985	9.30000019	273580522	\N	CNY	api	2025-11-09 07:07:11.565923+08
9051385a-15c2-4830-a9c4-05c0f6afa8d7	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-12	9.30000019	9.43999958	9.14000034	9.18999958	224536178	\N	CNY	api	2025-11-09 07:07:11.569668+08
65e94b02-a6d5-4f96-b3e0-004cd566aa2a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-13	9.11999989	9.22000027	8.97000027	9.06999969	207422731	\N	CNY	api	2025-11-09 07:07:11.570637+08
32deacfb-1d80-49e3-869d-971f710108df	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-14	9.30000019	9.30000019	8.93000031	8.94999981	218835356	\N	CNY	api	2025-11-09 07:07:11.57144+08
295c718a-5fcf-4882-bd63-5f97b8a49c6e	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-15	8.89999962	8.94999981	8.69999981	8.71000004	162873443	\N	CNY	api	2025-11-09 07:07:11.572479+08
aa0adc80-1021-44d2-89e4-a3bb09283e56	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-18	8.78999996	9.02999973	8.76000023	8.84000015	186612931	\N	CNY	api	2025-11-09 07:07:11.573116+08
8273507e-c14b-44dd-a3a0-0a2052760e54	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-19	8.84000015	8.85000038	8.52999973	8.75000000	162673593	\N	CNY	api	2025-11-09 07:07:11.573709+08
b84aa347-4489-40ad-bb38-0a83dc943f54	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-20	8.69999981	8.78999996	8.64999962	8.76000023	95570876	\N	CNY	api	2025-11-09 07:07:11.574407+08
1df021ea-192e-484a-89c1-440908113884	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-21	8.72999954	8.78999996	8.61999989	8.68000031	101182659	\N	CNY	api	2025-11-09 07:07:11.575094+08
ffd31e4b-5223-462b-93f5-11db1874a14f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-22	8.65999985	8.77999973	8.40999985	8.42000008	134386899	\N	CNY	api	2025-11-09 07:07:11.575634+08
221d902e-2533-42cf-bf06-3beb414db336	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-25	8.43000031	8.48999977	8.25000000	8.38000011	113898746	\N	CNY	api	2025-11-09 07:07:11.576167+08
318439e8-aa0e-48e9-91ab-affc167a8c26	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-26	8.34000015	8.47999954	8.31999969	8.35999966	95347951	\N	CNY	api	2025-11-09 07:07:11.576652+08
556a8d88-70e8-4cc4-a9e9-ca99bf407e7a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-27	8.34000015	8.44999981	8.22000027	8.44999981	104254908	\N	CNY	api	2025-11-09 07:07:11.577106+08
6015a030-8dd1-4b5a-b993-89ecd94ba92b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-28	8.43000031	8.55000019	8.40999985	8.47999954	110050462	\N	CNY	api	2025-11-09 07:07:11.577577+08
ec8e428e-b0fa-4063-8927-fdcd84eff7b5	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-11-29	8.43000031	8.72999954	8.42000008	8.60000038	149095776	\N	CNY	api	2025-11-09 07:07:11.578106+08
e142fdf1-b1f6-447d-a11b-76f363776253	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-02	8.52999973	8.72999954	8.52000046	8.68000031	108741356	\N	CNY	api	2025-11-09 07:07:11.578562+08
721935cb-482c-43ec-a0e7-10e3fedf0680	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-03	8.64999962	8.77999973	8.60000038	8.73999977	117281518	\N	CNY	api	2025-11-09 07:07:11.578993+08
08ead325-e740-4a1f-b2c7-ee4904eaa355	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-04	8.69999981	8.69999981	8.52999973	8.55000019	110173644	\N	CNY	api	2025-11-09 07:07:11.579473+08
173c7ddd-3d70-424c-ab57-1b6762a3cefc	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-05	8.50000000	8.53999996	8.46000004	8.52000046	73343506	\N	CNY	api	2025-11-09 07:07:11.579989+08
0e0c06ee-5669-41b9-9f1f-61cbe3782812	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-06	8.51000023	8.72000027	8.47999954	8.68000031	130103582	\N	CNY	api	2025-11-09 07:07:11.580555+08
8f6eeaae-6bcb-4d4c-a851-fdb289266cc0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-09	8.64999962	8.69999981	8.38000011	8.42000008	164165901	\N	CNY	api	2025-11-09 07:07:11.580989+08
bae6bf0c-e716-491e-aa37-3578c429c358	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-10	8.98999977	8.98999977	8.57999992	8.57999992	280265383	\N	CNY	api	2025-11-09 07:07:11.581408+08
24465470-d226-4531-9072-2a29644687ef	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-11	8.51000023	8.76000023	8.50000000	8.64999962	141034155	\N	CNY	api	2025-11-09 07:07:11.581802+08
7caab9ea-6c45-490d-a21e-7f09e98b3b50	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-12	8.63000011	8.72000027	8.55000019	8.68999958	128904211	\N	CNY	api	2025-11-09 07:07:11.582181+08
e9939d12-8141-4638-b5f9-dcd51fc4afd4	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-13	8.59000015	8.60999966	8.39999962	8.40999985	192078187	\N	CNY	api	2025-11-09 07:07:11.583014+08
a8263774-4e67-4396-ad73-6c00761281d0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-16	8.42000008	8.44999981	8.19999981	8.22999954	119813001	\N	CNY	api	2025-11-09 07:07:11.583667+08
77559efa-8180-4907-9afa-d3629ef7c01d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-17	8.23999977	8.26000023	8.13000011	8.14000034	87303717	\N	CNY	api	2025-11-09 07:07:11.58418+08
f473e8f2-599d-468b-8e57-02e307beca7b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-18	8.17000008	8.21000004	8.13000011	8.14000034	69535505	\N	CNY	api	2025-11-09 07:07:11.584729+08
35036f6c-48cf-4592-ab65-9295ff224c08	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-19	8.00000000	8.01000023	7.82000017	7.90999985	183812253	\N	CNY	api	2025-11-09 07:07:11.585412+08
4fce4c40-f36c-463e-9495-929c83b33e4e	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-20	7.88000011	7.92999983	7.80000019	7.82000017	116440030	\N	CNY	api	2025-11-09 07:07:11.586156+08
47c4e98e-64b9-427e-84da-6ad646604582	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-23	7.78999996	7.80000019	7.65000010	7.65999985	116901330	\N	CNY	api	2025-11-09 07:07:11.586701+08
c2a3f000-6747-4b78-a6b9-16d30a694e26	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-24	7.67999983	7.73000002	7.63000011	7.73000002	88060778	\N	CNY	api	2025-11-09 07:07:11.587094+08
fbeb0c86-a1d0-4cd8-8cb1-be8ca11572ba	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-25	7.71000004	7.73000002	7.46999979	7.53999996	151766288	\N	CNY	api	2025-11-09 07:07:11.587472+08
28695009-3c90-4d5a-ba5c-2915f86ed9a8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-26	7.50000000	7.55999994	7.48000002	7.51000023	71018803	\N	CNY	api	2025-11-09 07:07:11.587918+08
4695a4f2-0b6f-475d-ae23-f4ee4dbf5f88	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-27	7.51000023	7.63000011	7.48999977	7.55000019	100432377	\N	CNY	api	2025-11-09 07:07:11.588303+08
21aa0e04-20df-4986-93b7-26d2d02bc7f8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-30	7.50000000	7.51000023	7.32999992	7.36000013	133889091	\N	CNY	api	2025-11-09 07:07:11.588834+08
09a9ca1a-417a-4859-8afb-19d8947a007f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2024-12-31	7.38000011	7.44000006	7.25000000	7.26000023	100753551	\N	CNY	api	2025-11-09 07:07:11.589366+08
bf839b0e-ac94-4eed-a854-2918481d9add	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-02	7.25000000	7.36000013	7.07000017	7.11000013	118266605	\N	CNY	api	2025-11-09 07:07:11.589879+08
c8151a4c-43e2-49b1-ae7c-0ea2e8fc9e2d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-03	7.17000008	7.17999983	6.96000004	7.00000000	112491516	\N	CNY	api	2025-11-09 07:07:11.590738+08
65e84ff6-c452-4e55-890d-7f5d56647429	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-06	6.98999977	7.01000023	6.88999987	6.98000002	85085661	\N	CNY	api	2025-11-09 07:07:11.591291+08
eeab794d-fb2b-4f60-beeb-381fb3d420a8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-07	6.96000004	7.05000019	6.92000008	7.05000019	72047105	\N	CNY	api	2025-11-09 07:07:11.592787+08
7e41ecc2-b019-40ee-a6e8-8b1fc0475c9b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-08	7.01999998	7.03000021	6.82999992	6.96000004	91268396	\N	CNY	api	2025-11-09 07:07:11.593659+08
18fa7803-2817-4369-b231-ee00ca18cb3f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-09	6.92999983	7.01000023	6.90999985	6.94999981	67468602	\N	CNY	api	2025-11-09 07:07:11.594605+08
838e4ffd-2fdf-4b46-a561-2db3ac35c4b0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-10	6.96000004	7.03000021	6.69000006	6.69000006	133879776	\N	CNY	api	2025-11-09 07:07:11.595594+08
47335f14-ef48-4ed6-8f70-6496fc8f289c	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-13	6.59999990	6.76999998	6.55000019	6.76000023	91114692	\N	CNY	api	2025-11-09 07:07:11.59661+08
2de19f0b-4b05-47f2-9568-04e05b2fe86f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-14	6.76000023	6.92999983	6.75000000	6.90999985	111645428	\N	CNY	api	2025-11-09 07:07:11.597976+08
72140134-eb48-4c9f-8178-4bff65a57abe	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-15	6.88000011	6.96000004	6.78999996	6.86000013	88729429	\N	CNY	api	2025-11-09 07:07:11.598792+08
c77e4084-2d6e-486a-9e9c-311884b38151	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-16	6.98000002	6.98999977	6.84000015	6.88000011	111054528	\N	CNY	api	2025-11-09 07:07:11.600983+08
bad2ca45-6e05-4302-bb4b-b8bd57c9e809	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-17	6.57999992	6.65000010	6.44999981	6.63000011	362028275	\N	CNY	api	2025-11-09 07:07:11.601648+08
23a1d73a-221f-41c8-9a79-31deb142f73a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-20	6.59999990	6.94000006	6.48000002	6.84999990	298816747	\N	CNY	api	2025-11-09 07:07:11.602308+08
c50aa7eb-ea81-4311-8895-3336b49475ba	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-21	6.84000015	7.53999996	6.82000017	7.36000013	584939709	\N	CNY	api	2025-11-09 07:07:11.602904+08
b26f38ff-285f-4c96-892e-db9c677f3ab5	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-22	7.26999998	7.36000013	6.98000002	7.01999998	344872780	\N	CNY	api	2025-11-09 07:07:11.603472+08
d7aebd08-a797-4cbe-b359-bdfeac44295e	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-23	7.15000010	7.69999981	7.07999992	7.36000013	441658131	\N	CNY	api	2025-11-09 07:07:11.603883+08
668439e8-2b04-4bfb-8b71-47e2ca1c656f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-24	7.32999992	7.53999996	7.21000004	7.38999987	255502424	\N	CNY	api	2025-11-09 07:07:11.60437+08
bb4706ca-5b12-4e44-b870-8db38cdd1f10	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-01-27	7.38000011	7.55999994	7.21999979	7.26999998	215175329	\N	CNY	api	2025-11-09 07:07:11.604739+08
05d5ca7f-968d-4e8f-8b45-225f58f1d2ca	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-05	7.05000019	7.17999983	6.88000011	6.96999979	276584682	\N	CNY	api	2025-11-09 07:07:11.605534+08
ed241f3e-f840-400e-b66d-4889540f5d23	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-06	6.96999979	7.15999985	6.92000008	7.01999998	186880547	\N	CNY	api	2025-11-09 07:07:11.606048+08
3eef06d4-2fed-4b1b-ada9-54bf6147be83	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-07	7.05000019	7.65000010	7.01000023	7.42000008	326921582	\N	CNY	api	2025-11-09 07:07:11.606564+08
8206871b-03ea-405a-8ae9-1fdcfd03b718	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-10	7.38999987	7.44999981	7.26999998	7.42000008	186225773	\N	CNY	api	2025-11-09 07:07:11.606991+08
54f0c132-e74a-4c35-8350-583568ff45fb	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-11	7.46000004	7.53999996	7.21999979	7.23999977	173609054	\N	CNY	api	2025-11-09 07:07:11.607536+08
3e6d1783-8ce2-4a3f-9413-d63ea2cd2a90	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-12	7.25000000	7.96000004	7.13000011	7.96000004	379738987	\N	CNY	api	2025-11-09 07:07:11.608221+08
89db2e63-f0f4-431e-8d36-bbd014020244	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-13	7.78999996	8.22000027	7.69999981	7.96999979	574153031	\N	CNY	api	2025-11-09 07:07:11.608774+08
25f3a876-5b83-4350-96bd-78c7281b032b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-14	7.92999983	8.05000019	7.71000004	7.80999994	262999442	\N	CNY	api	2025-11-09 07:07:11.609222+08
2beef256-dcf3-4e69-909e-0b1ac4521b1f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-17	7.75000000	7.86999989	7.61999989	7.67999983	224527083	\N	CNY	api	2025-11-09 07:07:11.609682+08
2aee45b0-f6af-4b80-aab8-155982f369e1	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-18	7.63999987	7.76000023	7.46999979	7.51999998	200949545	\N	CNY	api	2025-11-09 07:07:11.610109+08
a8fc3851-c8b5-453b-9734-5f2af6b32d06	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-19	7.50000000	7.71999979	7.48000002	7.65000010	180917457	\N	CNY	api	2025-11-09 07:07:11.610499+08
31cc55d7-ad11-46e5-a9d0-b6830b86cf3a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-20	7.59000015	7.59999990	7.48999977	7.51999998	137024687	\N	CNY	api	2025-11-09 07:07:11.610877+08
ba6a5077-fbd3-4f80-9984-5e55de2fef53	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-21	7.53000021	7.73000002	7.48999977	7.61999989	193512882	\N	CNY	api	2025-11-09 07:07:11.611303+08
4f6d6642-b831-4860-a475-bc4c55c46dcd	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-24	7.65999985	8.06999969	7.65999985	7.82000017	317591806	\N	CNY	api	2025-11-09 07:07:11.611741+08
063f497f-f06f-4cf0-948c-4d9e498436b6	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-25	7.75000000	7.86000013	7.67000008	7.67999983	177147975	\N	CNY	api	2025-11-09 07:07:11.612346+08
246d0525-109e-42a6-bba5-dcd963a85464	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-26	7.71000004	7.86000013	7.69999981	7.84000015	194143567	\N	CNY	api	2025-11-09 07:07:11.612827+08
017174c4-aeb3-4c20-b679-3c57d6609792	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-27	7.78000021	7.88999987	7.73999977	7.80999994	171577342	\N	CNY	api	2025-11-09 07:07:11.613251+08
23a8f37d-455b-4745-b431-992603b100e8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-02-28	7.76999998	8.02999973	7.67000008	7.75000000	272679023	\N	CNY	api	2025-11-09 07:07:11.613685+08
9d7f8fed-bf20-4fd2-a872-a3570bd24efa	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-03	7.75000000	7.96000004	7.75000000	7.78999996	189366181	\N	CNY	api	2025-11-09 07:07:11.614121+08
e9a1d9a1-3090-4074-a345-da174882f2d4	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-04	7.71999979	7.73000002	7.53000021	7.63999987	145843421	\N	CNY	api	2025-11-09 07:07:11.614677+08
463375bf-a5e7-4f2e-aa0d-1c719a21510b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-05	7.59999990	7.69000006	7.42000008	7.53000021	136469106	\N	CNY	api	2025-11-09 07:07:11.615474+08
656823da-9bfd-45c5-bdae-3033e3c678f9	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-06	7.57999992	7.82000017	7.55999994	7.76999998	211713302	\N	CNY	api	2025-11-09 07:07:11.615926+08
50030088-0f00-4cfc-84a1-a07344297955	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-07	7.65000010	7.65999985	7.51999998	7.53000021	159372804	\N	CNY	api	2025-11-09 07:07:11.616459+08
ef3f37cd-4553-4df0-ad92-56cc59ad397d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-10	7.53999996	7.57000017	7.44000006	7.48000002	97780993	\N	CNY	api	2025-11-09 07:07:11.616826+08
dd8ade2b-2422-4b0f-b9fd-0c390968eaeb	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-11	7.40000010	7.44999981	7.34999990	7.42999983	87239337	\N	CNY	api	2025-11-09 07:07:11.617212+08
080a1659-267f-4dba-a9c4-193293a362da	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-12	7.42999983	7.48000002	7.40000010	7.44000006	66116815	\N	CNY	api	2025-11-09 07:07:11.617663+08
0ec98370-7fa8-4f5d-aca9-65d53fe9d237	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-13	7.40999985	7.44000006	7.32999992	7.34999990	75837650	\N	CNY	api	2025-11-09 07:07:11.618074+08
db3d7b4f-0c45-44e0-a819-6b2ab4cd5090	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-14	7.36999989	7.59000015	7.36999989	7.53999996	145652192	\N	CNY	api	2025-11-09 07:07:11.618465+08
1cff4b91-6537-49a5-8e1a-56f95897972a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-17	7.59999990	7.73000002	7.53999996	7.55999994	129008943	\N	CNY	api	2025-11-09 07:07:11.618822+08
fe5a069d-19eb-4a67-a262-00e6ef41f5e1	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-18	7.57000017	7.59000015	7.48999977	7.53000021	89340809	\N	CNY	api	2025-11-09 07:07:11.619202+08
080ad1b8-8f93-4be5-918e-763aed7fcff5	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-19	7.48999977	7.51999998	7.42999983	7.46999979	70856638	\N	CNY	api	2025-11-09 07:07:11.619718+08
d07f7a70-2c5f-401b-b27d-a6ca68019588	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-20	7.44999981	7.48999977	7.40999985	7.42999983	61230239	\N	CNY	api	2025-11-09 07:07:11.620175+08
fb8cebc0-7cbb-4d4c-9b1c-d0167cfe5699	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-21	7.40000010	7.42000008	7.26999998	7.36000013	130662088	\N	CNY	api	2025-11-09 07:07:11.620641+08
780dcd13-e384-4cbd-ae7b-29700cacd544	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-24	7.34999990	7.34999990	7.15000010	7.17999983	105061250	\N	CNY	api	2025-11-09 07:07:11.621109+08
c216441e-8fec-4773-bfb4-d0747f0d59c6	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-25	7.17000008	7.23000002	7.13999987	7.19000006	65503731	\N	CNY	api	2025-11-09 07:07:11.621592+08
f8811b80-0ce7-48d5-8136-dc0b587aa3d0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-26	7.19000006	7.26000023	7.17999983	7.19999981	70937747	\N	CNY	api	2025-11-09 07:07:11.622091+08
6cfb21bf-122a-4ce4-9dda-df01b3cc3eb9	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-27	7.19000006	7.21999979	7.11000013	7.17000008	56204815	\N	CNY	api	2025-11-09 07:07:11.622609+08
604249ed-827c-497d-8e37-2e17047d5d27	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-28	7.17000008	7.21000004	7.11000013	7.11999989	49144140	\N	CNY	api	2025-11-09 07:07:11.622941+08
f5f2d6e4-7a93-4fc4-b10d-b4b29bc49e57	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-03-31	7.11000013	7.11000013	6.98000002	7.05000019	72778083	\N	CNY	api	2025-11-09 07:07:11.623378+08
5340d435-92c7-45f7-b28c-ffcc0de9edea	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-01	7.07000017	7.21000004	7.03999996	7.11000013	70965066	\N	CNY	api	2025-11-09 07:07:11.623732+08
d7e53a51-7fb0-49c1-b697-2e4128bb25e3	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-02	7.09000015	7.09999990	7.01999998	7.03999996	50685328	\N	CNY	api	2025-11-09 07:07:11.624234+08
97c08c85-01c2-4356-9a21-ca3b60329a6d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-03	7.00000000	7.23000002	6.98999977	7.13999987	91433005	\N	CNY	api	2025-11-09 07:07:11.624974+08
cfe192a4-0c97-46dd-b81d-0e90a8e795a1	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-07	6.86000013	6.92999983	6.46000004	6.59999990	196633480	\N	CNY	api	2025-11-09 07:07:11.625406+08
5cd64663-0b29-4fbd-a84d-02b292c15a02	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-08	6.59999990	6.84000015	6.59999990	6.80000019	142555014	\N	CNY	api	2025-11-09 07:07:11.625752+08
5e92aea5-a2c0-4044-8707-68cb07f00c95	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-09	6.69999981	7.17000008	6.61999989	7.05999994	185307977	\N	CNY	api	2025-11-09 07:07:11.626165+08
19e5d1f9-faf5-4dc8-967a-d06aecf50fdb	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-10	7.00000000	7.28999996	6.90000010	7.19999981	207328561	\N	CNY	api	2025-11-09 07:07:11.626492+08
7133a5d0-f51c-4cbd-a70a-d3ba751fc0bb	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-11	7.13000011	7.19999981	7.00000000	7.07999992	137257832	\N	CNY	api	2025-11-09 07:07:11.62715+08
0cdc4757-c419-4341-87c9-1ba1d2d45f17	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-14	7.05999994	7.11999989	7.03000021	7.05000019	85833344	\N	CNY	api	2025-11-09 07:07:11.627872+08
380c153c-dbe5-4867-936a-39378666a0fb	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-15	7.03999996	7.03999996	6.92000008	6.98999977	76095482	\N	CNY	api	2025-11-09 07:07:11.628386+08
3d13e322-3492-49d9-9d87-47d1208b5986	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-16	6.98000002	7.09000015	6.94999981	7.03999996	82908750	\N	CNY	api	2025-11-09 07:07:11.628929+08
e8bc6a47-8926-490d-97a6-e11f46202830	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-17	7.01999998	7.34000015	7.00000000	7.19999981	245003354	\N	CNY	api	2025-11-09 07:07:11.629478+08
47affdee-b2cc-4112-828c-3284b4341535	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-18	7.19000006	7.36000013	7.09999990	7.30999994	163214662	\N	CNY	api	2025-11-09 07:07:11.630207+08
4da71918-79c1-4107-888d-8b0185a94080	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-21	7.19999981	7.23000002	7.13999987	7.17999983	130350591	\N	CNY	api	2025-11-09 07:07:11.630668+08
b38b9ea1-f1d7-4361-9713-7ba2b9355352	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-22	7.15999985	7.21999979	7.13000011	7.17999983	83868946	\N	CNY	api	2025-11-09 07:07:11.631101+08
fa84af1a-a241-493b-8e43-67b7b6d74fbc	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-23	7.17999983	7.23000002	7.05000019	7.07000017	108656453	\N	CNY	api	2025-11-09 07:07:11.631634+08
149fc79e-4a09-421a-835b-273a150670cd	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-24	7.07000017	7.15000010	7.01000023	7.07999992	83027357	\N	CNY	api	2025-11-09 07:07:11.632626+08
26e0d42e-e5fd-4261-971a-954c60dbda09	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-25	7.09000015	7.26999998	7.05000019	7.05000019	183211045	\N	CNY	api	2025-11-09 07:07:11.633343+08
1e2be3b1-f286-47ac-9dae-e953a844b6eb	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-28	6.96999979	6.98999977	6.80999994	6.82999992	135721601	\N	CNY	api	2025-11-09 07:07:11.633911+08
22918463-209b-41bd-83c5-bc4b5e1bba9b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-29	6.82999992	6.86000013	6.80000019	6.80999994	65291899	\N	CNY	api	2025-11-09 07:07:11.634514+08
cab9ad30-1ce6-4a9a-8d53-6f64d4ce11f8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-04-30	6.69999981	6.82000017	6.63000011	6.80999994	92454224	\N	CNY	api	2025-11-09 07:07:11.635138+08
5203243e-0a9c-46f4-a3b7-c7788ac92dd3	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-06	6.78999996	6.84000015	6.78000021	6.82999992	72136373	\N	CNY	api	2025-11-09 07:07:11.635702+08
a32affe2-95a5-4372-bc9a-3003d5c0b71c	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-07	7.03000021	7.05999994	6.88000011	6.90000010	135462392	\N	CNY	api	2025-11-09 07:07:11.636551+08
a0837879-b347-4632-acfd-71efe4a35c80	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-08	6.86999989	6.90999985	6.84000015	6.88000011	70634512	\N	CNY	api	2025-11-09 07:07:11.637103+08
039f3961-24d7-48c4-bd90-c92e1968244f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-09	6.88000011	6.88999987	6.78000021	6.78000021	73341784	\N	CNY	api	2025-11-09 07:07:11.637765+08
d4e6d048-4dfe-445e-9186-6fba72864041	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-12	6.80999994	6.84999990	6.78000021	6.84999990	62724247	\N	CNY	api	2025-11-09 07:07:11.63845+08
30a2f21e-161a-4b83-a24d-b1d222c78eab	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-13	6.86999989	6.90999985	6.84000015	6.86000013	58298162	\N	CNY	api	2025-11-09 07:07:11.639043+08
8493c9ed-6569-48a0-8374-7a2b0aff20d4	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-14	6.86000013	6.94000006	6.80999994	6.88999987	74003592	\N	CNY	api	2025-11-09 07:07:11.639584+08
02a87cda-aaca-45e9-8a22-d04914df666d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-15	6.88999987	6.92000008	6.78999996	6.78999996	75391897	\N	CNY	api	2025-11-09 07:07:11.64007+08
94429eea-6857-4559-8e83-4a5c0b5c977b	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-16	6.80000019	6.82000017	6.73000002	6.76999998	54474911	\N	CNY	api	2025-11-09 07:07:11.640722+08
e0e93471-b5a9-4896-94cf-f8a0cd67eb63	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-19	6.75000000	6.82999992	6.73000002	6.80000019	56176046	\N	CNY	api	2025-11-09 07:07:11.641298+08
76004787-d523-467e-8110-902e3a431700	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-20	6.78999996	6.80000019	6.75000000	6.78000021	52695404	\N	CNY	api	2025-11-09 07:07:11.641859+08
70f18c9d-525b-4ce9-a31e-11b96047f371	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-21	6.78000021	6.78999996	6.75000000	6.76000023	43362423	\N	CNY	api	2025-11-09 07:07:11.642381+08
ad6d26ad-221b-4737-8814-1f9b06e63a38	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-22	6.73999977	6.75000000	6.65999985	6.67000008	61403643	\N	CNY	api	2025-11-09 07:07:11.642906+08
59b18b5e-55bc-418b-98e4-aa50a6adc3ab	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-23	6.67999983	6.69000006	6.63000011	6.63000011	44211199	\N	CNY	api	2025-11-09 07:07:11.643374+08
fd1ac1c1-61fa-44c8-9084-f9a4c997944e	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-26	6.63000011	6.65000010	6.59999990	6.63000011	37820798	\N	CNY	api	2025-11-09 07:07:11.643894+08
f8461713-588f-44fa-809b-d904687a2949	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-27	6.63000011	6.71000004	6.61999989	6.67000008	46603825	\N	CNY	api	2025-11-09 07:07:11.644388+08
03251808-0691-4f00-8890-91f3b54ca0ad	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-28	6.73000002	6.76000023	6.67000008	6.67999983	40758813	\N	CNY	api	2025-11-09 07:07:11.645+08
3a801f21-1905-4cec-81b9-80e78b8c66f1	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-29	6.67000008	6.73000002	6.67000008	6.69999981	46360067	\N	CNY	api	2025-11-09 07:07:11.645568+08
d4f6c463-4fce-4b3b-a95d-4ce485e44ccc	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-05-30	6.67999983	6.69999981	6.63999987	6.63999987	48742045	\N	CNY	api	2025-11-09 07:07:11.646118+08
655d4b16-68e8-49f5-86e7-3632fa07ac40	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-03	6.57999992	6.59999990	6.53999996	6.57999992	64683305	\N	CNY	api	2025-11-09 07:07:11.646635+08
94c56d85-9ab4-4a07-8092-3f14b6f771dc	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-04	6.59000015	6.63999987	6.57000017	6.61999989	50625152	\N	CNY	api	2025-11-09 07:07:11.647248+08
e1dcadc2-1774-4f31-b2ee-62592c039baf	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-05	6.61000013	6.65999985	6.59000015	6.63999987	51121293	\N	CNY	api	2025-11-09 07:07:11.64787+08
6cb17a99-8f56-4f6a-b123-c1254660a6cf	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-06	6.63999987	6.65999985	6.59000015	6.59999990	45261067	\N	CNY	api	2025-11-09 07:07:11.648666+08
1a053580-460e-4d8f-b776-ed8f62e485e7	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-09	6.59999990	6.63999987	6.57999992	6.61999989	44399702	\N	CNY	api	2025-11-09 07:07:11.649185+08
44b554ad-39e7-4809-b806-7bc3441f7126	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-10	6.63000011	6.73000002	6.55999994	6.59999990	104135818	\N	CNY	api	2025-11-09 07:07:11.64974+08
4d43be08-95fe-4e43-a7bf-101c006045ad	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-11	6.57000017	6.61000013	6.53999996	6.57000017	99042083	\N	CNY	api	2025-11-09 07:07:11.650372+08
a5f52167-45af-4abc-9133-7b58fe8932a0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-12	6.55000019	6.55999994	6.48000002	6.51000023	107652062	\N	CNY	api	2025-11-09 07:07:11.650934+08
4c5e207f-6d70-44bf-a4a8-c6a3d058699e	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-13	6.50000000	6.51000023	6.42000008	6.44000006	87615048	\N	CNY	api	2025-11-09 07:07:11.651505+08
47624475-d004-47be-8c2f-acb1e7be0c8d	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-16	6.46000004	6.63000011	6.44999981	6.57000017	130234810	\N	CNY	api	2025-11-09 07:07:11.652087+08
5bec936c-4111-4342-9298-de735df3e643	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-17	6.57000017	6.57999992	6.51000023	6.53000021	58239089	\N	CNY	api	2025-11-09 07:07:11.653547+08
a6e33db8-1704-4930-86e1-87968ff90a10	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-18	6.51000023	6.53000021	6.42000008	6.44000006	63539630	\N	CNY	api	2025-11-09 07:07:11.654112+08
0acc883f-da33-4258-9081-35bf3efa7d10	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-19	6.42000008	6.42999983	6.30000019	6.32000017	85454622	\N	CNY	api	2025-11-09 07:07:11.654688+08
9fc98818-8ef3-4f16-bcad-bd331dc3ec9f	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-20	6.32999992	6.34000015	6.28000021	6.28999996	52448490	\N	CNY	api	2025-11-09 07:07:11.655177+08
09f99b99-70cb-45df-80e3-a1ebe953a51a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-23	6.26000023	6.30000019	6.21000004	6.28999996	55151187	\N	CNY	api	2025-11-09 07:07:11.655646+08
32d17076-3aea-4880-9cfe-180d007c41b1	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-24	6.28999996	6.36999989	6.28000021	6.34999990	62028282	\N	CNY	api	2025-11-09 07:07:11.656107+08
ad7c2537-d5ac-4786-b7f5-8eb153f889d3	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-25	6.34000015	6.42999983	6.32000017	6.42999983	82090369	\N	CNY	api	2025-11-09 07:07:11.656574+08
309d931b-ebfe-404a-a4c0-5c75ae1ee0f6	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-26	6.42000008	6.44000006	6.38000011	6.38999987	66062072	\N	CNY	api	2025-11-09 07:07:11.657043+08
f272437d-244c-4341-b201-c7dab2d4ba8a	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-27	6.38999987	6.48000002	6.38000011	6.38999987	78678574	\N	CNY	api	2025-11-09 07:07:11.657568+08
92fe5121-9cff-4d5b-ad29-c564b88fa0e0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-06-30	6.40000010	6.44999981	6.38999987	6.42000008	60407348	\N	CNY	api	2025-11-09 07:07:11.658141+08
88d53275-e8b8-4c71-9b95-93581892cfa1	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-01	6.42000008	6.42000008	6.30999994	6.34999990	59831800	\N	CNY	api	2025-11-09 07:07:11.658706+08
a5933674-3662-4a99-99b0-060a9e2284d8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-02	6.36000013	6.51999998	6.34000015	6.50000000	131085904	\N	CNY	api	2025-11-09 07:07:11.659638+08
285400a6-2e28-4331-b56f-e5327a24a186	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-03	6.48000002	6.55000019	6.44000006	6.46000004	81014012	\N	CNY	api	2025-11-09 07:07:11.660138+08
b7ed0826-a46f-442d-b362-b9f63ba89297	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-04	6.48000002	6.51999998	6.40999985	6.44000006	78668847	\N	CNY	api	2025-11-09 07:07:11.660647+08
84e3df09-2cb1-4ce6-8dac-0f583f6dab6e	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-07	6.44000006	6.59000015	6.44000006	6.51999998	120538148	\N	CNY	api	2025-11-09 07:07:11.661299+08
b3900440-fa97-4f81-ad69-c79893b653e2	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-08	6.51000023	6.57999992	6.46999979	6.55999994	93478326	\N	CNY	api	2025-11-09 07:07:11.661908+08
65df9037-e0c8-4a45-8487-151c06565fc9	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-09	6.53999996	6.57999992	6.51999998	6.53999996	73591657	\N	CNY	api	2025-11-09 07:07:11.662455+08
a17e56e3-24e2-4562-b439-9143c12bbcd7	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-10	6.51999998	6.86999989	6.51000023	6.76000023	251702913	\N	CNY	api	2025-11-09 07:07:11.662982+08
1be930fc-d1a1-40e0-91bc-2e7fcec45dae	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-11	6.75000000	6.78999996	6.67999983	6.76000023	162870659	\N	CNY	api	2025-11-09 07:07:11.66344+08
fe673f60-3b4a-4a0d-9f47-74301958a0a5	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-14	6.73000002	6.78999996	6.63000011	6.65999985	120552525	\N	CNY	api	2025-11-09 07:07:11.663927+08
4227d886-ba33-4817-99cd-119d9ce45752	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-15	6.63999987	6.65000010	6.46000004	6.59999990	152132047	\N	CNY	api	2025-11-09 07:07:11.664461+08
dfae7810-5892-4288-b8f3-309690c49b99	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-16	6.55000019	6.65000010	6.53000021	6.55999994	84908116	\N	CNY	api	2025-11-09 07:07:11.665092+08
aedc9b0c-587a-4845-9f8b-7e551e94e6a6	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-17	6.55999994	6.59000015	6.51000023	6.55999994	70966370	\N	CNY	api	2025-11-09 07:07:11.665549+08
351efa3f-c05b-42ac-8231-f1f83c1886c4	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-18	6.57000017	6.59000015	6.53999996	6.57000017	57403003	\N	CNY	api	2025-11-09 07:07:11.666019+08
05bd2484-3b75-46a8-ab94-fe86a78088d8	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-21	6.55999994	6.61000013	6.55000019	6.59999990	74411098	\N	CNY	api	2025-11-09 07:07:11.666928+08
cda559b9-abcd-46ea-9769-7e88571bd0cc	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-22	6.61000013	6.71999979	6.53000021	6.69999981	148801040	\N	CNY	api	2025-11-09 07:07:11.667487+08
3789deab-c32e-41a9-8e57-9145113bfbee	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-23	6.73000002	6.82999992	6.67999983	6.71999979	170675431	\N	CNY	api	2025-11-09 07:07:11.668059+08
1fd0ffc8-e39e-4032-acbd-88f6d987dfff	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-24	6.69999981	6.84000015	6.67000008	6.80999994	184232987	\N	CNY	api	2025-11-09 07:07:11.66883+08
aa44e1d4-5ba1-4e5c-85a2-29ed09c69155	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-25	6.80999994	6.84000015	6.76000023	6.78000021	123594926	\N	CNY	api	2025-11-09 07:07:11.669342+08
9bf3ca26-419c-47de-9d7a-147a1be444f2	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-28	6.78000021	6.84000015	6.67999983	6.78999996	119404153	\N	CNY	api	2025-11-09 07:07:11.669805+08
a0ac70dc-6389-4832-9ced-02c332824fa3	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-07-29	6.76000023	6.80999994	6.69999981	6.80999994	99347899	\N	CNY	api	2025-11-09 07:07:11.670375+08
727f9ae6-c36c-4c25-ac51-afedaa611cba	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	2025-10-23	6.40999985	6.42999983	6.32999992	6.38000011	75366863	\N	CNY	api	2025-11-07 23:30:10.780813+08
e09372a7-d18b-41b6-b3de-11f9947e169e	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-11	38.29999924	38.70000076	37.88999939	38.33000183	70314555	\N	CNY	api	2025-11-09 07:07:12.077257+08
c5b958ed-fd85-4dd7-a45a-d6cf27403710	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-12	38.18999863	38.84000015	37.50999832	37.59000015	89328928	\N	CNY	api	2025-11-09 07:07:12.079992+08
43df0681-5eac-4682-82a6-0b19a14f7bf5	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-13	37.59000015	37.97999954	37.50999832	37.81999969	48530440	\N	CNY	api	2025-11-09 07:07:12.081103+08
75d5033d-6c10-4eb8-a3c5-ce443301dce1	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-14	37.65999985	38.47999954	37.52999878	38.06000137	67644030	\N	CNY	api	2025-11-09 07:07:12.082547+08
b6d8f343-833c-44d4-b123-569d4c14e823	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-15	38.08000183	38.56999969	37.81000137	37.81999969	69927688	\N	CNY	api	2025-11-09 07:07:12.083629+08
331534b0-128c-42f7-8f2a-cd7b469af860	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-18	38.04999924	38.65999985	37.79999924	37.90000153	76344807	\N	CNY	api	2025-11-09 07:07:12.084294+08
c8ee892b-6ee7-46d8-8f0d-78c8d6174912	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-19	37.90999985	38.18000031	37.45000076	37.72000122	52124855	\N	CNY	api	2025-11-09 07:07:12.0849+08
ba51e14c-2662-41b4-8b76-4538856e750e	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-20	37.79999924	37.84999847	37.40000153	37.47999954	45129126	\N	CNY	api	2025-11-09 07:07:12.085525+08
d313aa98-0042-47e8-95f4-54e9ac5137f5	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-21	37.47999954	37.65999985	37.27000046	37.43000031	35033614	\N	CNY	api	2025-11-09 07:07:12.086053+08
1df8ebea-56e0-44ff-94c4-dd9259fadc23	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-22	37.43000031	37.54999924	36.36000061	36.45000076	69049090	\N	CNY	api	2025-11-09 07:07:12.086577+08
fec24496-21bd-4d8d-8aea-4f4a043a0cb9	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-25	36.70000076	36.86000061	36.11999893	36.22000122	53409473	\N	CNY	api	2025-11-09 07:07:12.087198+08
87d439e4-000d-46a6-b883-400225391aeb	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-26	36.02999878	36.58000183	35.84000015	36.38999939	45942121	\N	CNY	api	2025-11-09 07:07:12.087776+08
9daaaaf5-4a96-45b0-9110-0faa89148576	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-27	36.38999939	36.68000031	36.11000061	36.59999847	39207688	\N	CNY	api	2025-11-09 07:07:12.088295+08
95bce18a-36d8-4240-a543-bd0c73afa172	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-28	36.59999847	36.84999847	36.18000031	36.47000122	45193910	\N	CNY	api	2025-11-09 07:07:12.089058+08
24d5ae04-a9fc-40f5-9ea6-62d205c72e4c	a7569e62-8eec-4468-8798-d1e948ef4679	2024-11-29	36.59000015	37.00000000	36.31000137	36.34000015	66437999	\N	CNY	api	2025-11-09 07:07:12.089539+08
894e19cc-89c0-4f36-ae4d-eea1b5b44ad3	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-02	36.45000076	36.68000031	36.20000076	36.50999832	42465209	\N	CNY	api	2025-11-09 07:07:12.09007+08
c0ee5e04-155b-4c8b-a649-128383f5bd64	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-03	36.65000153	37.22000122	36.38000107	37.11999893	72198609	\N	CNY	api	2025-11-09 07:07:12.09073+08
ce51e280-b396-4bf7-8adb-155d31bec6cd	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-04	37.09000015	37.09000015	36.52999878	36.81000137	62051124	\N	CNY	api	2025-11-09 07:07:12.091582+08
92fb7281-82cb-4baa-b229-a736b80ae2be	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-05	36.65999985	37.36000061	36.61000061	36.90999985	56894934	\N	CNY	api	2025-11-09 07:07:12.092243+08
2d6caef7-bd08-43ff-b690-590cbbcd03d9	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-06	37.00999832	37.81999969	37.00999832	37.70000076	87723587	\N	CNY	api	2025-11-09 07:07:12.092903+08
91b19353-99b5-49ae-b8b6-5881deb0c9a7	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-09	37.59000015	37.99000168	37.34999847	37.70000076	49299535	\N	CNY	api	2025-11-09 07:07:12.093418+08
ef4f615c-9fa7-4140-bddf-cf0f8350dd6c	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-10	38.79999924	38.99000168	38.40000153	38.59999847	103895319	\N	CNY	api	2025-11-09 07:07:12.093844+08
972c0989-6687-4b54-8d6e-64baac1c1a57	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-11	38.54000092	38.79000092	38.22999954	38.29999924	51770936	\N	CNY	api	2025-11-09 07:07:12.09425+08
68597cc0-e0a7-41f6-8b17-2326422c8572	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-12	38.29000092	38.83000183	38.20999908	38.79999924	58688876	\N	CNY	api	2025-11-09 07:07:12.094909+08
fc147e39-cd38-49ee-8c1c-5e6f410a9360	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-13	38.45000076	38.59999847	37.27999878	37.29999924	111798280	\N	CNY	api	2025-11-09 07:07:12.09535+08
1a6fd6f8-7aa3-43a1-85f6-58943f2f7713	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-16	37.34999847	37.77999878	37.31999969	37.74000168	64031589	\N	CNY	api	2025-11-09 07:07:12.095779+08
d92b06c6-10ce-4c80-bdfd-45f7b58872dc	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-17	37.54000092	38.15999985	37.54000092	37.84999847	60310408	\N	CNY	api	2025-11-09 07:07:12.096347+08
acecb54a-b865-4bbb-a736-91947c9d89cc	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-18	38.02000046	38.65999985	37.86000061	38.52000046	80585536	\N	CNY	api	2025-11-09 07:07:12.096837+08
b102fd78-b39e-4c85-9bd8-1835b1f63298	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-19	38.38000107	38.52999878	38.00000000	38.02000046	61119582	\N	CNY	api	2025-11-09 07:07:12.097369+08
5e2b5129-ec93-4618-b7de-cbde4ee6c4af	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-20	38.04999924	38.27999878	37.86000061	37.90999985	54215038	\N	CNY	api	2025-11-09 07:07:12.097976+08
7934d227-3b22-4a5f-8969-0fd1bac800b4	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-23	37.99000168	38.70000076	37.97999954	38.34999847	90269156	\N	CNY	api	2025-11-09 07:07:12.099706+08
00ad5f72-92aa-4018-a4a6-4508c2c534de	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-24	38.34999847	39.29000092	38.31999969	39.22000122	99342846	\N	CNY	api	2025-11-09 07:07:12.100198+08
fea0b4e0-a7a9-4168-a4af-9a12f586c9aa	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-25	39.22999954	39.56000137	38.99000168	39.40000153	75591307	\N	CNY	api	2025-11-09 07:07:12.100628+08
e5f2694c-5bb8-4d8d-ab4f-8f04490b15ac	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-26	39.40000153	39.54000092	39.00999832	39.47999954	53925194	\N	CNY	api	2025-11-09 07:07:12.101035+08
18ddb394-2d88-4c0f-8e42-25747a2e4bf4	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-27	39.47999954	39.63999939	38.77999878	39.34000015	70031955	\N	CNY	api	2025-11-09 07:07:12.101396+08
cc46f43c-f42a-44f4-a4f1-c861cc9ed0b1	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-30	39.34000015	39.79999924	39.25000000	39.61999893	67884533	\N	CNY	api	2025-11-09 07:07:12.101851+08
251eb15e-ce19-43b5-b61b-2fcc1cd655fb	a7569e62-8eec-4468-8798-d1e948ef4679	2024-12-31	39.56000137	39.90000153	39.29999924	39.29999924	64371699	\N	CNY	api	2025-11-09 07:07:12.102273+08
815c4eab-2f44-4b9c-99de-5049c035bb8c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-02	39.34999847	39.50000000	38.34000015	38.50999832	64200070	\N	CNY	api	2025-11-09 07:07:12.102695+08
a67ba910-f395-4db5-9021-6238de4f16e8	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-03	38.59999847	39.04000092	38.54000092	38.65999985	68258306	\N	CNY	api	2025-11-09 07:07:12.103121+08
ccde4bda-e117-48a5-a263-32e29ed2d81b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-06	38.90000153	39.09999847	38.13000107	39.04999924	61715863	\N	CNY	api	2025-11-09 07:07:12.103503+08
0715901c-4216-4c0b-85f5-93c33f6330aa	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-07	38.97000122	39.15000153	38.61000061	38.90000153	49275205	\N	CNY	api	2025-11-09 07:07:12.103923+08
265f8921-a532-43ee-a2cc-39683f5c87df	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-08	38.83000183	39.54999924	38.81999969	39.27999878	75148102	\N	CNY	api	2025-11-09 07:07:12.104762+08
7dbfdbb1-30e7-408f-a4da-fb30b01be2a6	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-09	39.40000153	39.43000031	38.83000183	39.00000000	44708335	\N	CNY	api	2025-11-09 07:07:12.105293+08
c283391e-42fe-4c1f-b63d-ee688a552555	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-10	39.34000015	39.45000076	38.81000137	38.97999954	48142480	\N	CNY	api	2025-11-09 07:07:12.105933+08
64174e09-244b-45a7-b227-13fafce25fac	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-13	38.93000031	39.15000153	38.54000092	39.06999969	60632274	\N	CNY	api	2025-11-09 07:07:12.106625+08
e03e823d-e991-41c3-8d1c-c116fb869d29	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-14	39.09000015	39.97000122	38.90000153	39.84999847	70801188	\N	CNY	api	2025-11-09 07:07:12.107033+08
915804bd-929a-4634-a8c8-7521f4ffb38d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-15	39.99000168	41.00000000	39.88999939	40.63999939	79670088	\N	CNY	api	2025-11-09 07:07:12.107424+08
5dfe5e0e-2d6f-41b5-a90a-fe3ab8520fe4	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-16	40.65000153	41.15000153	40.52999878	40.99000168	59259386	\N	CNY	api	2025-11-09 07:07:12.107838+08
d21ed925-f422-4be4-a60a-39241e6d1ce4	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-17	40.95999908	41.15999985	40.13000107	40.70999908	47590050	\N	CNY	api	2025-11-09 07:07:12.108195+08
d5f46b17-a943-4807-bc78-a1e7212e42f3	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-20	40.97999954	41.06999969	40.11000061	40.11999893	54257482	\N	CNY	api	2025-11-09 07:07:12.108605+08
0c3d5a66-b780-4ebb-8db7-f0707c167e41	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-21	40.31999969	40.50999832	40.00999832	40.13999939	40068506	\N	CNY	api	2025-11-09 07:07:12.109017+08
ff8ddaf2-652f-499d-becb-7175923f2fbf	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-22	40.13999939	40.15999985	39.31999969	39.45000076	58891222	\N	CNY	api	2025-11-09 07:07:12.109427+08
673e97b9-1a0f-488c-b179-e7219e4f9f78	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-23	39.66999817	40.22999954	39.52000046	39.83000183	60661810	\N	CNY	api	2025-11-09 07:07:12.109857+08
b0960ab9-e509-45df-a5ef-c332ed524a3a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-24	39.65999985	40.54999924	39.45999908	40.25999832	57465234	\N	CNY	api	2025-11-09 07:07:12.110219+08
c72bddf7-0072-41cd-ad65-6be1af98869e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-01-27	40.58000183	40.97000122	40.54999924	40.65000153	52606047	\N	CNY	api	2025-11-09 07:07:12.110592+08
e20330ac-0ee4-4f37-9c32-e339596c1be3	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-05	40.84999847	40.90000153	39.90000153	40.00000000	50478889	\N	CNY	api	2025-11-09 07:07:12.110981+08
fa1c40d0-ad07-4b43-909b-75c03da4e5b3	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-06	40.00000000	40.38000107	39.72999954	40.20000076	46608842	\N	CNY	api	2025-11-09 07:07:12.11151+08
8c48676b-81d9-43b7-8312-505b96410c3c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-07	40.09999847	40.40000153	39.95999908	40.20000076	52106618	\N	CNY	api	2025-11-09 07:07:12.111928+08
ce34f452-9f81-416a-85c7-d529f4d325ce	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-10	40.20000076	40.91999817	39.95999908	40.59999847	58180595	\N	CNY	api	2025-11-09 07:07:12.112465+08
63472a76-6e1c-4302-bd71-c8b8da8faa06	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-11	40.75000000	41.04000092	40.63999939	40.97999954	45777119	\N	CNY	api	2025-11-09 07:07:12.11285+08
e8967a02-9d22-4c7b-8125-33ce9d90b2bc	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-12	40.95999908	41.65999985	40.56000137	41.61999893	60359149	\N	CNY	api	2025-11-09 07:07:12.113276+08
60b21dd6-06a3-477c-9aba-8fd38af7e7a0	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-13	41.65000153	41.95000076	41.34000015	41.70999908	46220698	\N	CNY	api	2025-11-09 07:07:12.113726+08
e0f05dea-8a29-431b-9ad7-ed879951db30	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-14	41.68999863	42.02999878	41.52000046	42.02999878	49873690	\N	CNY	api	2025-11-09 07:07:12.114112+08
0ea89df4-8660-4e24-acf5-147c208ea4d3	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-17	41.99000168	41.99000168	41.36000061	41.72000122	53612561	\N	CNY	api	2025-11-09 07:07:12.114555+08
d96c8669-44fe-42b2-a177-e477446e1827	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-18	41.50999832	42.47999954	41.50999832	42.04999924	54666539	\N	CNY	api	2025-11-09 07:07:12.115291+08
a41abb02-7b19-4270-b7c4-1e09c06db90a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-19	42.00000000	42.15000153	41.75999832	41.97999954	37470223	\N	CNY	api	2025-11-09 07:07:12.115937+08
ed2bc745-46b2-49f2-bd71-ac7bdc2fb96f	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-20	42.00000000	42.09000015	41.68000031	41.84999847	40767508	\N	CNY	api	2025-11-09 07:07:12.116195+08
ff5d9ee4-896b-4d42-8152-4ed7e454c59e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-21	41.95999908	41.99000168	41.22000122	41.40000153	59525579	\N	CNY	api	2025-11-09 07:07:12.116447+08
bab9a647-0852-4167-b239-eaeaca1473ed	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-24	41.38999939	41.75000000	41.09999847	41.27000046	57110709	\N	CNY	api	2025-11-09 07:07:12.116703+08
92871e28-e416-4e58-a370-74f6134d4b13	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-25	41.15000153	41.43999863	40.90999985	41.02999878	50732120	\N	CNY	api	2025-11-09 07:07:12.117051+08
ae0346e9-f205-4b6a-81d6-f2583b9f600d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-26	41.13000107	41.70000076	41.04999924	41.47999954	47644661	\N	CNY	api	2025-11-09 07:07:12.117309+08
0b6b253d-dfc4-48d1-b2c2-e2c6fff5d951	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-27	41.59999847	42.40000153	41.27999878	42.38000107	62259657	\N	CNY	api	2025-11-09 07:07:12.117538+08
a9dd4e68-f65e-4e11-b101-b5d4573750ed	a7569e62-8eec-4468-8798-d1e948ef4679	2025-02-28	42.38000107	42.65999985	42.04999924	42.04999924	70542365	\N	CNY	api	2025-11-09 07:07:12.117775+08
3d9568a2-59a2-4917-ab21-28ff5208616c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-03	42.11999893	42.61999893	41.95000076	42.04999924	47014902	\N	CNY	api	2025-11-09 07:07:12.118021+08
49d13820-256b-4abb-bd4a-eaaaa8c69a0b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-04	41.90999985	42.09999847	41.77000046	41.79999924	31724542	\N	CNY	api	2025-11-09 07:07:12.118294+08
bd4f156e-4d3e-40d7-841d-a3c1f7992f45	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-05	41.95999908	42.90999985	41.75000000	42.88999939	63203743	\N	CNY	api	2025-11-09 07:07:12.118706+08
bcd5f026-b415-4d28-b9e1-70fcc8adc600	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-06	42.88999939	43.09999847	42.45000076	42.95999908	57205304	\N	CNY	api	2025-11-09 07:07:12.11908+08
45f70b59-21e9-4857-adf8-a4cef3d6e070	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-07	42.90000153	43.79999924	42.84999847	43.56999969	60541319	\N	CNY	api	2025-11-09 07:07:12.119448+08
65e8aa53-7846-4f02-a8ec-de65cee5cd6a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-10	43.49000168	43.58000183	42.81999969	43.06999969	50874971	\N	CNY	api	2025-11-09 07:07:12.119815+08
67d82676-2c77-4705-9022-5cf1c3512859	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-11	42.77000046	43.63999939	42.70999908	43.50999832	56574109	\N	CNY	api	2025-11-09 07:07:12.120181+08
f03bea80-a3c0-470d-a906-11424fe5bb0f	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-12	43.50000000	43.86000061	43.25000000	43.54000092	41825836	\N	CNY	api	2025-11-09 07:07:12.120554+08
f2118b67-d5fc-41ba-83fa-2e5e321ecfdc	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-13	43.59999847	44.38000107	43.50000000	43.84000015	58553928	\N	CNY	api	2025-11-09 07:07:12.120924+08
5ead55ee-c5cb-45fa-b6f8-e6a85cf14c95	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-14	44.00000000	45.47000122	43.93999863	45.15999985	91127535	\N	CNY	api	2025-11-09 07:07:12.1213+08
cf56204d-6b2c-425e-852b-32f800bf0117	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-17	45.31999969	45.50000000	44.97999954	45.04000092	65420973	\N	CNY	api	2025-11-09 07:07:12.121893+08
42ace8c2-c618-489f-9852-74705d34ec4d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-18	45.29000092	45.38000107	44.81999969	45.13999939	42822001	\N	CNY	api	2025-11-09 07:07:12.122281+08
96d50855-a750-4c8a-b334-44f9cf2b7dec	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-19	45.27999878	46.09999847	45.09999847	46.02000046	67070594	\N	CNY	api	2025-11-09 07:07:12.12266+08
8c92b0a5-0df2-456e-a6ed-babd14ff0d2c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-20	45.91999817	45.91999817	44.77999878	45.24000168	67865603	\N	CNY	api	2025-11-09 07:07:12.123014+08
2fc98bc9-3280-46c6-9e35-6056f60035fb	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-21	45.11999893	45.34000015	44.52000046	44.70000076	67541170	\N	CNY	api	2025-11-09 07:07:12.123284+08
30aee23d-b543-4369-bf7c-a6fe780d37d9	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-24	44.54999924	45.18999863	44.54999924	45.04999924	44957619	\N	CNY	api	2025-11-09 07:07:12.123565+08
bb4cfdb9-71ac-4da5-a103-338d97f24ed2	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-25	45.00000000	45.50000000	44.95000076	45.09000015	35687155	\N	CNY	api	2025-11-09 07:07:12.123872+08
a4a2a767-0d07-4f45-9847-6199efe71b3d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-26	44.50000000	44.59000015	42.61000061	42.65999985	157832632	\N	CNY	api	2025-11-09 07:07:12.124411+08
b636acd3-00fa-420b-aac8-8d0a8b87c412	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-27	42.75000000	43.74000168	42.74000168	43.25999832	82795081	\N	CNY	api	2025-11-09 07:07:12.124712+08
51a83947-d242-4c09-a7c2-30fd98754900	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-28	43.29999924	43.45000076	43.06000137	43.22000122	38618409	\N	CNY	api	2025-11-09 07:07:12.12501+08
f96eee9b-e350-498d-a89f-fa4659e03dc7	a7569e62-8eec-4468-8798-d1e948ef4679	2025-03-31	43.20999908	43.77999878	42.61000061	43.29000092	53956888	\N	CNY	api	2025-11-09 07:07:12.125297+08
8baedfca-8209-44bd-b87c-e42e18fe560d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-01	43.27999878	43.29000092	42.75000000	42.86999893	38936035	\N	CNY	api	2025-11-09 07:07:12.125594+08
61c098c8-046a-45fa-8464-64635a7da6da	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-02	42.86999893	43.15000153	42.68000031	42.72999954	33120189	\N	CNY	api	2025-11-09 07:07:12.125953+08
a61a79a2-21f1-4195-a17c-ad2c64f8ad0c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-03	42.02000046	42.84999847	42.02000046	42.65000153	46416550	\N	CNY	api	2025-11-09 07:07:12.126412+08
fa207129-01da-43b1-aeec-67e7afca4718	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-07	40.93999863	42.00000000	39.38999939	40.83000183	181563292	\N	CNY	api	2025-11-09 07:07:12.126723+08
40408616-f995-4512-8a84-1c739ca9fee3	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-08	40.77999878	41.20000076	40.43999863	41.15000153	161047736	\N	CNY	api	2025-11-09 07:07:12.127276+08
dbb874a5-d836-42d3-9342-10320cbf4007	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-09	40.59999847	41.02000046	40.29999924	40.45999908	97396935	\N	CNY	api	2025-11-09 07:07:12.127609+08
9ae0cfa5-a8cd-4e77-8e47-f2c1d7760bce	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-10	40.99000168	41.45000076	40.54999924	41.09999847	74378875	\N	CNY	api	2025-11-09 07:07:12.12806+08
faecb030-b7e3-4bfd-9641-b03e2d06aaf4	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-11	41.11000061	41.68999863	40.81000137	41.50999832	58305691	\N	CNY	api	2025-11-09 07:07:12.128493+08
001ef5d6-b376-4e17-8872-eecc50a7488a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-14	41.68000031	41.90999985	41.40999985	41.47999954	48215984	\N	CNY	api	2025-11-09 07:07:12.128925+08
3c88c4b3-846a-4504-a4ad-a4e58a80fbfc	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-15	41.49000168	42.29000092	41.45000076	42.09999847	61456386	\N	CNY	api	2025-11-09 07:07:12.12933+08
e1610902-e18f-4118-baf6-61119e7517da	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-16	41.97999954	42.58000183	41.81999969	42.25000000	57629358	\N	CNY	api	2025-11-09 07:07:12.12973+08
8b0fe95c-84ec-4e6d-b4f0-b2e981b900ed	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-17	42.11999893	42.36000061	41.84999847	42.11999893	40579288	\N	CNY	api	2025-11-09 07:07:12.130144+08
8c288dfa-b220-44c3-9fb5-7c9f023024fe	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-18	42.13000107	42.79000092	42.04999924	42.75000000	43500128	\N	CNY	api	2025-11-09 07:07:12.130522+08
01a639f7-39d2-4db8-a9a5-716566dec2c8	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-21	42.65999985	43.08000183	42.27999878	42.27999878	41646585	\N	CNY	api	2025-11-09 07:07:12.130917+08
b06024b9-51e7-46e1-851b-932a79462b1e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-22	42.31000137	42.54000092	42.00999832	42.00999832	43378813	\N	CNY	api	2025-11-09 07:07:12.131296+08
c73cbec1-46b5-430f-b4d0-8450bc85cd8f	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-23	42.29999924	42.29999924	41.77000046	41.99000168	46774359	\N	CNY	api	2025-11-09 07:07:12.131716+08
01e1d668-9983-4f38-b41b-0e6e25cea90b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-24	42.00000000	42.38000107	41.95000076	42.20999908	41365185	\N	CNY	api	2025-11-09 07:07:12.13208+08
75e9f155-7b1a-45ee-8917-c917fd3efd37	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-25	42.29000092	42.54999924	42.04000092	42.08000183	42434993	\N	CNY	api	2025-11-09 07:07:12.132463+08
fd6e53fa-53a7-4325-a7b8-80500ee5e9aa	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-28	42.15000153	42.56000137	42.02999878	42.34999847	38697317	\N	CNY	api	2025-11-09 07:07:12.132862+08
37de8256-bc7b-4ea7-9639-70a3efb93786	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-29	42.34999847	42.65000153	42.00000000	42.00000000	45769853	\N	CNY	api	2025-11-09 07:07:12.133305+08
63af3b50-42ae-46fa-b69a-95c6ab89bac1	a7569e62-8eec-4468-8798-d1e948ef4679	2025-04-30	41.63999939	41.63999939	40.50999832	40.74000168	117268210	\N	CNY	api	2025-11-09 07:07:12.1336+08
4b08cac1-88c7-453a-928e-22a30fd28d1c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-06	40.90000153	41.40999985	40.50999832	41.36999893	66640999	\N	CNY	api	2025-11-09 07:07:12.134202+08
c7823b72-d857-4b7c-8b37-cf77b4bde018	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-07	41.79000092	42.22999954	41.31000137	42.02000046	71291388	\N	CNY	api	2025-11-09 07:07:12.134614+08
2ab5c7d5-b690-452a-a064-c1c3883f5a34	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-08	42.00999832	43.41999817	42.00000000	42.79999924	83380964	\N	CNY	api	2025-11-09 07:07:12.135025+08
95388b8f-d29a-441b-baf4-98434f2fbc68	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-09	42.79999924	43.59999847	42.79999924	43.47999954	66815472	\N	CNY	api	2025-11-09 07:07:12.135493+08
3d20807f-1687-4bfe-af3d-69a109353f3c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-12	43.45000076	44.40000153	43.11000061	43.79999924	84897409	\N	CNY	api	2025-11-09 07:07:12.135935+08
8835e0fe-ddce-4912-8cfb-dfa6187550b4	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-13	44.09000015	44.65000153	43.84999847	44.56000137	69912417	\N	CNY	api	2025-11-09 07:07:12.136308+08
e8520b2a-2486-4590-ba01-4a4533bf0a70	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-14	44.54999924	45.29999924	44.31999969	44.81000137	71279018	\N	CNY	api	2025-11-09 07:07:12.136683+08
984783a0-fb8b-45d3-a407-b10cc8e58119	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-15	44.83000183	45.38000107	44.65000153	44.91999817	68460048	\N	CNY	api	2025-11-09 07:07:12.137067+08
89edd9ed-fb93-4b74-b715-185b7d8495a8	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-16	44.75000000	44.97999954	44.02999878	44.27000046	61965535	\N	CNY	api	2025-11-09 07:07:12.137435+08
afe1ea32-e621-4c99-9ea6-9ee0084fa737	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-19	44.20000076	44.45999908	43.75000000	43.84000015	50281701	\N	CNY	api	2025-11-09 07:07:12.137812+08
98c5d642-9053-4747-af85-9e2e57c7e1f1	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-20	44.02999878	44.61000061	43.86999893	43.90000153	50053483	\N	CNY	api	2025-11-09 07:07:12.138203+08
78432107-750c-40a8-8f3e-b01a1360ce05	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-21	43.95000076	44.36999893	43.84000015	43.90000153	49920035	\N	CNY	api	2025-11-09 07:07:12.138541+08
0e798892-4f9d-4fae-b4a0-8e4d2c4e17b1	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-22	43.90000153	44.56000137	43.75000000	44.50999832	56565562	\N	CNY	api	2025-11-09 07:07:12.138902+08
c2dabc8e-91be-4828-982a-c829068e49ab	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-23	44.61999893	44.68000031	43.90000153	44.04999924	54146009	\N	CNY	api	2025-11-09 07:07:12.139315+08
596c51e0-d55b-4359-9c5f-c4884ac0d289	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-26	43.88999939	44.16999817	43.63000107	43.79999924	45609975	\N	CNY	api	2025-11-09 07:07:12.139667+08
574d8953-bb5a-4efc-a990-3e40ecc3863d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-27	43.79999924	44.15000153	43.66999817	43.74000168	36375001	\N	CNY	api	2025-11-09 07:07:12.139994+08
a23419dd-d144-4907-9e64-1a1a845afdc4	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-28	43.77999878	44.04999924	43.59999847	43.68000031	30035524	\N	CNY	api	2025-11-09 07:07:12.140292+08
d1892c9e-2e63-43b8-943c-442b8c711de6	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-29	43.70000076	43.95000076	43.45000076	43.47000122	49298970	\N	CNY	api	2025-11-09 07:07:12.140618+08
6a11b3a9-4114-4d1f-9e8d-94a2d4065d82	a7569e62-8eec-4468-8798-d1e948ef4679	2025-05-30	43.54999924	43.88000107	43.34999847	43.43000031	57139144	\N	CNY	api	2025-11-09 07:07:12.140956+08
5173d3fa-e899-42dd-ab5e-a47dde7efdbc	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-03	43.50000000	44.43000031	43.50000000	43.97000122	50368513	\N	CNY	api	2025-11-09 07:07:12.141508+08
af615082-dda8-4318-8a68-c1d2bfd6febc	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-04	44.04999924	44.27000046	43.90000153	44.06000137	37341667	\N	CNY	api	2025-11-09 07:07:12.141863+08
182a173d-2d44-4919-a5c9-208da92d7ea3	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-05	44.06000137	44.41999817	44.00000000	44.36999893	42131680	\N	CNY	api	2025-11-09 07:07:12.142242+08
34c8c111-bca9-4adb-91ec-95928a197c94	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-06	44.45000076	44.70999908	44.29999924	44.47000122	37349895	\N	CNY	api	2025-11-09 07:07:12.142697+08
fb0a5129-a0f7-46bf-ab81-f91e01c0e13a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-09	44.59999847	44.68000031	44.20999908	44.59999847	47477446	\N	CNY	api	2025-11-09 07:07:12.143045+08
337c2e17-3af2-4718-a5d0-a200e6b6e06f	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-10	44.56999969	45.04999924	44.45000076	44.66999817	52834892	\N	CNY	api	2025-11-09 07:07:12.143359+08
dbe96f54-e511-4a1e-95df-b03816e546aa	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-11	44.72000122	45.68000031	44.72000122	45.31000137	77676108	\N	CNY	api	2025-11-09 07:07:12.143702+08
422a68a1-144e-4fe2-93b2-a4056edc6b84	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-12	45.40000153	45.65000153	45.09999847	45.22999954	45239070	\N	CNY	api	2025-11-09 07:07:12.144026+08
0e2f8e27-6020-48e3-8b08-4dbf8a18765a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-13	45.24000168	45.34999847	44.95000076	45.18000031	47408056	\N	CNY	api	2025-11-09 07:07:12.144388+08
c6553645-7ad9-4f4f-b825-b763deab8c36	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-16	45.08000183	45.81000137	44.95000076	45.77999878	41447435	\N	CNY	api	2025-11-09 07:07:12.144785+08
b6fa0e57-e717-4a59-ad55-1c4f67142a1d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-17	45.88000107	46.04999924	45.70999908	45.97999954	47420901	\N	CNY	api	2025-11-09 07:07:12.145111+08
fb131de5-d564-4c73-99d3-12e03d942f50	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-18	45.91999817	46.06999969	45.65000153	45.84999847	42642859	\N	CNY	api	2025-11-09 07:07:12.145437+08
0748756f-97dd-42a7-9a59-7602c73da11b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-19	45.84000015	46.06000137	45.36999893	45.63000107	51345430	\N	CNY	api	2025-11-09 07:07:12.145787+08
bea0df40-40c9-4cde-b1aa-5455864b1579	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-20	45.72999954	46.18000031	45.54999924	45.99000168	44815652	\N	CNY	api	2025-11-09 07:07:12.146152+08
e3976b80-0f0d-4642-ba39-d8e66078650c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-23	45.90000153	46.34000015	45.43000031	46.25000000	53893148	\N	CNY	api	2025-11-09 07:07:12.14652+08
2594f84d-ff09-4e58-91d0-ff71ce8feb9d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-24	46.31000137	47.00000000	46.18000031	46.75000000	65581461	\N	CNY	api	2025-11-09 07:07:12.1469+08
12ed5361-5183-46f3-bcb6-c2955d1c9d44	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-25	46.75000000	47.50000000	46.59000015	47.50000000	60767987	\N	CNY	api	2025-11-09 07:07:12.147267+08
7452f689-6fd3-4840-9d3c-2b75ff30a3cd	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-26	47.49000168	47.88000107	47.04999924	47.88000107	59020064	\N	CNY	api	2025-11-09 07:07:12.147597+08
ca80e6d7-dabe-4ef3-8611-88f4e775c6ea	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-27	47.84999847	47.86999893	46.04000092	46.22000122	95414320	\N	CNY	api	2025-11-09 07:07:12.147964+08
545e707e-9b21-4f8b-b126-1dd9cd90c44d	a7569e62-8eec-4468-8798-d1e948ef4679	2025-06-30	46.13000107	46.29000092	45.77000046	45.95000076	62461363	\N	CNY	api	2025-11-09 07:07:12.148319+08
64ba91cd-55e0-4461-87cf-03af3b177e89	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-01	45.95999908	46.66999817	45.91999817	46.45000076	45061309	\N	CNY	api	2025-11-09 07:07:12.148808+08
142e41b2-4980-425b-8950-ce4c7ac973d3	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-02	46.70000076	47.15999985	46.45000076	46.90000153	51856318	\N	CNY	api	2025-11-09 07:07:12.149128+08
df344973-274e-495f-b30c-b6e3a5d7498e	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-03	46.90000153	46.95000076	46.34000015	46.61000061	55622576	\N	CNY	api	2025-11-09 07:07:12.14942+08
ee698928-fda4-4d25-acf0-dd2698b49d54	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-04	46.59999847	47.50000000	46.40000153	47.06999969	67894832	\N	CNY	api	2025-11-09 07:07:12.149682+08
8ac4ffc3-e3c1-4a3c-a580-728a4dfceb02	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-07	47.06999969	47.29999924	46.70000076	47.20000076	56742742	\N	CNY	api	2025-11-09 07:07:12.150081+08
b777fd3e-5147-4d97-adf3-c1fd27233cea	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-08	47.27999878	47.66999817	47.09999847	47.61999893	63742101	\N	CNY	api	2025-11-09 07:07:12.150397+08
3ce29dcd-37ae-491b-921b-a576ca30b74c	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-09	47.50000000	47.77000046	47.13000107	47.13000107	61456635	\N	CNY	api	2025-11-09 07:07:12.150781+08
a44e8bb1-97a0-4e54-8262-1216b14f2bd7	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-10	47.09999847	48.54999924	47.09999847	48.24000168	121978404	\N	CNY	api	2025-11-09 07:07:12.151149+08
5fab7073-a68f-4f45-8825-d4858ee1c7a2	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-11	46.27999878	46.50000000	45.61999893	45.63999939	118444284	\N	CNY	api	2025-11-09 07:07:12.151505+08
31566152-4c58-49af-85ed-ca252d8b3f43	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-14	45.65000153	46.09000015	45.43999863	45.56999969	64848437	\N	CNY	api	2025-11-09 07:07:12.151853+08
ec43ac7f-bed0-422a-b2c6-559985709e09	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-15	45.77000046	45.91999817	44.79999924	45.22000122	66620626	\N	CNY	api	2025-11-09 07:07:12.152192+08
fc8e6b63-baeb-4517-9d8d-5cedfb5e3fc1	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-16	45.25999832	45.54000092	44.88000107	45.11000061	46818639	\N	CNY	api	2025-11-09 07:07:12.152559+08
5fbbd429-1127-442e-b6fd-c4795e4bfe45	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-17	45.09999847	45.33000183	44.90999985	45.00000000	41689506	\N	CNY	api	2025-11-09 07:07:12.152905+08
708c2764-4502-4da3-afdc-54dd2107c841	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-18	45.04999924	45.15999985	44.74000168	45.04999924	54343057	\N	CNY	api	2025-11-09 07:07:12.15328+08
1d929c30-ad2b-491b-8b8c-5cd604926497	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-21	45.04999924	45.22999954	44.83000183	44.84999847	56641201	\N	CNY	api	2025-11-09 07:07:12.153595+08
8ffbeb16-71e8-4679-840e-1e33c26c1f21	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-22	44.84999847	44.97999954	44.20999908	44.93999863	92231906	\N	CNY	api	2025-11-09 07:07:12.153918+08
34d3976b-6300-4ac4-8db1-d721ad665980	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-23	44.97000122	45.70000076	44.95999908	45.11999893	85324905	\N	CNY	api	2025-11-09 07:07:12.15424+08
89f4dc1b-3981-40c1-8775-802cab1efe8a	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-24	45.20999908	45.36000061	44.79999924	44.88000107	82662013	\N	CNY	api	2025-11-09 07:07:12.15458+08
ed58265a-721f-4b96-a1c2-6a3e82ba8894	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-25	44.84000015	45.16999817	44.75000000	44.83000183	69626423	\N	CNY	api	2025-11-09 07:07:12.1549+08
290d652f-ad3c-48aa-88aa-b09e4563d86b	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-28	44.79999924	45.15999985	44.40999985	44.43999863	63512720	\N	CNY	api	2025-11-09 07:07:12.155219+08
4514a5a4-f743-45cb-8bf3-e6bbf09d4480	a7569e62-8eec-4468-8798-d1e948ef4679	2025-07-29	44.43999863	44.79999924	44.13999939	44.13999939	78581282	\N	CNY	api	2025-11-09 07:07:12.155691+08
f8bc208b-ef2d-4114-97e1-2aa29849f73b	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-11	1590.00000000	1609.94995117	1567.18994141	1598.01000977	4385365	\N	CNY	api	2025-11-09 07:07:12.584513+08
58e219b5-85c8-48ab-aa5a-77651b3a98be	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-12	1589.00000000	1623.00000000	1573.94995117	1577.19995117	4922266	\N	CNY	api	2025-11-09 07:07:12.585516+08
ae1a4cc7-1ca0-4ff8-b2b1-c4d2fa296dc8	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-13	1568.00000000	1586.66003418	1561.28002930	1578.50000000	2912526	\N	CNY	api	2025-11-09 07:07:12.58588+08
ba498bc1-7bae-4fed-afaa-13b59c0d48f2	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-14	1570.00000000	1594.44995117	1565.65002441	1573.80004883	2924814	\N	CNY	api	2025-11-09 07:07:12.586203+08
edb50cc9-44eb-457a-a91a-10c77ea153db	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-15	1569.00000000	1581.00000000	1553.00000000	1559.00000000	3376112	\N	CNY	api	2025-11-09 07:07:12.586889+08
eb1db7de-684d-4656-8690-c1e3f9438c43	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-18	1562.00000000	1575.98999023	1555.00000000	1559.00000000	2709219	\N	CNY	api	2025-11-09 07:07:12.587352+08
a9fb8d9a-4f2b-43a9-a04b-f6ccb8df4f14	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-19	1565.00000000	1569.36999512	1525.00000000	1541.92004395	3326643	\N	CNY	api	2025-11-09 07:07:12.587731+08
39a061e9-90a0-4ffe-b6eb-ce3f4c0903df	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-20	1543.00000000	1553.96997070	1531.30004883	1544.81005859	2134455	\N	CNY	api	2025-11-09 07:07:12.588044+08
9d14f409-bf9e-43db-ad60-b1dde47d4834	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-21	1543.86999512	1548.98999023	1532.00000000	1545.13000488	1826179	\N	CNY	api	2025-11-09 07:07:12.588358+08
7548b842-d5be-4952-aae0-06534b1afb2f	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-22	1541.15002441	1547.77001953	1507.81994629	1507.81994629	3343611	\N	CNY	api	2025-11-09 07:07:12.588896+08
7deaada4-2459-4218-b2d5-b36141ae7759	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-25	1511.00000000	1532.00000000	1496.67004395	1498.56994629	3318556	\N	CNY	api	2025-11-09 07:07:12.589133+08
d1f62051-dac7-41c6-9f42-477131608bb4	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-26	1498.56994629	1518.88000488	1488.88000488	1509.00000000	2574479	\N	CNY	api	2025-11-09 07:07:12.589388+08
90b334a7-99a9-4653-a551-74dd33282bd5	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-27	1509.00000000	1522.15002441	1505.00000000	1519.05004883	2593417	\N	CNY	api	2025-11-09 07:07:12.589659+08
d95de23b-ce8e-4ffa-bd75-d4da8d047c87	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-28	1522.00000000	1524.98999023	1502.00000000	1518.00000000	2395203	\N	CNY	api	2025-11-09 07:07:12.590004+08
9b6d61d8-3e60-4a67-884f-6bc95f1767c6	49589118-facc-4785-abf3-3d2d4d054f17	2024-11-29	1517.00000000	1555.00000000	1513.20996094	1525.73999023	3608810	\N	CNY	api	2025-11-09 07:07:12.590402+08
6735788e-1b60-41de-a64f-def602d1800e	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-02	1526.00000000	1529.98999023	1515.09997559	1525.00000000	2681954	\N	CNY	api	2025-11-09 07:07:12.590665+08
b52894dc-8f3e-4c0f-acd5-d372736d30d9	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-03	1524.00000000	1528.90002441	1516.07995605	1526.73999023	2480662	\N	CNY	api	2025-11-09 07:07:12.590941+08
37330906-56c4-4e22-be60-45be40e62fa7	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-04	1520.06994629	1523.66003418	1510.00000000	1520.00000000	2392389	\N	CNY	api	2025-11-09 07:07:12.591222+08
559297bc-1acf-445f-bae5-e7f6a2b38985	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-05	1510.85998535	1517.85998535	1510.00000000	1511.00000000	1614147	\N	CNY	api	2025-11-09 07:07:12.59153+08
241ce5d5-5388-4487-b648-657e0c7671d2	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-06	1513.00000000	1538.90002441	1508.06994629	1521.01000977	3203969	\N	CNY	api	2025-11-09 07:07:12.591822+08
ecd07947-9334-437b-afa4-fc613fb18b01	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-09	1522.02001953	1529.71997070	1513.19995117	1518.80004883	1979986	\N	CNY	api	2025-11-09 07:07:12.59206+08
4e77a4c6-d1f2-4bce-b0d2-f513a3368f97	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-10	1570.00000000	1579.72998047	1545.18005371	1546.58996582	6031210	\N	CNY	api	2025-11-09 07:07:12.592325+08
4f81a521-b6e0-4418-862e-06f93e5ce4a2	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-11	1540.00000000	1555.00000000	1530.97998047	1535.59997559	2967112	\N	CNY	api	2025-11-09 07:07:12.592735+08
3550b89c-e29b-4c4c-a95f-eca7ce34a30c	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-12	1532.02001953	1566.00000000	1529.00000000	1565.80004883	4193652	\N	CNY	api	2025-11-09 07:07:12.593468+08
86013864-40c3-4f92-a616-61089479295a	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-13	1550.01000977	1554.98999023	1518.88000488	1519.00000000	4951197	\N	CNY	api	2025-11-09 07:07:12.593927+08
361700e8-6b75-499b-a549-28497fa1335d	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-16	1521.00000000	1529.00000000	1510.70996094	1527.19995117	3253710	\N	CNY	api	2025-11-09 07:07:12.594289+08
5dcdd3de-2010-4e3e-9ba6-da72c4f94980	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-17	1525.98999023	1569.00000000	1521.01000977	1558.00000000	5417163	\N	CNY	api	2025-11-09 07:07:12.59493+08
17c31e5c-9299-405e-9dd5-0fc889ea74d6	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-18	1557.96997070	1577.00000000	1547.09997559	1571.50000000	4116226	\N	CNY	api	2025-11-09 07:07:12.595362+08
c7e51d7c-7119-4286-8c69-bee9641c43c6	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-19	1565.14001465	1567.93005371	1550.32995605	1551.01000977	2480932	\N	CNY	api	2025-11-09 07:07:12.595853+08
3c171769-871b-4dd9-9391-5316c6b7954b	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-20	1531.13000488	1541.80004883	1520.02001953	1522.00000000	2815774	\N	CNY	api	2025-11-09 07:07:12.596169+08
11cdb706-e576-4017-bf6c-57d8c59edbae	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-23	1523.00000000	1538.00000000	1517.00000000	1526.44995117	2160269	\N	CNY	api	2025-11-09 07:07:12.596872+08
8c12dcfb-6e08-4456-b958-9bfb8cedf63b	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-24	1525.00000000	1544.00000000	1521.58996582	1538.81994629	2210492	\N	CNY	api	2025-11-09 07:07:12.597233+08
64d15b96-5351-46a2-8cdd-876c9894d4f4	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-25	1538.80004883	1538.80004883	1526.09997559	1530.00000000	1712339	\N	CNY	api	2025-11-09 07:07:12.597585+08
a360f635-ff3f-4dbf-abd3-417d3739d33f	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-26	1534.00000000	1538.78002930	1523.00000000	1527.79003906	1828651	\N	CNY	api	2025-11-09 07:07:12.597882+08
e4ffe83a-53fd-464b-9a70-470fe18fd5cf	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-27	1528.90002441	1536.00000000	1519.50000000	1528.96997070	2075932	\N	CNY	api	2025-11-09 07:07:12.59822+08
2065580f-feb5-4de0-8e3e-2eed5c060c42	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-30	1533.96997070	1543.95996094	1525.00000000	1525.00000000	2512982	\N	CNY	api	2025-11-09 07:07:12.598521+08
4f2878ee-9c00-46f2-baaf-f52423e551f8	49589118-facc-4785-abf3-3d2d4d054f17	2024-12-31	1525.40002441	1545.00000000	1522.01000977	1524.00000000	3935445	\N	CNY	api	2025-11-09 07:07:12.598849+08
e73bc311-b40e-4067-8cd3-27981ff90526	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-02	1524.00000000	1524.48999023	1480.00000000	1488.00000000	5002870	\N	CNY	api	2025-11-09 07:07:12.599205+08
60751aa5-2347-455b-b28f-b774e97823c9	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-03	1494.50000000	1494.98999023	1467.01000977	1475.00000000	3262836	\N	CNY	api	2025-11-09 07:07:12.599535+08
a34ac1f7-22b5-49f6-b763-6bac2fc83c63	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-06	1453.00000000	1462.66003418	1432.80004883	1440.00000000	4425512	\N	CNY	api	2025-11-09 07:07:12.599792+08
fe6c5cd3-f9c9-4d5c-967f-f8dc60d64671	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-07	1444.66003418	1451.89001465	1439.00000000	1440.19995117	2422118	\N	CNY	api	2025-11-09 07:07:12.600072+08
ffd42f31-2ccc-42be-9373-e0a1501ec298	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-08	1440.00000000	1451.81994629	1426.66003418	1442.50000000	3525821	\N	CNY	api	2025-11-09 07:07:12.60032+08
fba5858a-952c-448c-bb6c-51793267ff3a	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-09	1448.98999023	1464.57995605	1432.97998047	1444.00000000	2970565	\N	CNY	api	2025-11-09 07:07:12.600576+08
59781d15-a76e-44e7-931b-beaca3dc76df	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-10	1447.09997559	1451.94995117	1436.00000000	1436.00000000	2187195	\N	CNY	api	2025-11-09 07:07:12.600829+08
5e43669d-17a3-4910-9a2f-6187cb26fe4a	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-13	1425.00000000	1444.43994141	1422.01000977	1443.97998047	2108251	\N	CNY	api	2025-11-09 07:07:12.60108+08
3c1db5d0-646c-44b4-9826-fbebde4872ed	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-14	1444.94995117	1478.68005371	1442.00000000	1472.50000000	3095657	\N	CNY	api	2025-11-09 07:07:12.60133+08
0c60000f-223f-4dde-8a08-86cdb2675051	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-15	1467.00000000	1474.59997559	1460.01000977	1471.27001953	1839934	\N	CNY	api	2025-11-09 07:07:12.601601+08
f61dc787-dd53-4a3c-b189-510be351a093	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-16	1474.00000000	1482.66003418	1442.00000000	1446.38000488	2634213	\N	CNY	api	2025-11-09 07:07:12.601849+08
51681f98-7f01-4782-b55e-eea6020f8409	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-17	1446.39001465	1461.00000000	1446.38000488	1454.75000000	1830894	\N	CNY	api	2025-11-09 07:07:12.602136+08
d28acdf2-282f-43ad-9586-76103f2b6e78	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-20	1461.00000000	1489.79003906	1460.00000000	1474.80004883	3140975	\N	CNY	api	2025-11-09 07:07:12.602389+08
dfd4ff8f-5764-4ae9-ac13-08f541f53c62	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-21	1481.00000000	1482.00000000	1465.00000000	1468.15002441	1685604	\N	CNY	api	2025-11-09 07:07:12.602865+08
28d52642-b644-4b9a-9012-6f53f8604b6a	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-22	1463.27001953	1467.94995117	1438.00000000	1441.00000000	2829384	\N	CNY	api	2025-11-09 07:07:12.603143+08
fcdc9b96-854b-4e90-ae3c-d38f63d16356	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-23	1449.96997070	1468.00000000	1438.00000000	1443.00000000	2712504	\N	CNY	api	2025-11-09 07:07:12.603577+08
45152b25-ad4a-4a95-b02f-fd25056ec10d	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-24	1442.00000000	1447.79003906	1430.31005859	1436.00000000	3136034	\N	CNY	api	2025-11-09 07:07:12.603879+08
833c1879-1415-4f9b-b3eb-550950e35f99	49589118-facc-4785-abf3-3d2d4d054f17	2025-01-27	1437.00000000	1443.96997070	1427.02001953	1434.98999023	2935646	\N	CNY	api	2025-11-09 07:07:12.604163+08
31721104-f7cc-4701-9039-14ea8caae6bb	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-05	1440.00000000	1443.00000000	1402.20996094	1403.80004883	4075652	\N	CNY	api	2025-11-09 07:07:12.604408+08
469917e7-d1af-4950-9558-45a58a4f0c36	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-06	1400.01000977	1421.98999023	1400.01000977	1412.83996582	2735582	\N	CNY	api	2025-11-09 07:07:12.604688+08
ec33cb2b-fc2b-423c-9c69-d7bb01dc23d4	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-07	1413.68005371	1442.68005371	1403.41003418	1436.00000000	3724207	\N	CNY	api	2025-11-09 07:07:12.60494+08
9125776c-5692-4414-83c8-83cde50a64d0	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-10	1438.00000000	1440.00000000	1427.08996582	1431.51000977	2083979	\N	CNY	api	2025-11-09 07:07:12.605207+08
3579aebf-aa54-41fa-ba93-c81e64c9785a	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-11	1434.94995117	1435.95996094	1415.90002441	1418.00000000	2357283	\N	CNY	api	2025-11-09 07:07:12.605448+08
4535e0c2-4dd3-47d3-b8a8-2d8e642c2cf7	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-12	1418.00000000	1445.00000000	1416.88000488	1443.00000000	2547579	\N	CNY	api	2025-11-09 07:07:12.605902+08
dc0a370d-6a5c-42f0-8d66-cdea6cb1f50a	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-13	1443.02001953	1475.25000000	1434.51000977	1465.06005859	4338536	\N	CNY	api	2025-11-09 07:07:12.606284+08
39eda30f-fd64-4e30-80a0-43a18b3ddeb5	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-14	1465.06005859	1477.00000000	1458.21997070	1475.00000000	2709992	\N	CNY	api	2025-11-09 07:07:12.606502+08
0d281fdc-a111-4662-98ab-afaea23ac0b8	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-17	1481.00000000	1494.97998047	1467.09997559	1471.61999512	3247059	\N	CNY	api	2025-11-09 07:07:12.60683+08
78ef7e03-01fc-4339-897e-23142ecda202	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-18	1470.00000000	1492.98999023	1462.07995605	1475.00000000	2779992	\N	CNY	api	2025-11-09 07:07:12.607065+08
5f994b8a-526b-4c39-ae99-b7e87a3a964d	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-19	1475.05004883	1494.43994141	1464.90002441	1491.00000000	3239331	\N	CNY	api	2025-11-09 07:07:12.607409+08
ce88d3e6-b849-43c6-9c77-deaea80ee393	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-20	1483.00000000	1491.96997070	1473.39001465	1474.00000000	2374973	\N	CNY	api	2025-11-09 07:07:12.607689+08
e9198089-34b8-4099-9e11-97d7e0a7b8d7	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-21	1480.00000000	1496.72998047	1473.01000977	1488.20996094	3641783	\N	CNY	api	2025-11-09 07:07:12.607938+08
74d4f458-a5a3-4323-b465-2133be9080f0	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-24	1488.00000000	1499.52001953	1474.00000000	1479.06994629	3474373	\N	CNY	api	2025-11-09 07:07:12.608173+08
48c5d21f-a55f-40fb-ad9f-62e0f8aa02b5	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-25	1470.01000977	1473.39001465	1452.00000000	1454.00000000	2838743	\N	CNY	api	2025-11-09 07:07:12.608656+08
5c58cb29-de02-47cc-b2ae-6790b5dbbc18	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-26	1455.44995117	1464.95996094	1445.00000000	1460.01000977	2636609	\N	CNY	api	2025-11-09 07:07:12.60887+08
0901b296-98c1-411e-86ea-bbac7365a8bd	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-27	1460.02001953	1489.90002441	1454.00000000	1485.56005859	4976217	\N	CNY	api	2025-11-09 07:07:12.609089+08
4eda08e7-048c-4cea-a1b1-df5084547ae5	49589118-facc-4785-abf3-3d2d4d054f17	2025-02-28	1485.50000000	1528.38000488	1482.00000000	1500.79003906	5612895	\N	CNY	api	2025-11-09 07:07:12.609334+08
7da4d807-d539-4d03-87bb-3128a054f336	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-03	1502.59997559	1520.98999023	1481.50000000	1487.02001953	3159566	\N	CNY	api	2025-11-09 07:07:12.609571+08
b15a9f0b-3833-4394-a94b-cfb478711228	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-04	1485.00000000	1486.00000000	1465.20996094	1470.10998535	2521121	\N	CNY	api	2025-11-09 07:07:12.6098+08
0a591d0c-dfa9-493f-8669-ef1c03c305b4	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-05	1472.00000000	1474.00000000	1460.09997559	1466.36999512	2460522	\N	CNY	api	2025-11-09 07:07:12.610061+08
58fdf04d-6fb3-49bc-adf1-efbe57794272	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-06	1474.00000000	1510.19995117	1472.07995605	1505.97998047	4216764	\N	CNY	api	2025-11-09 07:07:12.610289+08
50b4cf7d-6967-42ec-8786-5e33b9118f68	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-07	1503.00000000	1528.35998535	1503.00000000	1521.00000000	3799135	\N	CNY	api	2025-11-09 07:07:12.610521+08
487c1368-4a53-4f37-865d-7288e5e3e356	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-10	1519.81005859	1526.88000488	1506.14001465	1522.90002441	3136907	\N	CNY	api	2025-11-09 07:07:12.610792+08
2283110b-2f3f-4a62-8961-60b893c081db	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-11	1517.00000000	1548.68005371	1512.00000000	1548.68005371	3977560	\N	CNY	api	2025-11-09 07:07:12.611024+08
4792e851-6dd9-4a6c-b0d4-241e9a43030b	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-12	1546.95996094	1549.68005371	1526.34997559	1542.57995605	2960396	\N	CNY	api	2025-11-09 07:07:12.611252+08
b7e63dd8-901f-4dc9-880b-03547f4fa14b	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-13	1544.00000000	1555.50000000	1530.88000488	1537.77001953	2572439	\N	CNY	api	2025-11-09 07:07:12.611509+08
989c6908-960a-4e63-96d8-d05a7ec69781	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-14	1547.66003418	1628.01000977	1541.00000000	1628.01000977	9291315	\N	CNY	api	2025-11-09 07:07:12.611745+08
a5278714-ce20-4588-ad14-8d1e94846bb2	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-17	1657.00000000	1657.98999023	1626.88000488	1637.85998535	5468913	\N	CNY	api	2025-11-09 07:07:12.611956+08
3eed3456-a79d-43d0-b4ec-5b747b04d83f	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-18	1645.04003906	1652.00000000	1621.69995117	1624.00000000	3161345	\N	CNY	api	2025-11-09 07:07:12.612166+08
dedadc04-0f4f-4c0d-9ba3-6c2517762134	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-19	1624.29003906	1648.00000000	1623.00000000	1635.70996094	2738955	\N	CNY	api	2025-11-09 07:07:12.6124+08
59809c11-1ebb-47ce-8ff5-bc1180018fbd	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-20	1635.70996094	1637.59997559	1595.06994629	1604.00000000	3673677	\N	CNY	api	2025-11-09 07:07:12.612637+08
cf94cfbe-a0da-4ced-8867-2790d76bd5c6	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-21	1599.00000000	1612.19995117	1568.82995605	1573.75000000	3361430	\N	CNY	api	2025-11-09 07:07:12.612858+08
cfbdbbf2-5871-44b0-bd53-d088e322a71f	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-24	1570.00000000	1589.66003418	1562.38000488	1583.00000000	2556585	\N	CNY	api	2025-11-09 07:07:12.61307+08
0334d58a-1b6a-4422-ae85-3062b112bfa5	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-25	1588.00000000	1592.80004883	1566.66003418	1575.50000000	1767438	\N	CNY	api	2025-11-09 07:07:12.613436+08
388c8b99-05af-4797-b0b4-943f4e312d34	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-26	1572.77001953	1582.57995605	1571.00000000	1576.00000000	1432356	\N	CNY	api	2025-11-09 07:07:12.613645+08
e2cb3adf-a875-4170-be52-779531a7dd21	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-27	1576.00000000	1598.25000000	1573.38000488	1589.00000000	1795563	\N	CNY	api	2025-11-09 07:07:12.613859+08
4dc9c413-7adc-4318-95c3-81b3d58310c9	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-28	1590.93005371	1593.00000000	1576.00000000	1585.20996094	1622789	\N	CNY	api	2025-11-09 07:07:12.614077+08
f1d34dac-ee7c-4d89-a51e-20a100460344	49589118-facc-4785-abf3-3d2d4d054f17	2025-03-31	1580.97998047	1586.95996094	1560.06005859	1561.00000000	2108494	\N	CNY	api	2025-11-09 07:07:12.614313+08
c5e35493-c09e-455b-919c-701f4e0ac895	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-01	1564.00000000	1569.89001465	1552.20996094	1556.02001953	1855644	\N	CNY	api	2025-11-09 07:07:12.614536+08
273a2005-ede7-4e67-9280-d476a17830bb	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-02	1558.00000000	1567.80004883	1545.50000000	1549.02001953	2167401	\N	CNY	api	2025-11-09 07:07:12.614744+08
6c911430-5472-4178-97bb-748f66b21c61	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-03	1530.00000000	1586.00000000	1529.01000977	1568.88000488	3548050	\N	CNY	api	2025-11-09 07:07:12.614957+08
0a5ef122-f965-4430-9c81-b1f76c2c7477	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-07	1520.01000977	1536.84997559	1462.00000000	1500.00000000	10195267	\N	CNY	api	2025-11-09 07:07:12.615169+08
ba6de6d7-e7a4-4140-a48e-8520eab8106d	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-08	1513.00000000	1545.00000000	1495.00000000	1545.00000000	7387649	\N	CNY	api	2025-11-09 07:07:12.6154+08
da6c3bf2-b95a-46eb-81cd-49f0f7ea9bea	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-09	1525.02001953	1556.80004883	1520.55004883	1541.04003906	5563004	\N	CNY	api	2025-11-09 07:07:12.615714+08
34c3d867-7981-4a51-9f70-0beaffbbf7d0	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-10	1550.98999023	1555.00000000	1528.00000000	1549.00000000	3862021	\N	CNY	api	2025-11-09 07:07:12.615914+08
7f8f8f85-1631-4925-b10a-48819554c07e	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-11	1579.96997070	1579.96997070	1545.00000000	1568.97998047	3263423	\N	CNY	api	2025-11-09 07:07:12.616125+08
8d6ee7b8-920c-475d-aece-fc3653a308e4	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-14	1560.96997070	1566.00000000	1551.53002930	1551.98999023	2171144	\N	CNY	api	2025-11-09 07:07:12.616309+08
a1058cc1-969a-4fe7-a93f-5ca033e000d5	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-15	1552.00000000	1565.00000000	1545.00000000	1558.00000000	2148928	\N	CNY	api	2025-11-09 07:07:12.616501+08
5405e0ac-4d3f-484b-8909-8b380fd9ea1a	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-16	1552.00000000	1576.00000000	1537.00000000	1559.17004395	3115605	\N	CNY	api	2025-11-09 07:07:12.616711+08
6702e165-8d73-4c11-b9b1-1cd6dcc9ae35	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-17	1554.00000000	1576.50000000	1549.98999023	1570.00000000	2384605	\N	CNY	api	2025-11-09 07:07:12.616934+08
bba59e80-c463-442f-aa03-da1a36caeb71	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-18	1566.00000000	1575.00000000	1556.00000000	1565.93994141	2029848	\N	CNY	api	2025-11-09 07:07:12.617139+08
73f28ff7-3a8d-4513-9160-c853f4e9c620	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-21	1565.50000000	1565.50000000	1551.00000000	1551.00000000	1805703	\N	CNY	api	2025-11-09 07:07:12.617367+08
a7fe525f-906e-4ae8-9986-98d8c24239eb	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-22	1550.00000000	1556.30004883	1543.20996094	1548.80004883	1843214	\N	CNY	api	2025-11-09 07:07:12.617581+08
da80c87e-1125-4ad7-bf2c-727d42105024	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-23	1559.00000000	1559.21997070	1545.00000000	1552.00000000	1866876	\N	CNY	api	2025-11-09 07:07:12.617991+08
70b47dfe-9d7f-4a17-9a55-a95db93edc96	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-24	1552.00000000	1560.68005371	1548.97998047	1552.25000000	1487181	\N	CNY	api	2025-11-09 07:07:12.6182+08
e9037ebf-5e39-4563-9399-bc11e17e6b7f	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-25	1557.09997559	1561.19995117	1550.00000000	1550.00000000	1476490	\N	CNY	api	2025-11-09 07:07:12.618432+08
ba926307-8ff5-4acf-a988-f01d1b362ede	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-28	1552.00000000	1555.00000000	1546.59997559	1550.00000000	1465972	\N	CNY	api	2025-11-09 07:07:12.618637+08
a3794e28-0c5e-489c-89a5-2186e999ec13	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-29	1550.00000000	1552.54003906	1532.02001953	1544.00000000	1892180	\N	CNY	api	2025-11-09 07:07:12.618851+08
f6ed4ff0-d623-4dd2-b018-4310e4372499	49589118-facc-4785-abf3-3d2d4d054f17	2025-04-30	1549.98999023	1566.66003418	1546.30004883	1547.00000000	2575425	\N	CNY	api	2025-11-09 07:07:12.619059+08
2e18040f-bf4c-4fda-8382-13826b48d46f	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-06	1559.00000000	1559.00000000	1544.32995605	1550.19995117	1830026	\N	CNY	api	2025-11-09 07:07:12.619267+08
bf2bd5b3-9f61-4e81-984b-465adc64bb34	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-07	1570.00000000	1570.00000000	1550.19995117	1555.00000000	2746221	\N	CNY	api	2025-11-09 07:07:12.619474+08
03eb14d6-7bdf-423a-b812-6fceab03b242	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-08	1553.00000000	1592.78002930	1549.82995605	1578.18994141	3348106	\N	CNY	api	2025-11-09 07:07:12.61969+08
767c5e40-9edf-4eb7-b860-3dd3745d33fc	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-09	1578.98999023	1597.44995117	1575.05004883	1591.18005371	2367190	\N	CNY	api	2025-11-09 07:07:12.619899+08
c38b8b5f-4f62-4761-b0ee-aebd62454bf3	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-12	1598.00000000	1618.93005371	1596.60998535	1604.50000000	2473533	\N	CNY	api	2025-11-09 07:07:12.620111+08
123e1597-1fca-4ec4-8a79-9229f07fc135	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-13	1608.92004395	1608.92004395	1585.10998535	1590.30004883	2125829	\N	CNY	api	2025-11-09 07:07:12.620491+08
74614c94-928f-4474-af6b-f0c633ea4040	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-14	1590.00000000	1645.00000000	1588.18005371	1634.98999023	3946012	\N	CNY	api	2025-11-09 07:07:12.620698+08
edf0525d-c99d-4fab-882a-73b501579f60	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-15	1634.80004883	1643.58996582	1624.13000488	1632.01000977	2473285	\N	CNY	api	2025-11-09 07:07:12.620901+08
826bca25-0746-4d8e-88a4-c8b7ebf32f3a	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-16	1633.98999023	1636.98999023	1614.13000488	1614.13000488	2293522	\N	CNY	api	2025-11-09 07:07:12.621105+08
77e350c2-ec68-4204-b45d-321e20c323d2	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-19	1596.00000000	1600.00000000	1573.88000488	1578.97998047	3806283	\N	CNY	api	2025-11-09 07:07:12.62131+08
77064ded-e22a-45e5-b48f-4262fc2299fd	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-20	1580.00000000	1594.80004883	1575.09997559	1586.00000000	1952153	\N	CNY	api	2025-11-09 07:07:12.621512+08
c2c166c9-a5d6-4697-85ef-78999f1298d9	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-21	1585.00000000	1595.93994141	1580.96997070	1580.96997070	1979464	\N	CNY	api	2025-11-09 07:07:12.62172+08
9a0e226f-2665-42f0-a077-c9c420ae6504	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-22	1580.98999023	1584.98999023	1570.09997559	1580.00000000	1509024	\N	CNY	api	2025-11-09 07:07:12.621923+08
6c6428f1-cf13-49b3-9d71-19a35ce78729	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-23	1574.96997070	1587.90002441	1571.66003418	1572.59997559	2153700	\N	CNY	api	2025-11-09 07:07:12.622145+08
30ea4c37-cbf1-44ba-b541-4677964a8bdc	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-26	1570.00000000	1574.63000488	1545.00000000	1550.50000000	2708653	\N	CNY	api	2025-11-09 07:07:12.62234+08
8ed8ae2b-a82d-46d3-842e-0daf2b65cca8	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-27	1551.00000000	1558.59997559	1543.51000977	1543.90002441	1775213	\N	CNY	api	2025-11-09 07:07:12.622547+08
8c998be0-edd4-4af0-82ef-65cda8b0a279	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-28	1543.98999023	1546.45996094	1533.00000000	1537.00000000	1626568	\N	CNY	api	2025-11-09 07:07:12.622747+08
40ac66f5-03df-4039-a1f7-ed50d3bd48ce	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-29	1540.00000000	1555.00000000	1532.00000000	1540.00000000	2185958	\N	CNY	api	2025-11-09 07:07:12.622942+08
d21808c5-6a7c-41a6-b768-04406b7590ad	49589118-facc-4785-abf3-3d2d4d054f17	2025-05-30	1540.15002441	1545.00000000	1515.23999023	1522.00000000	3123918	\N	CNY	api	2025-11-09 07:07:12.62316+08
4d3c329f-68e3-4998-8631-28b9e847eaca	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-03	1508.01000977	1519.00000000	1505.02001953	1509.00000000	2897918	\N	CNY	api	2025-11-09 07:07:12.623374+08
1c223df1-45df-4b8c-898b-488de5d37a06	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-04	1510.50000000	1523.00000000	1509.21997070	1509.95996094	2300809	\N	CNY	api	2025-11-09 07:07:12.623573+08
2e967e1d-352b-4b60-a484-551e7cd637f4	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-05	1514.00000000	1516.00000000	1502.19995117	1514.00000000	2321366	\N	CNY	api	2025-11-09 07:07:12.623754+08
90631423-6903-4c3e-90eb-8fd580d67a17	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-06	1513.80004883	1518.96997070	1503.00000000	1506.39001465	2502307	\N	CNY	api	2025-11-09 07:07:12.623971+08
dd828242-0079-4ee6-905d-9b52328cba54	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-09	1505.02001953	1508.69995117	1485.68005371	1486.10998535	4495867	\N	CNY	api	2025-11-09 07:07:12.624155+08
a7dd20fb-d3a0-4bbe-b51f-b3ea617a6b00	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-10	1486.00000000	1492.00000000	1474.80004883	1475.01000977	3049220	\N	CNY	api	2025-11-09 07:07:12.62435+08
5435940e-25c7-43d7-a174-26fac4c81990	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-11	1476.80004883	1494.00000000	1476.09997559	1480.00000000	3089282	\N	CNY	api	2025-11-09 07:07:12.624731+08
e1b5f5b0-6f6b-41a5-ae07-4bba160c456c	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-12	1480.00000000	1483.86999512	1454.09997559	1459.00000000	4990361	\N	CNY	api	2025-11-09 07:07:12.624918+08
18aa8726-8092-4a34-91e0-6252df580cda	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-13	1444.41003418	1449.96997070	1425.06005859	1426.94995117	5911325	\N	CNY	api	2025-11-09 07:07:12.625106+08
93f3659e-7b63-490a-9d76-aff541898709	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-16	1401.19995117	1425.04003906	1401.18005371	1422.29003906	4288787	\N	CNY	api	2025-11-09 07:07:12.625289+08
7943cec9-b517-4a54-9d17-0d0fc21fe228	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-17	1420.00000000	1427.00000000	1412.18005371	1427.00000000	2723151	\N	CNY	api	2025-11-09 07:07:12.625467+08
c5cc47d0-0c91-4edf-bf19-c166933b8400	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-18	1440.00000000	1443.43994141	1421.01000977	1425.00000000	3076099	\N	CNY	api	2025-11-09 07:07:12.625667+08
9c88c547-dc16-49f8-a431-69aa3ef81ee4	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-19	1426.00000000	1433.67004395	1417.18005371	1426.00000000	2450072	\N	CNY	api	2025-11-09 07:07:12.625863+08
54e6bc42-3f20-4d06-b838-de175b8b2727	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-20	1423.57995605	1441.14001465	1420.19995117	1428.66003418	3481581	\N	CNY	api	2025-11-09 07:07:12.626069+08
f310c103-4c3e-4a14-9510-cf3184faa49d	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-23	1420.00000000	1433.00000000	1405.18005371	1420.00000000	2672331	\N	CNY	api	2025-11-09 07:07:12.626326+08
1a938ba5-fa1c-4ead-a1cb-18e2fdfc18c4	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-24	1423.34997559	1451.68005371	1423.34997559	1437.19995117	3631151	\N	CNY	api	2025-11-09 07:07:12.62664+08
073d6be4-9762-479b-96bf-9dc7de4a260e	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-25	1439.10998535	1449.19995117	1420.51000977	1435.85998535	4105007	\N	CNY	api	2025-11-09 07:07:12.626833+08
5aa50ae1-3f2c-4fc6-88f5-fd2f5da7d7be	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-26	1415.00000000	1428.00000000	1410.07995605	1420.00000000	3486025	\N	CNY	api	2025-11-09 07:07:12.627005+08
8f2ac9d5-3dba-4ab7-ac93-6e0621226507	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-27	1420.01000977	1423.00000000	1403.08996582	1403.08996582	3824973	\N	CNY	api	2025-11-09 07:07:12.627186+08
813d468d-c24a-4c94-b911-fc02291967af	49589118-facc-4785-abf3-3d2d4d054f17	2025-06-30	1403.50000000	1413.22998047	1402.00000000	1409.52001953	3045730	\N	CNY	api	2025-11-09 07:07:12.627372+08
4c463268-602a-4d78-b48f-f815da0984e3	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-01	1409.00000000	1411.93994141	1403.31005859	1405.09997559	1987819	\N	CNY	api	2025-11-09 07:07:12.627638+08
3eddf9e0-13de-470f-b5e9-bd46e23d24e9	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-02	1409.50000000	1414.80004883	1400.00000000	1409.59997559	2621825	\N	CNY	api	2025-11-09 07:07:12.627913+08
4fdc5303-7677-4c17-a82d-a9223720cef6	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-03	1412.00000000	1422.68994141	1408.00000000	1415.59997559	2441267	\N	CNY	api	2025-11-09 07:07:12.628247+08
724284a4-9972-489f-87ff-634b6e743c92	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-04	1415.69995117	1431.89001465	1410.01000977	1422.21997070	2876691	\N	CNY	api	2025-11-09 07:07:12.628454+08
14a880c5-416f-4544-b278-b9ea4eea11a2	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-07	1422.28002930	1423.50000000	1410.01000977	1410.69995117	2385467	\N	CNY	api	2025-11-09 07:07:12.628643+08
e331337d-8eee-4114-b9b8-289816a92489	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-08	1410.70996094	1420.00000000	1410.69995117	1416.10998535	1867370	\N	CNY	api	2025-11-09 07:07:12.628836+08
b44e18ea-0b2e-417e-84b7-0cf78825f388	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-09	1415.00000000	1429.96997070	1414.17004395	1418.88000488	2774532	\N	CNY	api	2025-11-09 07:07:12.62921+08
866725c9-c546-4cc0-8689-6e1d9e4096da	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-10	1418.96997070	1436.18005371	1410.40002441	1426.50000000	3872503	\N	CNY	api	2025-11-09 07:07:12.629399+08
1ac16ede-3eee-4f3e-8c9a-d19f8d5d865a	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-11	1423.16003418	1458.00000000	1423.16003418	1427.00000000	5724335	\N	CNY	api	2025-11-09 07:07:12.629589+08
a65a2e8e-e46e-4192-9a6f-f2e091b4c527	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-14	1430.00000000	1434.97998047	1421.59997559	1423.59997559	2778094	\N	CNY	api	2025-11-09 07:07:12.62977+08
15089f42-7050-406e-b48d-4f6124bed23f	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-15	1420.97998047	1422.93005371	1408.31994629	1411.00000000	3540578	\N	CNY	api	2025-11-09 07:07:12.629959+08
8c2185a0-4e0a-4ca3-bf20-874a08d48d3c	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-16	1410.01000977	1417.48999023	1409.94995117	1411.03002930	2128605	\N	CNY	api	2025-11-09 07:07:12.630148+08
55351892-9117-4b18-9f9c-64e58f333cc3	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-17	1413.97998047	1423.01000977	1412.88000488	1416.34997559	2310554	\N	CNY	api	2025-11-09 07:07:12.630332+08
2261a29f-5cb8-4ee8-90ff-96a3e4a7c04f	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-18	1420.00000000	1437.81005859	1416.38000488	1437.00000000	4182341	\N	CNY	api	2025-11-09 07:07:12.630513+08
2fa09136-917f-4c6d-b2d6-3c6b53574202	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-21	1436.98999023	1446.80004883	1435.00000000	1443.00000000	2620331	\N	CNY	api	2025-11-09 07:07:12.630702+08
d0ffafe6-2f08-4c40-a754-931a4b04a747	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-22	1444.00000000	1466.59997559	1440.68005371	1464.97998047	4211898	\N	CNY	api	2025-11-09 07:07:12.630948+08
7fc04c39-e291-4f5b-af8b-dac62c72e459	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-23	1469.00000000	1495.00000000	1468.94995117	1475.50000000	4504484	\N	CNY	api	2025-11-09 07:07:12.631127+08
fd7d919a-0f3a-4e3b-8665-821dc45de853	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-24	1476.00000000	1499.00000000	1475.00000000	1491.50000000	3880364	\N	CNY	api	2025-11-09 07:07:12.631321+08
d181bbfd-aab3-4392-9b09-abc57048b1d0	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-25	1491.40002441	1491.40002441	1453.00000000	1455.00000000	4191126	\N	CNY	api	2025-11-09 07:07:12.631579+08
c949385d-1f41-4cae-87a2-91afd01636b8	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-28	1453.00000000	1454.98999023	1436.30004883	1438.66003418	3858632	\N	CNY	api	2025-11-09 07:07:12.63184+08
ed7d70e1-2a32-4be9-b6c9-29c573471d32	49589118-facc-4785-abf3-3d2d4d054f17	2025-07-29	1439.59997559	1448.79003906	1435.01000977	1439.00000000	2630408	\N	CNY	api	2025-11-09 07:07:12.632045+08
\.


--
-- Data for Name: asset_types; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.asset_types (id, code, name, category, description, is_active, created_at, location_dimension) FROM stdin;
26baf585-bfba-4af4-bc41-d9efdc05d82a	STOCK_OPTION	股票期权	STOCK_OPTION	股票期权合约，包括认购期权和认沽期权	t	2025-11-07 23:16:55.333125+08	market
ce4ebe16-471f-4d06-b37a-6b5bdf91b018	COMMODITY	商品	commodity	贵金属、原油等商品	t	2025-11-07 21:05:53.355326+08	global
39267764-141d-43f7-bdc3-32a6a4b6e084	TREASURY	国债	BOND	政府债券	t	2025-11-09 11:26:53.055048+08	market
759fd931-caad-408b-9b46-938bc94b62ce	ETF	交易所交易基金	ETF	在交易所交易的指数基金	t	2025-11-07 21:05:53.355326+08	market
1317e563-bc85-418d-bd6b-bc49d6719ce5	BOND	企业债券	BOND	企业债券	t	2025-11-07 21:05:53.355326+08	country
53195789-6c3e-41b3-b30a-4d328126728c	MUTUAL_FUND	共同基金	FUND	开放式基金	t	2025-11-07 21:05:53.355326+08	country
9ed792c8-2fbb-4453-8380-5e957a651df3	CRYPTO	加密货币	CRYPTO	数字货币	t	2025-11-07 21:05:53.355326+08	global
a38b6c3d-61de-482d-8859-16e72f3107fd	HEDGE_FUND	对冲基金	FUND	私募基金与对冲基金	t	2025-11-07 21:06:31.056188+08	country
4016a03f-0738-4c9a-8c77-faa1e4b87966	FOREX	外汇	CURRENCY	\N	t	2025-11-08 15:39:17.304747+08	global
916f709e-d2fe-4bbb-a0b5-f0e680c30c53	REIT	房地产投资信托	FUND	房地产投资信托基金	t	2025-11-07 21:05:53.355326+08	country
716c257e-388f-4cde-a5b6-373effe40d78	OPTION	期权	FUTURE	股票期权合约	t	2025-11-07 21:05:53.355326+08	market
810cc3b6-01c0-4cea-af47-b34563226fc9	FUTURE	期货	FUTURE	期货合约	t	2025-11-07 21:05:53.355326+08	market
c7705c2b-9c24-449e-9015-a1ec8b826f6e	CASH	现金	CURRENCY	现金及现金等价物	t	2025-11-07 21:05:53.355326+08	country
761e5638-cff8-4247-bfd7-00edcd57a51a	STOCK	股票	EQUITY	普通股票	t	2025-11-07 21:05:53.355326+08	market
60c02f02-b096-4f08-971e-653d3b5a7ddf	BANK_WEALTH	银行理财产品	CURRENCY	银行发行的理财产品，包括保本和非保本理财产品	t	2025-11-08 10:18:32.181688+08	country
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.assets (id, symbol, name, asset_type_id, currency, isin, cusip, sector, industry, description, metadata, is_active, created_at, updated_at, risk_level, lot_size, tick_size, listing_date, delisting_date, tags, created_by, updated_by, liquidity_tag, country_id) FROM stdin;
2aa3f894-681b-4a75-9003-ab376a35df7e	000001	平安银行	761e5638-cff8-4247-bfd7-00edcd57a51a	CNY	\N	\N	金融	银行	中国平安银行股份有限公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	d7d5c3ba-92c1-4619-891c-de4d455179ed
a6efbeb9-3af7-4565-a0b0-8a222138ca7d	000002	万科A	761e5638-cff8-4247-bfd7-00edcd57a51a	CNY	\N	\N	房地产	房地产开发	万科企业股份有限公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	d7d5c3ba-92c1-4619-891c-de4d455179ed
87827534-5cc9-4f7e-a066-348b52e4965f	0941	中国移动	761e5638-cff8-4247-bfd7-00edcd57a51a	HKD	\N	\N	通信	电信运营	中国移动有限公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	a1f8cb91-32af-4479-89e7-0b99e7ee4057
a4d3853b-0417-42c2-8d5d-dd32d3659e4a	0700	腾讯控股	761e5638-cff8-4247-bfd7-00edcd57a51a	HKD	\N	\N	科技	互联网	腾讯控股有限公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	a1f8cb91-32af-4479-89e7-0b99e7ee4057
e9919f45-1585-4645-8a62-036c08865605	510300	沪深300ETF	759fd931-caad-408b-9b46-938bc94b62ce	CNY	\N	\N	ETF	指数基金	华泰柏瑞沪深300ETF	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	d7d5c3ba-92c1-4619-891c-de4d455179ed
a7569e62-8eec-4468-8798-d1e948ef4679	600036	招商银行	761e5638-cff8-4247-bfd7-00edcd57a51a	CNY	\N	\N	金融	银行	招商银行股份有限公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	d7d5c3ba-92c1-4619-891c-de4d455179ed
49589118-facc-4785-abf3-3d2d4d054f17	600519	贵州茅台	761e5638-cff8-4247-bfd7-00edcd57a51a	CNY	\N	\N	消费	白酒	贵州茅台酒股份有限公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	d7d5c3ba-92c1-4619-891c-de4d455179ed
9dd1720a-bd8f-4810-9648-b47b516d82cb	AAPL	Apple Inc.	761e5638-cff8-4247-bfd7-00edcd57a51a	USD	\N	\N	科技	消费电子	苹果公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	c447b588-db26-4ef5-bac5-0e623820ecae
e18a110d-3daa-4d2f-9880-c3985dce8bbf	GOOGL	Alphabet Inc.	761e5638-cff8-4247-bfd7-00edcd57a51a	USD	\N	\N	科技	互联网	谷歌母公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	c447b588-db26-4ef5-bac5-0e623820ecae
43fc85a9-db6d-4390-a6ef-7b4b5979fdda	MSFT	Microsoft Corporation	761e5638-cff8-4247-bfd7-00edcd57a51a	USD	\N	\N	科技	软件	微软公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	c447b588-db26-4ef5-bac5-0e623820ecae
b267651d-83dc-495e-8623-0f4c7c27662c	SPY	SPDR S&P 500 ETF	759fd931-caad-408b-9b46-938bc94b62ce	USD	\N	\N	ETF	指数基金	标普500指数ETF	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	c447b588-db26-4ef5-bac5-0e623820ecae
0aab0dfa-ce4c-4bb0-a315-5c0c2cd82c21	TSLA	Tesla, Inc.	761e5638-cff8-4247-bfd7-00edcd57a51a	USD	\N	\N	汽车	电动汽车	特斯拉公司	\N	t	2025-11-07 21:06:05.812344+08	2025-11-07 21:06:05.812344+08	MEDIUM	1	0.010000	\N	\N	\N	\N	\N	cc893a70-ae7f-47ed-a81e-97486a3b4524	c447b588-db26-4ef5-bac5-0e623820ecae
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.audit_logs (id, user_id, table_name, record_id, action, old_values, new_values, changed_fields, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: benchmark_prices; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.benchmark_prices (id, benchmark_id, price_date, price, currency, created_at) FROM stdin;
\.


--
-- Data for Name: benchmarks; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.benchmarks (id, name, symbol, description, asset_class, currency, data_source, is_active, created_at) FROM stdin;
3295fc27-ccb0-4149-9d63-349231982751	沪深300指数	CSI300	沪深300指数，反映A股市场整体表现	equity	CNY	\N	t	2025-11-07 21:05:53.359287+08
8cdf279f-6a15-4a37-ac94-aecf13e97156	上证指数	SHCOMP	上海证券交易所综合股价指数	equity	CNY	\N	t	2025-11-07 21:05:53.359287+08
37ace466-8b41-4ddb-b0a9-461d96b8eab3	深证成指	SZCOMP	深圳证券交易所成份股价指数	equity	CNY	\N	t	2025-11-07 21:05:53.359287+08
ffd11eda-614b-4cd2-9a2e-41754f2198f3	恒生指数	HSI	香港恒生指数	equity	HKD	\N	t	2025-11-07 21:05:53.359287+08
b37a6a3c-b8a8-46a8-960c-ecb0262fa91a	标普500指数	SPX	标准普尔500指数	equity	USD	\N	t	2025-11-07 21:05:53.359287+08
19548a7a-33cc-4374-a35f-3fd20ef93c8b	纳斯达克指数	IXIC	纳斯达克综合指数	equity	USD	\N	t	2025-11-07 21:05:53.359287+08
fd5ff7d6-8de9-4c98-9f30-41d57a1ba263	日经225指数	N225	日经225指数	equity	JPY	\N	t	2025-11-07 21:05:53.359287+08
8de063ae-fb49-42cf-b18c-9656b1a55a7f	富时100指数	UKX	英国富时100指数	equity	GBP	\N	t	2025-11-07 21:05:53.359287+08
6c8f4959-35d7-43b7-9580-3e0747147ea5	DAX指数	DAX	德国DAX指数	equity	EUR	\N	t	2025-11-07 21:05:53.359287+08
\.


--
-- Data for Name: bond_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.bond_details (id, asset_id, bond_type, credit_rating, face_value, coupon_rate, coupon_frequency, issue_date, maturity_date, years_to_maturity, yield_to_maturity, current_yield, issuer, issue_price, issue_size, callable, call_date, call_price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cash_flows; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.cash_flows (id, portfolio_id, trading_account_id, asset_id, flow_type, amount, currency, flow_date, description, transaction_id, created_at, date, category) FROM stdin;
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.countries (id, code, name, currency, timezone, is_active, created_at, updated_at) FROM stdin;
c447b588-db26-4ef5-bac5-0e623820ecae	US	美国	USD	America/New_York	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
7b1dccae-1542-42fe-b069-e62554e6195a	GB	英国	GBP	Europe/London	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
61ac326e-26e7-454c-a08d-858afc897667	JP	日本	JPY	Asia/Tokyo	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
3d131879-1ea4-46e2-8773-8a2a50bfc460	DE	德国	EUR	Europe/Berlin	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
f0c7ec9b-2a14-41f6-96bf-f45d4d1897e3	FR	法国	EUR	Europe/Paris	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
d7d5c3ba-92c1-4619-891c-de4d455179ed	CN	中国	CNY	Asia/Shanghai	t	2025-11-08 10:22:35.250429+08	2025-11-08 10:22:35.250429+08
a1f8cb91-32af-4479-89e7-0b99e7ee4057	HK	中国香港	HKD	Asia/Hong_Kong	t	2025-11-08 15:28:32.452397+08	2025-11-08 15:28:32.452397+08
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.email_verification_tokens (id, user_id, token_hash, email, expires_at, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.exchange_rates (id, from_currency, to_currency, rate_date, rate, data_source, created_at) FROM stdin;
f5a3e67c-84c0-43f6-8cd6-829f71d44948	USD	CNY	2015-11-30	6.39840000	historical_import	2025-11-09 10:18:48.376031+08
705b78eb-5be0-4993-8605-950689ed7459	EUR	CNY	2015-11-30	6.76890000	historical_import	2025-11-09 10:18:48.378559+08
66e00dd8-2147-4317-9d21-01ae6ca8a062	GBP	CNY	2015-11-30	9.60400000	historical_import	2025-11-09 10:18:48.379314+08
9b25eec6-d6bd-40fc-9ed4-db013508ef4d	USD	HKD	2025-11-08	7.78000000	api	2025-11-08 20:00:01.099307+08
f5abc080-7d14-4b8e-a26c-a40023d071c5	USD	SGD	2025-11-08	1.30000000	api	2025-11-08 20:00:01.10026+08
55d5639b-2fd7-4fa1-b4f6-0aae15ebbb5b	USD	HKD	2025-11-09	7.78000000	api	2025-11-09 04:00:00.98589+08
b08e1d7c-0620-40bc-a566-96c67c602b0f	USD	SGD	2025-11-09	1.30000000	api	2025-11-09 04:00:00.987092+08
dac7318b-2bf7-465f-8d44-8d716432dba7	JPY	CNY	2015-11-30	0.05198000	historical_import	2025-11-09 10:18:48.379778+08
e2b77e45-ba5c-4a65-bde3-f2937d9a3479	HKD	CNY	2015-11-30	0.82559000	historical_import	2025-11-09 10:18:48.380204+08
93c30e06-fa8a-4a27-a442-0d1839506ef4	SGD	CNY	2015-11-30	4.53070000	historical_import	2025-11-09 10:18:48.380572+08
2f726b9f-e12f-4f43-8e02-ba021e5843c8	AUD	CNY	2015-11-30	4.61380000	historical_import	2025-11-09 10:18:48.38099+08
e41e5546-c346-42aa-b54a-cd439a617914	CAD	CNY	2015-11-30	4.78600000	historical_import	2025-11-09 10:18:48.381367+08
d40ddad6-c365-484d-a84f-58286da0f0d6	CHF	CNY	2015-11-30	6.20830000	historical_import	2025-11-09 10:18:48.381639+08
30081985-81ea-4a83-8d44-0356ad2d0daf	INR	CNY	2015-11-30	0.09597000	historical_import	2025-11-09 10:18:48.381921+08
8d0113ea-4a35-4e2b-9617-ec037baf64df	USD	CNY	2015-12-31	6.48550000	historical_import	2025-11-09 10:18:48.382206+08
5dac055d-a1b5-4a8a-b67a-fe10bec3f9d4	EUR	CNY	2015-12-31	7.06080000	historical_import	2025-11-09 10:18:48.382518+08
834cff17-3dac-4ca4-b0c9-a6c4982c155f	GBP	CNY	2015-12-31	9.62030000	historical_import	2025-11-09 10:18:48.382755+08
0fa1545d-7b00-4013-979e-2406696fda46	JPY	CNY	2015-12-31	0.05387000	historical_import	2025-11-09 10:18:48.383024+08
46270ea5-5be7-412a-9e5b-f1ad0ea4a92c	HKD	CNY	2015-12-31	0.83683000	historical_import	2025-11-09 10:18:48.3834+08
fe4e9b81-de23-41f0-9c19-4d2ebe80ae63	SGD	CNY	2015-12-31	4.57990000	historical_import	2025-11-09 10:18:48.383764+08
7f8633ee-726a-42ac-817c-8386598d2e77	AUD	CNY	2015-12-31	4.73970000	historical_import	2025-11-09 10:18:48.38412+08
a69b5ba1-9ac0-4120-8830-c3264e97126d	CAD	CNY	2015-12-31	4.67110000	historical_import	2025-11-09 10:18:48.384466+08
feb430fd-e97c-489e-9164-3a7a33a1dd3e	CHF	CNY	2015-12-31	6.51670000	historical_import	2025-11-09 10:18:48.384819+08
76039eed-62dd-42f3-b665-8bb0b3626ac2	INR	CNY	2015-12-31	0.09804000	historical_import	2025-11-09 10:18:48.385196+08
6f1dd0c7-8b2a-46f9-82d7-0677d9e8e78f	USD	CNY	2016-01-31	6.57600000	historical_import	2025-11-09 10:18:48.385568+08
710eeea1-3197-4c34-83c8-1476c41015ad	EUR	CNY	2016-01-31	7.18100000	historical_import	2025-11-09 10:18:48.385893+08
79c81d7a-6ba1-4f64-abc3-757376e128db	GBP	CNY	2016-01-31	9.39800000	historical_import	2025-11-09 10:18:48.386447+08
78ae8cd2-769e-41c2-bbf8-a71934dc3e22	JPY	CNY	2016-01-31	0.05430000	historical_import	2025-11-09 10:18:48.386836+08
4b1d55ba-b91a-421a-ac7e-737c9bebd0fa	HKD	CNY	2016-01-31	0.84382000	historical_import	2025-11-09 10:18:48.387179+08
93b3ee74-12f7-4fcf-a357-c2790d2575f0	SGD	CNY	2016-01-31	4.61800000	historical_import	2025-11-09 10:18:48.387465+08
a4366ba6-f992-40d2-8a75-32b855adc8f5	AUD	CNY	2016-01-31	4.66660000	historical_import	2025-11-09 10:18:48.387759+08
91014f40-86bd-48a9-8bef-46990943789e	CAD	CNY	2016-01-31	4.67420000	historical_import	2025-11-09 10:18:48.388047+08
1e5ac69f-534b-436a-8ff0-b13a2a6e2d8e	CHF	CNY	2016-01-31	6.44380000	historical_import	2025-11-09 10:18:48.388327+08
3f0ffee7-305c-4abb-8ad3-0df4d771de27	INR	CNY	2016-01-31	0.09690000	historical_import	2025-11-09 10:18:48.388612+08
59cef3ea-1af5-4d17-8858-b68cdf91cb04	USD	CNY	2016-02-29	6.55320000	historical_import	2025-11-09 10:18:48.388897+08
11a5ce64-6133-4f9a-88ea-3130f1671cbb	EUR	CNY	2016-02-29	7.13510000	historical_import	2025-11-09 10:18:48.389172+08
999222d7-aa3c-4500-a2c4-b897f1109ac3	GBP	CNY	2016-02-29	9.08000000	historical_import	2025-11-09 10:18:48.389465+08
919a75de-a738-4ad8-8c47-dc5d3868a3fe	JPY	CNY	2016-02-29	0.05794000	historical_import	2025-11-09 10:18:48.389672+08
cebaa296-3786-48a5-98ff-02cdf35764ab	HKD	CNY	2016-02-29	0.84288000	historical_import	2025-11-09 10:18:48.389888+08
c61a1942-89a3-4b08-8cee-927862fa3015	SGD	CNY	2016-02-29	4.65590000	historical_import	2025-11-09 10:18:48.390113+08
775045e1-3391-4fbb-a722-f1ca37a15340	AUD	CNY	2016-02-29	4.67570000	historical_import	2025-11-09 10:18:48.390318+08
3c125c53-5755-4d67-93ef-2bfc1eda9dbc	CAD	CNY	2016-02-29	4.83180000	historical_import	2025-11-09 10:18:48.390556+08
fd1de073-f0c6-4647-9731-ad158d05b84d	CHF	CNY	2016-02-29	6.53760000	historical_import	2025-11-09 10:18:48.39085+08
8959a7fa-4743-4fb3-a7b6-59c3c509cf14	INR	CNY	2016-02-29	0.09593000	historical_import	2025-11-09 10:18:48.391114+08
3a7dd6d9-7330-4e35-a438-3d8a0aeffafd	USD	CNY	2016-03-31	6.45710000	historical_import	2025-11-09 10:18:48.391358+08
38958785-3614-424e-969f-8e0edc90877b	EUR	CNY	2016-03-31	7.35140000	historical_import	2025-11-09 10:18:48.391607+08
c5e05c20-5286-48c6-b6fb-75b647d02946	GBP	CNY	2016-03-31	9.28730000	historical_import	2025-11-09 10:18:48.391846+08
d0265e91-a45b-43e0-9f8c-6542365e345d	JPY	CNY	2016-03-31	0.05748000	historical_import	2025-11-09 10:18:48.392096+08
ce30d9fe-b3c3-4b35-9728-ce034799fd8e	HKD	CNY	2016-03-31	0.83272000	historical_import	2025-11-09 10:18:48.392349+08
c39a583f-681e-4cf6-8fcd-adc5822f791e	SGD	CNY	2016-03-31	4.80360000	historical_import	2025-11-09 10:18:48.392612+08
2e4cdf40-d8b3-45d9-b18e-2c86b505c372	AUD	CNY	2016-03-31	4.96480000	historical_import	2025-11-09 10:18:48.392866+08
af6202f9-0f6f-4f05-a26c-36fd51601360	CAD	CNY	2016-03-31	4.98810000	historical_import	2025-11-09 10:18:48.393145+08
0921706a-1703-4573-9edb-92140046950d	CHF	CNY	2016-03-31	6.72530000	historical_import	2025-11-09 10:18:48.393487+08
39d3e1e4-7646-43bb-86a8-a6d2d2b65586	INR	CNY	2016-03-31	0.09746000	historical_import	2025-11-09 10:18:48.393966+08
d178041c-f849-42e9-b5e0-a049b43fc016	USD	CNY	2016-04-30	6.48450000	historical_import	2025-11-09 10:18:48.394219+08
abddb6ae-4934-4795-8b3c-5e6931f72557	EUR	CNY	2016-04-30	7.39430000	historical_import	2025-11-09 10:18:48.394482+08
8e0b9ffa-b24c-4365-9591-181e03b4011e	GBP	CNY	2016-04-30	9.47680000	historical_import	2025-11-09 10:18:48.394738+08
29759de7-fa13-469b-97e8-87159fdcc160	JPY	CNY	2016-04-30	0.06044000	historical_import	2025-11-09 10:18:48.394991+08
e23f5630-ca90-4002-80f7-cd55955278da	HKD	CNY	2016-04-30	0.83584000	historical_import	2025-11-09 10:18:48.395264+08
c889cab6-ae25-4297-bfa2-7becd8ec2dd9	SGD	CNY	2016-04-30	4.82940000	historical_import	2025-11-09 10:18:48.395469+08
3f823d0f-41d3-4ee8-bb0e-933f26ac1f96	AUD	CNY	2016-04-30	4.94670000	historical_import	2025-11-09 10:18:48.395666+08
a6e034d0-0c84-4f16-9254-d50ca9df4d38	CAD	CNY	2016-04-30	5.17590000	historical_import	2025-11-09 10:18:48.395858+08
4949c43d-4436-4835-8d97-c5ca53f5b1a0	CHF	CNY	2016-04-30	6.73190000	historical_import	2025-11-09 10:18:48.396087+08
ce228d34-e1f9-4d02-9982-c09949914f19	INR	CNY	2016-04-30	0.09768000	historical_import	2025-11-09 10:18:48.396319+08
c19e0e9f-4792-4fbd-a1b2-8f131d994dbd	USD	CNY	2016-05-31	6.57730000	historical_import	2025-11-09 10:18:48.396558+08
992a02e6-2bff-4e86-ae4f-35fb43eb13eb	EUR	CNY	2016-05-31	7.33630000	historical_import	2025-11-09 10:18:48.396768+08
74e44e88-5a4b-4eca-9029-56ff42660ba4	GBP	CNY	2016-05-31	9.62960000	historical_import	2025-11-09 10:18:48.396969+08
0907a85f-c66c-42ec-82c6-a5f6b49492c0	JPY	CNY	2016-05-31	0.05924000	historical_import	2025-11-09 10:18:48.397167+08
4b4ed593-f6f2-401c-bd24-bbb435942367	HKD	CNY	2016-05-31	0.84676000	historical_import	2025-11-09 10:18:48.397373+08
9783e483-7724-4ff3-986b-ff1c0ac473c2	SGD	CNY	2016-05-31	4.77410000	historical_import	2025-11-09 10:18:48.397607+08
173d546b-2490-4538-92b5-3b5f24f53aad	AUD	CNY	2016-05-31	4.77440000	historical_import	2025-11-09 10:18:48.397882+08
3a5d1266-34d3-4c91-a827-44f0e0f67af3	CAD	CNY	2016-05-31	5.04910000	historical_import	2025-11-09 10:18:48.398105+08
00edfb9e-4a96-4be7-96ca-cc751d7dc729	CHF	CNY	2016-05-31	6.64280000	historical_import	2025-11-09 10:18:48.398321+08
387db63d-f28a-48bb-89da-12ce073931ff	INR	CNY	2016-05-31	0.09788000	historical_import	2025-11-09 10:18:48.398537+08
3c4cb9f4-d1a9-4501-a260-a8c7b2ad70f9	USD	CNY	2016-06-30	6.64340000	historical_import	2025-11-09 10:18:48.398728+08
8008fe04-1b44-455a-8dbb-a476897fb59e	EUR	CNY	2016-06-30	7.37550000	historical_import	2025-11-09 10:18:48.39894+08
fd46b3f9-feea-4a4e-bc93-d63167815dc1	GBP	CNY	2016-06-30	8.92380000	historical_import	2025-11-09 10:18:48.399145+08
1b33e550-c944-4c6a-9847-837b86c15bca	JPY	CNY	2016-06-30	0.06467000	historical_import	2025-11-09 10:18:48.399434+08
5ad807cd-69c1-4598-a5c7-63c71420d5a2	HKD	CNY	2016-06-30	0.85627000	historical_import	2025-11-09 10:18:48.399863+08
4d061401-9782-481e-8984-fd19beb930f9	SGD	CNY	2016-06-30	4.93110000	historical_import	2025-11-09 10:18:48.400116+08
b04aa83a-13b8-47bd-9a2d-6b7bfdeb0fb4	AUD	CNY	2016-06-30	4.94040000	historical_import	2025-11-09 10:18:48.400365+08
d56a82f5-d5b1-4a4a-9156-67df281e360a	CAD	CNY	2016-06-30	5.12760000	historical_import	2025-11-09 10:18:48.400614+08
e1dca903-de51-420f-aa71-79551607caa8	CHF	CNY	2016-06-30	6.78710000	historical_import	2025-11-09 10:18:48.401096+08
8c8d7dfd-1dbc-472d-883a-8c6b097cdbfc	INR	CNY	2016-06-30	0.09839000	historical_import	2025-11-09 10:18:48.401366+08
7d76cf9a-35b2-4c1f-a04a-792d949981ac	USD	CNY	2016-07-31	6.65060000	historical_import	2025-11-09 10:18:48.401607+08
5710c1c6-77e8-4f4c-b7e7-d57fe8c29e19	EUR	CNY	2016-07-31	7.39080000	historical_import	2025-11-09 10:18:48.401847+08
01040fd7-9792-4f5c-b4a7-7dfbc3f0ca5b	GBP	CNY	2016-07-31	8.75690000	historical_import	2025-11-09 10:18:48.402083+08
01b7326d-a5ae-4beb-b4c2-0bbae5881869	JPY	CNY	2016-07-31	0.06436000	historical_import	2025-11-09 10:18:48.402317+08
4f3b4c2f-d433-41ab-b85a-fc9c66223a91	HKD	CNY	2016-07-31	0.85730000	historical_import	2025-11-09 10:18:48.402559+08
33ee8417-9358-4363-bcd7-5cf25e37a92b	SGD	CNY	2016-07-31	4.92230000	historical_import	2025-11-09 10:18:48.402784+08
c98b12be-2921-4745-a78f-7cce396595e4	AUD	CNY	2016-07-31	4.99990000	historical_import	2025-11-09 10:18:48.403034+08
eeee114e-7462-4ea2-b445-13ff8bd666da	CAD	CNY	2016-07-31	5.04730000	historical_import	2025-11-09 10:18:48.403278+08
aab88e74-f7ef-4d85-9a01-55a14431ddb9	CHF	CNY	2016-07-31	6.82880000	historical_import	2025-11-09 10:18:48.403522+08
8e1c0023-9a2a-4afd-afdd-b40c11320242	INR	CNY	2016-07-31	0.09933000	historical_import	2025-11-09 10:18:48.403755+08
fee3b6d0-5663-4b08-8ea4-c3e11bdb5f9f	USD	CNY	2016-08-31	6.67540000	historical_import	2025-11-09 10:18:48.403988+08
5c56e280-c10d-44ae-b884-4acdff98a2a6	EUR	CNY	2016-08-31	7.43110000	historical_import	2025-11-09 10:18:48.404221+08
cd78ed7c-567a-414d-88cc-6764f78d7c64	GBP	CNY	2016-08-31	8.76250000	historical_import	2025-11-09 10:18:48.404454+08
a23b6a80-f687-4a51-b81c-ce2a252b3e36	JPY	CNY	2025-11-09	0.04651000	api	2025-11-09 10:01:24.782028+08
1df5aa03-fb4c-488a-a0c7-0bf757ca8039	JPY	CNY	2016-08-31	0.06461000	historical_import	2025-11-09 10:18:48.404705+08
05265ebe-e196-4444-b70b-447734de8ce6	HKD	CNY	2016-08-31	0.86051000	historical_import	2025-11-09 10:18:48.404967+08
833f0afe-5234-44b4-b362-95856367557a	SGD	CNY	2016-08-31	4.89500000	historical_import	2025-11-09 10:18:48.405223+08
06cece5c-031d-4552-95fe-5903f646fd79	AUD	CNY	2016-08-31	5.01900000	historical_import	2025-11-09 10:18:48.405486+08
1751a050-9703-46a3-b9c5-13878516e497	CAD	CNY	2016-08-31	5.09570000	historical_import	2025-11-09 10:18:48.405719+08
af677d27-a1c9-4a5d-86a7-577658185333	CHF	CNY	2016-08-31	6.78210000	historical_import	2025-11-09 10:18:48.405981+08
ed11f858-9cae-445c-9ed4-394e242ea296	INR	CNY	2016-08-31	0.09967000	historical_import	2025-11-09 10:18:48.406233+08
92987d5f-dd9c-4038-be13-9cb6817f9788	USD	CNY	2016-09-30	6.67170000	historical_import	2025-11-09 10:18:48.40649+08
86fb7f18-ba5e-43c8-bdea-962c45587a41	EUR	CNY	2016-09-30	7.44630000	historical_import	2025-11-09 10:18:48.406745+08
9ca8c9e7-1991-4319-8af5-79b2cb76a088	GBP	CNY	2016-09-30	8.64810000	historical_import	2025-11-09 10:18:48.406974+08
fee1645a-473b-4c27-b54a-29bebf3d7cc0	JPY	CNY	2016-09-30	0.06584000	historical_import	2025-11-09 10:18:48.407373+08
f8e4603d-e1be-49c4-a456-0b00607b9633	HKD	CNY	2016-09-30	0.86038000	historical_import	2025-11-09 10:18:48.407624+08
52ca84d3-26c7-4a49-ae31-18d25b5bcbbd	SGD	CNY	2016-09-30	4.88760000	historical_import	2025-11-09 10:18:48.407928+08
3e6ba8d7-8c39-4f56-a457-387dcbced6c1	AUD	CNY	2016-09-30	5.08040000	historical_import	2025-11-09 10:18:48.408184+08
42e4132e-d834-4eff-9176-eef0f611314e	CAD	CNY	2016-09-30	5.06900000	historical_import	2025-11-09 10:18:48.408441+08
e4d83335-abf6-41d1-9373-ff1e9f8c9c31	CHF	CNY	2016-09-30	6.84650000	historical_import	2025-11-09 10:18:48.408673+08
ecc77645-203b-4da4-a7ba-452b8787b375	INR	CNY	2016-09-30	0.10013000	historical_import	2025-11-09 10:18:48.408912+08
d56715ce-4028-44d9-af74-26ac5f16d5c7	EUR	CNY	2025-11-09	8.23240000	api	2025-11-09 10:01:24.258241+08
ff71cc69-781d-42e8-b76c-6fc8189021f6	USD	CNY	2016-10-31	6.77470000	historical_import	2025-11-09 10:18:48.409145+08
518e5fe4-face-4b95-9d7d-ffec23d61be0	EUR	CNY	2016-10-31	7.41560000	historical_import	2025-11-09 10:18:48.40939+08
817665a3-5305-4894-af5f-7ecf659ad059	GBP	CNY	2016-10-31	8.23500000	historical_import	2025-11-09 10:18:48.409644+08
5277f1f0-315f-4ff8-a5db-e4ceb235697d	JPY	CNY	2016-10-31	0.06450000	historical_import	2025-11-09 10:18:48.409931+08
e72732fc-b9ac-44dc-b184-cc9613f538e8	HKD	CNY	2016-10-31	0.87358000	historical_import	2025-11-09 10:18:48.410233+08
8924e113-5ff2-4002-a349-2cecfaafd347	INR	CNY	2025-11-09	0.08030000	api	2025-11-09 10:01:28.520667+08
97caa9cb-5990-4f2d-b1d3-2877395b9499	SGD	CNY	2016-10-31	4.86240000	historical_import	2025-11-09 10:18:48.410516+08
01a78508-645d-42dd-a664-6f3790eead9a	AUD	CNY	2016-10-31	5.15080000	historical_import	2025-11-09 10:18:48.410778+08
e158c82e-a37b-42f1-8dcf-82c4c098cda1	AUD	CNY	2025-11-09	4.61510000	api	2025-11-09 10:01:25.627209+08
a8bf0f15-3f6a-4e0a-9681-d9c56f4e3be7	CAD	CNY	2016-10-31	5.05670000	historical_import	2025-11-09 10:18:48.411015+08
8a7edc2c-b26a-43e6-9b42-ca4151ecc6e7	CHF	CNY	2016-10-31	6.85360000	historical_import	2025-11-09 10:18:48.411253+08
5159a6c5-28bc-4fe4-8639-f304975cc7ee	INR	CNY	2016-10-31	0.10145000	historical_import	2025-11-09 10:18:48.411495+08
f339fc6a-e9ea-4b30-afab-d342b0869d70	USD	CNY	2016-11-30	6.88340000	historical_import	2025-11-09 10:18:48.411712+08
e003cc84-c77e-4cfe-bcf6-9a7de2057be9	CAD	CNY	2025-11-09	5.04710000	api	2025-11-09 10:01:26.611882+08
6234ea7a-7fc8-4847-b383-47afd41f44cd	EUR	CNY	2016-11-30	7.32050000	historical_import	2025-11-09 10:18:48.411948+08
522c01b8-5adb-466f-8ad7-8a11811ec1de	GBP	CNY	2016-11-30	8.58710000	historical_import	2025-11-09 10:18:48.412147+08
4fe230cd-3d7d-4be6-b3a7-7e9b4a5a4397	JPY	CNY	2016-11-30	0.06076000	historical_import	2025-11-09 10:18:48.412358+08
0ac51c9e-dfeb-40dd-9b45-9500e4d4e2f1	HKD	CNY	2016-11-30	0.88745000	historical_import	2025-11-09 10:18:48.412573+08
4c5c5962-affe-4eaa-8034-d07300787570	GBP	CNY	2025-11-09	9.34330000	api	2025-11-09 10:01:24.514323+08
aa01da12-43c9-48e9-b6dd-c3d01daadf1b	SGD	CNY	2016-11-30	4.82280000	historical_import	2025-11-09 10:18:48.412806+08
aaaa1c22-12d1-4ed7-94cf-9abca1767615	CHF	CNY	2025-11-09	8.84060000	api	2025-11-09 10:01:27.575053+08
4e2dc1d7-df43-4f35-b754-3638eccdef62	AUD	CNY	2016-11-30	5.12250000	historical_import	2025-11-09 10:18:48.413033+08
142cf0c9-8372-4c2e-9f28-df6f78000cdf	CAD	CNY	2016-11-30	5.14330000	historical_import	2025-11-09 10:18:48.413254+08
ebc68e82-2b82-4730-a7b8-a3fb76fb9eeb	CHF	CNY	2016-11-30	6.77640000	historical_import	2025-11-09 10:18:48.413507+08
495fa3c4-31e3-4b0e-b575-ab3b1e7f9230	INR	CNY	2016-11-30	0.10047000	historical_import	2025-11-09 10:18:48.413747+08
4ae7d54f-ac6e-4735-bb3a-36058c2e9d7c	USD	CNY	2016-12-31	6.94450000	historical_import	2025-11-09 10:18:48.413995+08
b98bd07e-5ece-4369-be9f-bfc1b1074531	EUR	CNY	2016-12-31	7.32020000	historical_import	2025-11-09 10:18:48.414419+08
ff8846ea-45b1-4e2e-b5ee-5637f05b7b64	GBP	CNY	2016-12-31	8.54980000	historical_import	2025-11-09 10:18:48.414644+08
c240a09c-b249-4bd7-9ce5-6fb044b5a35d	JPY	CNY	2016-12-31	0.05932000	historical_import	2025-11-09 10:18:48.41497+08
0d9b7fc8-3552-47df-b194-8fcd3c8153b6	HKD	CNY	2016-12-31	0.89543000	historical_import	2025-11-09 10:18:48.415245+08
3e98c5bb-0824-4b02-bff3-37950c2f674d	SGD	CNY	2016-12-31	4.80520000	historical_import	2025-11-09 10:18:48.415453+08
5be0c0c8-582d-4274-a2b3-f7829e4fd944	AUD	CNY	2016-12-31	5.01520000	historical_import	2025-11-09 10:18:48.415628+08
b6353965-4c73-412f-9a8d-5e920572eb20	CAD	CNY	2016-12-31	5.15940000	historical_import	2025-11-09 10:18:48.415793+08
254c165e-6855-4460-a2b5-ce4cd7fa8130	CHF	CNY	2016-12-31	6.81650000	historical_import	2025-11-09 10:18:48.415945+08
d5257351-d9e2-401f-b194-c2098034c252	INR	CNY	2016-12-31	0.10225000	historical_import	2025-11-09 10:18:48.416099+08
fc2b19e1-32c2-4b06-b6da-017e31a05270	USD	CNY	2017-01-31	6.87770000	historical_import	2025-11-09 10:18:48.416244+08
b38ee1e5-fa5c-4d2a-8fd3-c7d9a47d2ce7	EUR	CNY	2017-01-31	7.39700000	historical_import	2025-11-09 10:18:48.416436+08
5b070de8-e7cf-4f28-aed8-5d94c0ccaa38	GBP	CNY	2017-01-31	8.59070000	historical_import	2025-11-09 10:18:48.416782+08
d7d7fc83-d0f1-4c62-9ea6-f9b93bdad106	JPY	CNY	2017-01-31	0.06066000	historical_import	2025-11-09 10:18:48.416946+08
6117b25d-9182-4355-a8cd-08df15c34ca1	HKD	CNY	2017-01-31	0.88655000	historical_import	2025-11-09 10:18:48.417101+08
13690277-7b5d-4f12-8e98-6fc36ee13d1a	SGD	CNY	2017-01-31	4.86610000	historical_import	2025-11-09 10:18:48.417255+08
8ea3d18e-d60f-4d0e-a90a-7a966bf0db0e	AUD	CNY	2017-01-31	5.20990000	historical_import	2025-11-09 10:18:48.417408+08
8e425d56-448e-4a1e-8e25-9e916f167a6b	CAD	CNY	2017-01-31	5.26250000	historical_import	2025-11-09 10:18:48.417595+08
634abf3a-3155-4869-8cfe-1aeee01e1144	CHF	CNY	2017-01-31	6.93380000	historical_import	2025-11-09 10:18:48.417747+08
d8109b82-ff24-4493-a8d6-9fda43e9976c	INR	CNY	2017-01-31	0.10161000	historical_import	2025-11-09 10:18:48.417901+08
23fd6828-6b27-4768-8b12-369c98ec9061	USD	CNY	2017-02-28	6.86800000	historical_import	2025-11-09 10:18:48.418056+08
909277a5-44fb-4713-a6ed-f823c41c7ddb	EUR	CNY	2017-02-28	7.27800000	historical_import	2025-11-09 10:18:48.418219+08
032fc10d-1d48-4c13-bd99-979b7e0d42d7	GBP	CNY	2017-02-28	8.53170000	historical_import	2025-11-09 10:18:48.418467+08
fe48e924-04d4-44ec-afe0-0e7471a29920	JPY	CNY	2017-02-28	0.06125000	historical_import	2025-11-09 10:18:48.41867+08
2fedd0b0-66e3-46e3-b81e-7f8615bb8231	HKD	CNY	2017-02-28	0.88484000	historical_import	2025-11-09 10:18:48.418855+08
b5a85877-9845-4a1f-aaf7-1985b94b8fa9	SGD	CNY	2017-02-28	4.90730000	historical_import	2025-11-09 10:18:48.41901+08
78b70348-7ade-4016-a8fb-f72add68dec5	AUD	CNY	2017-02-28	5.27120000	historical_import	2025-11-09 10:18:48.419176+08
8a25d11a-62c7-4351-9cf6-d237110b9646	CAD	CNY	2017-02-28	5.20450000	historical_import	2025-11-09 10:18:48.419388+08
82981108-6936-4207-8faf-cd39c73ece41	CHF	CNY	2017-02-28	6.83510000	historical_import	2025-11-09 10:18:48.419728+08
1ddc0a45-9da9-448c-b7d8-f64211125f1c	INR	CNY	2017-02-28	0.10305000	historical_import	2025-11-09 10:18:48.419882+08
06f8d8ab-c71d-409a-a4c0-307ebd3458a2	USD	CNY	2017-03-31	6.88820000	historical_import	2025-11-09 10:18:48.420037+08
626e44b6-0250-4430-b14e-32b14f23d8ad	EUR	CNY	2017-03-31	7.36420000	historical_import	2025-11-09 10:18:48.420187+08
87a9f137-0d33-4334-8b3e-465f5d66981e	GBP	CNY	2017-03-31	8.60780000	historical_import	2025-11-09 10:18:48.420364+08
2b58b137-ea4d-459a-9dbe-42e69e3c05f3	JPY	CNY	2017-03-31	0.06160000	historical_import	2025-11-09 10:18:48.42058+08
6fd30f6f-77fd-423a-9d15-3a9ffa9e24a4	HKD	CNY	2017-03-31	0.88646000	historical_import	2025-11-09 10:18:48.420769+08
95d5f49a-bb21-4851-9fcf-54a178c0b7a4	SGD	CNY	2017-03-31	4.92920000	historical_import	2025-11-09 10:18:48.420936+08
02aca7fd-204e-4198-87c7-7d18cee82ba2	AUD	CNY	2017-03-31	5.26690000	historical_import	2025-11-09 10:18:48.421107+08
de6958c3-6ee5-42af-97cd-986313eea7bc	CAD	CNY	2017-03-31	5.16240000	historical_import	2025-11-09 10:18:48.421301+08
aa8d725b-94ab-4d79-a9dd-0ffd34ab5a81	CHF	CNY	2017-03-31	6.88500000	historical_import	2025-11-09 10:18:48.421489+08
22a94a54-b976-4f47-95cb-2a598f786d5f	INR	CNY	2017-03-31	0.10612000	historical_import	2025-11-09 10:18:48.421679+08
19c825a6-2737-4e68-8dd3-630aee83a172	USD	CNY	2017-04-30	6.89540000	historical_import	2025-11-09 10:18:48.421863+08
b5c32e04-d1a1-4a3f-85f0-fbc4f2054d7c	EUR	CNY	2017-04-30	7.53670000	historical_import	2025-11-09 10:18:48.422018+08
6436d300-2d63-48b2-8ac1-7062e83903cc	GBP	CNY	2017-04-30	8.92200000	historical_import	2025-11-09 10:18:48.422173+08
28ab6fcd-d634-48a9-9f43-83ac0bf4f9f8	JPY	CNY	2017-04-30	0.06190000	historical_import	2025-11-09 10:18:48.422338+08
1032f203-d04a-41f9-b27e-9b2d42f25d7e	HKD	CNY	2017-04-30	0.88663000	historical_import	2025-11-09 10:18:48.422487+08
3912f0a4-fe27-42a0-9039-b53c80dcf57b	SGD	CNY	2017-04-30	4.93950000	historical_import	2025-11-09 10:18:48.42267+08
55b740fa-8eb8-4c13-8cfc-a4f3cda5613c	AUD	CNY	2017-04-30	5.15190000	historical_import	2025-11-09 10:18:48.422884+08
39b3bd4c-1e95-4be1-934b-1448faef8de4	CAD	CNY	2017-04-30	5.05340000	historical_import	2025-11-09 10:18:48.423034+08
faad9390-cb8b-4984-ad5c-ae0d4c004374	CHF	CNY	2017-04-30	6.95850000	historical_import	2025-11-09 10:18:48.423211+08
73fef3d5-2140-4cf6-a085-d35fff8fc4ef	INR	CNY	2017-04-30	0.10727000	historical_import	2025-11-09 10:18:48.423376+08
b4cd0a0c-1636-4df9-9456-e46133964af9	USD	CNY	2017-05-31	6.81300000	historical_import	2025-11-09 10:18:48.423532+08
f70df52d-d792-4a1c-ae87-5764b892721e	EUR	CNY	2017-05-31	7.64490000	historical_import	2025-11-09 10:18:48.423702+08
f72412c5-280a-403a-a7e6-e41c91b70f2a	GBP	CNY	2017-05-31	8.75050000	historical_import	2025-11-09 10:18:48.423859+08
4c50d52d-0611-4e06-979d-a1cf838ad817	JPY	CNY	2017-05-31	0.06145000	historical_import	2025-11-09 10:18:48.424011+08
44d9d808-327f-4995-b9a6-6b6e3ef5b2fc	HKD	CNY	2017-05-31	0.87449000	historical_import	2025-11-09 10:18:48.424177+08
27a0c160-592f-4db3-b40e-c563d9dec1a1	SGD	CNY	2017-05-31	4.92650000	historical_import	2025-11-09 10:18:48.42435+08
6952c279-1471-43e3-b202-6815901cd483	AUD	CNY	2017-05-31	5.07830000	historical_import	2025-11-09 10:18:48.424552+08
764cc7f9-4d7e-453f-b93d-5a540d788c7f	CAD	CNY	2017-05-31	5.06020000	historical_import	2025-11-09 10:18:48.425067+08
6c04e436-98c0-4edf-aa6a-22c6059ed399	CHF	CNY	2017-05-31	7.01620000	historical_import	2025-11-09 10:18:48.425224+08
f559db00-e6e3-4a84-9eee-bd044908680c	INR	CNY	2017-05-31	0.10569000	historical_import	2025-11-09 10:18:48.425375+08
40a97f00-4327-46fa-8ae6-7a355438d682	USD	CNY	2017-06-30	6.78100000	historical_import	2025-11-09 10:18:48.425534+08
45e7c7bd-65bf-4ada-9bc2-bb0fa3ed5475	EUR	CNY	2017-06-30	7.73850000	historical_import	2025-11-09 10:18:48.42569+08
291d2647-ca95-4d5c-b1a6-1fb42ca30cf8	GBP	CNY	2017-06-30	8.80050000	historical_import	2025-11-09 10:18:48.425879+08
7ef56590-5bce-4de2-b0d6-e504067a5ba7	JPY	CNY	2017-06-30	0.06058000	historical_import	2025-11-09 10:18:48.426242+08
1bd7ef06-f055-44df-84c8-7d4d47a557c2	HKD	CNY	2017-06-30	0.86883000	historical_import	2025-11-09 10:18:48.426425+08
93fd6836-8ef4-40c7-8f59-d53bf9248aa5	SGD	CNY	2017-06-30	4.92580000	historical_import	2025-11-09 10:18:48.426586+08
c7a75a54-4cba-4edc-858a-09f70ef6f64a	AUD	CNY	2017-06-30	5.21080000	historical_import	2025-11-09 10:18:48.426733+08
dd7440ed-09db-4478-a383-4361312d9057	CAD	CNY	2017-06-30	5.23400000	historical_import	2025-11-09 10:18:48.426906+08
1fe3c06e-b8f2-461b-8e5c-fe3b85f1f69e	CHF	CNY	2017-06-30	7.08010000	historical_import	2025-11-09 10:18:48.427074+08
d53f74a4-3b1c-4922-b16a-214b7c97e891	INR	CNY	2017-06-30	0.10494000	historical_import	2025-11-09 10:18:48.427543+08
12a1d35d-b382-4575-b96a-8cd0c9bb35e5	USD	CNY	2017-07-31	6.72770000	historical_import	2025-11-09 10:18:48.427708+08
982b9c78-78c0-42a5-aaa3-bdf198a98e6a	EUR	CNY	2017-07-31	7.88960000	historical_import	2025-11-09 10:18:48.427857+08
35aea5e0-ee10-49db-9a2e-8232f549c4a4	GBP	CNY	2017-07-31	8.82310000	historical_import	2025-11-09 10:18:48.428014+08
de27b175-85db-4768-9c8c-d99ce1f75f16	JPY	CNY	2017-07-31	0.06083000	historical_import	2025-11-09 10:18:48.428176+08
d19d60ac-f214-47a7-95b5-e2f3809cbaa7	HKD	CNY	2017-07-31	0.86133000	historical_import	2025-11-09 10:18:48.428339+08
4097f17c-cf04-43d8-a61c-5d5f75bf0692	SGD	CNY	2017-07-31	4.95640000	historical_import	2025-11-09 10:18:48.428489+08
fbeede96-73c8-4609-831c-f3b06e327761	AUD	CNY	2017-07-31	5.36230000	historical_import	2025-11-09 10:18:48.42864+08
4b5484de-510b-4e0f-92b5-e779ea924d14	CAD	CNY	2017-07-31	5.39460000	historical_import	2025-11-09 10:18:48.428783+08
254f1332-6411-40f9-b88e-961badbf547b	CHF	CNY	2017-07-31	6.94570000	historical_import	2025-11-09 10:18:48.428936+08
1552c7ef-4473-4207-85c6-146c346c05dd	INR	CNY	2017-07-31	0.10482000	historical_import	2025-11-09 10:18:48.429259+08
075837fd-d3a0-44ee-a648-e44a371645a2	USD	CNY	2017-08-31	6.60120000	historical_import	2025-11-09 10:18:48.429412+08
10bd1916-b476-44b9-81a1-7b4fa85d5e4d	EUR	CNY	2017-08-31	7.80590000	historical_import	2025-11-09 10:18:48.429554+08
533631c2-b14d-475f-b013-ea7c0bc7324c	GBP	CNY	2017-08-31	8.48720000	historical_import	2025-11-09 10:18:48.429722+08
392394fd-d0c5-497c-a93e-6e393be025c4	JPY	CNY	2017-08-31	0.05967000	historical_import	2025-11-09 10:18:48.429882+08
945c5e68-3327-4caa-bc95-9e321666dd14	HKD	CNY	2017-08-31	0.84364000	historical_import	2025-11-09 10:18:48.430036+08
24b2b457-043a-44a8-8f20-bbc70d88fdfc	SGD	CNY	2017-08-31	4.85020000	historical_import	2025-11-09 10:18:48.430182+08
bbea737c-3d1c-4859-ba01-186b14611170	AUD	CNY	2017-08-31	5.19840000	historical_import	2025-11-09 10:18:48.430333+08
b957d58f-fd4d-45ac-b0dc-eabf7a657772	CAD	CNY	2017-08-31	5.21440000	historical_import	2025-11-09 10:18:48.430492+08
f9ff09b3-207d-4a87-971c-1e2ba76bd17f	CHF	CNY	2017-08-31	6.81980000	historical_import	2025-11-09 10:18:48.4307+08
bbfd6fae-70df-4304-b6f4-ec26b436d865	INR	CNY	2017-08-31	0.10325000	historical_import	2025-11-09 10:18:48.430865+08
5d6171cf-edbc-47a2-9c95-8b892db3aa41	USD	CNY	2017-09-30	6.65200000	historical_import	2025-11-09 10:18:48.431021+08
5a506c84-8560-4be5-a8d8-11e92c4567d4	EUR	CNY	2017-09-30	7.85340000	historical_import	2025-11-09 10:18:48.431181+08
49d04ede-4c19-47f4-a616-9a72205db7c8	GBP	CNY	2017-09-30	8.90630000	historical_import	2025-11-09 10:18:48.431373+08
eebee763-8a54-4d9b-b548-6abe29e7eb7a	JPY	CNY	2017-09-30	0.05913000	historical_import	2025-11-09 10:18:48.431531+08
d40d0ed6-b8e1-4b20-8e51-453b4c9580d7	HKD	CNY	2017-09-30	0.85165000	historical_import	2025-11-09 10:18:48.431691+08
5dbe394c-2269-4ed0-8f05-fd53abb4bc19	SGD	CNY	2017-09-30	4.89890000	historical_import	2025-11-09 10:18:48.431989+08
a2abfb6c-3ed1-4d0a-9325-c5b5c4cdd81b	AUD	CNY	2017-09-30	5.20960000	historical_import	2025-11-09 10:18:48.432176+08
0fef9b1b-3d04-41a6-85ae-01d964adbf64	CAD	CNY	2017-09-30	5.34720000	historical_import	2025-11-09 10:18:48.432354+08
9e36dd92-e33b-495f-af23-8937b74a37c1	CHF	CNY	2017-09-30	6.85470000	historical_import	2025-11-09 10:18:48.432614+08
8d6439e3-6d0e-43ad-ab51-685af70ed38b	INR	CNY	2017-09-30	0.10190000	historical_import	2025-11-09 10:18:48.432928+08
1c278910-f050-4b7c-a1f3-a8012d3e76ee	USD	CNY	2017-10-31	6.63150000	historical_import	2025-11-09 10:18:48.433095+08
d2c5359f-3701-4da3-bd58-5cf6c5c33afe	EUR	CNY	2017-10-31	7.71770000	historical_import	2025-11-09 10:18:48.433252+08
6fb329e1-4989-4a69-ab80-2c8cb88a5fe4	GBP	CNY	2017-10-31	8.78480000	historical_import	2025-11-09 10:18:48.43341+08
88170618-623a-4b02-b191-c36b666bb7b3	JPY	CNY	2017-10-31	0.05847000	historical_import	2025-11-09 10:18:48.433567+08
8dbbfb83-79e3-4874-ba15-fea3fd663519	HKD	CNY	2017-10-31	0.85026000	historical_import	2025-11-09 10:18:48.433781+08
d1542e19-89f5-4c20-9cda-ceb6f4cfbbc7	SGD	CNY	2017-10-31	4.86610000	historical_import	2025-11-09 10:18:48.433964+08
80638608-e73a-4462-9cfb-2ec3990dc0ca	AUD	CNY	2017-10-31	5.07410000	historical_import	2025-11-09 10:18:48.434117+08
d04b9564-29f0-4d79-bc3f-cad90b700856	CAD	CNY	2017-10-31	5.14380000	historical_import	2025-11-09 10:18:48.434271+08
3e84a98c-1819-44a7-8b34-30d2401917e9	CHF	CNY	2017-10-31	6.64060000	historical_import	2025-11-09 10:18:48.434578+08
0f677fa0-f458-433d-8b1f-7acb0ab17bbb	INR	CNY	2017-10-31	0.10242000	historical_import	2025-11-09 10:18:48.434733+08
bf9d3cc1-6f21-49c4-8321-e46a52ff7a34	USD	CNY	2017-11-30	6.61470000	historical_import	2025-11-09 10:18:48.434888+08
b495b171-5541-4400-b517-eb0727c904d1	EUR	CNY	2017-11-30	7.83770000	historical_import	2025-11-09 10:18:48.435041+08
b98d2912-bff9-4750-9008-8d72658d4844	GBP	CNY	2017-11-30	8.90800000	historical_import	2025-11-09 10:18:48.435188+08
72375c55-f3aa-415f-abb8-a3335f5504e2	JPY	CNY	2017-11-30	0.05889000	historical_import	2025-11-09 10:18:48.435333+08
c6a47c69-c666-4a45-9e08-8f7373ffb44e	HKD	CNY	2017-11-30	0.84710000	historical_import	2025-11-09 10:18:48.435485+08
3679ef1a-f047-4564-a2fe-cb1001a19de2	SGD	CNY	2017-11-30	4.90290000	historical_import	2025-11-09 10:18:48.435636+08
88d025e4-834d-47a7-bec0-2f45a9801b01	AUD	CNY	2017-11-30	5.00520000	historical_import	2025-11-09 10:18:48.43578+08
9f53b13e-b511-475c-8751-cf2ec56c2bea	CAD	CNY	2017-11-30	5.13380000	historical_import	2025-11-09 10:18:48.435931+08
dd5e936a-9b33-4a02-bc70-72f41329c9b7	CHF	CNY	2017-11-30	6.69950000	historical_import	2025-11-09 10:18:48.436079+08
d8c27a05-9860-4953-8bf4-0918805f5243	INR	CNY	2017-11-30	0.10260000	historical_import	2025-11-09 10:18:48.436223+08
c618b787-808a-4df3-8734-571f2367feb2	USD	CNY	2017-12-31	6.50750000	historical_import	2025-11-09 10:18:48.436531+08
aa42da29-eb3b-4e1f-a597-40f04f83e9d4	EUR	CNY	2017-12-31	7.80440000	historical_import	2025-11-09 10:18:48.436706+08
21f30083-d653-4882-b365-272babd5ad54	GBP	CNY	2017-12-31	8.79640000	historical_import	2025-11-09 10:18:48.436898+08
ee8cf806-8aa8-4a58-a8c3-76cbbe017672	JPY	CNY	2017-12-31	0.05781000	historical_import	2025-11-09 10:18:48.437156+08
5a16869b-1b70-47c1-89f0-28bdcb87f098	HKD	CNY	2017-12-31	0.83274000	historical_import	2025-11-09 10:18:48.437477+08
08150033-c5b8-4df6-9276-05853917ae40	SGD	CNY	2017-12-31	4.87040000	historical_import	2025-11-09 10:18:48.437766+08
bfee6ee3-7d64-47fd-b8a3-6ea8ac8eb59a	AUD	CNY	2017-12-31	5.08560000	historical_import	2025-11-09 10:18:48.438006+08
d7e04b6c-296e-4a72-8bc5-6b62716889d7	CAD	CNY	2017-12-31	5.18940000	historical_import	2025-11-09 10:18:48.438229+08
8deebc07-485d-4ff5-9b2d-0c1822322b5a	CHF	CNY	2017-12-31	6.66930000	historical_import	2025-11-09 10:18:48.438412+08
f69f0477-b2cb-486d-a8ab-16e4b902c945	INR	CNY	2017-12-31	0.10188000	historical_import	2025-11-09 10:18:48.438659+08
aaf0929f-5197-40ac-af63-aa7506e5220c	USD	CNY	2018-01-31	6.28880000	historical_import	2025-11-09 10:18:48.438948+08
b6472d98-3e33-4b61-9819-e1b4cc94f006	EUR	CNY	2018-01-31	7.83400000	historical_import	2025-11-09 10:18:48.439208+08
f728ac0b-b453-4b1a-a0d2-b3a68929bd78	GBP	CNY	2018-01-31	8.91140000	historical_import	2025-11-09 10:18:48.439406+08
d1d44e31-66f3-4629-94d3-4614bcc2db60	JPY	CNY	2018-01-31	0.05777000	historical_import	2025-11-09 10:18:48.439596+08
a958e097-fe25-43b9-8a23-312e90abcd35	HKD	CNY	2018-01-31	0.80420000	historical_import	2025-11-09 10:18:48.439791+08
c3fbfe42-0783-4863-8d21-6c6bb456bf78	SGD	CNY	2018-01-31	4.80970000	historical_import	2025-11-09 10:18:48.439979+08
e25772e1-7c83-44c3-a284-e672eece942f	AUD	CNY	2018-01-31	5.10130000	historical_import	2025-11-09 10:18:48.440389+08
c0ad0bb7-b08f-48e1-94cd-d252132ab6a5	CAD	CNY	2018-01-31	5.12360000	historical_import	2025-11-09 10:18:48.440904+08
d71dc60c-5443-40e6-a9bc-29e341be6475	CHF	CNY	2018-01-31	6.73540000	historical_import	2025-11-09 10:18:48.441136+08
fe3ffd6b-49b8-4edf-8179-a89f918e985e	INR	CNY	2018-01-31	0.09894000	historical_import	2025-11-09 10:18:48.441348+08
6699f12a-9a76-461a-a0ff-b5cd00f9eb2d	USD	CNY	2018-02-28	6.32760000	historical_import	2025-11-09 10:18:48.441531+08
ab6030ec-d906-4867-878f-d9394d39f722	EUR	CNY	2018-02-28	7.72850000	historical_import	2025-11-09 10:18:48.441695+08
b385fb0c-2805-4f42-afac-a09c07ba4f0d	GBP	CNY	2018-02-28	8.74120000	historical_import	2025-11-09 10:18:48.441914+08
29a71680-0048-479a-a134-c3b773aa90c8	JPY	CNY	2018-02-28	0.05912000	historical_import	2025-11-09 10:18:48.4421+08
c784e828-cd39-4803-beac-97ac187b5708	HKD	CNY	2018-02-28	0.80846000	historical_import	2025-11-09 10:18:48.442271+08
740b284d-7aad-47f5-91ea-e53aaac28f8d	SGD	CNY	2018-02-28	4.78190000	historical_import	2025-11-09 10:18:48.442433+08
e2f35c9c-69a3-4c28-9608-b9e1eab09275	AUD	CNY	2018-02-28	4.94240000	historical_import	2025-11-09 10:18:48.442635+08
f2d38112-1d0c-4ae1-b0ca-d7e770ae892a	CAD	CNY	2018-02-28	4.95160000	historical_import	2025-11-09 10:18:48.442808+08
9fa033d3-b769-465e-90a3-440f25a4ca8a	CHF	CNY	2018-02-28	6.70880000	historical_import	2025-11-09 10:18:48.442987+08
96e6feaa-9880-4880-9e26-95488748e496	INR	CNY	2018-02-28	0.09706000	historical_import	2025-11-09 10:18:48.443163+08
bac652a3-21df-4822-b1fd-db55bf1912d4	USD	CNY	2018-03-31	6.28750000	historical_import	2025-11-09 10:18:48.443318+08
27a471fb-43da-4a04-80ce-401c92594b6f	EUR	CNY	2018-03-31	7.74680000	historical_import	2025-11-09 10:18:48.443463+08
0212035e-adf0-4802-99b1-78ed2e4bf132	GBP	CNY	2018-03-31	8.85450000	historical_import	2025-11-09 10:18:48.443626+08
8ca7c7f8-0ae6-43a8-9ab9-b380aabe62f6	JPY	CNY	2018-03-31	0.05907000	historical_import	2025-11-09 10:18:48.443787+08
9bbac545-11cb-485e-8bd4-f155bdef3007	HKD	CNY	2018-03-31	0.80115000	historical_import	2025-11-09 10:18:48.443942+08
38a515bd-66fe-44ff-91d1-5974af6fedab	SGD	CNY	2018-03-31	4.79440000	historical_import	2025-11-09 10:18:48.444092+08
86fd9a8f-3a9b-4696-afc7-591f6951e485	AUD	CNY	2018-03-31	4.83090000	historical_import	2025-11-09 10:18:48.444248+08
4158cb34-7f3a-4e71-8967-4fc0deb84d1e	CAD	CNY	2018-03-31	4.87370000	historical_import	2025-11-09 10:18:48.444456+08
c4873ad4-f018-4441-b148-66e6e7f12241	INR	CNY	2018-03-31	0.09647000	historical_import	2025-11-09 10:18:48.444632+08
0630ac23-1003-4e9e-8f8f-96537fee9c94	USD	CNY	2018-04-30	6.33940000	historical_import	2025-11-09 10:18:48.444826+08
5c1c80d6-207d-4afe-87d3-a1b19d6c6456	GBP	CNY	2018-04-30	8.70550000	historical_import	2025-11-09 10:18:48.444985+08
21afb216-7096-4d8a-9f31-7786e6446963	JPY	CNY	2018-04-30	0.05796000	historical_import	2025-11-09 10:18:48.445134+08
40761fe2-bddf-422d-a2de-ac79607173c3	HKD	CNY	2018-04-30	0.80773000	historical_import	2025-11-09 10:18:48.445289+08
5cfba312-fa34-4384-8ab0-201ce3d8a307	SGD	CNY	2018-04-30	4.78110000	historical_import	2025-11-09 10:18:48.445436+08
aecded32-77d3-4242-bac5-955478b886bb	AUD	CNY	2018-04-30	4.78200000	historical_import	2025-11-09 10:18:48.445604+08
da173cb6-7e95-46e9-9faa-c25f940453fb	CAD	CNY	2018-04-30	4.92690000	historical_import	2025-11-09 10:18:48.445757+08
8437a9d9-0db6-425b-b2dd-b1c63d416fce	CHF	CNY	2018-04-30	6.39820000	historical_import	2025-11-09 10:18:48.446098+08
9441928b-456c-4745-8270-cdfd046300ca	INR	CNY	2018-04-30	0.09551000	historical_import	2025-11-09 10:18:48.446245+08
bb16abef-3fed-4da7-b76f-e6397fed0eb1	USD	CNY	2018-05-31	6.40660000	historical_import	2025-11-09 10:18:48.446401+08
7903e9c5-e140-4fd9-882f-ab9b9c48a636	EUR	CNY	2018-05-31	7.49510000	historical_import	2025-11-09 10:18:48.446573+08
3c5a25ab-cb6f-4d02-ad43-758d721a12d5	GBP	CNY	2018-05-31	8.54820000	historical_import	2025-11-09 10:18:48.446767+08
8af82d2c-2b09-44ae-8f79-f623beaaba1e	JPY	CNY	2018-05-31	0.05886000	historical_import	2025-11-09 10:18:48.446913+08
196141a8-0f6d-436c-8fec-d21ad915d88a	HKD	CNY	2018-05-31	0.81630000	historical_import	2025-11-09 10:18:48.447067+08
77f3f740-2e10-4b80-a0f3-e2f1634a0789	SGD	CNY	2018-05-31	4.78740000	historical_import	2025-11-09 10:18:48.447207+08
ebaf5976-f6a7-4ced-a8fa-77ef81bdccce	AUD	CNY	2018-05-31	4.86250000	historical_import	2025-11-09 10:18:48.447348+08
d895fcbd-7bc5-472d-b8b4-a20af49b541e	CAD	CNY	2018-05-31	4.98410000	historical_import	2025-11-09 10:18:48.447498+08
6248be92-a947-49a0-8d26-05b5bb1176d4	CHF	CNY	2018-05-31	6.50280000	historical_import	2025-11-09 10:18:48.447647+08
a9163ad6-4d48-47d5-af45-d3c69ca741c8	INR	CNY	2018-05-31	0.09511000	historical_import	2025-11-09 10:18:48.4478+08
66c8e687-b0c1-46bb-a7bf-910270f31446	USD	CNY	2018-06-30	6.61950000	historical_import	2025-11-09 10:18:48.448078+08
0a368c53-b6bd-4e88-8472-9242607943cb	EUR	CNY	2018-06-30	7.71700000	historical_import	2025-11-09 10:18:48.448289+08
90d861fc-af45-4ca0-bf70-90318708d72d	GBP	CNY	2018-06-30	8.70940000	historical_import	2025-11-09 10:18:48.448465+08
4b1ddc78-4f61-402a-8d68-de1c59baf56f	JPY	CNY	2018-06-30	0.05980000	historical_import	2025-11-09 10:18:48.448624+08
5258dedd-53c6-4304-945f-595efaa3b053	HKD	CNY	2018-06-30	0.84368000	historical_import	2025-11-09 10:18:48.448803+08
9b93d1cd-c8b7-4da2-a996-008eda6327b2	SGD	CNY	2018-06-30	4.85470000	historical_import	2025-11-09 10:18:48.448969+08
77355bb5-740e-4cb1-a8f4-276b457aee52	AUD	CNY	2018-06-30	4.88820000	historical_import	2025-11-09 10:18:48.449125+08
a585ba4a-ba6e-415b-88a4-a4160b648c33	CAD	CNY	2018-06-30	4.99740000	historical_import	2025-11-09 10:18:48.449279+08
1fcf1719-1eea-4216-b785-1f49ddc5f89c	CHF	CNY	2018-06-30	6.67040000	historical_import	2025-11-09 10:18:48.449432+08
32b3c497-b7a7-4c75-9410-a52084770c1a	USD	CNY	2018-07-31	6.83180000	historical_import	2025-11-09 10:18:48.449581+08
626b1acf-5f19-4f63-b6f5-4336101fc862	GBP	CNY	2018-07-31	8.98660000	historical_import	2025-11-09 10:18:48.449745+08
fab4acc1-4f5e-4737-bb54-a3d77534f1e5	JPY	CNY	2018-07-31	0.06128000	historical_import	2025-11-09 10:18:48.449894+08
8471fb73-f644-4e60-a50c-94bed3a585fb	HKD	CNY	2018-07-31	0.87042000	historical_import	2025-11-09 10:18:48.450031+08
ac30a5fc-37aa-4e8e-9e9a-cbe7e835bb55	CAD	CNY	2018-07-31	5.24110000	historical_import	2025-11-09 10:18:48.450187+08
7c0b1eb8-8ed8-42ed-8e2d-bd7635148bda	USD	CNY	2018-08-31	6.83750000	historical_import	2025-11-09 10:18:48.450518+08
0303fd80-2d13-41cf-9210-2575d599b5c9	GBP	CNY	2018-08-31	8.87720000	historical_import	2025-11-09 10:18:48.450655+08
6a0f9e32-f816-4742-b556-582ebaca09ca	HKD	CNY	2018-08-31	0.87109000	historical_import	2025-11-09 10:18:48.450802+08
57d8f9da-0caa-4090-8083-77f08ef105fb	SGD	CNY	2018-08-31	4.98990000	historical_import	2025-11-09 10:18:48.450953+08
25941539-dd26-48da-b84b-b54f957b2dc2	USD	CNY	2018-09-30	6.88170000	historical_import	2025-11-09 10:18:48.451105+08
063b8252-fe1b-4bd2-837e-3bfc66a13da7	SGD	CNY	2018-09-30	5.02950000	historical_import	2025-11-09 10:18:48.451251+08
5249bf6d-b663-4ca4-a50f-244d00be8a2b	AUD	CNY	2018-09-30	4.96400000	historical_import	2025-11-09 10:18:48.4514+08
396d8f60-3e02-40e2-9f55-fca319a4cbb7	CAD	CNY	2018-09-30	5.28820000	historical_import	2025-11-09 10:18:48.451562+08
36a7d30b-a131-4bba-b36e-7a9315248b16	USD	CNY	2018-10-31	6.97430000	historical_import	2025-11-09 10:18:48.451716+08
3b594418-31b5-472e-ba63-f7b848c4a7c6	CAD	CNY	2018-10-31	5.31330000	historical_import	2025-11-09 10:18:48.452069+08
d5eb9a93-fa21-4ecb-bd7b-c5bc086bced1	USD	CNY	2018-11-30	6.94580000	historical_import	2025-11-09 10:18:48.452237+08
c9678565-7722-4125-ba97-038231261c45	USD	CNY	2018-12-31	6.87780000	historical_import	2025-11-09 10:18:48.45239+08
6e0b380d-8252-47d5-9bda-1a8bb1c93ba1	USD	CNY	2019-01-31	6.70350000	historical_import	2025-11-09 10:18:48.452532+08
2500081f-ac8b-4bbd-a379-030e2caf19ad	USD	CNY	2019-02-28	6.68440000	historical_import	2025-11-09 10:18:48.452674+08
8b1f4834-294c-4553-9d6a-640d3851c349	USD	CNY	2019-03-31	6.71090000	historical_import	2025-11-09 10:18:48.452823+08
0a7acf3d-2c6d-45cf-bd0f-d8c84aa68776	USD	CNY	2019-04-30	6.73390000	historical_import	2025-11-09 10:18:48.452975+08
c89227a5-e428-4b29-bc9e-cfdc0f625870	USD	CNY	2019-05-31	6.90920000	historical_import	2025-11-09 10:18:48.45313+08
3bfb802b-6942-4442-bd86-1ab9eb1961f7	USD	CNY	2019-06-30	6.87040000	historical_import	2025-11-09 10:18:48.453286+08
52beb4e0-e08f-4dbb-961c-731271ebf828	USD	CNY	2019-07-31	6.88220000	historical_import	2025-11-09 10:18:48.453435+08
a7bce308-72dd-4827-8136-f3f8ee40cb38	USD	CNY	2019-08-31	7.15010000	historical_import	2025-11-09 10:18:48.453599+08
bd564858-b1ac-44f6-a8de-453b306c0808	HKD	CNY	2019-08-31	0.91171000	historical_import	2025-11-09 10:18:48.453748+08
7e99afbb-8fa0-49a6-bea5-88b308fe418d	SGD	CNY	2019-08-31	5.15330000	historical_import	2025-11-09 10:18:48.453908+08
063aa783-4a7b-4e85-b099-15f8be82715a	AUD	CNY	2019-08-31	4.81210000	historical_import	2025-11-09 10:18:48.454063+08
655f6af3-9d13-44b1-8b31-213303e14a66	CHF	CNY	2019-08-31	7.23330000	historical_import	2025-11-09 10:18:48.454233+08
e8685213-0cec-43c1-8772-b88d00928fbd	USD	CNY	2019-09-30	7.14340000	historical_import	2025-11-09 10:18:48.454404+08
7204e787-8335-4bdd-8d8a-6abf387c7bfe	GBP	CNY	2019-09-30	8.78190000	historical_import	2025-11-09 10:18:48.454559+08
44f1c4b9-fecc-43f6-a1e6-5ace45f7b8a3	AUD	CNY	2019-09-30	4.82350000	historical_import	2025-11-09 10:18:48.454712+08
756c6c90-4f60-4dab-a693-98eb1d377fc9	INR	CNY	2019-09-30	0.10081000	historical_import	2025-11-09 10:18:48.454848+08
9822c8cc-2141-4eb6-a06e-699176e336de	USD	CNY	2019-10-31	7.04140000	historical_import	2025-11-09 10:18:48.455+08
608ab141-6134-4309-9d84-b4d1fe79105f	GBP	CNY	2019-10-31	9.11850000	historical_import	2025-11-09 10:18:48.455417+08
0897b481-e1da-4c26-82b6-2ed99f6335b9	JPY	CNY	2019-10-31	0.06505000	historical_import	2025-11-09 10:18:48.455632+08
6abbe92e-9571-4f2f-a14a-6d97f0664384	USD	CNY	2019-11-30	7.02710000	historical_import	2025-11-09 10:18:48.456019+08
095ee77f-af48-4cfc-b22a-c2a8d7f3071d	USD	CNY	2019-12-31	6.96150000	historical_import	2025-11-09 10:18:48.45642+08
a6488787-0878-4763-829a-ccc84ff0d10d	SGD	CNY	2019-12-31	5.17540000	historical_import	2025-11-09 10:18:48.456715+08
503976cc-9770-4b4d-b763-f8480d72f4bb	USD	CNY	2020-02-29	6.98390000	historical_import	2025-11-09 10:18:48.456897+08
060f2f17-1f96-4243-a2b9-4e0bfdafbd4d	USD	CNY	2020-03-31	7.09970000	historical_import	2025-11-09 10:18:48.457081+08
10ca142f-ee74-42f2-aee4-c17d37248a57	USD	CNY	2020-04-30	7.04900000	historical_import	2025-11-09 10:18:48.457245+08
a16b866a-4c74-4380-8fc5-f931a4b4bba1	USD	CNY	2020-05-31	7.13510000	historical_import	2025-11-09 10:18:48.457408+08
2d92f365-52a3-4133-82e2-d794289b1d41	USD	CNY	2020-06-30	7.07440000	historical_import	2025-11-09 10:18:48.45756+08
946d4ccc-ee0d-47d8-a6d0-5b98e7506816	USD	CNY	2020-07-31	6.97480000	historical_import	2025-11-09 10:18:48.457715+08
e5ff4099-6c1a-48bd-98f3-e80af95040c5	USD	CNY	2020-08-31	6.84350000	historical_import	2025-11-09 10:18:48.45786+08
c892db89-94da-4b4f-9c3a-c9b7457cc9f6	USD	CNY	2020-09-30	6.80900000	historical_import	2025-11-09 10:18:48.458004+08
a8eb1e59-78b2-44f7-8bd4-254193d2b860	USD	CNY	2020-10-31	6.68130000	historical_import	2025-11-09 10:18:48.458158+08
2dd24a38-67e2-456c-8047-0f9a9019226f	USD	CNY	2020-11-30	6.57750000	historical_import	2025-11-09 10:18:48.458313+08
8fbd3426-f56f-468f-a9b8-9279d897fc22	USD	CNY	2020-12-31	6.53780000	historical_import	2025-11-09 10:18:48.458461+08
07c99749-6727-42bc-a9d3-cbbbff05553f	USD	CNY	2021-01-31	6.43100000	historical_import	2025-11-09 10:18:48.458607+08
6a8ac654-c671-4b7c-8f44-e0d070a9d64d	USD	CNY	2021-02-28	6.46690000	historical_import	2025-11-09 10:18:48.45876+08
d8602b35-4237-43ba-9455-492638f3efb7	USD	CNY	2021-03-31	6.55110000	historical_import	2025-11-09 10:18:48.458901+08
8f574d4f-54ba-4989-81c3-55fba3db8911	USD	CNY	2021-04-30	6.46700000	historical_import	2025-11-09 10:18:48.459045+08
fec5cd5d-9db7-4fd4-b832-e2ce61effef4	USD	CNY	2021-05-31	6.37010000	historical_import	2025-11-09 10:18:48.459183+08
a6b1b0fd-e677-43ef-827e-54cadfcd10b2	USD	CNY	2021-06-30	6.45760000	historical_import	2025-11-09 10:18:48.459327+08
0c8ea028-0169-4d4b-9fa1-972398496788	USD	CNY	2021-07-31	6.46190000	historical_import	2025-11-09 10:18:48.459507+08
240f42ec-af2a-4b19-b232-5ff90b785296	USD	CNY	2021-08-31	6.46150000	historical_import	2025-11-09 10:18:48.459716+08
6bdd30a7-ec5b-45df-aa85-511360ba79a1	USD	CNY	2021-09-30	6.46400000	historical_import	2025-11-09 10:18:48.459871+08
8d0a8314-e217-46ab-acb3-78c28212247d	USD	CNY	2021-10-31	6.39660000	historical_import	2025-11-09 10:18:48.460047+08
3aea5e17-4bf4-4754-bbc0-156b3193eceb	USD	CNY	2021-11-30	6.37110000	historical_import	2025-11-09 10:18:48.460233+08
caf1c4c7-e352-4d8e-a63a-e82fe2a30b9b	USD	CNY	2021-12-31	6.35240000	historical_import	2025-11-09 10:18:48.460453+08
f46b0d49-4458-4f3f-b45e-25c749029612	USD	CNY	2022-01-31	6.36100000	historical_import	2025-11-09 10:18:48.46062+08
07feb10c-6cbb-42c0-a80b-e4973ae2dab8	USD	CNY	2022-02-28	6.31040000	historical_import	2025-11-09 10:18:48.460951+08
6f5e8b77-6c4b-4232-9698-76fa0543aabf	USD	CNY	2022-03-31	6.34200000	historical_import	2025-11-09 10:18:48.461104+08
6f5a8a00-9c46-4cce-8f15-80e0dc08e934	USD	CNY	2022-04-30	6.58830000	historical_import	2025-11-09 10:18:48.461265+08
5e804733-ee57-47df-92e7-e81ef2703936	USD	CNY	2022-05-31	6.66500000	historical_import	2025-11-09 10:18:48.461409+08
c30a766e-3744-41d5-8515-636b81b90d5b	USD	CNY	2022-06-30	6.70300000	historical_import	2025-11-09 10:18:48.461558+08
0fc6ba4e-2e18-4fa7-8b58-6a9950e239e0	USD	CNY	2022-07-31	6.73710000	historical_import	2025-11-09 10:18:48.461699+08
ff46d973-e179-4b83-9f20-f47f0680e266	USD	CNY	2022-08-31	6.89470000	historical_import	2025-11-09 10:18:48.461849+08
1a1496d1-49f8-44d9-8b04-604522b2f98a	USD	CNY	2022-09-30	7.11610000	historical_import	2025-11-09 10:18:48.462004+08
52b1c95b-e295-45dd-8392-5be99cc1f21d	USD	CNY	2022-10-31	7.30080000	historical_import	2025-11-09 10:18:48.462149+08
51feee79-4d24-45ae-bd86-84d895de4760	USD	CNY	2022-11-30	7.07760000	historical_import	2025-11-09 10:18:48.4623+08
18e71525-e752-4645-ab99-381235e303a9	USD	CNY	2022-12-31	6.89870000	historical_import	2025-11-09 10:18:48.462456+08
d6d437cd-6cc0-4bf1-bc11-41340e90b257	USD	CNY	2023-01-31	6.75690000	historical_import	2025-11-09 10:18:48.462604+08
af50043e-2565-46fe-a20d-3ac8305d9d00	USD	CNY	2023-02-28	6.93690000	historical_import	2025-11-09 10:18:48.462743+08
8c1efb75-4366-4c64-99f8-fbb82ccfa978	USD	CNY	2023-03-31	6.87480000	historical_import	2025-11-09 10:18:48.462902+08
6e4f0abf-e494-4b59-82d2-e016122c4625	USD	CNY	2023-04-30	6.91910000	historical_import	2025-11-09 10:18:48.463053+08
54aef536-34fb-4b78-b3c4-3227f20c8a4b	USD	CNY	2023-05-31	7.10720000	historical_import	2025-11-09 10:18:48.463201+08
f32bfaaa-dd5d-4323-b1af-9743c701a6e8	USD	CNY	2023-06-30	7.26880000	historical_import	2025-11-09 10:18:48.463337+08
ade0c490-63b6-4caf-a2e9-8060eb32420a	USD	CNY	2023-07-31	7.14940000	historical_import	2025-11-09 10:18:48.46348+08
b6505c7b-6517-4c1a-835d-046ba50853db	USD	CNY	2023-08-31	7.28710000	historical_import	2025-11-09 10:18:48.463611+08
e9028997-521a-4e40-9584-8bc2cfe8a703	USD	CNY	2023-09-30	7.30150000	historical_import	2025-11-09 10:18:48.463747+08
980254c0-2ab1-4387-be8d-272b9b98cfb2	USD	CNY	2023-10-31	7.31580000	historical_import	2025-11-09 10:18:48.463903+08
557cf98d-bcab-4086-91b8-b28c15c3335c	USD	CNY	2023-11-30	7.13640000	historical_import	2025-11-09 10:18:48.464079+08
6c7a6326-95ce-4310-a5f6-e0b5265141ce	USD	CNY	2023-12-31	7.10490000	historical_import	2025-11-09 10:18:48.464239+08
11cb26a2-5869-4013-b5f8-0142e6d77efc	USD	CNY	2024-01-31	7.17810000	historical_import	2025-11-09 10:18:48.464391+08
fa0062a0-9b9d-4882-a88c-f385ed7b0609	USD	CNY	2024-02-29	7.19450000	historical_import	2025-11-09 10:18:48.464542+08
9e409e8c-ce3e-4736-8dd4-a19ad556213c	USD	CNY	2024-03-31	7.22820000	historical_import	2025-11-09 10:18:48.464694+08
2d1bb8c8-71ca-4993-9e25-86ded9bd7d52	USD	CNY	2024-04-30	7.24100000	historical_import	2025-11-09 10:18:48.464861+08
33774dbd-d350-49a1-a3a0-175fe861a987	USD	CNY	2024-05-31	7.24080000	historical_import	2025-11-09 10:18:48.465144+08
f7d8bc48-8ea5-4af2-928e-5f0894cc121e	USD	CNY	2024-06-30	7.26280000	historical_import	2025-11-09 10:18:48.465309+08
a916dccd-97a6-47fc-8482-23c47242b2de	USD	CNY	2024-07-31	7.22150000	historical_import	2025-11-09 10:18:48.46571+08
38ad27c4-d352-410f-825d-36d780e482a0	USD	CNY	2024-08-31	7.08800000	historical_import	2025-11-09 10:18:48.465872+08
7c39a4a2-df46-416c-80de-a0ac92e97bba	USD	CNY	2024-09-30	7.01240000	historical_import	2025-11-09 10:18:48.466028+08
c053aad6-fc71-4a25-b334-3fc40c4a4bc2	USD	CNY	2024-10-31	7.11600000	historical_import	2025-11-09 10:18:48.46618+08
b0e8db0e-0fcb-46b9-a5ba-a2e8989a53da	USD	CNY	2024-11-30	7.24140000	historical_import	2025-11-09 10:18:48.466324+08
33e655f5-1598-4d96-a552-b9d05a199af2	USD	CNY	2024-12-31	7.29940000	historical_import	2025-11-09 10:18:48.466477+08
a68cdb33-1d30-48d7-a2d3-5ab749398fb7	USD	CNY	2025-01-31	7.25130000	historical_import	2025-11-09 10:18:48.466628+08
378c446b-adf9-4447-887e-7c92d55ed62f	USD	CNY	2025-02-28	7.27900000	historical_import	2025-11-09 10:18:48.466787+08
abb5fadd-9ec7-451d-9e75-2b8ac7be2907	USD	CNY	2025-03-31	7.25310000	historical_import	2025-11-09 10:18:48.466962+08
f446b0a0-1bc3-4481-94aa-852fa957dfc2	USD	CNY	2025-04-30	7.26590000	historical_import	2025-11-09 10:18:48.467319+08
7b366620-d6fd-489b-bb73-a88a5867ec2d	USD	CNY	2025-05-31	7.19430000	historical_import	2025-11-09 10:18:48.46749+08
500b7f9a-db32-40b0-8602-3e3a0cde3fa9	USD	CNY	2025-06-30	7.16470000	historical_import	2025-11-09 10:18:48.467646+08
a366e8f0-eff2-4490-99a9-f9c2ff8dafa9	USD	CNY	2025-07-31	7.19470000	historical_import	2025-11-09 10:18:48.467789+08
22602695-0fc8-4c4e-a4f0-a76808d0ea8c	USD	CNY	2025-08-31	7.13290000	historical_import	2025-11-09 10:18:48.467934+08
2c3be555-3f35-40e7-bfb3-346002c90686	USD	CNY	2025-09-30	7.11960000	historical_import	2025-11-09 10:18:48.46808+08
dd7f20b2-f501-42c0-af17-6aa34d0898c0	USD	CNY	2025-10-31	7.11620000	historical_import	2025-11-09 10:18:48.46823+08
061915ec-0021-40c8-9c06-18e325e3f282	HKD	CNY	2025-11-09	0.91565000	api	2025-11-09 10:01:25.041952+08
f610750d-2f49-440c-9056-af85efa73f7a	SGD	CNY	2025-11-09	5.46890000	api	2025-11-09 10:01:25.3048+08
\.


--
-- Data for Name: fund_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.fund_details (id, asset_id, fund_type, fund_category, management_fee, custodian_fee, subscription_fee, redemption_fee, nav, nav_date, accumulated_nav, fund_size, inception_date, fund_manager, fund_company, min_investment, min_redemption, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: futures_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.futures_details (id, asset_id, futures_type, underlying_asset, contract_month, contract_size, tick_size, tick_value, trading_hours, last_trading_date, delivery_date, delivery_method, initial_margin, maintenance_margin, margin_rate, position_limit, daily_price_limit, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: liquidity_tags; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.liquidity_tags (id, name, description, color, sort_order, is_active, created_at) FROM stdin;
cc893a70-ae7f-47ed-a81e-97486a3b4524	高流动性	大盘股、主要ETF等高流动性资产	#22c55e	1	t	2025-11-07 21:05:53.358078+08
c6ef56b5-8971-47b6-9f3b-c449ff5913d6	中等流动性	中盘股、部分基金等中等流动性资产	#f59e0b	2	t	2025-11-07 21:05:53.358078+08
7a3c492c-3aa4-494d-9cf2-4a46d17f183a	低流动性	小盘股、私募基金等低流动性资产	#ef4444	3	t	2025-11-07 21:05:53.358078+08
f882c8fd-4edb-4667-8ad0-0aa385d5de71	锁定期	有锁定期限制的资产	#8b5cf6	4	t	2025-11-07 21:05:53.358078+08
7003ccf0-d1c5-4fe0-a32a-7f5b4f35a48f	不可交易	暂停交易或退市的资产	#6b7280	5	t	2025-11-07 21:05:53.358078+08
\.


--
-- Data for Name: markets; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.markets (id, code, name, country, currency, timezone, trading_hours, holidays, is_active, created_at, updated_at) FROM stdin;
d1f012ef-ff87-447e-9061-43b77382c43c	SSE	上海证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
93b2ea2a-17ee-41c5-9603-e82aee44417f	SZSE	深圳证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
b32e2b9c-e3d4-4e41-b7bb-81e9c35db53c	HKEX	香港交易所	HKG	HKD	Asia/Hong_Kong	{"open": "09:30", "close": "16:00", "lunch_break": {"end": "13:00", "start": "12:00"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
bf6232a9-40e3-4788-98e8-f18ee0ec2fb6	NYSE	纽约证券交易所	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
b9e633ae-50b0-467d-bf96-351b9eab0a0c	NASDAQ	纳斯达克	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
93e69f74-5df6-47ef-9ac2-639072dcf1cf	TSE	东京证券交易所	JPN	JPY	Asia/Tokyo	{"open": "09:00", "close": "15:00", "lunch_break": {"end": "12:30", "start": "11:30"}}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
b4359415-0cbc-4786-97a9-2ffbf5df7188	LSE	伦敦证券交易所	GBR	GBP	Europe/London	{"open": "08:00", "close": "16:30"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
06954cbd-28dd-444c-9137-85bf6a15ecf2	FWB	法兰克福证券交易所	DEU	EUR	Europe/Berlin	{"open": "09:00", "close": "17:30"}	\N	t	2025-11-07 21:05:53.356856+08	2025-11-07 21:05:53.356856+08
\.


--
-- Data for Name: option_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.option_details (id, asset_id, underlying_asset_id, option_type, strike_price, expiration_date, contract_size, exercise_style, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: performance_metrics; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.performance_metrics (id, portfolio_id, metric_type, period_type, period_start, period_end, value, currency, metadata, calculated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.permissions (id, name, resource, action, description, created_at) FROM stdin;
35705400-574b-4ac4-967f-eea3283e32f8	users.create	users	create	创建用户	2025-11-07 21:05:53.350655+08
eef94c62-8cc3-466b-be67-d6c028dc9320	users.read	users	read	查看用户信息	2025-11-07 21:05:53.350655+08
e5d6ab45-d2b1-463c-a9c3-25acd95a3e20	users.update	users	update	更新用户信息	2025-11-07 21:05:53.350655+08
a8b2da5e-192e-47cf-ac4b-e2221e093c95	users.delete	users	delete	删除用户	2025-11-07 21:05:53.350655+08
85a02685-1689-4abb-9af8-9562db0179ea	portfolios.create	portfolios	create	创建投资组合	2025-11-07 21:05:53.350655+08
213c516c-2e81-4900-b880-390f3221c113	portfolios.read	portfolios	read	查看投资组合	2025-11-07 21:05:53.350655+08
71c5f73f-ec3e-4ffc-9b20-feecaec2f536	portfolios.update	portfolios	update	更新投资组合	2025-11-07 21:05:53.350655+08
c8ea0975-9405-42ce-ab2f-bd1a37de520e	portfolios.delete	portfolios	delete	删除投资组合	2025-11-07 21:05:53.350655+08
1692e1a7-a33d-4dc7-8306-5a25f482d82f	accounts.create	trading_accounts	create	创建交易账户	2025-11-07 21:05:53.350655+08
30d64c5a-fc49-45a3-9652-6747c08a924a	accounts.read	trading_accounts	read	查看交易账户	2025-11-07 21:05:53.350655+08
8485e1e9-2a9e-4704-a863-0e1e5c304950	accounts.update	trading_accounts	update	更新交易账户	2025-11-07 21:05:53.350655+08
b27540e1-0a3b-43ee-9464-e3ecb5b27321	accounts.delete	trading_accounts	delete	删除交易账户	2025-11-07 21:05:53.350655+08
9f757852-e630-498f-a5c5-353436a40ae4	transactions.create	transactions	create	创建交易记录	2025-11-07 21:05:53.350655+08
17a0a364-e115-471d-8392-e88879720791	transactions.read	transactions	read	查看交易记录	2025-11-07 21:05:53.350655+08
cb436f9a-7ef2-46bc-8341-e99372b79f7f	transactions.update	transactions	update	更新交易记录	2025-11-07 21:05:53.350655+08
4d2247d5-2882-4c7c-a300-8e4eaa294b80	transactions.delete	transactions	delete	删除交易记录	2025-11-07 21:05:53.350655+08
d9629cb0-d0eb-4c3b-aa0f-229f93b3e07e	transactions.import	transactions	import	批量导入交易记录	2025-11-07 21:05:53.350655+08
f48b62db-e078-4cfe-b4ac-8dde98283b3c	assets.create	assets	create	创建资产	2025-11-07 21:05:53.350655+08
f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	assets.read	assets	read	查看资产信息	2025-11-07 21:05:53.350655+08
56c23162-5976-4ca4-964e-b1b36ae41e85	assets.update	assets	update	更新资产信息	2025-11-07 21:05:53.350655+08
0790f87a-cd62-4f05-82ff-042902b0a51b	assets.delete	assets	delete	删除资产	2025-11-07 21:05:53.350655+08
09aa0f57-e97a-4dc1-ab00-c3c3af8b1d11	reports.create	reports	create	创建报表	2025-11-07 21:05:53.350655+08
3eed05cc-1d64-4e07-9b97-b8ed103e59b0	reports.read	reports	read	查看报表	2025-11-07 21:05:53.350655+08
6cae6bd0-8d33-4cf5-8a0c-98eab2133ae1	reports.update	reports	update	更新报表	2025-11-07 21:05:53.350655+08
6eca62f8-ff89-4ab0-b45a-f47e056daa5c	reports.delete	reports	delete	删除报表	2025-11-07 21:05:53.350655+08
614e6f26-125d-482e-8480-7ad01bd5228f	reports.export	reports	export	导出报表	2025-11-07 21:05:53.350655+08
e4b3d8bc-3a48-4eb1-bb68-8ca02320f790	system.config	system	config	系统配置管理	2025-11-07 21:05:53.350655+08
f6c544aa-a006-4c5d-8524-813a6b083b8a	system.logs	system	logs	查看系统日志	2025-11-07 21:05:53.350655+08
990cff7f-bdf1-424c-b21a-d4d8f4ee0040	system.backup	system	backup	数据备份管理	2025-11-07 21:05:53.350655+08
16814e43-0a3c-462d-bb1f-79838297ee17	exchange_rate.create	exchange_rate	create	创建汇率记录	2025-11-09 10:31:48.187804+08
4370924f-7b52-464a-a673-4cd437513100	exchange_rate.read	exchange_rate	read	查看汇率信息	2025-11-09 10:31:48.187804+08
09b8012b-b744-444b-8fc0-e93cf6e76917	exchange_rate.update	exchange_rate	update	更新汇率信息	2025-11-09 10:31:48.187804+08
fdacdee2-7d5e-41d2-8899-94210bdbc475	exchange_rate.delete	exchange_rate	delete	删除汇率记录	2025-11-09 10:31:48.187804+08
5cd2d8fd-c94e-406e-87c3-21ea04a19723	exchange_rate.import	exchange_rate	import	批量导入汇率数据	2025-11-09 10:31:48.187804+08
\.


--
-- Data for Name: portfolio_snapshots; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.portfolio_snapshots (id, portfolio_id, snapshot_date, total_value, cash_value, invested_value, unrealized_gain_loss, realized_gain_loss, currency, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: portfolio_tags; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.portfolio_tags (id, portfolio_id, tag_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: portfolios; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.portfolios (id, user_id, name, description, base_currency, is_default, is_active, created_at, updated_at, sort_order) FROM stdin;
\.


--
-- Data for Name: position_snapshots; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.position_snapshots (id, position_id, portfolio_snapshot_id, snapshot_date, quantity, market_price, market_value, average_cost, total_cost, unrealized_gain_loss, currency, created_at) FROM stdin;
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.positions (id, portfolio_id, trading_account_id, asset_id, quantity, average_cost, total_cost, currency, first_purchase_date, last_transaction_date, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: price_data_sources; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_data_sources (id, name, provider, api_endpoint, api_key_encrypted, config, rate_limit, timeout_seconds, is_active, last_sync_at, last_sync_status, last_error_message, created_at, updated_at, created_by, updated_by) FROM stdin;
5a0a447b-27ba-491b-a995-09f80f5162c9	天天基金	ttjj	http://api.1234567.com.cn/fund	\N	{"features": {"fund_nav": true, "fund_holding": true, "fund_ranking": true, "manager_info": true, "fund_performance": true}, "free_plan": false, "data_types": ["fund_nav", "fund_ranking", "fund_holding"], "description": "中国最大的基金数据平台，包含基金净值、排名、持仓", "requires_api_key": true, "supports_markets": ["SSE", "SZSE"], "supports_products": ["FUND", "ETF"], "rate_limit_per_minute": 60}	60	30	f	\N	\N	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
a0bac1dd-9e3d-4988-85f9-f25379e47085	Binance API	binance	https://api.binance.com/api	\N	{"features": {"kline_data": true, "trade_data": true, "order_placement": true, "real_time_prices": true, "account_management": true}, "free_plan": true, "data_types": ["real_time", "historical", "klines", "trades"], "description": "币安加密货币交易所数据，包含实时行情、交易数据", "requires_api_key": false, "supports_markets": ["CRYPTO"], "supports_products": ["CRYPTO"], "rate_limit_per_minute": 1200}	1200	15	f	\N	\N	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
bf901d15-81a7-497d-88b3-d24b8ab60fe9	FRED (Federal Reserve)	fred	https://api.stlouisfed.org/fred	\N	{"features": {"historical": true, "batch_query": true}, "data_types": ["economic_indicators"], "requires_api_key": true, "supports_products": ["ECONOMIC_INDICATOR"], "supports_countries": ["US"], "rate_limit_per_minute": 120}	120	30	t	\N	\N	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
d8654879-c098-491a-bd6c-db7aeb2efbbf	新浪财经	sina	http://hq.sinajs.cn	\N	{"features": {"bid_ask": true, "realtime": true, "batch_query": true}, "data_types": ["realtime", "historical"], "requires_api_key": false, "supports_products": ["STOCK", "FUND", "FUTURES", "FOREX"], "supports_countries": ["CN"], "rate_limit_per_minute": 150}	200	15	t	2025-11-08 15:17:06.335562	success	\N	2025-11-07 22:02:26.557691	2025-11-07 22:02:26.557691	\N	\N
f6fede55-c798-44fa-b5d8-66ec7afd4809	东方财富	eastmoney	http://push2.eastmoney.com/api/qt/stock/kline/get	\N	{"supports_batch": false, "timeout_seconds": 15, "supports_products": ["STOCK", "FUND"], "supports_countries": ["CN"], "rate_limit_per_minute": 100}	60	30	t	\N	\N	\N	2025-11-08 07:13:40.553711	2025-11-08 07:13:40.553711	\N	\N
7755cebe-ded0-4d2e-8ee6-286c48ccf623	Yahoo Finance	yahoo_finance	https://query1.finance.yahoo.com/v8/finance/chart/	\N	{"supports_batch": false, "timeout_seconds": 30, "supports_products": ["STOCK", "ETF", "FUND"], "supports_countries": ["US", "HK", "CN"], "rate_limit_per_minute": 60}	60	30	t	2025-11-09 07:07:12.645739	success	\N	2025-11-08 07:11:32.459892	2025-11-08 07:11:32.459892	\N	\N
\.


--
-- Data for Name: price_sync_errors; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_errors (id, log_id, asset_id, asset_symbol, error_type, error_message, error_details, occurred_at) FROM stdin;
2c3965b6-e465-4045-a4eb-1eaf518b6ca7	d46d52f7-24e6-4464-9e72-8cb7186072cd	2aa3f894-681b-4a75-9003-ab376a35df7e	000001	other	Unsupported provider: sina	\N	2025-11-07 23:23:03.808785
39928394-6b39-4090-8b98-b3214bd5d7f9	d46d52f7-24e6-4464-9e72-8cb7186072cd	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	000002	other	Unsupported provider: sina	\N	2025-11-07 23:23:03.813878
c1a74020-91fb-4705-b529-987685d91449	d46d52f7-24e6-4464-9e72-8cb7186072cd	a7569e62-8eec-4468-8798-d1e948ef4679	600036	other	Unsupported provider: sina	\N	2025-11-07 23:23:03.815086
714f6f7f-b66a-4dba-9c03-bc8d035e556d	d46d52f7-24e6-4464-9e72-8cb7186072cd	49589118-facc-4785-abf3-3d2d4d054f17	600519	other	Unsupported provider: sina	\N	2025-11-07 23:23:03.816008
d8c8acae-fa8b-4b5b-8ab4-44ece20f525f	ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	2aa3f894-681b-4a75-9003-ab376a35df7e	000001	other	Tushare API key not configured	\N	2025-11-07 23:28:27.103661
e97066ef-08b7-4fd5-b66b-5bf60954c067	ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	a6efbeb9-3af7-4565-a0b0-8a222138ca7d	000002	other	Tushare API key not configured	\N	2025-11-07 23:28:27.108294
ad827849-35a8-4ec4-9491-89b83d1150d2	ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	a7569e62-8eec-4468-8798-d1e948ef4679	600036	other	Tushare API key not configured	\N	2025-11-07 23:28:27.109941
3a454628-e1ce-45b7-8df8-9cc14092ff15	ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	49589118-facc-4785-abf3-3d2d4d054f17	600519	other	Tushare API key not configured	\N	2025-11-07 23:28:27.111094
\.


--
-- Data for Name: price_sync_logs; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_logs (id, task_id, data_source_id, started_at, completed_at, status, total_assets, total_records, success_count, failed_count, skipped_count, result_summary, error_message) FROM stdin;
d46d52f7-24e6-4464-9e72-8cb7186072cd	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:23:03.799605	2025-11-07 23:23:03.817978	failed	4	0	0	4	0	{"errors": [{"error": "Unsupported provider: sina", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Unsupported provider: sina", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Unsupported provider: sina", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Unsupported provider: sina", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
221c33f4-5fe3-415c-9978-35945e02387e	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:25:24.389492	2025-11-07 23:25:24.399941	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
14aac112-0432-4d97-a122-6a873091cec8	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:26:34.492899	2025-11-07 23:26:34.496545	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
952c68a8-c3be-4d31-9a86-e01b070b536c	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:30:09.246066	2025-11-07 23:30:11.56784	success	4	261	261	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 261, "total_records": 261, "duration_seconds": 2}	\N
ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	\N	2025-11-07 23:28:27.087069	2025-11-07 23:28:27.113019	failed	4	0	0	4	0	{"errors": [{"error": "Tushare API key not configured", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Tushare API key not configured", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Tushare API key not configured", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Tushare API key not configured", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
b5d226ea-5546-4003-96b9-8217de2fd0d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-08 15:17:03.00095	2025-11-08 15:17:06.3348	success	10	284	284	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 10, "skipped_count": 0, "success_count": 284, "total_records": 284, "duration_seconds": 3}	\N
a7033f67-740f-4eb4-a71b-6c4fbe405420	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:08.30219	2025-11-08 20:00:08.307126	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
138414fc-b7ea-4a66-be8c-f1e3d3b782e2	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:32.049396	2025-11-08 20:00:32.055626	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
54974cb0-d021-46ef-a421-1f2b73e95b0d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:23:36.58379	2025-11-08 20:23:36.597436	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
155bf661-6bb1-4444-9ca5-0223d1d3969d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:55:03.087373	2025-11-08 20:55:06.543362	success	4	264	264	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 264, "total_records": 264, "duration_seconds": 3}	\N
c8838372-8286-4f7f-977b-1a3b9dce1086	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-09 07:07:09.788844	2025-11-09 07:07:12.64543	success	4	968	968	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 968, "total_records": 968, "duration_seconds": 2}	\N
\.


--
-- Data for Name: price_sync_logs_backup; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_logs_backup (id, task_id, data_source_id, started_at, completed_at, status, total_assets, total_records, success_count, failed_count, skipped_count, result_summary, error_message) FROM stdin;
d46d52f7-24e6-4464-9e72-8cb7186072cd	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:23:03.799605	2025-11-07 23:23:03.817978	failed	4	0	0	4	0	{"errors": [{"error": "Unsupported provider: sina", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Unsupported provider: sina", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Unsupported provider: sina", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Unsupported provider: sina", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
221c33f4-5fe3-415c-9978-35945e02387e	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:25:24.389492	2025-11-07 23:25:24.399941	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
14aac112-0432-4d97-a122-6a873091cec8	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:26:34.492899	2025-11-07 23:26:34.496545	success	4	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
952c68a8-c3be-4d31-9a86-e01b070b536c	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-07 23:30:09.246066	2025-11-07 23:30:11.56784	success	4	261	261	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 261, "total_records": 261, "duration_seconds": 2}	\N
ff20ea3c-b3bb-4bdc-8430-ff7952e2d1d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	\N	2025-11-07 23:28:27.087069	2025-11-07 23:28:27.113019	failed	4	0	0	4	0	{"errors": [{"error": "Tushare API key not configured", "symbol": "000001", "asset_id": "2aa3f894-681b-4a75-9003-ab376a35df7e"}, {"error": "Tushare API key not configured", "symbol": "000002", "asset_id": "a6efbeb9-3af7-4565-a0b0-8a222138ca7d"}, {"error": "Tushare API key not configured", "symbol": "600036", "asset_id": "a7569e62-8eec-4468-8798-d1e948ef4679"}, {"error": "Tushare API key not configured", "symbol": "600519", "asset_id": "49589118-facc-4785-abf3-3d2d4d054f17"}], "success": false, "failed_count": 4, "total_assets": 4, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
b5d226ea-5546-4003-96b9-8217de2fd0d0	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	d8654879-c098-491a-bd6c-db7aeb2efbbf	2025-11-08 15:17:03.00095	2025-11-08 15:17:06.3348	success	10	284	284	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 10, "skipped_count": 0, "success_count": 284, "total_records": 284, "duration_seconds": 3}	\N
a7033f67-740f-4eb4-a71b-6c4fbe405420	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:08.30219	2025-11-08 20:00:08.307126	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
138414fc-b7ea-4a66-be8c-f1e3d3b782e2	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:00:32.049396	2025-11-08 20:00:32.055626	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
54974cb0-d021-46ef-a421-1f2b73e95b0d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:23:36.58379	2025-11-08 20:23:36.597436	success	0	0	0	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 0, "skipped_count": 0, "success_count": 0, "total_records": 0, "duration_seconds": 0}	\N
155bf661-6bb1-4444-9ca5-0223d1d3969d	3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	7755cebe-ded0-4d2e-8ee6-286c48ccf623	2025-11-08 20:55:03.087373	2025-11-08 20:55:06.543362	success	4	264	264	0	0	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 264, "total_records": 264, "duration_seconds": 3}	\N
\.


--
-- Data for Name: price_sync_tasks; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.price_sync_tasks (id, name, description, data_source_id, asset_type_id, asset_ids, schedule_type, cron_expression, interval_minutes, sync_days_back, overwrite_existing, is_active, last_run_at, next_run_at, last_run_status, last_run_result, created_at, updated_at, created_by, updated_by, country_id) FROM stdin;
3c4ab0bf-fd9b-42e2-9f9e-6d4bc26f207f	股票价格同步	\N	7755cebe-ded0-4d2e-8ee6-286c48ccf623	761e5638-cff8-4247-bfd7-00edcd57a51a	\N	manual	\N	\N	365	t	t	2025-11-09 07:07:09.797005	\N	success	{"errors": [], "success": true, "failed_count": 0, "total_assets": 4, "skipped_count": 0, "success_count": 968, "total_records": 968, "duration_seconds": 2}	2025-11-07 23:21:30.717759	2025-11-07 23:21:30.717759	\N	\N	d7d5c3ba-92c1-4619-891c-de4d455179ed
\.


--
-- Data for Name: report_executions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.report_executions (id, report_id, execution_status, started_at, completed_at, file_path, file_size, error_message, metadata) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.reports (id, user_id, portfolio_id, name, description, report_type, parameters, schedule, is_scheduled, is_active, last_generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.role_permissions (id, role_id, permission_id, created_at) FROM stdin;
a0762afb-a48d-4eb4-8afc-021747207990	eb08af9f-bb10-47f5-94b1-0812282a4917	35705400-574b-4ac4-967f-eea3283e32f8	2025-11-07 21:05:53.352135+08
faaa935f-9a29-4410-8f03-22db179f4c81	eb08af9f-bb10-47f5-94b1-0812282a4917	eef94c62-8cc3-466b-be67-d6c028dc9320	2025-11-07 21:05:53.352135+08
c063991d-29fa-4b8e-b318-054ae2f36313	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	eef94c62-8cc3-466b-be67-d6c028dc9320	2025-11-07 21:05:53.352135+08
23754427-426a-4e88-8c84-ac4f52941aa9	927f1425-7f82-4c3d-8701-289e2ccb820b	eef94c62-8cc3-466b-be67-d6c028dc9320	2025-11-07 21:05:53.352135+08
8cbc685b-a1aa-466e-b618-a9320f638e56	eb08af9f-bb10-47f5-94b1-0812282a4917	e5d6ab45-d2b1-463c-a9c3-25acd95a3e20	2025-11-07 21:05:53.352135+08
76193866-18b5-4c1a-8de1-618b0adf3b4a	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	e5d6ab45-d2b1-463c-a9c3-25acd95a3e20	2025-11-07 21:05:53.352135+08
dc73a69b-72ad-40ab-ad13-e0cbb60c544c	eb08af9f-bb10-47f5-94b1-0812282a4917	a8b2da5e-192e-47cf-ac4b-e2221e093c95	2025-11-07 21:05:53.352135+08
886039eb-3511-4197-b0b7-56bb3f84ab14	eb08af9f-bb10-47f5-94b1-0812282a4917	85a02685-1689-4abb-9af8-9562db0179ea	2025-11-07 21:05:53.352135+08
fdd308e4-9562-4cc6-ac23-2c32aac48c97	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	85a02685-1689-4abb-9af8-9562db0179ea	2025-11-07 21:05:53.352135+08
6c45de77-50c7-4b9f-8daa-17bc30ca39cc	eb08af9f-bb10-47f5-94b1-0812282a4917	213c516c-2e81-4900-b880-390f3221c113	2025-11-07 21:05:53.352135+08
7c006dc1-beda-4d97-8831-fd9f59bc6682	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	213c516c-2e81-4900-b880-390f3221c113	2025-11-07 21:05:53.352135+08
a80c56be-8c70-464b-9235-db3fc6c48768	927f1425-7f82-4c3d-8701-289e2ccb820b	213c516c-2e81-4900-b880-390f3221c113	2025-11-07 21:05:53.352135+08
85998344-ecc2-4d5c-aff8-7e5254318cf3	eb08af9f-bb10-47f5-94b1-0812282a4917	71c5f73f-ec3e-4ffc-9b20-feecaec2f536	2025-11-07 21:05:53.352135+08
19cfc15f-623a-4e76-8321-c7a15a57d3ea	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	71c5f73f-ec3e-4ffc-9b20-feecaec2f536	2025-11-07 21:05:53.352135+08
5fc13459-8909-46cf-aef4-cc6ad01586d9	eb08af9f-bb10-47f5-94b1-0812282a4917	c8ea0975-9405-42ce-ab2f-bd1a37de520e	2025-11-07 21:05:53.352135+08
c15b5272-e623-4417-8bdd-d34ee3f63191	eb08af9f-bb10-47f5-94b1-0812282a4917	1692e1a7-a33d-4dc7-8306-5a25f482d82f	2025-11-07 21:05:53.352135+08
ca5f4613-fcc9-4f62-9680-2c51c4ae0f9f	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	1692e1a7-a33d-4dc7-8306-5a25f482d82f	2025-11-07 21:05:53.352135+08
0c96e9da-0bd2-4f6e-882a-dbf5e6b044be	eb08af9f-bb10-47f5-94b1-0812282a4917	30d64c5a-fc49-45a3-9652-6747c08a924a	2025-11-07 21:05:53.352135+08
e4902116-cdbe-498e-9fad-8828db27a1a9	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	30d64c5a-fc49-45a3-9652-6747c08a924a	2025-11-07 21:05:53.352135+08
3b77f8b3-ee11-4fd6-a9e6-d36ed530628c	927f1425-7f82-4c3d-8701-289e2ccb820b	30d64c5a-fc49-45a3-9652-6747c08a924a	2025-11-07 21:05:53.352135+08
af95b3dc-a339-43b4-b4bf-6a9714980d4d	eb08af9f-bb10-47f5-94b1-0812282a4917	8485e1e9-2a9e-4704-a863-0e1e5c304950	2025-11-07 21:05:53.352135+08
85ca0786-3ed0-4e36-ad18-81e232276c0a	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	8485e1e9-2a9e-4704-a863-0e1e5c304950	2025-11-07 21:05:53.352135+08
789254f4-ee3a-43da-a5cf-f71a1a0d7148	eb08af9f-bb10-47f5-94b1-0812282a4917	b27540e1-0a3b-43ee-9464-e3ecb5b27321	2025-11-07 21:05:53.352135+08
ef116949-f9eb-4074-b6bf-a18b7b0531ee	eb08af9f-bb10-47f5-94b1-0812282a4917	9f757852-e630-498f-a5c5-353436a40ae4	2025-11-07 21:05:53.352135+08
3fe09bb1-c1c9-4609-ad13-54129869cabe	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	9f757852-e630-498f-a5c5-353436a40ae4	2025-11-07 21:05:53.352135+08
dbaa25de-844b-4127-a792-39e2c7cf8e17	eb08af9f-bb10-47f5-94b1-0812282a4917	17a0a364-e115-471d-8392-e88879720791	2025-11-07 21:05:53.352135+08
3e3023c0-4013-4def-976f-427b98946912	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	17a0a364-e115-471d-8392-e88879720791	2025-11-07 21:05:53.352135+08
c37682b9-bd81-44ee-8dea-119d7c9aa8cd	927f1425-7f82-4c3d-8701-289e2ccb820b	17a0a364-e115-471d-8392-e88879720791	2025-11-07 21:05:53.352135+08
4cbd8c34-6dd1-4a30-b1ba-d1c484c78921	eb08af9f-bb10-47f5-94b1-0812282a4917	cb436f9a-7ef2-46bc-8341-e99372b79f7f	2025-11-07 21:05:53.352135+08
81ed3ed4-859d-4b13-9a3e-45e4506e5240	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	cb436f9a-7ef2-46bc-8341-e99372b79f7f	2025-11-07 21:05:53.352135+08
a1842d2a-6b00-4d3f-9226-35e486a996b6	eb08af9f-bb10-47f5-94b1-0812282a4917	4d2247d5-2882-4c7c-a300-8e4eaa294b80	2025-11-07 21:05:53.352135+08
cf446850-9d50-42f7-93a9-d8ec1b82a3de	eb08af9f-bb10-47f5-94b1-0812282a4917	d9629cb0-d0eb-4c3b-aa0f-229f93b3e07e	2025-11-07 21:05:53.352135+08
1c18ec4c-2144-4453-94e6-b56c4bfcfeb5	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	d9629cb0-d0eb-4c3b-aa0f-229f93b3e07e	2025-11-07 21:05:53.352135+08
d5ad8d9c-591c-4446-87a9-17221bfa199c	eb08af9f-bb10-47f5-94b1-0812282a4917	f48b62db-e078-4cfe-b4ac-8dde98283b3c	2025-11-07 21:05:53.352135+08
62cc5d47-fc77-4432-833d-5d6d88498569	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	f48b62db-e078-4cfe-b4ac-8dde98283b3c	2025-11-07 21:05:53.352135+08
ac9a7d81-418c-490d-b0df-6222a912db53	eb08af9f-bb10-47f5-94b1-0812282a4917	f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	2025-11-07 21:05:53.352135+08
4b289b8c-bd0e-4bb6-b37b-6850713696b2	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	2025-11-07 21:05:53.352135+08
d46d66f1-2675-4cf5-83a9-cbbe9c0f3b57	927f1425-7f82-4c3d-8701-289e2ccb820b	f8ecee8e-eb8e-4127-92b8-bbb361dbeeff	2025-11-07 21:05:53.352135+08
cb224bda-bef6-44ff-b5c1-526edec872a6	eb08af9f-bb10-47f5-94b1-0812282a4917	56c23162-5976-4ca4-964e-b1b36ae41e85	2025-11-07 21:05:53.352135+08
01806253-48f6-4eb5-be29-b9302c39846f	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	56c23162-5976-4ca4-964e-b1b36ae41e85	2025-11-07 21:05:53.352135+08
b9dfccbb-9dec-433f-ba22-d8043ca15186	eb08af9f-bb10-47f5-94b1-0812282a4917	0790f87a-cd62-4f05-82ff-042902b0a51b	2025-11-07 21:05:53.352135+08
6c9a8829-da08-4cda-acfa-5ae60556420e	eb08af9f-bb10-47f5-94b1-0812282a4917	09aa0f57-e97a-4dc1-ab00-c3c3af8b1d11	2025-11-07 21:05:53.352135+08
fd327680-1006-4090-971e-58c7ef4b7a10	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	09aa0f57-e97a-4dc1-ab00-c3c3af8b1d11	2025-11-07 21:05:53.352135+08
7b968e74-5cd0-4db7-a1ec-2c27117de43a	eb08af9f-bb10-47f5-94b1-0812282a4917	3eed05cc-1d64-4e07-9b97-b8ed103e59b0	2025-11-07 21:05:53.352135+08
7fda69a5-bcc1-4176-bc38-9b2553a07bd5	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	3eed05cc-1d64-4e07-9b97-b8ed103e59b0	2025-11-07 21:05:53.352135+08
7251ebed-7ab1-41e7-875a-4add9530210e	927f1425-7f82-4c3d-8701-289e2ccb820b	3eed05cc-1d64-4e07-9b97-b8ed103e59b0	2025-11-07 21:05:53.352135+08
9ae6bc0c-90e9-4d95-afc9-de28abc5c88e	eb08af9f-bb10-47f5-94b1-0812282a4917	6cae6bd0-8d33-4cf5-8a0c-98eab2133ae1	2025-11-07 21:05:53.352135+08
b109215a-15a4-4dc3-a767-13b926db2ac7	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	6cae6bd0-8d33-4cf5-8a0c-98eab2133ae1	2025-11-07 21:05:53.352135+08
21ec505c-7127-47c5-b70a-e76e8170b58b	eb08af9f-bb10-47f5-94b1-0812282a4917	6eca62f8-ff89-4ab0-b45a-f47e056daa5c	2025-11-07 21:05:53.352135+08
6a781f73-4d32-401c-9f95-22b59643ab0f	eb08af9f-bb10-47f5-94b1-0812282a4917	614e6f26-125d-482e-8480-7ad01bd5228f	2025-11-07 21:05:53.352135+08
304ce2d4-fd1e-4826-a92c-b13734918ce5	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	614e6f26-125d-482e-8480-7ad01bd5228f	2025-11-07 21:05:53.352135+08
798a6ee0-db04-48b6-9049-63d098a3e85d	eb08af9f-bb10-47f5-94b1-0812282a4917	e4b3d8bc-3a48-4eb1-bb68-8ca02320f790	2025-11-07 21:05:53.352135+08
b4afcc1c-c526-4e88-acd9-9d02961289f3	eb08af9f-bb10-47f5-94b1-0812282a4917	f6c544aa-a006-4c5d-8524-813a6b083b8a	2025-11-07 21:05:53.352135+08
7a0efb20-094e-45ab-9364-2a35dc052f77	eb08af9f-bb10-47f5-94b1-0812282a4917	990cff7f-bdf1-424c-b21a-d4d8f4ee0040	2025-11-07 21:05:53.352135+08
8518ca7b-36ec-4ef6-961f-ed3c4eda0e48	eb08af9f-bb10-47f5-94b1-0812282a4917	16814e43-0a3c-462d-bb1f-79838297ee17	2025-11-09 10:31:48.193349+08
9bed83b4-b843-4e2d-9a2a-887c8cfe5319	eb08af9f-bb10-47f5-94b1-0812282a4917	4370924f-7b52-464a-a673-4cd437513100	2025-11-09 10:31:48.193349+08
fb14ef44-4e35-4aab-a65e-62472dc41927	eb08af9f-bb10-47f5-94b1-0812282a4917	09b8012b-b744-444b-8fc0-e93cf6e76917	2025-11-09 10:31:48.193349+08
36989e01-eff2-4b52-a027-addeb00d798f	eb08af9f-bb10-47f5-94b1-0812282a4917	fdacdee2-7d5e-41d2-8899-94210bdbc475	2025-11-09 10:31:48.193349+08
b49bb067-d906-407e-b07d-f9f8039baec5	eb08af9f-bb10-47f5-94b1-0812282a4917	5cd2d8fd-c94e-406e-87c3-21ea04a19723	2025-11-09 10:31:48.193349+08
88ea4db1-b6c1-4118-b2a5-657dc29774a2	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	4370924f-7b52-464a-a673-4cd437513100	2025-11-09 10:31:48.196485+08
52227707-5119-4891-b5e6-a387e37be6c1	927f1425-7f82-4c3d-8701-289e2ccb820b	4370924f-7b52-464a-a673-4cd437513100	2025-11-09 10:31:48.197136+08
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.roles (id, name, description, is_active, created_at, updated_at) FROM stdin;
eb08af9f-bb10-47f5-94b1-0812282a4917	admin	系统管理员，拥有所有权限	t	2025-11-07 21:05:53.346865+08	2025-11-07 21:05:53.346865+08
38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	user	普通用户，拥有基本功能权限	t	2025-11-07 21:05:53.346865+08	2025-11-07 21:05:53.346865+08
927f1425-7f82-4c3d-8701-289e2ccb820b	viewer	只读用户，只能查看数据	t	2025-11-07 21:05:53.346865+08	2025-11-07 21:05:53.346865+08
\.


--
-- Data for Name: stock_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.stock_details (id, asset_id, sector, industry, market_cap, shares_outstanding, pe_ratio, pb_ratio, dividend_yield, company_website, headquarters, founded_year, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_option_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.stock_option_details (id, asset_id, underlying_stock_id, underlying_stock_symbol, underlying_stock_name, option_type, strike_price, expiration_date, contract_size, exercise_style, settlement_type, multiplier, trading_unit, min_price_change, margin_requirement, commission_rate, delta, gamma, theta, vega, rho, implied_volatility, historical_volatility, premium_currency, intrinsic_value, time_value, cost_divisor, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tag_categories; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.tag_categories (id, name, description, color, icon, user_id, parent_id, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.tags (id, name, description, color, icon, user_id, category_id, is_system, is_active, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trading_accounts; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.trading_accounts (id, portfolio_id, name, account_type, broker_name, account_number, currency, initial_balance, current_balance, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_tag_mappings; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.transaction_tag_mappings (transaction_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.transactions (id, portfolio_id, trading_account_id, asset_id, transaction_type, quantity, price, total_amount, fees, taxes, currency, exchange_rate, transaction_date, settlement_date, notes, tags, liquidity_tag_id, external_id, metadata, created_at, updated_at, user_id, side, executed_at, settled_at, status, liquidity_tag) FROM stdin;
\.


--
-- Data for Name: treasury_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.treasury_details (id, asset_id, treasury_type, term_type, face_value, coupon_rate, coupon_frequency, issue_date, maturity_date, term_years, issue_price, issue_number, yield_to_maturity, tradable, min_holding_period, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.user_roles (id, user_id, role_id, assigned_by, assigned_at, expires_at, is_active) FROM stdin;
cb56861d-abc8-4745-b041-a325409cfe57	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	38c76c8b-b714-4eb3-9114-2baf7f5fb3bc	e04747dd-bbe9-4d24-adcf-1c088e3c3491	2025-11-07 21:20:18.95748+08	\N	t
039c1f2f-0f06-4331-a3b6-2443eca1ce96	e04747dd-bbe9-4d24-adcf-1c088e3c3491	eb08af9f-bb10-47f5-94b1-0812282a4917	e04747dd-bbe9-4d24-adcf-1c088e3c3491	2025-11-07 21:21:06.096613+08	\N	t
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.user_sessions (id, user_id, token_hash, refresh_token_hash, device_info, ip_address, user_agent, is_active, expires_at, created_at, last_used_at) FROM stdin;
724cd83c-27ed-4c53-a025-5dba04b6cb9c	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$473iScTBipzF9PZzdR5TEO42h5KYO/7jeOvOwJAuIkZAx4/cdNSP.	\N	\N	\N	\N	t	2025-11-08 21:17:24+08	2025-11-07 21:17:24.964+08	2025-11-07 21:17:24.964+08
36014bca-ff1e-42a4-b79a-4bb9fd3f160b	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$HrsLtKPYJo9dDFJfud7vKuIrPFMN1ufMu9obK4IXRiSKY3aIFmJLq	\N	\N	\N	\N	t	2025-11-08 21:17:25+08	2025-11-07 21:17:25.393+08	2025-11-07 21:17:25.393+08
bc531fb9-2f42-4880-b6a0-32978f7d7534	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$d/5EhHhZqIv5iGJLe8GD1.BJEpTLnotGGkkoI4N/Ry3G29/93rI2.	\N	\N	\N	\N	t	2025-11-08 21:17:44+08	2025-11-07 21:17:44.897+08	2025-11-07 21:17:44.897+08
f4f7e96c-bf26-4c96-99e5-a3912855bd06	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$wtNGu6nNupnLbP6OgM4GG.nNPEZyzsKL2GlolHXgtj17wS.FBdyqG	\N	\N	\N	\N	t	2025-11-08 21:17:48+08	2025-11-07 21:17:48.248+08	2025-11-07 21:17:48.248+08
7961c023-4622-4351-aaad-daf64879536a	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$ZfpGXZ.nGMQQ2uYzrpr0beB.EjbzsskF.7ZKXYpJBfe0p8WHCPr3.	\N	\N	\N	\N	t	2025-11-08 21:19:41+08	2025-11-07 21:19:41.123+08	2025-11-07 21:19:41.123+08
1ba50a76-d4d4-43ce-bd91-e542995d6713	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$3nn.hYN6N6BdgDUebVaBeuGCHTmB1FdVea6uoYLUrVZ0NG03QM4FS	\N	\N	\N	\N	t	2025-11-08 21:21:33+08	2025-11-07 21:21:33.192+08	2025-11-07 21:21:33.192+08
092c433e-469e-4584-aa74-b0c271da432d	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$IIV3kCzZDGJ8tW3qVy4dSOdBrHQq4eG7.WaAEBcXxCH7rjPV5219.	\N	\N	\N	\N	t	2025-11-08 21:24:36+08	2025-11-07 21:24:36.284+08	2025-11-07 21:24:36.284+08
87955c7d-5d09-436f-89bc-30caaff64826	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$ssDZS2fJ4nDj.0EDxyCQwOtGEcBdsb0QvgyhoCQLGP.4oSqESGDgy	\N	\N	\N	\N	t	2025-11-08 21:25:53+08	2025-11-07 21:25:53.062+08	2025-11-07 21:25:53.062+08
44e22918-5143-43a1-b6e7-4261e0c0b4da	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$6ssOkAB8r7kReFUNnrg7m.XzA/z8cHYSTE9rXm7sW/w6gcBIxi/MO	\N	\N	\N	\N	t	2025-11-08 21:29:16+08	2025-11-07 21:29:16.086+08	2025-11-07 21:29:16.086+08
8f2c0067-b29d-4087-8db2-7a72d7b2f89a	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$28g5cF5.mTT7FCqsMP7Ife7l6rGo67AKrBAcJZWQCMOisUf0/h93a	\N	\N	\N	\N	t	2025-11-08 21:29:57+08	2025-11-07 21:29:57.443+08	2025-11-07 21:29:57.443+08
31703632-2c9e-4da2-9625-d6e7a0432dec	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$VINg0B/IgvBYesnGD3yGquN3VTe.yDsA8UyJb8BBfN89/7qE.8Gxi	\N	\N	\N	\N	t	2025-11-08 21:29:57+08	2025-11-07 21:29:57.547+08	2025-11-07 21:29:57.547+08
474fec7c-e585-44d3-9c36-ac4371e48c12	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$sAcmhlZpJOAwYSy6be3jWOCR0Dap5auDgv7qtJwVb0akuzF6Nony2	\N	\N	\N	\N	t	2025-11-08 21:51:00+08	2025-11-07 21:51:00.705+08	2025-11-07 21:51:00.705+08
e72ab5c2-76aa-4170-97d6-08eb28d71d75	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$wgqVdQ/aWD3.Ee114P034OMtwFUrGmZSFKmtpY/JXiVKJIX.1Pv0.	\N	\N	\N	\N	t	2025-11-08 21:51:59+08	2025-11-07 21:51:59.875+08	2025-11-07 21:51:59.875+08
9a660c5f-5062-4dde-9237-f9b20e3b2525	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$lPZEw03BbOLWWr1yMA2U8.gEuLVxOfY9ZMtqx1vISHNvZHLzKPrOK	\N	\N	\N	\N	t	2025-11-08 21:52:04+08	2025-11-07 21:52:04.922+08	2025-11-07 21:52:04.922+08
f5f13a29-88b8-4b70-a313-9ba60447b4ea	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$trcqziIYTIcoO7JVqtwcuu3FGL0WPoXTYyezR.nZui24g8yQzdypW	\N	\N	\N	\N	t	2025-11-09 10:44:17+08	2025-11-08 10:44:17.188+08	2025-11-08 10:44:17.188+08
c606ada3-8d3d-49c5-8492-d793307ae54d	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$d8Rivm25Vg9Dh9TykAPH3uTy7JMNG1mtNBxTa8JygtX.lwztbITjK	\N	\N	\N	\N	t	2025-11-09 10:44:22+08	2025-11-08 10:44:22.418+08	2025-11-08 10:44:22.418+08
6b813dc2-a6b1-4213-8835-640cd23ff5ce	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$PtAgktzeC5diScSEcVoqKuXso5g0BKI0DCs0e.mG9J8SAWuvkNyga	\N	\N	\N	\N	t	2025-11-09 11:46:51+08	2025-11-08 11:46:51.327+08	2025-11-08 11:46:51.327+08
9cb3c41d-6e48-4fe2-872a-136ff2de8795	a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	$2b$10$VGLxV.yO2/GN8rUgus6sHOgaR4CAgm.sh7qWVzwU6ss2Pmrw7Wz2W	\N	\N	\N	\N	t	2025-11-09 16:05:06+08	2025-11-08 16:05:06.381+08	2025-11-08 16:05:06.381+08
0db59352-e2c6-45bc-9726-e5fc87b0c702	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$4WhkNeZNgszytcn/aHADYu.Vo/XZIHOnkqVwU1g.5XC1Ai75Vb2.q	\N	\N	\N	\N	t	2025-11-09 18:54:22+08	2025-11-08 18:54:22.366+08	2025-11-08 18:54:22.366+08
70048169-e1d7-445c-83b2-a16a14985cf2	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$WkafIl2RbvMB3nCLtixeKem96iT6jNRjtCXnnDvCLf8i62pUoz592	\N	\N	\N	\N	t	2025-11-09 18:54:27+08	2025-11-08 18:54:27.804+08	2025-11-08 18:54:27.804+08
9f2e9d95-e7df-45a8-a018-fbd2e5f4fe96	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$RkNsbIok5m4T/zAgtuyAcOUK2oQ9vuUHcYiaTN4SyoeZsoeuEK2PC	\N	\N	\N	\N	t	2025-11-10 10:30:22+08	2025-11-09 10:30:23.023+08	2025-11-09 10:30:23.023+08
712e486f-4760-485d-9820-bf8486a61936	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$GVTYo.RHfvTg01ggXBDTjuU72QABIkeVGhKa.3CF8zujjqY8FWNp6	\N	\N	\N	\N	t	2025-11-10 10:32:43+08	2025-11-09 10:32:43.693+08	2025-11-09 10:32:43.693+08
6f74010f-9c93-434d-8ab4-46fc477ef949	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$GPb4oSM82kgm2du6QsMfhOglNzBew1Qb68unvs0ZhesIPuFgs78o.	\N	\N	\N	\N	t	2025-11-10 10:32:49+08	2025-11-09 10:32:49.272+08	2025-11-09 10:32:49.272+08
5c8631af-272c-44ff-a1e4-18b3c25f7114	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$u7qhX1/7tMAaJU5i7HyxjOjfq9ckZERpgCxDuBeY6jmAg99AKFgd.	\N	\N	\N	\N	t	2025-11-10 10:32:55+08	2025-11-09 10:32:55.365+08	2025-11-09 10:32:55.365+08
9e4f336a-462b-4c72-8e79-4b53847a8510	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$6F6VYaX/c0NtUPFsrT7EfenksWYkTrqOA0J6HxtORebl5Sxb8mYk6	\N	\N	\N	\N	t	2025-11-10 10:33:23+08	2025-11-09 10:33:23.23+08	2025-11-09 10:33:23.23+08
61c9190a-e798-486c-828e-5dadc684b0f3	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$A8SX80TU2hF2lMd/kkY2F.9hla2685T1ad08epQvRkpKKnOR6tBs6	\N	\N	\N	\N	t	2025-11-10 10:33:42+08	2025-11-09 10:33:42.198+08	2025-11-09 10:33:42.198+08
e82edf9a-628e-469a-befb-612fc488bea9	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$ovmYWNo5iRRqAykqxCePe.kpET09.6KkYCkOLb881rxjAHZtq.36.	\N	\N	\N	\N	t	2025-11-10 10:34:08+08	2025-11-09 10:34:08.927+08	2025-11-09 10:34:08.927+08
9d7bbee9-6eed-4310-b4b1-a849ab2bfd63	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$m5IrpJ20CtZeDL83fBipHud9nZtzimHIqqqxIIrLsVrxxBYYFsMY2	\N	\N	\N	\N	t	2025-11-10 10:34:16+08	2025-11-09 10:34:16.852+08	2025-11-09 10:34:16.852+08
9bc94f18-8d1e-4c75-9e06-2e9322fcb300	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$d7tazGtQn55wtrC6YYXR4u0PlfdLTl61da/NRG65E1Do9J29orqpe	\N	\N	\N	\N	t	2025-11-10 10:34:32+08	2025-11-09 10:34:32.205+08	2025-11-09 10:34:32.205+08
193e9be6-7e2e-4957-9397-d72301f08a24	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$s8FUegNGJrcN9vUvmhBu2OdUqgIxzyU8NM6Cuhc.Ap.SXpIXKYUvm	\N	\N	\N	\N	t	2025-11-10 10:36:20+08	2025-11-09 10:36:20.484+08	2025-11-09 10:36:20.484+08
9b118150-5699-4b50-9226-f9eb6ec216a4	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$0Z3TKxqdtiA9RZI137TXqOl6de6ggUpnb0cY8ok1/cCw10EG1ggIi	\N	\N	\N	\N	t	2025-11-10 10:37:26+08	2025-11-09 10:37:26.195+08	2025-11-09 10:37:26.195+08
5f4e2d76-9774-4146-badd-3b6e56efdbbc	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$KKEJBmvI0B39i.isRqL7DO5XF82mcoCvOKrN472UkaCAUpFBp9H9K	\N	\N	\N	\N	t	2025-11-10 10:37:43+08	2025-11-09 10:37:43.174+08	2025-11-09 10:37:43.174+08
9549a7a0-a50a-4d89-b280-4332bb6a429e	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$EgMSCYLAdM29Xr97aNJjE.UZIyQcSkagnRUFtgGKRPuh0wX3f/.La	\N	\N	\N	\N	t	2025-11-10 10:38:30+08	2025-11-09 10:38:30.763+08	2025-11-09 10:38:30.763+08
dcce7fc1-3fc3-452a-87e8-8f56d2ad82de	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$EnL6N0mp0haP1KQDq0TUHuHGxgw.27E0cvprO79GObDmLmDGPkWVq	\N	\N	\N	\N	t	2025-11-10 10:42:20+08	2025-11-09 10:42:20.075+08	2025-11-09 10:42:20.075+08
dc148f4a-3ace-4b4b-8f33-62a90f16db12	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$nZtVqUKcTHlKhuJPG7knGeFuwD.m9tgL19Avv05hS03ZobarNEhn.	\N	\N	\N	\N	t	2025-11-10 10:42:36+08	2025-11-09 10:42:37.02+08	2025-11-09 10:42:37.02+08
714d6697-5e21-4cf6-a201-325bd2b98e14	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$sC59w6oZVR1aZenff0HwFeoREpFSiZj4EjEthbOIUTZbG4FQdJfjC	\N	\N	\N	\N	t	2025-11-10 10:44:14+08	2025-11-09 10:44:14.291+08	2025-11-09 10:44:14.291+08
214e3a51-9d24-4e1e-8284-2b25c642afe1	e04747dd-bbe9-4d24-adcf-1c088e3c3491	$2b$10$QrDqHxzbzVSREKTIYwEhA.BHyjbF2JdSkAvwOxLNiILK72jekz4Eq	\N	\N	\N	\N	t	2025-11-10 10:44:31+08	2025-11-09 10:44:31.249+08	2025-11-09 10:44:31.249+08
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.users (id, email, username, password_hash, first_name, last_name, phone, avatar_url, timezone, language, currency_preference, is_active, is_verified, email_verified_at, last_login_at, login_count, failed_login_attempts, locked_until, created_at, updated_at) FROM stdin;
a7f71f4e-b5a2-40fd-a4fb-e573b4e911ea	testapi@finapp.com	\N	$2b$12$CngaJ48leb94pf7hX/ku1euMpsLvtgcLF3q6WvYOhzTMUq5MeYs.u	Jason		+86 10 1234 5678	\N	Asia/Shanghai	zh-CN	CNY	t	t	\N	2025-11-08 16:05:06.392+08	0	0	\N	2025-11-07 21:17:24.904+08	2025-11-08 16:05:06.393+08
e04747dd-bbe9-4d24-adcf-1c088e3c3491	admin@finapp.com	\N	$2b$12$KPg1vbozHHnAzbBRBkYdOOx3Q9kYBmg44XS4JZFDK1U9st..iQpcy	Admin	User	+86 10 8765 4321	\N	UTC	zh-CN	CNY	t	t	\N	2025-11-09 10:44:31.249+08	0	0	\N	2025-11-07 21:17:25.336+08	2025-11-09 10:44:31.25+08
\.


--
-- Data for Name: wealth_product_details; Type: TABLE DATA; Schema: finapp; Owner: finapp_user
--

COPY finapp.wealth_product_details (id, asset_id, product_type, risk_level, expected_return, min_return, max_return, return_type, issue_date, start_date, maturity_date, lock_period, min_investment, max_investment, investment_increment, issuer, product_code, early_redemption, redemption_fee, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: asset_prices; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.asset_prices (id, asset_id, price_date, open_price, high_price, low_price, close_price, volume, adjusted_close, currency, data_source, created_at) FROM stdin;
\.


--
-- Data for Name: asset_types; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.asset_types (id, code, name, category, description, is_active, created_at) FROM stdin;
69bcd777-7604-4e76-9ce2-fabbadfbc440	STOCK	股票	equity	普通股票	t	2025-11-07 20:37:50.506681+08
0f9ab4f3-972e-43d6-9408-a484c9a1a041	ETF	交易所交易基金	fund	在交易所交易的指数基金	t	2025-11-07 20:37:50.506681+08
8616eafb-743d-458b-811a-fd4f45972fc3	MUTUAL_FUND	共同基金	fund	开放式基金	t	2025-11-07 20:37:50.506681+08
da6a3219-2479-4926-844d-5f60ebfe41aa	BOND	债券	fixed_income	政府或企业债券	t	2025-11-07 20:37:50.506681+08
80634d26-c443-4f06-8008-63aa32d79e2e	OPTION	期权	derivative	股票期权合约	t	2025-11-07 20:37:50.506681+08
872a1de0-a165-47d9-b06f-9fd8fd0a0d2a	FUTURE	期货	derivative	期货合约	t	2025-11-07 20:37:50.506681+08
923e9701-bf7b-49d3-9b61-eb7af43d602c	CRYPTO	加密货币	crypto	数字货币	t	2025-11-07 20:37:50.506681+08
c7a568c1-edbf-45dc-8566-add099f23906	CASH	现金	cash	现金及现金等价物	t	2025-11-07 20:37:50.506681+08
8afad30b-8184-41a5-b34b-b608225f4fbd	COMMODITY	商品	commodity	贵金属、原油等商品	t	2025-11-07 20:37:50.506681+08
3ff57144-fd98-4999-bb9b-03d4878223b5	REIT	房地产投资信托	real_estate	房地产投资信托基金	t	2025-11-07 20:37:50.506681+08
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.assets (id, symbol, name, asset_type_id, market_id, currency, isin, cusip, sector, industry, description, metadata, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.audit_logs (id, user_id, table_name, record_id, action, old_values, new_values, changed_fields, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: benchmark_prices; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.benchmark_prices (id, benchmark_id, price_date, price, currency, created_at) FROM stdin;
\.


--
-- Data for Name: benchmarks; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.benchmarks (id, name, symbol, description, asset_class, currency, data_source, is_active, created_at) FROM stdin;
10d6e355-01c0-4c1f-8bd8-aaa54446d4cd	沪深300指数	CSI300	沪深300指数，反映A股市场整体表现	equity	CNY	\N	t	2025-11-07 20:37:50.510462+08
2cc3c56a-87c5-4355-b572-17c5fa1a83a9	上证指数	SHCOMP	上海证券交易所综合股价指数	equity	CNY	\N	t	2025-11-07 20:37:50.510462+08
ae3cf127-5dd1-43c6-99bc-827ae1799509	深证成指	SZCOMP	深圳证券交易所成份股价指数	equity	CNY	\N	t	2025-11-07 20:37:50.510462+08
6a517bb3-67cd-44b1-b6c2-735703840de5	恒生指数	HSI	香港恒生指数	equity	HKD	\N	t	2025-11-07 20:37:50.510462+08
cc5c1be2-2754-4296-9c37-1a37758522ec	标普500指数	SPX	标准普尔500指数	equity	USD	\N	t	2025-11-07 20:37:50.510462+08
6659ec57-b45c-4d6f-9f85-791ddba0aca2	纳斯达克指数	IXIC	纳斯达克综合指数	equity	USD	\N	t	2025-11-07 20:37:50.510462+08
e0e808fb-f21d-4988-8f22-e41337868f2c	日经225指数	N225	日经225指数	equity	JPY	\N	t	2025-11-07 20:37:50.510462+08
d646987a-83a6-4f2f-873d-ee7906292bb1	富时100指数	UKX	英国富时100指数	equity	GBP	\N	t	2025-11-07 20:37:50.510462+08
0c0b3a4c-8c8f-4320-8421-af90f1b651ad	DAX指数	DAX	德国DAX指数	equity	EUR	\N	t	2025-11-07 20:37:50.510462+08
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.email_verification_tokens (id, user_id, token_hash, email, expires_at, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.exchange_rates (id, from_currency, to_currency, rate_date, rate, data_source, created_at) FROM stdin;
c01cc66e-216b-4100-a24a-e595abbccb10	USD	CNY	2025-11-07	7.20000000	manual	2025-11-07 20:37:50.511495+08
2e5338a4-478d-4bf1-b7f8-ecfb27fdf6c5	HKD	CNY	2025-11-07	0.92000000	manual	2025-11-07 20:37:50.511495+08
ccba404d-5084-4d76-ab7b-4eb4a845ca28	JPY	CNY	2025-11-07	0.04800000	manual	2025-11-07 20:37:50.511495+08
8dd5ab6a-44f9-44ed-87de-585381784ddf	EUR	CNY	2025-11-07	7.80000000	manual	2025-11-07 20:37:50.511495+08
a1a0c810-b051-4da3-9fc4-8b0d675e25f2	GBP	CNY	2025-11-07	9.10000000	manual	2025-11-07 20:37:50.511495+08
3ee7ef26-e69e-45ff-a321-ad4f28d50485	CNY	USD	2025-11-07	0.13890000	manual	2025-11-07 20:37:50.511495+08
7d055819-8893-476c-aeda-18a4e89e4b16	CNY	HKD	2025-11-07	1.08700000	manual	2025-11-07 20:37:50.511495+08
85a56ad3-50ff-4dcb-93d3-1344121cbfd1	CNY	JPY	2025-11-07	20.83330000	manual	2025-11-07 20:37:50.511495+08
f96571bf-8f8c-480c-a4eb-65965fb0db82	CNY	EUR	2025-11-07	0.12820000	manual	2025-11-07 20:37:50.511495+08
899d3d8f-c3eb-4687-9d2e-5138b3dd506e	CNY	GBP	2025-11-07	0.10990000	manual	2025-11-07 20:37:50.511495+08
\.


--
-- Data for Name: liquidity_tags; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.liquidity_tags (id, name, description, color, sort_order, is_active, created_at) FROM stdin;
b6d9da25-d0ce-4bca-9253-d1d7ed63a70c	高流动性	大盘股、主要ETF等高流动性资产	#22c55e	1	t	2025-11-07 20:37:50.508391+08
23fc8fc7-fc39-4a3d-b994-ae8eccfbadca	中等流动性	中盘股、部分基金等中等流动性资产	#f59e0b	2	t	2025-11-07 20:37:50.508391+08
1cc2f5cc-7d93-4ccd-a261-4f259ff1d7d5	低流动性	小盘股、私募基金等低流动性资产	#ef4444	3	t	2025-11-07 20:37:50.508391+08
68a43122-aba5-4c91-a173-a44a08f73ab8	锁定期	有锁定期限制的资产	#8b5cf6	4	t	2025-11-07 20:37:50.508391+08
04cb9d00-1029-4e11-898b-44fd864c84c8	不可交易	暂停交易或退市的资产	#6b7280	5	t	2025-11-07 20:37:50.508391+08
\.


--
-- Data for Name: markets; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.markets (id, code, name, country, currency, timezone, trading_hours, holidays, is_active, created_at, updated_at) FROM stdin;
f999a5fb-414f-445e-9c50-462214781ed0	SSE	上海证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
96179b90-7208-4a4c-ad01-a6c5c4c345c1	SZSE	深圳证券交易所	CHN	CNY	Asia/Shanghai	{"open": "09:30", "close": "15:00", "lunch_break": {"end": "13:00", "start": "11:30"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
1bd28043-093d-4794-a4f6-38b961fc1614	HKEX	香港交易所	HKG	HKD	Asia/Hong_Kong	{"open": "09:30", "close": "16:00", "lunch_break": {"end": "13:00", "start": "12:00"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
1cefc02a-e99f-4e09-bad4-773c281d4bd6	NYSE	纽约证券交易所	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
c014db1e-0629-4e9d-b704-b73d8e3d4f0f	NASDAQ	纳斯达克	USA	USD	America/New_York	{"open": "09:30", "close": "16:00"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
9187f350-df32-4ffd-baeb-7f64afb2cdb7	TSE	东京证券交易所	JPN	JPY	Asia/Tokyo	{"open": "09:00", "close": "15:00", "lunch_break": {"end": "12:30", "start": "11:30"}}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
e37cc414-b563-4d78-ab52-e4c5bc9c0108	LSE	伦敦证券交易所	GBR	GBP	Europe/London	{"open": "08:00", "close": "16:30"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
0c2ae5d6-bd49-4d80-940b-704008bda5d5	FWB	法兰克福证券交易所	DEU	EUR	Europe/Berlin	{"open": "09:00", "close": "17:30"}	\N	t	2025-11-07 20:37:50.507585+08	2025-11-07 20:37:50.507585+08
\.


--
-- Data for Name: option_details; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.option_details (id, asset_id, underlying_asset_id, option_type, strike_price, expiration_date, contract_size, exercise_style, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.permissions (id, name, resource, action, description, created_at) FROM stdin;
cfea6186-62c8-4b3e-abfb-c81905aed9fc	users.create	users	create	创建用户	2025-11-07 20:37:50.501561+08
ea335b30-6c85-43e9-b9ff-711571342403	users.read	users	read	查看用户信息	2025-11-07 20:37:50.501561+08
d0459fcf-9155-4ef8-af0a-edd0d94b32ee	users.update	users	update	更新用户信息	2025-11-07 20:37:50.501561+08
f0bbb563-f1d6-4334-94c1-d00aa7962407	users.delete	users	delete	删除用户	2025-11-07 20:37:50.501561+08
d4b15ebc-7ae4-4a5e-ae16-34b249792989	portfolios.create	portfolios	create	创建投资组合	2025-11-07 20:37:50.501561+08
a22f3316-86f1-4d7b-912a-ffec9fff0d6c	portfolios.read	portfolios	read	查看投资组合	2025-11-07 20:37:50.501561+08
096d4047-bac5-4bf2-ae3a-d516c449b48e	portfolios.update	portfolios	update	更新投资组合	2025-11-07 20:37:50.501561+08
7d201d1f-96c1-4b69-a829-87e0e3845b2a	portfolios.delete	portfolios	delete	删除投资组合	2025-11-07 20:37:50.501561+08
0d6ec5f1-789b-45af-806e-47100da555f4	accounts.create	trading_accounts	create	创建交易账户	2025-11-07 20:37:50.501561+08
c624ee32-b553-4244-8a0c-2050465a9623	accounts.read	trading_accounts	read	查看交易账户	2025-11-07 20:37:50.501561+08
7341a05c-da3b-4739-9dfd-eaf819a014b6	accounts.update	trading_accounts	update	更新交易账户	2025-11-07 20:37:50.501561+08
32ae4e88-42e0-4594-98b9-2cee8fcf716e	accounts.delete	trading_accounts	delete	删除交易账户	2025-11-07 20:37:50.501561+08
15434351-d5f9-4cab-9dad-c183a4ef1575	transactions.create	transactions	create	创建交易记录	2025-11-07 20:37:50.501561+08
b9053248-fdfb-4734-8ba2-be991d59d52f	transactions.read	transactions	read	查看交易记录	2025-11-07 20:37:50.501561+08
f3ee0981-5c2a-4b0a-a826-3d70d112c1c1	transactions.update	transactions	update	更新交易记录	2025-11-07 20:37:50.501561+08
5ff1f467-b1bc-4e4c-a590-89c282096518	transactions.delete	transactions	delete	删除交易记录	2025-11-07 20:37:50.501561+08
aaac51da-aec2-4027-a78d-42d2f523f2d4	transactions.import	transactions	import	批量导入交易记录	2025-11-07 20:37:50.501561+08
b9ad6bef-ffb9-4c13-aa81-f16910f9ad3f	assets.create	assets	create	创建资产	2025-11-07 20:37:50.501561+08
72b8d6da-754b-4083-9cdf-2a251f8d6adb	assets.read	assets	read	查看资产信息	2025-11-07 20:37:50.501561+08
028ad711-52f7-4e19-bae1-b3b3977292db	assets.update	assets	update	更新资产信息	2025-11-07 20:37:50.501561+08
733a755a-781c-4f2b-848b-e48e28e9c504	assets.delete	assets	delete	删除资产	2025-11-07 20:37:50.501561+08
902a61ea-a904-4ea0-bff3-1ba041ed5be0	reports.create	reports	create	创建报表	2025-11-07 20:37:50.501561+08
aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	reports.read	reports	read	查看报表	2025-11-07 20:37:50.501561+08
b6a43b66-a24d-4ff1-852f-6dd7130a427f	reports.update	reports	update	更新报表	2025-11-07 20:37:50.501561+08
6cfe96ff-09af-42ef-9fda-cfcf349eb518	reports.delete	reports	delete	删除报表	2025-11-07 20:37:50.501561+08
39584463-d9f5-449c-bba0-44d02580dcdb	reports.export	reports	export	导出报表	2025-11-07 20:37:50.501561+08
6381d308-4c2d-43a2-9662-15ced4e87c3e	system.config	system	config	系统配置管理	2025-11-07 20:37:50.501561+08
142f03b1-a24f-4346-9c9f-4fe5187ba829	system.logs	system	logs	查看系统日志	2025-11-07 20:37:50.501561+08
4902d6c6-845e-4247-a7e8-9eea1c512f8e	system.backup	system	backup	数据备份管理	2025-11-07 20:37:50.501561+08
\.


--
-- Data for Name: portfolios; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.portfolios (id, user_id, name, description, base_currency, is_default, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.positions (id, portfolio_id, trading_account_id, asset_id, quantity, average_cost, total_cost, currency, first_purchase_date, last_transaction_date, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report_executions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.report_executions (id, report_id, execution_status, started_at, completed_at, file_path, file_size, error_message, metadata) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.reports (id, user_id, portfolio_id, name, description, report_type, parameters, schedule, is_scheduled, is_active, last_generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.role_permissions (id, role_id, permission_id, created_at) FROM stdin;
1c6228cf-f559-49bc-b92f-835dfaaf2145	1f1bf9e1-758f-4be9-8aed-93ce84986f44	cfea6186-62c8-4b3e-abfb-c81905aed9fc	2025-11-07 20:37:50.503104+08
2de9830c-2b90-459c-80eb-9ada2f260361	1f1bf9e1-758f-4be9-8aed-93ce84986f44	ea335b30-6c85-43e9-b9ff-711571342403	2025-11-07 20:37:50.503104+08
7fbb2227-f8f8-4a33-9c6e-a994d8fc7ad3	802fd45d-95dd-4548-a7d6-e09808832ae7	ea335b30-6c85-43e9-b9ff-711571342403	2025-11-07 20:37:50.503104+08
b6a967c5-70dd-492a-adb1-2344f00a2d73	660d9712-b07c-4519-8a84-9da637180dfd	ea335b30-6c85-43e9-b9ff-711571342403	2025-11-07 20:37:50.503104+08
28fd9e7c-785a-49d1-a129-894beaaec763	1f1bf9e1-758f-4be9-8aed-93ce84986f44	d0459fcf-9155-4ef8-af0a-edd0d94b32ee	2025-11-07 20:37:50.503104+08
86a48c0a-a06d-4d42-a16a-71020c3f9a39	802fd45d-95dd-4548-a7d6-e09808832ae7	d0459fcf-9155-4ef8-af0a-edd0d94b32ee	2025-11-07 20:37:50.503104+08
5777b665-a90e-45b4-b86d-2acad46f4a05	1f1bf9e1-758f-4be9-8aed-93ce84986f44	f0bbb563-f1d6-4334-94c1-d00aa7962407	2025-11-07 20:37:50.503104+08
bab7a8e5-0933-4b59-ac45-ec3be48867f3	1f1bf9e1-758f-4be9-8aed-93ce84986f44	d4b15ebc-7ae4-4a5e-ae16-34b249792989	2025-11-07 20:37:50.503104+08
7e18ac8b-eec5-45d3-9a76-e9436ba15568	802fd45d-95dd-4548-a7d6-e09808832ae7	d4b15ebc-7ae4-4a5e-ae16-34b249792989	2025-11-07 20:37:50.503104+08
1141dfeb-8ba7-4f47-b1d2-aa169840bb82	1f1bf9e1-758f-4be9-8aed-93ce84986f44	a22f3316-86f1-4d7b-912a-ffec9fff0d6c	2025-11-07 20:37:50.503104+08
08e7c34e-bfd2-4aea-9aee-19e543eeed3c	802fd45d-95dd-4548-a7d6-e09808832ae7	a22f3316-86f1-4d7b-912a-ffec9fff0d6c	2025-11-07 20:37:50.503104+08
3ebd9397-213f-46f4-a354-9b697ab648e4	660d9712-b07c-4519-8a84-9da637180dfd	a22f3316-86f1-4d7b-912a-ffec9fff0d6c	2025-11-07 20:37:50.503104+08
598061dd-dc89-4dc0-a6a3-d3539a3d112d	1f1bf9e1-758f-4be9-8aed-93ce84986f44	096d4047-bac5-4bf2-ae3a-d516c449b48e	2025-11-07 20:37:50.503104+08
9f1172af-5f5b-494a-9456-e8f3d20b9750	802fd45d-95dd-4548-a7d6-e09808832ae7	096d4047-bac5-4bf2-ae3a-d516c449b48e	2025-11-07 20:37:50.503104+08
3f33a2a6-cf29-4fa5-95db-3471883a6967	1f1bf9e1-758f-4be9-8aed-93ce84986f44	7d201d1f-96c1-4b69-a829-87e0e3845b2a	2025-11-07 20:37:50.503104+08
9926dd2f-1a81-46f3-82d5-2fa54c5aadb7	1f1bf9e1-758f-4be9-8aed-93ce84986f44	0d6ec5f1-789b-45af-806e-47100da555f4	2025-11-07 20:37:50.503104+08
050d4379-daf9-4b31-8942-be42c3df3de6	802fd45d-95dd-4548-a7d6-e09808832ae7	0d6ec5f1-789b-45af-806e-47100da555f4	2025-11-07 20:37:50.503104+08
e8a046ec-0bac-4db1-bb79-6c9e7d64f2c4	1f1bf9e1-758f-4be9-8aed-93ce84986f44	c624ee32-b553-4244-8a0c-2050465a9623	2025-11-07 20:37:50.503104+08
8b950b7b-0fcd-4546-984b-f11ec231e5e1	802fd45d-95dd-4548-a7d6-e09808832ae7	c624ee32-b553-4244-8a0c-2050465a9623	2025-11-07 20:37:50.503104+08
d073e28c-8f4c-4550-ab2d-976fb619f34a	660d9712-b07c-4519-8a84-9da637180dfd	c624ee32-b553-4244-8a0c-2050465a9623	2025-11-07 20:37:50.503104+08
5493d02b-ee58-401e-b5ca-6a96bb5caa0f	1f1bf9e1-758f-4be9-8aed-93ce84986f44	7341a05c-da3b-4739-9dfd-eaf819a014b6	2025-11-07 20:37:50.503104+08
06ee4715-aa05-44b8-b0cb-be110ea86411	802fd45d-95dd-4548-a7d6-e09808832ae7	7341a05c-da3b-4739-9dfd-eaf819a014b6	2025-11-07 20:37:50.503104+08
6ffe0421-e098-476b-9b1f-3e4dda86baf8	1f1bf9e1-758f-4be9-8aed-93ce84986f44	32ae4e88-42e0-4594-98b9-2cee8fcf716e	2025-11-07 20:37:50.503104+08
65e4da36-2341-451d-abae-836f157aed60	1f1bf9e1-758f-4be9-8aed-93ce84986f44	15434351-d5f9-4cab-9dad-c183a4ef1575	2025-11-07 20:37:50.503104+08
78fc81e0-c8b3-475a-8533-ddbe15706a25	802fd45d-95dd-4548-a7d6-e09808832ae7	15434351-d5f9-4cab-9dad-c183a4ef1575	2025-11-07 20:37:50.503104+08
dcd2c76b-c534-4a41-b7d3-08d573bf32f1	1f1bf9e1-758f-4be9-8aed-93ce84986f44	b9053248-fdfb-4734-8ba2-be991d59d52f	2025-11-07 20:37:50.503104+08
fb30803a-2eae-457c-8d04-b92892f7b7dc	802fd45d-95dd-4548-a7d6-e09808832ae7	b9053248-fdfb-4734-8ba2-be991d59d52f	2025-11-07 20:37:50.503104+08
cc36c127-38b9-415f-9743-67bcb46d4692	660d9712-b07c-4519-8a84-9da637180dfd	b9053248-fdfb-4734-8ba2-be991d59d52f	2025-11-07 20:37:50.503104+08
a70139b0-efd2-4bcd-a735-1cfa2d46d902	1f1bf9e1-758f-4be9-8aed-93ce84986f44	f3ee0981-5c2a-4b0a-a826-3d70d112c1c1	2025-11-07 20:37:50.503104+08
6f90d00e-f71e-48e5-841e-61585cf2a107	802fd45d-95dd-4548-a7d6-e09808832ae7	f3ee0981-5c2a-4b0a-a826-3d70d112c1c1	2025-11-07 20:37:50.503104+08
1a997484-c395-4459-a160-df01663d7036	1f1bf9e1-758f-4be9-8aed-93ce84986f44	5ff1f467-b1bc-4e4c-a590-89c282096518	2025-11-07 20:37:50.503104+08
a3456c00-14f3-4c27-a73c-76fefeaa3026	1f1bf9e1-758f-4be9-8aed-93ce84986f44	aaac51da-aec2-4027-a78d-42d2f523f2d4	2025-11-07 20:37:50.503104+08
97046e7a-a28f-4815-84b3-abcbc5c360f6	802fd45d-95dd-4548-a7d6-e09808832ae7	aaac51da-aec2-4027-a78d-42d2f523f2d4	2025-11-07 20:37:50.503104+08
baf99772-34cd-422d-94a6-0db3f4a16bcf	1f1bf9e1-758f-4be9-8aed-93ce84986f44	b9ad6bef-ffb9-4c13-aa81-f16910f9ad3f	2025-11-07 20:37:50.503104+08
0b393b69-c40c-4f83-b215-be1a7b62eb6e	802fd45d-95dd-4548-a7d6-e09808832ae7	b9ad6bef-ffb9-4c13-aa81-f16910f9ad3f	2025-11-07 20:37:50.503104+08
31b70301-fa05-4f8c-ac12-11107c951d89	1f1bf9e1-758f-4be9-8aed-93ce84986f44	72b8d6da-754b-4083-9cdf-2a251f8d6adb	2025-11-07 20:37:50.503104+08
d61922c9-b6a2-46a2-ab88-2e020d9902e8	802fd45d-95dd-4548-a7d6-e09808832ae7	72b8d6da-754b-4083-9cdf-2a251f8d6adb	2025-11-07 20:37:50.503104+08
c4ec9870-1ae1-43be-8b37-4908b9bb575f	660d9712-b07c-4519-8a84-9da637180dfd	72b8d6da-754b-4083-9cdf-2a251f8d6adb	2025-11-07 20:37:50.503104+08
cd03f8d9-9e7e-4a03-acc0-41b89b97a5ee	1f1bf9e1-758f-4be9-8aed-93ce84986f44	028ad711-52f7-4e19-bae1-b3b3977292db	2025-11-07 20:37:50.503104+08
3fd1bcfc-091a-46a7-8ffb-bb2cdaabd0d1	802fd45d-95dd-4548-a7d6-e09808832ae7	028ad711-52f7-4e19-bae1-b3b3977292db	2025-11-07 20:37:50.503104+08
acf2604b-e588-4691-9c8d-68b7bef01cb8	1f1bf9e1-758f-4be9-8aed-93ce84986f44	733a755a-781c-4f2b-848b-e48e28e9c504	2025-11-07 20:37:50.503104+08
86e7f89f-8d98-4277-a9c0-ac9431f2aa24	1f1bf9e1-758f-4be9-8aed-93ce84986f44	902a61ea-a904-4ea0-bff3-1ba041ed5be0	2025-11-07 20:37:50.503104+08
71a86e31-b9dd-467a-9215-f1486e936a5f	802fd45d-95dd-4548-a7d6-e09808832ae7	902a61ea-a904-4ea0-bff3-1ba041ed5be0	2025-11-07 20:37:50.503104+08
85881fe7-0fe7-4b1d-9985-169a397d09be	1f1bf9e1-758f-4be9-8aed-93ce84986f44	aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	2025-11-07 20:37:50.503104+08
4f95f0c9-39ee-465c-9f2b-792ad33cd625	802fd45d-95dd-4548-a7d6-e09808832ae7	aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	2025-11-07 20:37:50.503104+08
3cf859a3-ee33-49a7-ac92-86529558a762	660d9712-b07c-4519-8a84-9da637180dfd	aadbf74b-d91c-4b01-bf3a-45a9e7d803bf	2025-11-07 20:37:50.503104+08
226097d0-6b02-4647-bffc-4e5af64a7f88	1f1bf9e1-758f-4be9-8aed-93ce84986f44	b6a43b66-a24d-4ff1-852f-6dd7130a427f	2025-11-07 20:37:50.503104+08
f98cc7e6-30a0-4346-9f15-63b5cb122d23	802fd45d-95dd-4548-a7d6-e09808832ae7	b6a43b66-a24d-4ff1-852f-6dd7130a427f	2025-11-07 20:37:50.503104+08
e746fdaf-d111-472f-90fe-63c923067476	1f1bf9e1-758f-4be9-8aed-93ce84986f44	6cfe96ff-09af-42ef-9fda-cfcf349eb518	2025-11-07 20:37:50.503104+08
f1be91e8-e81e-4da5-b06a-2d8400e1937a	1f1bf9e1-758f-4be9-8aed-93ce84986f44	39584463-d9f5-449c-bba0-44d02580dcdb	2025-11-07 20:37:50.503104+08
48794cc7-7a28-461a-bc3b-d42a8806a6d6	802fd45d-95dd-4548-a7d6-e09808832ae7	39584463-d9f5-449c-bba0-44d02580dcdb	2025-11-07 20:37:50.503104+08
8398cd4b-4485-4e47-8e5f-f215724d9f57	1f1bf9e1-758f-4be9-8aed-93ce84986f44	6381d308-4c2d-43a2-9662-15ced4e87c3e	2025-11-07 20:37:50.503104+08
42cfff39-2bdb-49cf-bec3-5926b4b4e163	1f1bf9e1-758f-4be9-8aed-93ce84986f44	142f03b1-a24f-4346-9c9f-4fe5187ba829	2025-11-07 20:37:50.503104+08
f834d16a-4e94-441b-9438-6ae205b7a231	1f1bf9e1-758f-4be9-8aed-93ce84986f44	4902d6c6-845e-4247-a7e8-9eea1c512f8e	2025-11-07 20:37:50.503104+08
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.roles (id, name, description, is_active, created_at, updated_at) FROM stdin;
1f1bf9e1-758f-4be9-8aed-93ce84986f44	admin	系统管理员，拥有所有权限	t	2025-11-07 20:37:50.495427+08	2025-11-07 20:37:50.495427+08
802fd45d-95dd-4548-a7d6-e09808832ae7	user	普通用户，拥有基本功能权限	t	2025-11-07 20:37:50.495427+08	2025-11-07 20:37:50.495427+08
660d9712-b07c-4519-8a84-9da637180dfd	viewer	只读用户，只能查看数据	t	2025-11-07 20:37:50.495427+08	2025-11-07 20:37:50.495427+08
\.


--
-- Data for Name: trading_accounts; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.trading_accounts (id, portfolio_id, name, account_type, broker_name, account_number, currency, initial_balance, current_balance, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.transactions (id, portfolio_id, trading_account_id, asset_id, transaction_type, quantity, price, total_amount, fees, taxes, currency, exchange_rate, transaction_date, settlement_date, notes, tags, liquidity_tag_id, external_id, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assigned_at, expires_at, is_active) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.user_sessions (id, user_id, token_hash, refresh_token_hash, device_info, ip_address, user_agent, is_active, expires_at, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: caojun
--

COPY public.users (id, email, username, password_hash, first_name, last_name, phone, avatar_url, timezone, language, currency_preference, is_active, is_verified, email_verified_at, last_login_at, login_count, failed_login_attempts, locked_until, created_at, updated_at) FROM stdin;
\.


--
-- Name: portfolio_tags_id_seq; Type: SEQUENCE SET; Schema: finapp; Owner: finapp_user
--

SELECT pg_catalog.setval('finapp.portfolio_tags_id_seq', 1, false);


--
-- Name: tag_categories_id_seq; Type: SEQUENCE SET; Schema: finapp; Owner: finapp_user
--

SELECT pg_catalog.setval('finapp.tag_categories_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: finapp; Owner: finapp_user
--

SELECT pg_catalog.setval('finapp.tags_id_seq', 1, false);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: asset_prices asset_prices_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.asset_prices
    ADD CONSTRAINT asset_prices_pkey PRIMARY KEY (id);


--
-- Name: asset_types asset_types_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.asset_types
    ADD CONSTRAINT asset_types_pkey PRIMARY KEY (id);


--
-- Name: assets assets_country_id_symbol_unique; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_country_id_symbol_unique UNIQUE (country_id, symbol);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: benchmark_prices benchmark_prices_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.benchmark_prices
    ADD CONSTRAINT benchmark_prices_pkey PRIMARY KEY (id);


--
-- Name: benchmarks benchmarks_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.benchmarks
    ADD CONSTRAINT benchmarks_pkey PRIMARY KEY (id);


--
-- Name: bond_details bond_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.bond_details
    ADD CONSTRAINT bond_details_pkey PRIMARY KEY (id);


--
-- Name: cash_flows cash_flows_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_pkey PRIMARY KEY (id);


--
-- Name: countries countries_code_key; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.countries
    ADD CONSTRAINT countries_code_key UNIQUE (code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: fund_details fund_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.fund_details
    ADD CONSTRAINT fund_details_pkey PRIMARY KEY (id);


--
-- Name: futures_details futures_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.futures_details
    ADD CONSTRAINT futures_details_pkey PRIMARY KEY (id);


--
-- Name: liquidity_tags liquidity_tags_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.liquidity_tags
    ADD CONSTRAINT liquidity_tags_pkey PRIMARY KEY (id);


--
-- Name: markets markets_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.markets
    ADD CONSTRAINT markets_pkey PRIMARY KEY (id);


--
-- Name: option_details option_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.option_details
    ADD CONSTRAINT option_details_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: performance_metrics performance_metrics_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.performance_metrics
    ADD CONSTRAINT performance_metrics_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: portfolio_snapshots portfolio_snapshots_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_snapshots
    ADD CONSTRAINT portfolio_snapshots_pkey PRIMARY KEY (id);


--
-- Name: portfolio_tags portfolio_tags_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_pkey PRIMARY KEY (id);


--
-- Name: portfolios portfolios_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolios
    ADD CONSTRAINT portfolios_pkey PRIMARY KEY (id);


--
-- Name: position_snapshots position_snapshots_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.position_snapshots
    ADD CONSTRAINT position_snapshots_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: price_data_sources price_data_sources_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_data_sources
    ADD CONSTRAINT price_data_sources_pkey PRIMARY KEY (id);


--
-- Name: price_sync_errors price_sync_errors_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_errors
    ADD CONSTRAINT price_sync_errors_pkey PRIMARY KEY (id);


--
-- Name: price_sync_logs price_sync_logs_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_logs
    ADD CONSTRAINT price_sync_logs_pkey PRIMARY KEY (id);


--
-- Name: price_sync_tasks price_sync_tasks_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_pkey PRIMARY KEY (id);


--
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: stock_details stock_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_details
    ADD CONSTRAINT stock_details_pkey PRIMARY KEY (id);


--
-- Name: stock_option_details stock_option_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_option_details
    ADD CONSTRAINT stock_option_details_pkey PRIMARY KEY (id);


--
-- Name: tag_categories tag_categories_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories
    ADD CONSTRAINT tag_categories_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: trading_accounts trading_accounts_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.trading_accounts
    ADD CONSTRAINT trading_accounts_pkey PRIMARY KEY (id);


--
-- Name: transaction_tag_mappings transaction_tag_mappings_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transaction_tag_mappings
    ADD CONSTRAINT transaction_tag_mappings_pkey PRIMARY KEY (transaction_id, tag_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: treasury_details treasury_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.treasury_details
    ADD CONSTRAINT treasury_details_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wealth_product_details wealth_product_details_pkey; Type: CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.wealth_product_details
    ADD CONSTRAINT wealth_product_details_pkey PRIMARY KEY (id);


--
-- Name: asset_prices asset_prices_asset_id_price_date_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_asset_id_price_date_key UNIQUE (asset_id, price_date);


--
-- Name: asset_prices asset_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_pkey PRIMARY KEY (id);


--
-- Name: asset_types asset_types_code_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_types
    ADD CONSTRAINT asset_types_code_key UNIQUE (code);


--
-- Name: asset_types asset_types_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_types
    ADD CONSTRAINT asset_types_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: assets assets_symbol_market_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_symbol_market_id_key UNIQUE (symbol, market_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: benchmark_prices benchmark_prices_benchmark_id_price_date_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmark_prices
    ADD CONSTRAINT benchmark_prices_benchmark_id_price_date_key UNIQUE (benchmark_id, price_date);


--
-- Name: benchmark_prices benchmark_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmark_prices
    ADD CONSTRAINT benchmark_prices_pkey PRIMARY KEY (id);


--
-- Name: benchmarks benchmarks_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_name_key UNIQUE (name);


--
-- Name: benchmarks benchmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_pkey PRIMARY KEY (id);


--
-- Name: benchmarks benchmarks_symbol_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmarks
    ADD CONSTRAINT benchmarks_symbol_key UNIQUE (symbol);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_from_currency_to_currency_rate_date_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_from_currency_to_currency_rate_date_key UNIQUE (from_currency, to_currency, rate_date);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: liquidity_tags liquidity_tags_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.liquidity_tags
    ADD CONSTRAINT liquidity_tags_name_key UNIQUE (name);


--
-- Name: liquidity_tags liquidity_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.liquidity_tags
    ADD CONSTRAINT liquidity_tags_pkey PRIMARY KEY (id);


--
-- Name: markets markets_code_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT markets_code_key UNIQUE (code);


--
-- Name: markets markets_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT markets_pkey PRIMARY KEY (id);


--
-- Name: option_details option_details_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.option_details
    ADD CONSTRAINT option_details_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: portfolios portfolios_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_pkey PRIMARY KEY (id);


--
-- Name: portfolios portfolios_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_user_id_name_key UNIQUE (user_id, name);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: positions positions_portfolio_id_trading_account_id_asset_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_portfolio_id_trading_account_id_asset_id_key UNIQUE (portfolio_id, trading_account_id, asset_id);


--
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_id_key UNIQUE (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: trading_accounts trading_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.trading_accounts
    ADD CONSTRAINT trading_accounts_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_id_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_key UNIQUE (user_id, role_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: asset_prices_asset_id_price_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX asset_prices_asset_id_price_date_key ON finapp.asset_prices USING btree (asset_id, price_date);


--
-- Name: asset_types_code_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX asset_types_code_key ON finapp.asset_types USING btree (code);


--
-- Name: benchmark_prices_benchmark_id_price_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX benchmark_prices_benchmark_id_price_date_key ON finapp.benchmark_prices USING btree (benchmark_id, price_date);


--
-- Name: benchmarks_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX benchmarks_name_key ON finapp.benchmarks USING btree (name);


--
-- Name: benchmarks_symbol_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX benchmarks_symbol_key ON finapp.benchmarks USING btree (symbol);


--
-- Name: bond_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX bond_details_asset_id_key ON finapp.bond_details USING btree (asset_id);


--
-- Name: exchange_rates_from_currency_to_currency_rate_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX exchange_rates_from_currency_to_currency_rate_date_key ON finapp.exchange_rates USING btree (from_currency, to_currency, rate_date);


--
-- Name: fund_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX fund_details_asset_id_key ON finapp.fund_details USING btree (asset_id);


--
-- Name: futures_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX futures_details_asset_id_key ON finapp.futures_details USING btree (asset_id);


--
-- Name: idx_asset_prices_asset_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_asset_date ON finapp.asset_prices USING btree (asset_id, price_date);


--
-- Name: idx_asset_prices_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_asset_id ON finapp.asset_prices USING btree (asset_id);


--
-- Name: idx_asset_prices_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_created_at ON finapp.asset_prices USING btree (created_at);


--
-- Name: idx_asset_prices_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_date ON finapp.asset_prices USING btree (price_date);


--
-- Name: idx_asset_prices_price_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_prices_price_date ON finapp.asset_prices USING btree (price_date);


--
-- Name: idx_asset_types_category; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_category ON finapp.asset_types USING btree (category);


--
-- Name: idx_asset_types_code; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_code ON finapp.asset_types USING btree (code);


--
-- Name: idx_asset_types_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_is_active ON finapp.asset_types USING btree (is_active);


--
-- Name: idx_asset_types_location_dimension; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_asset_types_location_dimension ON finapp.asset_types USING btree (location_dimension);


--
-- Name: idx_assets_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_active ON finapp.assets USING btree (is_active);


--
-- Name: idx_assets_asset_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_asset_type ON finapp.assets USING btree (asset_type_id);


--
-- Name: idx_assets_asset_type_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_asset_type_id ON finapp.assets USING btree (asset_type_id);


--
-- Name: idx_assets_country_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_country_id ON finapp.assets USING btree (country_id);


--
-- Name: idx_assets_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_created_at ON finapp.assets USING btree (created_at);


--
-- Name: idx_assets_currency; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_currency ON finapp.assets USING btree (currency);


--
-- Name: idx_assets_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_is_active ON finapp.assets USING btree (is_active);


--
-- Name: idx_assets_sector; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_sector ON finapp.assets USING btree (sector);


--
-- Name: idx_assets_symbol; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_assets_symbol ON finapp.assets USING btree (symbol);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_action ON finapp.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_created_at ON finapp.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_record_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_record_id ON finapp.audit_logs USING btree (record_id);


--
-- Name: idx_audit_logs_table_name; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_table_name ON finapp.audit_logs USING btree (table_name);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_audit_logs_user_id ON finapp.audit_logs USING btree (user_id);


--
-- Name: idx_benchmark_prices_benchmark_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmark_prices_benchmark_date ON finapp.benchmark_prices USING btree (benchmark_id, price_date);


--
-- Name: idx_benchmark_prices_benchmark_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmark_prices_benchmark_id ON finapp.benchmark_prices USING btree (benchmark_id);


--
-- Name: idx_benchmark_prices_price_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmark_prices_price_date ON finapp.benchmark_prices USING btree (price_date);


--
-- Name: idx_benchmarks_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmarks_is_active ON finapp.benchmarks USING btree (is_active);


--
-- Name: idx_benchmarks_symbol; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_benchmarks_symbol ON finapp.benchmarks USING btree (symbol);


--
-- Name: idx_bond_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_bond_details_asset ON finapp.bond_details USING btree (asset_id);


--
-- Name: idx_bond_details_maturity; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_bond_details_maturity ON finapp.bond_details USING btree (maturity_date);


--
-- Name: idx_bond_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_bond_details_type ON finapp.bond_details USING btree (bond_type);


--
-- Name: idx_cash_flows_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_asset_id ON finapp.cash_flows USING btree (asset_id);


--
-- Name: idx_cash_flows_category; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_category ON finapp.cash_flows USING btree (category);


--
-- Name: idx_cash_flows_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_date ON finapp.cash_flows USING btree (date);


--
-- Name: idx_cash_flows_flow_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_flow_date ON finapp.cash_flows USING btree (flow_date);


--
-- Name: idx_cash_flows_flow_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_flow_type ON finapp.cash_flows USING btree (flow_type);


--
-- Name: idx_cash_flows_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_portfolio_id ON finapp.cash_flows USING btree (portfolio_id);


--
-- Name: idx_cash_flows_trading_account_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_trading_account_id ON finapp.cash_flows USING btree (trading_account_id);


--
-- Name: idx_cash_flows_transaction_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_cash_flows_transaction_id ON finapp.cash_flows USING btree (transaction_id);


--
-- Name: idx_email_verification_tokens_expires_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_email_verification_tokens_expires_at ON finapp.email_verification_tokens USING btree (expires_at);


--
-- Name: idx_email_verification_tokens_token_hash; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_email_verification_tokens_token_hash ON finapp.email_verification_tokens USING btree (token_hash);


--
-- Name: idx_email_verification_tokens_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_email_verification_tokens_user_id ON finapp.email_verification_tokens USING btree (user_id);


--
-- Name: idx_exchange_rates_currencies; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_exchange_rates_currencies ON finapp.exchange_rates USING btree (from_currency, to_currency);


--
-- Name: idx_exchange_rates_currencies_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_exchange_rates_currencies_date ON finapp.exchange_rates USING btree (from_currency, to_currency, rate_date);


--
-- Name: idx_exchange_rates_rate_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_exchange_rates_rate_date ON finapp.exchange_rates USING btree (rate_date);


--
-- Name: idx_fund_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_fund_details_asset ON finapp.fund_details USING btree (asset_id);


--
-- Name: idx_fund_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_fund_details_type ON finapp.fund_details USING btree (fund_type);


--
-- Name: idx_futures_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_futures_details_asset ON finapp.futures_details USING btree (asset_id);


--
-- Name: idx_futures_details_month; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_futures_details_month ON finapp.futures_details USING btree (contract_month);


--
-- Name: idx_futures_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_futures_details_type ON finapp.futures_details USING btree (futures_type);


--
-- Name: idx_liquidity_tags_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_liquidity_tags_is_active ON finapp.liquidity_tags USING btree (is_active);


--
-- Name: idx_liquidity_tags_sort_order; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_liquidity_tags_sort_order ON finapp.liquidity_tags USING btree (sort_order);


--
-- Name: idx_markets_code; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_markets_code ON finapp.markets USING btree (code);


--
-- Name: idx_markets_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_markets_is_active ON finapp.markets USING btree (is_active);


--
-- Name: idx_option_details_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_option_details_asset_id ON finapp.option_details USING btree (asset_id);


--
-- Name: idx_option_details_expiration_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_option_details_expiration_date ON finapp.option_details USING btree (expiration_date);


--
-- Name: idx_option_details_underlying_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_option_details_underlying_asset_id ON finapp.option_details USING btree (underlying_asset_id);


--
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_password_reset_tokens_expires_at ON finapp.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token_hash; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_password_reset_tokens_token_hash ON finapp.password_reset_tokens USING btree (token_hash);


--
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_password_reset_tokens_user_id ON finapp.password_reset_tokens USING btree (user_id);


--
-- Name: idx_performance_metrics_metric_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_metric_type ON finapp.performance_metrics USING btree (metric_type);


--
-- Name: idx_performance_metrics_period_dates; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_period_dates ON finapp.performance_metrics USING btree (period_start, period_end);


--
-- Name: idx_performance_metrics_period_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_period_type ON finapp.performance_metrics USING btree (period_type);


--
-- Name: idx_performance_metrics_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_performance_metrics_portfolio_id ON finapp.performance_metrics USING btree (portfolio_id);


--
-- Name: idx_portfolio_snapshots_portfolio_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolio_snapshots_portfolio_date ON finapp.portfolio_snapshots USING btree (portfolio_id, snapshot_date);


--
-- Name: idx_portfolio_snapshots_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolio_snapshots_portfolio_id ON finapp.portfolio_snapshots USING btree (portfolio_id);


--
-- Name: idx_portfolio_snapshots_snapshot_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolio_snapshots_snapshot_date ON finapp.portfolio_snapshots USING btree (snapshot_date);


--
-- Name: idx_portfolios_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_is_active ON finapp.portfolios USING btree (is_active);


--
-- Name: idx_portfolios_is_default; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_is_default ON finapp.portfolios USING btree (is_default);


--
-- Name: idx_portfolios_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_user_id ON finapp.portfolios USING btree (user_id);


--
-- Name: idx_portfolios_user_sort; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_portfolios_user_sort ON finapp.portfolios USING btree (user_id, sort_order);


--
-- Name: idx_position_snapshots_portfolio_snapshot_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_position_snapshots_portfolio_snapshot_id ON finapp.position_snapshots USING btree (portfolio_snapshot_id);


--
-- Name: idx_position_snapshots_position_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_position_snapshots_position_id ON finapp.position_snapshots USING btree (position_id);


--
-- Name: idx_position_snapshots_snapshot_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_position_snapshots_snapshot_date ON finapp.position_snapshots USING btree (snapshot_date);


--
-- Name: idx_positions_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_asset_id ON finapp.positions USING btree (asset_id);


--
-- Name: idx_positions_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_is_active ON finapp.positions USING btree (is_active);


--
-- Name: idx_positions_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_portfolio_id ON finapp.positions USING btree (portfolio_id);


--
-- Name: idx_positions_trading_account_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_positions_trading_account_id ON finapp.positions USING btree (trading_account_id);


--
-- Name: idx_price_data_sources_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_data_sources_active ON finapp.price_data_sources USING btree (is_active);


--
-- Name: idx_price_data_sources_provider; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_data_sources_provider ON finapp.price_data_sources USING btree (provider);


--
-- Name: idx_price_sync_errors_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_errors_asset ON finapp.price_sync_errors USING btree (asset_id);


--
-- Name: idx_price_sync_errors_log; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_errors_log ON finapp.price_sync_errors USING btree (log_id);


--
-- Name: idx_price_sync_logs_started; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_logs_started ON finapp.price_sync_logs USING btree (started_at DESC);


--
-- Name: idx_price_sync_logs_status; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_logs_status ON finapp.price_sync_logs USING btree (status);


--
-- Name: idx_price_sync_logs_task; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_logs_task ON finapp.price_sync_logs USING btree (task_id);


--
-- Name: idx_price_sync_tasks_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_active ON finapp.price_sync_tasks USING btree (is_active);


--
-- Name: idx_price_sync_tasks_country_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_country_id ON finapp.price_sync_tasks USING btree (country_id);


--
-- Name: idx_price_sync_tasks_data_source; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_data_source ON finapp.price_sync_tasks USING btree (data_source_id);


--
-- Name: idx_price_sync_tasks_schedule; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_price_sync_tasks_schedule ON finapp.price_sync_tasks USING btree (schedule_type, is_active);


--
-- Name: idx_report_executions_report_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_report_executions_report_id ON finapp.report_executions USING btree (report_id);


--
-- Name: idx_report_executions_started_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_report_executions_started_at ON finapp.report_executions USING btree (started_at);


--
-- Name: idx_report_executions_status; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_report_executions_status ON finapp.report_executions USING btree (execution_status);


--
-- Name: idx_reports_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_is_active ON finapp.reports USING btree (is_active);


--
-- Name: idx_reports_is_scheduled; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_is_scheduled ON finapp.reports USING btree (is_scheduled);


--
-- Name: idx_reports_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_portfolio_id ON finapp.reports USING btree (portfolio_id);


--
-- Name: idx_reports_report_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_report_type ON finapp.reports USING btree (report_type);


--
-- Name: idx_reports_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_reports_user_id ON finapp.reports USING btree (user_id);


--
-- Name: idx_role_permissions_permission_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_role_permissions_permission_id ON finapp.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_role_permissions_role_id ON finapp.role_permissions USING btree (role_id);


--
-- Name: idx_stock_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_details_asset ON finapp.stock_details USING btree (asset_id);


--
-- Name: idx_stock_details_industry; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_details_industry ON finapp.stock_details USING btree (industry);


--
-- Name: idx_stock_details_sector; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_details_sector ON finapp.stock_details USING btree (sector);


--
-- Name: idx_stock_option_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_asset ON finapp.stock_option_details USING btree (asset_id);


--
-- Name: idx_stock_option_details_expiration; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_expiration ON finapp.stock_option_details USING btree (expiration_date);


--
-- Name: idx_stock_option_details_strike; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_strike ON finapp.stock_option_details USING btree (strike_price);


--
-- Name: idx_stock_option_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_type ON finapp.stock_option_details USING btree (option_type);


--
-- Name: idx_stock_option_details_underlying; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_stock_option_details_underlying ON finapp.stock_option_details USING btree (underlying_stock_id);


--
-- Name: idx_trading_accounts_account_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_trading_accounts_account_type ON finapp.trading_accounts USING btree (account_type);


--
-- Name: idx_trading_accounts_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_trading_accounts_is_active ON finapp.trading_accounts USING btree (is_active);


--
-- Name: idx_trading_accounts_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_trading_accounts_portfolio_id ON finapp.trading_accounts USING btree (portfolio_id);


--
-- Name: idx_transaction_tag_mappings_tag_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transaction_tag_mappings_tag_id ON finapp.transaction_tag_mappings USING btree (tag_id);


--
-- Name: idx_transaction_tag_mappings_transaction_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transaction_tag_mappings_transaction_id ON finapp.transaction_tag_mappings USING btree (transaction_id);


--
-- Name: idx_transactions_asset_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_asset_id ON finapp.transactions USING btree (asset_id);


--
-- Name: idx_transactions_executed_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_executed_at ON finapp.transactions USING btree (executed_at);


--
-- Name: idx_transactions_external_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_external_id ON finapp.transactions USING btree (external_id);


--
-- Name: idx_transactions_liquidity_tag; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_liquidity_tag ON finapp.transactions USING btree (liquidity_tag);


--
-- Name: idx_transactions_liquidity_tag_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_liquidity_tag_id ON finapp.transactions USING btree (liquidity_tag_id);


--
-- Name: idx_transactions_portfolio_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_portfolio_id ON finapp.transactions USING btree (portfolio_id);


--
-- Name: idx_transactions_side; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_side ON finapp.transactions USING btree (side);


--
-- Name: idx_transactions_status; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_status ON finapp.transactions USING btree (status);


--
-- Name: idx_transactions_tags; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_tags ON finapp.transactions USING gin (tags);


--
-- Name: idx_transactions_total_amount; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_total_amount ON finapp.transactions USING btree (total_amount);


--
-- Name: idx_transactions_trading_account_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_trading_account_id ON finapp.transactions USING btree (trading_account_id);


--
-- Name: idx_transactions_transaction_date; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_transaction_date ON finapp.transactions USING btree (transaction_date);


--
-- Name: idx_transactions_transaction_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_transaction_type ON finapp.transactions USING btree (transaction_type);


--
-- Name: idx_transactions_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_transactions_user_id ON finapp.transactions USING btree (user_id);


--
-- Name: idx_treasury_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_treasury_details_asset ON finapp.treasury_details USING btree (asset_id);


--
-- Name: idx_treasury_details_maturity; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_treasury_details_maturity ON finapp.treasury_details USING btree (maturity_date);


--
-- Name: idx_treasury_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_treasury_details_type ON finapp.treasury_details USING btree (treasury_type);


--
-- Name: idx_user_roles_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_roles_is_active ON finapp.user_roles USING btree (is_active);


--
-- Name: idx_user_roles_role_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_roles_role_id ON finapp.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_roles_user_id ON finapp.user_roles USING btree (user_id);


--
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_expires_at ON finapp.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_is_active ON finapp.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_token_hash; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_token_hash ON finapp.user_sessions USING btree (token_hash);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_user_sessions_user_id ON finapp.user_sessions USING btree (user_id);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_created_at ON finapp.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_email ON finapp.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_is_active ON finapp.users USING btree (is_active);


--
-- Name: idx_users_last_login_at; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_last_login_at ON finapp.users USING btree (last_login_at);


--
-- Name: idx_users_username; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_users_username ON finapp.users USING btree (username);


--
-- Name: idx_wealth_details_asset; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_wealth_details_asset ON finapp.wealth_product_details USING btree (asset_id);


--
-- Name: idx_wealth_details_risk; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_wealth_details_risk ON finapp.wealth_product_details USING btree (risk_level);


--
-- Name: idx_wealth_details_type; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE INDEX idx_wealth_details_type ON finapp.wealth_product_details USING btree (product_type);


--
-- Name: liquidity_tags_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX liquidity_tags_name_key ON finapp.liquidity_tags USING btree (name);


--
-- Name: markets_code_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX markets_code_key ON finapp.markets USING btree (code);


--
-- Name: performance_metrics_portfolio_id_metric_type_period_type_pe_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX performance_metrics_portfolio_id_metric_type_period_type_pe_key ON finapp.performance_metrics USING btree (portfolio_id, metric_type, period_type, period_start, period_end);


--
-- Name: permissions_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX permissions_name_key ON finapp.permissions USING btree (name);


--
-- Name: portfolio_snapshots_portfolio_id_snapshot_date_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX portfolio_snapshots_portfolio_id_snapshot_date_key ON finapp.portfolio_snapshots USING btree (portfolio_id, snapshot_date);


--
-- Name: portfolio_tags_portfolio_id_tag_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX portfolio_tags_portfolio_id_tag_id_key ON finapp.portfolio_tags USING btree (portfolio_id, tag_id);


--
-- Name: portfolios_user_id_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX portfolios_user_id_name_key ON finapp.portfolios USING btree (user_id, name);


--
-- Name: positions_portfolio_id_trading_account_id_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX positions_portfolio_id_trading_account_id_asset_id_key ON finapp.positions USING btree (portfolio_id, trading_account_id, asset_id);


--
-- Name: price_data_sources_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX price_data_sources_name_key ON finapp.price_data_sources USING btree (name);


--
-- Name: role_permissions_role_id_permission_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX role_permissions_role_id_permission_id_key ON finapp.role_permissions USING btree (role_id, permission_id);


--
-- Name: roles_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX roles_name_key ON finapp.roles USING btree (name);


--
-- Name: stock_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX stock_details_asset_id_key ON finapp.stock_details USING btree (asset_id);


--
-- Name: stock_option_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX stock_option_details_asset_id_key ON finapp.stock_option_details USING btree (asset_id);


--
-- Name: tag_categories_user_id_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX tag_categories_user_id_name_key ON finapp.tag_categories USING btree (user_id, name);


--
-- Name: tags_user_id_name_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX tags_user_id_name_key ON finapp.tags USING btree (user_id, name);


--
-- Name: treasury_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX treasury_details_asset_id_key ON finapp.treasury_details USING btree (asset_id);


--
-- Name: user_roles_user_id_role_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX user_roles_user_id_role_id_key ON finapp.user_roles USING btree (user_id, role_id);


--
-- Name: users_email_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX users_email_key ON finapp.users USING btree (email);


--
-- Name: users_username_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX users_username_key ON finapp.users USING btree (username);


--
-- Name: wealth_product_details_asset_id_key; Type: INDEX; Schema: finapp; Owner: finapp_user
--

CREATE UNIQUE INDEX wealth_product_details_asset_id_key ON finapp.wealth_product_details USING btree (asset_id);


--
-- Name: idx_assets_asset_type_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_asset_type_id ON public.assets USING btree (asset_type_id);


--
-- Name: idx_assets_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_is_active ON public.assets USING btree (is_active);


--
-- Name: idx_assets_market_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_market_id ON public.assets USING btree (market_id);


--
-- Name: idx_assets_symbol; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_symbol ON public.assets USING btree (symbol);


--
-- Name: idx_assets_symbol_market; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_assets_symbol_market ON public.assets USING btree (symbol, market_id);


--
-- Name: idx_email_verification_tokens_expires_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_email_verification_tokens_expires_at ON public.email_verification_tokens USING btree (expires_at);


--
-- Name: idx_email_verification_tokens_token_hash; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_email_verification_tokens_token_hash ON public.email_verification_tokens USING btree (token_hash);


--
-- Name: idx_email_verification_tokens_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_email_verification_tokens_user_id ON public.email_verification_tokens USING btree (user_id);


--
-- Name: idx_option_details_asset_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_option_details_asset_id ON public.option_details USING btree (asset_id);


--
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_password_reset_tokens_expires_at ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token_hash; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_password_reset_tokens_token_hash ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_password_reset_tokens_user_id ON public.password_reset_tokens USING btree (user_id);


--
-- Name: idx_portfolios_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_portfolios_is_active ON public.portfolios USING btree (is_active);


--
-- Name: idx_portfolios_is_default; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_portfolios_is_default ON public.portfolios USING btree (is_default);


--
-- Name: idx_portfolios_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_portfolios_user_id ON public.portfolios USING btree (user_id);


--
-- Name: idx_role_permissions_permission_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_role_permissions_permission_id ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_role_permissions_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: idx_trading_accounts_account_type; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_trading_accounts_account_type ON public.trading_accounts USING btree (account_type);


--
-- Name: idx_trading_accounts_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_trading_accounts_is_active ON public.trading_accounts USING btree (is_active);


--
-- Name: idx_trading_accounts_portfolio_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_trading_accounts_portfolio_id ON public.trading_accounts USING btree (portfolio_id);


--
-- Name: idx_user_roles_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_roles_is_active ON public.user_roles USING btree (is_active);


--
-- Name: idx_user_roles_role_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_roles_role_id ON public.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_roles_user_id ON public.user_roles USING btree (user_id);


--
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_expires_at ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: idx_user_sessions_token_hash; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_token_hash ON public.user_sessions USING btree (token_hash);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_last_login_at; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_last_login_at ON public.users USING btree (last_login_at);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: caojun
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: roles update_roles_updated_at; Type: TRIGGER; Schema: public; Owner: caojun
--

CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: caojun
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: asset_prices asset_prices_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.asset_prices
    ADD CONSTRAINT asset_prices_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: assets assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES finapp.asset_types(id);


--
-- Name: assets assets_country_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT assets_country_id_fkey FOREIGN KEY (country_id) REFERENCES finapp.countries(id) ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id);


--
-- Name: benchmark_prices benchmark_prices_benchmark_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.benchmark_prices
    ADD CONSTRAINT benchmark_prices_benchmark_id_fkey FOREIGN KEY (benchmark_id) REFERENCES finapp.benchmarks(id) ON DELETE CASCADE;


--
-- Name: bond_details bond_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.bond_details
    ADD CONSTRAINT bond_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: cash_flows cash_flows_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id);


--
-- Name: cash_flows cash_flows_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: cash_flows cash_flows_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES finapp.trading_accounts(id);


--
-- Name: cash_flows cash_flows_transaction_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.cash_flows
    ADD CONSTRAINT cash_flows_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES finapp.transactions(id);


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: assets fk_assets_liquidity_tag; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.assets
    ADD CONSTRAINT fk_assets_liquidity_tag FOREIGN KEY (liquidity_tag) REFERENCES finapp.liquidity_tags(id);


--
-- Name: fund_details fund_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.fund_details
    ADD CONSTRAINT fund_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: futures_details futures_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.futures_details
    ADD CONSTRAINT futures_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.option_details
    ADD CONSTRAINT option_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_underlying_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.option_details
    ADD CONSTRAINT option_details_underlying_asset_id_fkey FOREIGN KEY (underlying_asset_id) REFERENCES finapp.assets(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: performance_metrics performance_metrics_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.performance_metrics
    ADD CONSTRAINT performance_metrics_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: portfolio_snapshots portfolio_snapshots_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_snapshots
    ADD CONSTRAINT portfolio_snapshots_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: portfolio_tags portfolio_tags_created_by_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_created_by_fkey FOREIGN KEY (created_by) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: portfolio_tags portfolio_tags_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: portfolio_tags portfolio_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolio_tags
    ADD CONSTRAINT portfolio_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES finapp.tags(id) ON DELETE CASCADE;


--
-- Name: portfolios portfolios_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.portfolios
    ADD CONSTRAINT portfolios_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: position_snapshots position_snapshots_portfolio_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.position_snapshots
    ADD CONSTRAINT position_snapshots_portfolio_snapshot_id_fkey FOREIGN KEY (portfolio_snapshot_id) REFERENCES finapp.portfolio_snapshots(id) ON DELETE CASCADE;


--
-- Name: position_snapshots position_snapshots_position_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.position_snapshots
    ADD CONSTRAINT position_snapshots_position_id_fkey FOREIGN KEY (position_id) REFERENCES finapp.positions(id) ON DELETE CASCADE;


--
-- Name: positions positions_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id);


--
-- Name: positions positions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: positions positions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.positions
    ADD CONSTRAINT positions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES finapp.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: price_sync_errors price_sync_errors_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_errors
    ADD CONSTRAINT price_sync_errors_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE SET NULL;


--
-- Name: price_sync_errors price_sync_errors_log_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_errors
    ADD CONSTRAINT price_sync_errors_log_id_fkey FOREIGN KEY (log_id) REFERENCES finapp.price_sync_logs(id) ON DELETE CASCADE;


--
-- Name: price_sync_logs price_sync_logs_data_source_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_logs
    ADD CONSTRAINT price_sync_logs_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES finapp.price_data_sources(id) ON DELETE SET NULL;


--
-- Name: price_sync_logs price_sync_logs_task_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_logs
    ADD CONSTRAINT price_sync_logs_task_id_fkey FOREIGN KEY (task_id) REFERENCES finapp.price_sync_tasks(id) ON DELETE CASCADE;


--
-- Name: price_sync_tasks price_sync_tasks_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES finapp.asset_types(id);


--
-- Name: price_sync_tasks price_sync_tasks_country_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_country_id_fkey FOREIGN KEY (country_id) REFERENCES finapp.countries(id);


--
-- Name: price_sync_tasks price_sync_tasks_data_source_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.price_sync_tasks
    ADD CONSTRAINT price_sync_tasks_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES finapp.price_data_sources(id) ON DELETE CASCADE;


--
-- Name: report_executions report_executions_report_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.report_executions
    ADD CONSTRAINT report_executions_report_id_fkey FOREIGN KEY (report_id) REFERENCES finapp.reports(id) ON DELETE CASCADE;


--
-- Name: reports reports_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.reports
    ADD CONSTRAINT reports_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: reports reports_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.reports
    ADD CONSTRAINT reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES finapp.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES finapp.roles(id) ON DELETE CASCADE;


--
-- Name: stock_details stock_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_details
    ADD CONSTRAINT stock_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: stock_option_details stock_option_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_option_details
    ADD CONSTRAINT stock_option_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: stock_option_details stock_option_details_underlying_stock_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.stock_option_details
    ADD CONSTRAINT stock_option_details_underlying_stock_id_fkey FOREIGN KEY (underlying_stock_id) REFERENCES finapp.assets(id);


--
-- Name: tag_categories tag_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories
    ADD CONSTRAINT tag_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES finapp.tag_categories(id) ON DELETE SET NULL;


--
-- Name: tag_categories tag_categories_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tag_categories
    ADD CONSTRAINT tag_categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: tags tags_category_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags
    ADD CONSTRAINT tags_category_id_fkey FOREIGN KEY (category_id) REFERENCES finapp.tag_categories(id) ON DELETE SET NULL;


--
-- Name: tags tags_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.tags
    ADD CONSTRAINT tags_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: trading_accounts trading_accounts_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.trading_accounts
    ADD CONSTRAINT trading_accounts_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: transaction_tag_mappings transaction_tag_mappings_tag_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transaction_tag_mappings
    ADD CONSTRAINT transaction_tag_mappings_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES finapp.tags(id) ON DELETE CASCADE;


--
-- Name: transaction_tag_mappings transaction_tag_mappings_transaction_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transaction_tag_mappings
    ADD CONSTRAINT transaction_tag_mappings_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES finapp.transactions(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id);


--
-- Name: transactions transactions_liquidity_tag_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_liquidity_tag_id_fkey FOREIGN KEY (liquidity_tag_id) REFERENCES finapp.liquidity_tags(id);


--
-- Name: transactions transactions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES finapp.portfolios(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES finapp.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: treasury_details treasury_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.treasury_details
    ADD CONSTRAINT treasury_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES finapp.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES finapp.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES finapp.users(id) ON DELETE CASCADE;


--
-- Name: wealth_product_details wealth_product_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: finapp; Owner: finapp_user
--

ALTER TABLE ONLY finapp.wealth_product_details
    ADD CONSTRAINT wealth_product_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES finapp.assets(id) ON DELETE CASCADE;


--
-- Name: asset_prices asset_prices_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: assets assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.asset_types(id);


--
-- Name: assets assets_market_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_market_id_fkey FOREIGN KEY (market_id) REFERENCES public.markets(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: benchmark_prices benchmark_prices_benchmark_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.benchmark_prices
    ADD CONSTRAINT benchmark_prices_benchmark_id_fkey FOREIGN KEY (benchmark_id) REFERENCES public.benchmarks(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.option_details
    ADD CONSTRAINT option_details_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: option_details option_details_underlying_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.option_details
    ADD CONSTRAINT option_details_underlying_asset_id_fkey FOREIGN KEY (underlying_asset_id) REFERENCES public.assets(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: portfolios portfolios_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: positions positions_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: positions positions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: positions positions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES public.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: report_executions report_executions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: reports reports_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: reports reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: trading_accounts trading_accounts_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.trading_accounts
    ADD CONSTRAINT trading_accounts_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: transactions transactions_liquidity_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_liquidity_tag_id_fkey FOREIGN KEY (liquidity_tag_id) REFERENCES public.liquidity_tags(id);


--
-- Name: transactions transactions_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolios(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_trading_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_trading_account_id_fkey FOREIGN KEY (trading_account_id) REFERENCES public.trading_accounts(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: caojun
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: caojun
--

GRANT USAGE ON SCHEMA public TO finapp_user;


--
-- Name: TABLE asset_prices; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.asset_prices TO finapp_user;


--
-- Name: TABLE asset_types; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.asset_types TO finapp_user;


--
-- Name: TABLE assets; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.assets TO finapp_user;


--
-- Name: TABLE audit_logs; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.audit_logs TO finapp_user;


--
-- Name: TABLE benchmark_prices; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.benchmark_prices TO finapp_user;


--
-- Name: TABLE benchmarks; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.benchmarks TO finapp_user;


--
-- Name: TABLE email_verification_tokens; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.email_verification_tokens TO finapp_user;


--
-- Name: TABLE exchange_rates; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.exchange_rates TO finapp_user;


--
-- Name: TABLE liquidity_tags; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.liquidity_tags TO finapp_user;


--
-- Name: TABLE markets; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.markets TO finapp_user;


--
-- Name: TABLE option_details; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.option_details TO finapp_user;


--
-- Name: TABLE password_reset_tokens; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.password_reset_tokens TO finapp_user;


--
-- Name: TABLE permissions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.permissions TO finapp_user;


--
-- Name: TABLE portfolios; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.portfolios TO finapp_user;


--
-- Name: TABLE positions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.positions TO finapp_user;


--
-- Name: TABLE report_executions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.report_executions TO finapp_user;


--
-- Name: TABLE reports; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.reports TO finapp_user;


--
-- Name: TABLE role_permissions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.role_permissions TO finapp_user;


--
-- Name: TABLE roles; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.roles TO finapp_user;


--
-- Name: TABLE trading_accounts; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.trading_accounts TO finapp_user;


--
-- Name: TABLE transactions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.transactions TO finapp_user;


--
-- Name: TABLE user_roles; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.user_roles TO finapp_user;


--
-- Name: TABLE user_sessions; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.user_sessions TO finapp_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: caojun
--

GRANT SELECT ON TABLE public.users TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: finapp; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA finapp GRANT SELECT,USAGE ON SEQUENCES  TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: finapp; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA finapp GRANT SELECT ON TABLES  TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES  TO finapp_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: caojun
--

ALTER DEFAULT PRIVILEGES FOR ROLE caojun IN SCHEMA public GRANT SELECT ON TABLES  TO finapp_user;


--
-- PostgreSQL database dump complete
--

\unrestrict mhwxBnJLNwqT3LeJiZkCRa2lxcrTnZxFN48iQsb26CJTKWJxQETVWd2STPGpBh7

