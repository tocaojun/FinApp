# 数据源整理包完整清单

## 📦 包内容总结

已为你整理了四个主要财经数据源的完整 JSON 配置文件和文档。

### 核心配置文件

位置：`/docs/data-source-configs/`

| 文件 | 描述 | 大小 |
|------|------|------|
| `yahoo-finance.json` | Yahoo Finance 完整配置 | 866 B |
| `eastmoney.json` | 东方财富完整配置 | 966 B |
| `sina.json` | 新浪财经完整配置 | 990 B |
| `fred.json` | FRED 完整配置 | 1.3 KB |
| `init-data-sources.sql` | 数据库初始化脚本 | 7.2 KB |
| `README.md` | 目录说明文档 | 3.5 KB |

### 相关文档

位置：`/docs/`

| 文件 | 描述 | 大小 |
|------|------|------|
| `DATA_SOURCE_CONFIGS.md` | 完整配置指南（含详细说明） | 7.7 KB |
| `DATA_SOURCE_QUICK_REFERENCE.md` | 快速参考指南 | 4.9 KB |
| `DATA_SOURCE_PACKAGE_MANIFEST.md` | 本文件 | - |

---

## 🚀 快速开始

### 第一步：选择数据源

根据你的需求选择合适的数据源：

| 场景 | 推荐数据源 | 说明 |
|------|----------|------|
| 美股交易 | Yahoo Finance | 实时数据，无需 API Key |
| A股交易 | 东方财富 | 最实时的 A 股数据 |
| 国内期货 | 新浪财经 | 支持期货和外汇 |
| 经济分析 | FRED | 美国经济数据库 |
| 组合应用 | 全部 | 多源数据融合 |

### 第二步：配置数据源

**方式 A：UI 手动配置（推荐）**
```
1. 访问 http://localhost:3001/admin/data-sync
2. 点击"数据源"页签
3. 点击"新增数据源"
4. 打开对应 JSON 文件，复制内容粘贴
5. 点击"确定"保存
```

**方式 B：数据库脚本（推荐批量）**
```bash
# 备份数据库（重要！）
pg_dump -h localhost -U finapp_user -d finapp_test > backup_$(date +%s).sql

# 执行初始化脚本
psql -h localhost -U finapp_user -d finapp_test -f docs/data-source-configs/init-data-sources.sql
```

### 第三步：创建同步任务

1. 进入 **数据同步** → **同步任务** 页签
2. 点击 **新建任务** 按钮
3. 填写任务信息：
   - 任务名称
   - 选择数据源
   - 选择产品类型和国家
   - 设置调度方式
4. 点击 **确定** 创建任务
5. 点击 **立即运行** 测试

### 第四步：监控结果

- 查看 **同步日志** 页签
- 确认同步成功
- 检查导入的数据

---

## 📋 配置文件说明

### Yahoo Finance

```json
{
  "name": "Yahoo Finance",
  "provider": "yahoo_finance",
  "api_endpoint": "https://query1.finance.yahoo.com/v8/finance/chart/",
  "config": {
    "supports_products": ["STOCK", "ETF", "FUND"],
    "supports_countries": ["US", "HK", "CN"],
    "requires_api_key": false
  }
}
```

**特点：**
- ✅ 无需 API Key
- ✅ 美股、港股、A股实时数据
- ✅ 提供 K 线和财务数据
- ❌ 单个请求处理

### 东方财富

```json
{
  "name": "东方财富",
  "provider": "eastmoney",
  "api_endpoint": "http://push2.eastmoney.com/api/qt/stock/kline/get",
  "config": {
    "supports_products": ["STOCK", "FUND"],
    "supports_countries": ["CN"],
    "symbol_prefix": {
      "stock_sh": "sh",
      "stock_sz": "sz"
    }
  }
}
```

**特点：**
- ✅ 无需 API Key
- ✅ A 股数据最实时
- ✅ 支持基金数据
- ⚠️ 股票代码需要前缀（sh/sz）

### 新浪财经

```json
{
  "name": "新浪财经",
  "provider": "sina",
  "api_endpoint": "http://hq.sinajs.cn/",
  "config": {
    "supports_products": ["STOCK", "FUND", "FUTURES", "FOREX"],
    "supports_countries": ["CN"],
    "supports_batch": true
  }
}
```

**特点：**
- ✅ 无需 API Key
- ✅ 支持批量查询
- ✅ 支持期货、外汇
- ❌ 仅提供当天数据（无历史）

### FRED

```json
{
  "name": "FRED",
  "provider": "fred",
  "api_endpoint": "https://api.stlouisfed.org/fred/",
  "config": {
    "supports_products": ["ECONOMIC_INDICATOR"],
    "supports_countries": ["US"],
    "requires_api_key": true,
    "api_key_env_var": "FRED_API_KEY"
  }
}
```

**特点：**
- ⚠️ 需要 API Key（免费注册）
- ✅ 美国经济数据
- ✅ 历史数据丰富
- ✅ 支持批量查询

---

## 🔐 API Key 配置

### FRED（需要）

1. **获取 API Key**
   - 访问 https://fredaccount.stlouisfed.org/login/secure/
   - 注册或登录账户
   - 在 Settings 中创建新的 API Key

2. **配置环境变量**
   ```bash
   # 编辑 backend/.env
   FRED_API_KEY=your_api_key_here
   
   # 重启后端
   cd backend && npm run dev
   ```

3. **验证**
   ```bash
   # 测试 API 连接
   curl "https://api.stlouisfed.org/fred/series/UNRATE?api_key=$FRED_API_KEY&file_type=json"
   ```

---

## 🛠️ 常见操作

### 修改已有数据源配置

1. 在 UI 中编辑 JSON 配置
2. 或通过 SQL 更新：
   ```sql
   UPDATE finapp.price_data_sources
   SET config = '{"新的配置"}'::jsonb
   WHERE name = 'Yahoo Finance';
   ```

### 删除数据源

```sql
DELETE FROM finapp.price_data_sources
WHERE name = 'Yahoo Finance';
```

### 查看所有数据源

```sql
SELECT id, name, provider, is_active
FROM finapp.price_data_sources
ORDER BY created_at DESC;
```

### 启用/禁用数据源

```sql
UPDATE finapp.price_data_sources
SET is_active = true
WHERE provider = 'yahoo_finance';
```

---

## ✅ 质量检查

所有文件已通过验证：

- ✓ JSON 格式校验：所有 JSON 文件已验证
- ✓ 字段完整性：所有必需字段已包含
- ✓ 文档完整性：配置指南、快速参考已完成
- ✓ 国家维度：所有配置已更新为国家维度

---

## �� 相关文档导航

```
/docs/
├── DATA_SOURCE_CONFIGS.md              ← 完整配置说明
├── DATA_SOURCE_QUICK_REFERENCE.md      ← 快速参考
├── DATA_SOURCE_PACKAGE_MANIFEST.md     ← 本文件
└── data-source-configs/
    ├── README.md                       ← 目录说明
    ├── yahoo-finance.json              ← Yahoo Finance
    ├── eastmoney.json                  ← 东方财富
    ├── sina.json                       ← 新浪财经
    ├── fred.json                       ← FRED
    └── init-data-sources.sql           ← 数据库脚本
```

---

## 🎯 后续步骤建议

### 立即执行
1. ✅ 根据需求选择 1-2 个数据源
2. ✅ 配置数据源
3. ✅ 创建测试同步任务

### 本周完成
1. ✅ 验证所有数据源运行正常
2. ✅ 配置定时同步任务
3. ✅ 制定数据更新策略

### 持续优化
1. ✅ 监控同步任务运行状态
2. ✅ 根据实际需求调整配置
3. ✅ 定期备份和维护

---

## 📞 问题排查

### JSON 格式错误
- 使用工具验证：`cat file.json | jq .`
- 在线验证：https://jsonlint.com/
- 检查所有引号必须是英文双引号

### 连接超时
- 检查 API 端点 URL 是否正确
- 检查网络连接
- 增加 timeout_seconds 值

### 请求限制
- 检查速率限制设置
- 减少并发请求数
- 等待几分钟后重试

### 数据不更新
- 检查同步任务是否启用
- 查看同步日志错误信息
- 验证 API Key（FRED）

---

## �� 统计信息

| 项目 | 数值 |
|------|------|
| 配置文件数量 | 4 个 |
| 包含产品类型 | 8 种 |
| 支持国家数量 | 4 个 |
| 文档文件数 | 3 个 |
| 总包大小 | ~30 KB |
| 已验证格式 | 100% ✓ |

---

## 版本信息

- **版本**：1.0
- **发布日期**：2025-11-08
- **架构**：国家维度（支持多产品类型）
- **兼容性**：与现有系统完全兼容

---

**享受数据源管理的便利！** 🎉

