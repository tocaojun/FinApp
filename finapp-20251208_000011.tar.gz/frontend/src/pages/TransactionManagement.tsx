import React, { useState, useEffect } from 'react';
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  DatePicker,
  InputNumber,
  Space,
  message,
  Popconfirm,
  Tag,
  Card,
  Row,
  Col,
  Statistic,
  Drawer,
  Typography,
  Tooltip
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  UploadOutlined,
  DownloadOutlined,
  FilterOutlined,
  BarChartOutlined,
  DollarOutlined,
  ClockCircleOutlined,
  WalletOutlined
} from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import dayjs from 'dayjs';
import { TransactionService, Transaction } from '../services/transactionService';
import { PortfolioService } from '../services/portfolioService';
import { Portfolio } from '../types/portfolio';
import { AssetService, Asset } from '../services/assetService';
import { TagService, Tag as TagType } from '../services/tagService';
import { TradingAccountService, TradingAccount } from '../services/tradingAccountService';
import CategoryTagSelector from '../components/common/CategoryTagSelector';
import { TransactionImportModal } from '../components/transaction/TransactionImportModal';
import BalanceWealthProductForm from '../components/BalanceWealthProductForm';
import QuantityWealthProductForm from '../components/QuantityWealthProductForm';
import { formatCurrency, formatPrice } from '../utils/currencyUtils';

const { Option } = Select;
const { RangePicker } = DatePicker;
const { Title, Text, Paragraph } = Typography;

interface TransactionFormData {
  portfolioId: string;
  tradingAccountId: string;
  assetId: string;
  transactionType: string;
  side: string;
  quantity: number;
  price: number;
  fee: number;
  executedAt: dayjs.Dayjs;  // 表单字段名称（对应后端的 transactionDate，用户选择的交易日期）
  notes?: string;
  tags: string[];
  // 备注：executedAt 在前端表单中用于收集"用户选择的交易日期"
  // 后端会将其存储到 transaction_date 列，同时将当前时刻自动更新到 executed_at 列
}

interface TransactionStats {
  totalTransactions: number;
  totalAmount: number;
  totalFees: number;
  pendingCount: number;
  buyCount: number;
  sellCount: number;
  profitLoss: number;
  avgTransactionSize: number;
}

const TransactionManagement: React.FC = () => {
  
  const getSideFromTransactionType = (transactionType: string): string => {
    const type = transactionType.toLowerCase();
    if (type.includes('buy') || type === 'fund_subscribe' || type === 'deposit') {
      return 'BUY';
    } else if (type.includes('sell') || type === 'fund_redeem' || type === 'withdrawal') {
      return 'SELL';
    }
    return 'BUY';
  };
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [portfolios, setPortfolios] = useState<Portfolio[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [tags, setTags] = useState<TagType[]>([]);
  const [tradingAccounts, setTradingAccounts] = useState<TradingAccount[]>([]);
  const [loading, setLoading] = useState(false);
  const [portfoliosLoading, setPortfoliosLoading] = useState(false);
  const [assetsLoading, setAssetsLoading] = useState(false);
  const [tagsLoading, setTagsLoading] = useState(false);
  const [tradingAccountsLoading, setTradingAccountsLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [importModalVisible, setImportModalVisible] = useState(false);
  const [filterDrawerVisible, setFilterDrawerVisible] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [form] = Form.useForm<TransactionFormData>();
  const [filterForm] = Form.useForm();
  const [searchText, setSearchText] = useState('');
  const [selectedType, setSelectedType] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [selectedPortfolio, setSelectedPortfolio] = useState<string>('');
  const [dateRange, setDateRange] = useState<[dayjs.Dayjs, dayjs.Dayjs] | null>(null);
  const [statistics, setStatistics] = useState<TransactionStats>({
    totalTransactions: 0,
    totalAmount: 0,
    totalFees: 0,
    pendingCount: 0,
    buyCount: 0,
    sellCount: 0,
    profitLoss: 0,
    avgTransactionSize: 0
  });

  // 获取交易数据
  const fetchTransactions = async () => {
    try {
      setLoading(true);
      
      // 直接获取投资组合数据（避免依赖状态）
      const portfolioData = await PortfolioService.getPortfolios();
      setPortfolios(portfolioData);
      
      // 创建投资组合ID到名称的映射
      const portfolioMap = new Map<string, string>();
      portfolioData.forEach(p => portfolioMap.set(p.id, p.name));
      
      // 获取交易数据
      const response = await TransactionService.getTransactions();
      // 后端返回 { transactions: [...], total: ..., page: ..., limit: ... }
      const transactionData = response.transactions || [];
      
      // 调试：打印原始数据以检查 transactionDate 是否存在
      console.log('fetchTransactions - API response:', response);
      console.log('fetchTransactions - raw transaction data:', transactionData);
      if (transactionData.length > 0) {
        console.log('fetchTransactions - first transaction:', transactionData[0]);
        console.log('fetchTransactions - first transaction.transactionDate:', transactionData[0].transactionDate);
      }
      
      const formattedTransactions: Transaction[] = transactionData.map((tx: any, index: number) => {
        // 优先使用后端返回的投资组合名称
        const portfolioName = tx.portfolio?.name || portfolioMap.get(tx.portfolioId) || '未知投资组合';
        
        // 调试：打印原始数据的所有字段
        if (index === 0) {
          console.log('fetchTransactions - raw transaction keys:', Object.keys(tx));
          console.log('fetchTransactions - raw transaction.transactionDate:', tx.transactionDate);
          console.log('fetchTransactions - raw transaction.executedAt:', tx.executedAt);
        }
        
        const formatted = {
          id: tx.id,
          portfolioId: tx.portfolioId || '',
          portfolioName,
          tradingAccountId: tx.tradingAccountId || '',
          assetId: tx.assetId,
          assetName: tx.asset?.name || tx.assetName || '未知资产',
          assetSymbol: tx.asset?.symbol || tx.assetSymbol || '',
          transactionType: tx.transactionType?.toUpperCase() || tx.type?.toUpperCase() || 'BUY',
          side: tx.side || 'LONG',
          quantity: Number(tx.quantity || 0),
          price: Number(tx.price || 0),
          totalAmount: Number(tx.totalAmount || tx.amount || 0),
          amount: Number(tx.totalAmount || tx.amount || 0),
          fee: Number(tx.fees || tx.fee || 0),
          currency: tx.currency || 'CNY',
          transactionDate: tx.transactionDate,  // 用户选择的交易日期（必需）
          executedAt: tx.executedAt,  // 系统执行/更新的时刻（只读，不由前端修改）
          status: tx.status || 'EXECUTED',
          notes: tx.notes || '',
          tags: tx.tags || [],
          createdAt: tx.createdAt,
          updatedAt: tx.updatedAt
        } as Transaction;
        
        if (index === 0) {
          console.log('fetchTransactions - formatted transaction.transactionDate:', formatted.transactionDate);
        }
        
        return formatted;
      });
      
      setTransactions(formattedTransactions);
      await calculateStatistics(formattedTransactions);
    } catch (error) {
      console.error('获取交易数据失败:', error);
      message.error('获取交易数据失败');
    } finally {
      setLoading(false);
    }
  };

  // 获取投资组合数据
  const fetchPortfolios = async () => {
    try {
      setPortfoliosLoading(true);
      const portfolioData = await PortfolioService.getPortfolios();
      setPortfolios(portfolioData);
    } catch (error) {
      console.error('获取投资组合数据失败:', error);
      message.error('获取投资组合数据失败');
    } finally {
      setPortfoliosLoading(false);
    }
  };

  // 获取资产/产品数据
  const fetchAssets = async () => {
    try {
      setAssetsLoading(true);
      const response = await AssetService.searchAssets({ limit: 1000 });
      setAssets(response.assets);
    } catch (error) {
      console.error('获取产品数据失败:', error);
      message.error('获取产品数据失败');
    } finally {
      setAssetsLoading(false);
    }
  };

  // 获取标签数据
  const fetchTags = async () => {
    try {
      setTagsLoading(true);
      const response = await TagService.getAllTags();
      // 确保 response 是数组
      if (Array.isArray(response)) {
        setTags(response);
      } else {
        console.warn('标签数据格式不正确:', response);
        setTags([]);
      }
    } catch (error) {
      console.error('获取标签数据失败:', error);
      message.error('获取标签数据失败');
      setTags([]); // 设置为空数组避免 map 错误
    } finally {
      setTagsLoading(false);
    }
  };

  // 获取交易账户数据
  const fetchTradingAccounts = async (portfolioId?: string) => {
    try {
      setTradingAccountsLoading(true);
      let accountData: TradingAccount[] = [];
      
      if (portfolioId) {
        // 获取指定投资组合的交易账户
        accountData = await TradingAccountService.getTradingAccounts(portfolioId);
      } else {
        // 获取所有交易账户
        accountData = await TradingAccountService.getAllTradingAccounts();
      }
      
      setTradingAccounts(accountData);
    } catch (error) {
      console.error('获取交易账户数据失败:', error);
      message.error('获取交易账户数据失败');
      setTradingAccounts([]);
    } finally {
      setTradingAccountsLoading(false);
    }
  };

  // 初始化数据
  useEffect(() => {
    fetchTransactions();
    fetchPortfolios();
    fetchAssets();
    fetchTags();
    fetchTradingAccounts(); // 获取所有交易账户
  }, []);

  // 当选中的投资组合改变时，重新计算统计信息
  useEffect(() => {
    if (transactions.length > 0) {
      console.log('[TransactionManagement] selectedPortfolio changed, recalculating statistics');
      calculateStatistics(transactions);
    }
  }, [selectedPortfolio]);

  // 计算统计数据（支持汇率转换为人民币）
  const calculateStatistics = async (data: Transaction[]) => {
    // 统计计数信息（这部分不依赖汇率转换）
    const totalTransactions = data.length;
    const pendingCount = data.filter(t => t.status === 'PENDING').length;
    const buyCount = data.filter(t => {
      const type = t.transactionType?.toUpperCase() || '';
      return type.includes('BUY') || type === 'DEPOSIT' || type === 'FUND_SUBSCRIBE';
    }).length;
    const sellCount = data.filter(t => {
      const type = t.transactionType?.toUpperCase() || '';
      return type.includes('SELL') || type === 'WITHDRAWAL' || type === 'FUND_REDEEM';
    }).length;
    
    // 尝试调用新的 API 获取支持汇率转换的统计信息
    try {
      console.log('[calculateStatistics] Data length:', data.length);
      console.log('[calculateStatistics] Calling getTransactionSummaryWithConversion with portfolioId:', selectedPortfolio);
      console.log('[calculateStatistics] selectedPortfolio || undefined =', selectedPortfolio || undefined);
      const summaryWithConversion = await TransactionService.getTransactionSummaryWithConversion(selectedPortfolio || undefined, 'CNY');
      
      console.log('[calculateStatistics] API response received:', summaryWithConversion);
      console.log('[calculateStatistics] summaryWithConversion.totalTransactions:', summaryWithConversion?.totalTransactions);
      
      // 检查 API 响应是否有效：totalTransactions > 0 表示确实有交易数据
      // 不再以 totalAmountInBaseCurrency > 0 作为判断条件，因为可能存在买卖相互抵消的情况
      if (summaryWithConversion && summaryWithConversion.totalTransactions > 0) {
        const stats: TransactionStats = {
          totalTransactions: summaryWithConversion.totalTransactions,
          // 使用转换后的人民币金额，而不是直接相加不同币种的金额
          totalAmount: summaryWithConversion.totalAmountInBaseCurrency,
          // 使用转换后的人民币手续费
          totalFees: summaryWithConversion.totalFeesInBaseCurrency,
          pendingCount,
          buyCount,
          sellCount,
          // 使用转换后的 net cash flow
          profitLoss: summaryWithConversion.netCashFlow,
          avgTransactionSize: summaryWithConversion.totalTransactions > 0 ? summaryWithConversion.totalAmountInBaseCurrency / summaryWithConversion.totalTransactions : 0
        };
        
        console.log('[calculateStatistics] Using API data with currency conversion');
        setStatistics(stats);
      } else {
        // API 返回的数据为空（没有交易），设置为零
        console.log('[calculateStatistics] No transaction data from API, showing zeros');
        const emptyStats: TransactionStats = {
          totalTransactions: 0,
          totalAmount: 0,
          totalFees: 0,
          pendingCount: 0,
          buyCount: 0,
          sellCount: 0,
          profitLoss: 0,
          avgTransactionSize: 0
        };
        setStatistics(emptyStats);
      }
    } catch (error) {
      console.error('获取汇率转换统计数据失败:', error);
      // 降级方案：使用本地数据计算（不支持汇率转换，但仍然以币种分组方式聚合）
      console.log('[calculateStatistics] Falling back to local data calculation by currency');
      
      // 按币种聚合，不直接相加
      const currencyTotals = new Map<string, { amount: number; fees: number }>();
      data.forEach(t => {
        const currency = t.currency || 'CNY';
        if (!currencyTotals.has(currency)) {
          currencyTotals.set(currency, { amount: 0, fees: 0 });
        }
        const current = currencyTotals.get(currency)!;
        current.amount += t.amount || t.totalAmount || 0;
        current.fees += t.fee || 0;
      });
      
      // 输出警告日志，显示各币种的统计数据
      console.warn('[calculateStatistics] Fallback statistics by currency:', Array.from(currencyTotals.entries()));
      
      // 由于没有汇率信息，只显示交易笔数和计数统计
      const fallbackStats: TransactionStats = {
        totalTransactions,
        // 无法准确汇总不同币种的金额，显示 0 并提示用户
        totalAmount: 0,
        totalFees: 0,
        pendingCount,
        buyCount,
        sellCount,
        profitLoss: 0,
        avgTransactionSize: 0
      };
      
      console.warn('[calculateStatistics] Cannot aggregate amounts in different currencies without exchange rates. Showing 0 for amounts.');
      setStatistics(fallbackStats);
    }
  };

  // 表格列定义
  const columns: ColumnsType<Transaction> = [
    {
      title: '交易日期',
      dataIndex: 'transactionDate',
      key: 'transactionDate',
      width: 150,
      render: (text) => {
        if (!text) return '-';
        // transactionDate 是纯日期格式，确保按 YYYY-MM-DD 显示
        const dateStr = typeof text === 'string' 
          ? text.substring(0, 10)  // 字符串取前10位
          : dayjs(text).format('YYYY-MM-DD');
        return dateStr;
      },
      sorter: (a, b) => {
        const dateA = a.transactionDate ? dayjs(a.transactionDate).unix() : 0;
        const dateB = b.transactionDate ? dayjs(b.transactionDate).unix() : 0;
        return dateA - dateB;
      },
    },
    {
      title: '投资组合',
      dataIndex: 'portfolioName',
      key: 'portfolioName',
      width: 120,
      filters: portfolios.map(portfolio => ({
        text: portfolio.name,
        value: portfolio.name,
      })),
      onFilter: (value, record) => record.portfolioName === value,
    },
    {
      title: '产品',
      key: 'asset',
      width: 150,
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 'bold' }}>{record.assetSymbol}</div>
          <div style={{ fontSize: '12px', color: '#666' }}>{record.assetName}</div>
        </div>
      ),
    },
    {
      title: '类型',
      dataIndex: 'transactionType',
      key: 'transactionType',
      width: 120,
      render: (type) => {
        const typeMap: Record<string, { color: string; text: string }> = {
          // 新的具体交易类型
          STOCK_BUY: { color: 'green', text: '股票买入' },
          STOCK_SELL: { color: 'red', text: '股票卖出' },
          ETF_BUY: { color: 'green', text: 'ETF买入' },
          ETF_SELL: { color: 'red', text: 'ETF卖出' },
          FUND_SUBSCRIBE: { color: 'green', text: '基金申购' },
          FUND_REDEEM: { color: 'red', text: '基金赎回' },
          BOND_BUY: { color: 'green', text: '债券买入' },
          BOND_SELL: { color: 'red', text: '债券卖出' },
          CRYPTO_BUY: { color: 'green', text: '加密买入' },
          CRYPTO_SELL: { color: 'red', text: '加密卖出' },
          // 通用交易类型
          BUY: { color: 'green', text: '买入' },
          SELL: { color: 'red', text: '卖出' },
          DEPOSIT: { color: 'blue', text: '存入' },
          WITHDRAWAL: { color: 'orange', text: '取出' },
          DIVIDEND: { color: 'purple', text: '分红' },
          INTEREST: { color: 'cyan', text: '利息' },
          FEE: { color: 'volcano', text: '手续费' },
          // 旧的小写格式（向后兼容）
          buy: { color: 'green', text: '买入' },
          sell: { color: 'red', text: '卖出' },
          deposit: { color: 'blue', text: '存入' },
          withdrawal: { color: 'orange', text: '取出' },
          dividend: { color: 'purple', text: '分红' },
        };
        const mapping = typeMap[type] || { color: 'default', text: type };
        const { color, text } = mapping;
        return <Tag color={color}>{text}</Tag>;
      },
      filters: [
        { text: '股票买入', value: 'STOCK_BUY' },
        { text: '股票卖出', value: 'STOCK_SELL' },
        { text: 'ETF买入', value: 'ETF_BUY' },
        { text: 'ETF卖出', value: 'ETF_SELL' },
        { text: '基金申购', value: 'FUND_SUBSCRIBE' },
        { text: '基金赎回', value: 'FUND_REDEEM' },
        { text: '存入', value: 'DEPOSIT' },
        { text: '取出', value: 'WITHDRAWAL' },
        { text: '分红', value: 'DIVIDEND' },
        { text: '利息', value: 'INTEREST' },
      ],
      onFilter: (value, record) => record.transactionType === value,
    },
    {
      title: '数量',
      dataIndex: 'quantity',
      key: 'quantity',
      width: 100,
      align: 'right',
      render: (value) => value.toLocaleString(),
    },
    {
      title: '单价 (每份净值)',
      key: 'price',
      width: 120,
      align: 'right',
      render: (_, record) => formatPrice(record.price, record.currency, 4),
    },
    {
      title: '金额 (数量×单价)',
      dataIndex: 'amount',
      key: 'amount',
      width: 140,
      align: 'right',
      render: (amount, record) => {
        // 只显示金额绝对值，不体现资金流向
        const displayAmount = Math.abs(amount);
        return formatCurrency(displayAmount, record.currency, 2);
      },
      sorter: (a, b) => Math.abs(a.amount) - Math.abs(b.amount),
    },
    {
      title: '手续费',
      dataIndex: 'fee',
      key: 'fee',
      width: 100,
      align: 'right',
      render: (value, record) => formatCurrency(Math.abs(value), record.currency, 2),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 80,
      render: (status) => {
        const statusMap = {
          PENDING: { color: 'processing', text: '待执行' },
          EXECUTED: { color: 'success', text: '已执行' },
          CANCELLED: { color: 'default', text: '已取消' },
          FAILED: { color: 'error', text: '失败' },
        };
        const { color, text } = statusMap[status as keyof typeof statusMap];
        return <Tag color={color}>{text}</Tag>;
      },
      filters: [
        { text: '待执行', value: 'PENDING' },
        { text: '已执行', value: 'EXECUTED' },
        { text: '已取消', value: 'CANCELLED' },
        { text: '失败', value: 'FAILED' },
      ],
      onFilter: (value, record) => record.status === value,
    },
    {
      title: '标签',
      dataIndex: 'tags',
      key: 'tags',
      width: 120,
      render: (tags) => (
        <div>
          {tags.slice(0, 2).map((tag: string) => (
            <Tag key={tag} style={{ marginBottom: 2 }}>
              {tag}
            </Tag>
          ))}
          {tags.length > 2 && <Tag>+{tags.length - 2}</Tag>}
        </div>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 120,
      fixed: 'right',
      render: (_, record) => (
        <Space size="small">
          <Button
            type="link"
            size="small"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这条交易记录吗？"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
          >
            <Button
              type="link"
              size="small"
              danger
              icon={<DeleteOutlined />}
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // 事件处理函数
  const handleAdd = () => {
    setEditingTransaction(null);
    setSelectedAsset(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEdit = async (transaction: Transaction) => {
    try {
      setEditingTransaction(transaction);
      
      // 找到对应的 asset 并设置
      const asset = assets.find(a => a.id === transaction.assetId);
      setSelectedAsset(asset || null);
      
      // 加载该投资组合的交易账户列表
      if (transaction.portfolioId) {
        await fetchTradingAccounts(transaction.portfolioId);
      }
      
      // 日期处理: 使用 transactionDate（用户选择的交易日期）
      let executedAtValue;
      const transactionDate = transaction.transactionDate;
      
      if (!transactionDate) {
        // 如果 transactionDate 为空，允许用户编辑。显示当前日期作为默认值
        console.warn(`Transaction ${transaction.id} is missing transactionDate. Allowing user to fill it in.`);
        executedAtValue = dayjs();  // 使用当前日期作为默认
      } else if (typeof transactionDate === 'string') {
        // 如果是字符串，取前10位作为日期部分，避免时区转换
        const dateStr = transactionDate.substring(0, 10);
        executedAtValue = dayjs(dateStr);
      } else {
        // 如果是 Date 对象
        executedAtValue = dayjs(transactionDate);
      }
      
      // 标签处理: 确保标签是字符串数组
      let tagsValue = transaction.tags || [];
      if (typeof tagsValue === 'string') {
        try {
          tagsValue = JSON.parse(tagsValue);
        } catch (e) {
          tagsValue = tagsValue.split(',').map(tag => tag.trim()).filter(tag => tag);
        }
      }
      if (!Array.isArray(tagsValue)) {
        tagsValue = [];
      }
      
      // 设置表单值，确保包含 tradingAccountId 和 tags
      const formValues = {
        portfolioId: transaction.portfolioId,
        tradingAccountId: transaction.tradingAccountId,
        assetId: transaction.assetId,
        transactionType: transaction.transactionType.toLowerCase(), // 转换为小写以匹配表单选项
        side: transaction.side,
        quantity: transaction.quantity,
        price: transaction.price,
        fee: transaction.fee,
        executedAt: executedAtValue,
        notes: transaction.notes || '',
        tags: tagsValue,
      };
      
      form.setFieldsValue(formValues);
      setModalVisible(true);
    } catch (error) {
      console.error('编辑交易失败:', error);
      message.error('加载交易信息失败，请重试');
    }
  };

  const handleDelete = async (id: string) => {
    setLoading(true);
    try {
      // 调用真正的API删除交易
      await TransactionService.deleteTransaction(id);
      
      // 删除成功后，从本地状态中移除该交易
      const newTransactions = transactions.filter(t => t.id !== id);
      setTransactions(newTransactions);
      await calculateStatistics(newTransactions);
      message.success('删除成功');
    } catch (error) {
      console.error('删除交易失败:', error);
      message.error('删除失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values: TransactionFormData) => {
    setLoading(true);
    
    try {
      // 获取选中资产的 currency
      const asset = selectedAsset || assets.find(a => a.id === values.assetId);
      
      if (!asset) {
        message.error('请先选择产品');
        setLoading(false);
        return;
      }
      
      // 准备交易数据，匹配后端API格式
      if (editingTransaction) {
        // 编辑模式：只发送用户修改的字段
        const updateData = {
          quantity: values.quantity,
          price: values.price,
          fees: values.fee || 0,
          notes: values.notes || '',
          tags: values.tags || [],
          transactionDate: values.executedAt.format('YYYY-MM-DD') // 用户选择的交易日期（纯日期，对应 transaction_date 列）
          // 备注：executedAt 不需要在编辑时发送，后端会自动更新为当前时刻
        };
        
        // 更新交易记录
        await TransactionService.updateTransaction(editingTransaction.id, updateData);
        message.success('交易记录更新成功');
      } else {
        // 创建模式：根据产品类型处理不同的数据格式
        if (asset.productMode === 'BALANCE') {
          // 余额型理财产品的特殊处理
          const createData = {
            portfolioId: values.portfolioId,
            tradingAccountId: values.tradingAccountId,
            assetId: values.assetId,
            transactionType: values.transactionType, // 'APPLY' 或 'REDEEM'
            side: values.transactionType === 'APPLY' ? 'BUY' : 'SELL',
            quantity: values.amount || values.quantity, // 余额型产品使用金额
            price: 1.0, // 余额型产品价格固定为1
            fees: values.fee || 0,
            currency: asset.currency,
            transactionDate: values.executedAt.format('YYYY-MM-DD'),
            executedAt: new Date().toISOString(),
            notes: values.notes || '',
            tags: values.tags || []
          };
          
          console.log('余额型产品交易数据:', createData);
          await TransactionService.createTransaction(createData);
          message.success('申购/赎回操作成功');
        } else {
          // 传统产品的处理
          const createData = {
            portfolioId: values.portfolioId,
            tradingAccountId: values.tradingAccountId,
            assetId: values.assetId,
            transactionType: values.transactionType,
            side: getSideFromTransactionType(values.transactionType),
            quantity: values.quantity,
            price: values.price,
            fees: values.fee || 0,
            currency: asset.currency,
            transactionDate: values.executedAt.format('YYYY-MM-DD'),
            executedAt: new Date().toISOString(),
            notes: values.notes || '',
            tags: values.tags || []
          };
          
          await TransactionService.createTransaction(createData);
          message.success('交易记录添加成功');
        }
      }

      // 重新获取交易数据以确保数据同步
      await fetchTransactions();
      setModalVisible(false);
      form.resetFields();
    } catch (error: any) {
      console.error('交易操作失败:', error);
      
      // 提取更详细的错误信息
      let errorMessage = '操作失败，请重试';
      if (error?.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error?.message) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      
      message.error(`操作失败：${errorMessage}`);
    } finally {
      setLoading(false);
    }
  };

  const handleImport = () => {
    setImportModalVisible(true);
  };

  const handleExport = () => {
    message.info('导出功能开发中...');
  };

  // 加载交易账户
  const handleLoadAccounts = async (portfolioId: string) => {
    try {
      setTradingAccountsLoading(true);
      const accounts = await TradingAccountService.getTradingAccounts(portfolioId);
      setTradingAccounts(accounts);
    } catch (error) {
      console.error('加载交易账户失败:', error);
      message.error('加载交易账户失败');
    } finally {
      setTradingAccountsLoading(false);
    }
  };

  // 搜索资产
  const handleSearchAssets = async (keyword: string) => {
    if (!keyword || keyword.length < 2) return;
    
    try {
      setAssetsLoading(true);
      const response = await AssetService.searchAssets({ 
        keyword, 
        limit: 20 
      });
      setAssets(response.assets);
    } catch (error) {
      console.error('搜索资产失败:', error);
    } finally {
      setAssetsLoading(false);
    }
  };

  // 导入成功回调
  const handleImportSuccess = () => {
    message.success('导入成功');
    fetchTransactions();
  };

  const handleFilter = (values: any) => {
    console.log('筛选条件:', values);
    setFilterDrawerVisible(false);
    message.success('筛选条件已应用');
  };

  const resetFilters = () => {
    filterForm.resetFields();
    setSearchText('');
    setSelectedType('');
    setSelectedStatus('');
    setSelectedPortfolio('');
    setDateRange(null);
    message.success('筛选条件已重置');
  };

  // 筛选后的数据
  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = !searchText || 
      (transaction.assetName || '').toLowerCase().includes(searchText.toLowerCase()) ||
      (transaction.assetSymbol || '').toLowerCase().includes(searchText.toLowerCase()) ||
      (transaction.portfolioName || '').toLowerCase().includes(searchText.toLowerCase());
    
    const matchesType = !selectedType || transaction.transactionType === selectedType;
    const matchesStatus = !selectedStatus || transaction.status === selectedStatus;
    const matchesPortfolio = !selectedPortfolio || transaction.portfolioId === selectedPortfolio;
    
    // 使用 transactionDate（用户选择的交易日期）而不是 executedAt（系统执行时刻）
    const matchesDateRange = !dateRange || (
      transaction.transactionDate && 
      dayjs(transaction.transactionDate).isAfter(dateRange[0]) &&
      dayjs(transaction.transactionDate).isBefore(dateRange[1])
    );

    return matchesSearch && matchesType && matchesStatus && matchesPortfolio && matchesDateRange;
  });

  return (
    <div style={{ padding: '24px' }}>
      {/* 页面标题 */}
      <div style={{ marginBottom: '24px' }}>
        <Title level={2}>
          <WalletOutlined style={{ marginRight: '8px' }} />
          交易管理
        </Title>
        <Paragraph type="secondary">
          管理所有投资组合的交易记录，支持多种交易类型和批量操作
        </Paragraph>
      </div>

      {/* 统计卡片 */}
      <Row gutter={16} style={{ marginBottom: '24px' }}>
        <Col xs={24} sm={12} md={6}>
          <Card size="small">
            <Statistic
              title="总交易数"
              value={statistics.totalTransactions}
              prefix={<BarChartOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card size="small">
            <Statistic
              title="交易总额"
              value={statistics.totalAmount}
              precision={2}
              prefix={<DollarOutlined />}
              suffix="¥"
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card size="small">
            <Statistic
              title="总手续费"
              value={statistics.totalFees}
              precision={2}
              prefix="¥"
              valueStyle={{ color: '#fa8c16' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card size="small">
            <Statistic
              title="待执行"
              value={statistics.pendingCount}
              prefix={<ClockCircleOutlined />}
              valueStyle={{ color: '#722ed1' }}
            />
          </Card>
        </Col>
      </Row>

      {/* 操作栏 */}
      <Card style={{ marginBottom: '16px' }}>
        <Row justify="space-between" align="middle">
          <Col>
            <Space>
              <Input.Search
                placeholder="搜索产品名称或代码"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                style={{ width: 250 }}
                allowClear
              />
              <Select
                placeholder="交易类型"
                value={selectedType}
                onChange={setSelectedType}
                style={{ width: 120 }}
                allowClear
              >
                <Option value="BUY">买入</Option>
                <Option value="SELL">卖出</Option>
                <Option value="DEPOSIT">存入</Option>
                <Option value="WITHDRAWAL">取出</Option>
                <Option value="DIVIDEND">分红</Option>
                <Option value="INTEREST">利息</Option>
              </Select>
              <Select
                placeholder="状态"
                value={selectedStatus}
                onChange={setSelectedStatus}
                style={{ width: 100 }}
                allowClear
              >
                <Option value="PENDING">待执行</Option>
                <Option value="EXECUTED">已执行</Option>
                <Option value="CANCELLED">已取消</Option>
                <Option value="FAILED">失败</Option>
              </Select>
              <RangePicker
                value={dateRange}
                onChange={(dates) => setDateRange(dates as [dayjs.Dayjs, dayjs.Dayjs] | null)}
                placeholder={['开始日期', '结束日期']}
              />
              <Button
                icon={<FilterOutlined />}
                onClick={() => setFilterDrawerVisible(true)}
              >
                高级筛选
              </Button>
              <Button onClick={resetFilters}>
                重置
              </Button>
            </Space>
          </Col>
          <Col>
            <Space>
              <Button
                type="primary"
                icon={<PlusOutlined />}
                onClick={handleAdd}
              >
                添加交易
              </Button>
              <Button
                icon={<UploadOutlined />}
                onClick={handleImport}
              >
                批量导入
              </Button>
              <Button
                icon={<DownloadOutlined />}
                onClick={handleExport}
              >
                导出
              </Button>
            </Space>
          </Col>
        </Row>
      </Card>

      {/* 交易记录表格 */}
      <Card>
        <Table
          columns={columns}
          dataSource={filteredTransactions}
          rowKey="id"
          loading={loading}
          pagination={{
            total: filteredTransactions.length,
            pageSize: 20,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) => `第 ${range[0]}-${range[1]} 条，共 ${total} 条`,
          }}
          scroll={{ x: 1200 }}
          size="small"
        />
      </Card>

      {/* 添加/编辑交易模态框 */}
      <Modal
        title={editingTransaction ? '编辑交易' : '添加交易'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={600}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
        >
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item
                label="投资组合"
                name="portfolioId"
                rules={[{ required: true, message: '请选择投资组合' }]}
              >
                <Select 
                  placeholder="选择投资组合" 
                  loading={portfoliosLoading}
                  onChange={(portfolioId) => {
                    // 当选择投资组合时，清空交易账户选择并重新加载
                    form.setFieldsValue({ tradingAccountId: undefined });
                    fetchTradingAccounts(portfolioId);
                  }}
                >
                  {portfolios.map(portfolio => (
                    <Option key={portfolio.id} value={portfolio.id}>
                      {portfolio.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label="交易账户"
                name="tradingAccountId"
                rules={[{ required: true, message: '请选择交易账户' }]}
              >
                <Select 
                  placeholder="选择交易账户" 
                  loading={tradingAccountsLoading}
                  disabled={!form.getFieldValue('portfolioId')}
                >
                  {tradingAccounts.map(account => (
                    <Option key={account.id} value={account.id}>
                      {account.name} ({account.accountType})
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label="产品"
                name="assetId"
                rules={[{ required: true, message: '请选择产品' }]}
              >
                <Select 
                  placeholder="选择产品" 
                  showSearch
                  loading={assetsLoading}
                  onChange={(assetId) => {
                    // 保存完整的 asset 对象
                    const asset = assets.find(a => a.id === assetId);
                    setSelectedAsset(asset || null);
                  }}
                  filterOption={(input, option) =>
                    option?.children?.toString().toLowerCase().includes(input.toLowerCase()) || false
                  }
                >
                  {assets.map(asset => (
                    <Option key={asset.id} value={asset.id}>
                      {asset.symbol} - {asset.name} ({asset.currency})
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>

          {/* 根据产品类型显示不同的表单 */}
          {selectedAsset && selectedAsset.productMode === 'BALANCE' ? (
            // 余额型理财产品表单
            <BalanceWealthProductForm
              asset={selectedAsset}
              portfolioId={form.getFieldValue('portfolioId')}
              tradingAccountId={form.getFieldValue('tradingAccountId')}
              onSubmit={() => {}} // 这里会通过表单的 onFinish 处理
              form={form}
            />
          ) : selectedAsset && selectedAsset.productMode === 'QUANTITY' ? (
            // 净值型理财产品表单
            <QuantityWealthProductForm
              asset={selectedAsset}
              portfolioId={form.getFieldValue('portfolioId')}
              tradingAccountId={form.getFieldValue('tradingAccountId')}
              onSubmit={() => {}} // 这里会通过表单的 onFinish 处理
              form={form}
            />
          ) : selectedAsset ? (
            // 传统产品表单（股票、基金等）
            <>
              <Row gutter={16}>
                <Col span={12}>
                  <Form.Item
                    label="交易类型"
                    name="transactionType"
                    rules={[{ required: true, message: '请选择交易类型' }]}
                  >
                    <Select placeholder="选择交易类型">
                      <Option value="STOCK_BUY">股票买入</Option>
                      <Option value="STOCK_SELL">股票卖出</Option>
                      <Option value="ETF_BUY">ETF买入</Option>
                      <Option value="ETF_SELL">ETF卖出</Option>
                      <Option value="FUND_SUBSCRIBE">基金申购</Option>
                      <Option value="FUND_REDEEM">基金赎回</Option>
                      <Option value="BOND_BUY">债券买入</Option>
                      <Option value="BOND_SELL">债券卖出</Option>
                      <Option value="DEPOSIT">存入</Option>
                      <Option value="WITHDRAWAL">取出</Option>
                      <Option value="DIVIDEND">分红</Option>
                      <Option value="INTEREST">利息</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    label="备注信息"
                    name="notes"
                  >
                    <Input
                      placeholder="交易备注（可选）"
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={16}>
                <Col span={8}>
                  <Form.Item
                    label="数量"
                    name="quantity"
                    rules={[{ required: true, message: '请输入数量' }]}
                  >
                    <InputNumber
                      placeholder="数量"
                      style={{ width: '100%' }}
                      min={0}
                    />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    label="单价"
                    name="price"
                    rules={[{ required: true, message: '请输入单价' }]}
                  >
                    <InputNumber
                      placeholder="单价"
                      style={{ width: '100%' }}
                      min={0}
                      precision={5}
                    />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    label="手续费"
                    name="fee"
                  >
                    <InputNumber
                      placeholder="手续费"
                      style={{ width: '100%' }}
                      min={0}
                      precision={2}
                    />
                  </Form.Item>
                </Col>
              </Row>
            </>
          ) : (
            // 未选择产品时的提示
            <div style={{ textAlign: 'center', padding: '40px', color: '#999' }}>
              请先选择产品以显示相应的表单字段
            </div>
          )}

          {/* 通用字段：交易日期和标签 */}
          {selectedAsset && (
            <>
              <Form.Item
                label="交易日期"
                name="executedAt"
                rules={[{ required: true, message: '请选择交易日期' }]}
              >
                <DatePicker
                  style={{ width: '100%' }}
                  placeholder="选择交易日期"
                  format="YYYY-MM-DD"
                />
              </Form.Item>

              <Form.Item
                label="标签"
                name="tags"
              >
                <CategoryTagSelector
                  tags={tags}
                  placeholder="选择标签（同分类单选，不同分类可多选）"
                  loading={tagsLoading}
                  style={{ width: '100%' }}
                />
              </Form.Item>

              <Form.Item>
                <Space>
                  <Button type="primary" htmlType="submit" loading={loading}>
                    {editingTransaction ? '更新' : '添加'}
                  </Button>
                  <Button onClick={() => setModalVisible(false)}>
                    取消
                  </Button>
                </Space>
              </Form.Item>
            </>
          )}
        </Form>
      </Modal>

      {/* 高级筛选抽屉 */}
      <Drawer
        title="高级筛选"
        placement="right"
        onClose={() => setFilterDrawerVisible(false)}
        open={filterDrawerVisible}
        width={400}
      >
        <Form
          form={filterForm}
          layout="vertical"
          onFinish={handleFilter}
        >
          <Form.Item label="投资组合" name="portfolioIds">
            <Select mode="multiple" placeholder="选择投资组合" loading={portfoliosLoading}>
              {portfolios.map(portfolio => (
                <Option key={portfolio.id} value={portfolio.id}>
                  {portfolio.name}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item label="交易类型" name="transactionTypes">
            <Select mode="multiple" placeholder="选择交易类型">
              <Option value="BUY">买入</Option>
              <Option value="SELL">卖出</Option>
              <Option value="DEPOSIT">存入</Option>
              <Option value="WITHDRAWAL">取出</Option>
              <Option value="DIVIDEND">分红</Option>
              <Option value="INTEREST">利息</Option>
            </Select>
          </Form.Item>

          <Form.Item label="金额范围" name="amountRange">
            <Input.Group compact>
              <InputNumber
                style={{ width: '45%' }}
                placeholder="最小金额"
                min={0}
              />
              <Input
                style={{ width: '10%', textAlign: 'center', pointerEvents: 'none' }}
                placeholder="~"
                disabled
              />
              <InputNumber
                style={{ width: '45%' }}
                placeholder="最大金额"
                min={0}
              />
            </Input.Group>
          </Form.Item>

          <Form.Item label="标签" name="tags">
            <CategoryTagSelector
              tags={tags}
              placeholder="选择标签进行筛选（可多选）"
              loading={tagsLoading}
              style={{ width: '100%' }}
            />
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                应用筛选
              </Button>
              <Button onClick={() => filterForm.resetFields()}>
                重置
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Drawer>

      {/* 批量导入弹窗 */}
      <TransactionImportModal
        visible={importModalVisible}
        onClose={() => setImportModalVisible(false)}
        onSuccess={handleImportSuccess}
        portfolios={portfolios}
        tradingAccounts={tradingAccounts}
        assets={assets}
        onLoadAccounts={handleLoadAccounts}
        onSearchAssets={handleSearchAssets}
      />
    </div>
  );
};

export default TransactionManagement;